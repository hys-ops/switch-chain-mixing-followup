# Leaf labels in the four-vertex switch chain

Submitted for public review by **hys-ops**. Start with the [English reading note](REVIEW_NOTE.md) and the [nine-page proof](notes/Leaf_Core_Switch_Chain_Public_Review_hys-ops.pdf). The review copies change attribution/metadata, not mathematics.

## Results and the objects they refer to

| Statement | Primary Lean declaration | Scope |
|---|---|---|
| Sharp order on the many-hub family | `LeafResult.many_hub_theta`; finite constants in `LeafResult.time_bounds` | Exactly h hubs of degree h⁴ and h⁵ labeled leaves, n=h+h⁵. Worst start, uniform stationary distribution on labeled realizations, TV one quarter. For h≥1024 the constants are 1/3072 and 2049. |
| Both directions of the time bound | `LeafResult.actual_upper`, `LeafLower.Star.polynomial_tv_lower` | The upper bound uses a direct proof of the thinned label shuffle bound. The lower bound uses a specified star-union start and a harmonic potential for its retained edges. |
| Exact finite comparison in Theorem 5 | `SharpClock.graph_finite`, `SharpClock.worst_finite` | All integer times and all starting graphs. Includes r=s and t=0. The right-hand side has the same six terms and constants as the draft. The reference continuous-time matrix has r states, indexed by overlap. |
| Fixed smaller hub degree | `HubMarks.fixed_edge_uniform`, `HubMarks.fixed_vertex_uniform`, `Avoid.fixed_worst`, `Avoid.fixed_no_cutoff` | The two initial strata correspond to presence or absence of the hub–hub edge. Each limit is uniform over the indicated stratum. The maximum has the edge-start curve. `Avoid.joined_eventually_farther` gives the strict comparison for every fixed positive scaled time. |
| Growing smaller hub degree | `UrnWindow.Degrees.dense_graph_uniform`, `CriticalResult.critical_graph_uniform`, `HubMarks.sparse_graph_uniform` | Uniform over all labeled starting graphs for each fixed window offset. The primary sources' quartet clock and rejection/holding probabilities are retained. The curves are computed within Lean. |
| Alternative critical center | `CriticalAlternative.critical_logK_graph_uniform` | Centering at log k gives means α+exp(−c), α. The half-log-N center gives α+√α exp(−c), α. |
| Literal maxima and inverse times | `TwoHubWorst.limit`, `GrowingInverse.original_time`, `GrowingInverse.original_quarter`, `GrowingInverse.window_width`, `GrowingInverse.cutoff_ratio` | All three growing regimes. Includes the actual finite maximum, the unique inverse for 0<ε<1, second-order time, positive Q/N window for two accuracies, and cutoff ratio. |

In many-hub `quarterTime`, the value is defined by cases to make the function total. `actual_upper` supplies an actual mixing-time witness at every h used in the finite and asymptotic comparisons. The full general h,r sufficient-condition theorem of the draft is outside this specialization. The proof covers all graph states for the displayed degree vector.

The general-purpose comparison interface `PhysicalReduction.tridiagonal_profiles` accepts a scalar urn profile as an explicit mathematical hypothesis. It is provided for comparison to the published proof. The three primary growing graph endpoints above have no such input. `ProfileAudit.lean` traverses local proof constants from the worst-start endpoints and checks connections to the actual published kernel, as well as independence from this conditional route. In the growth regime g.two, g.small and g.grows describe the degree sequence: 2≤r≤s, r→∞. At fixed r, s runs through k+2 with k→∞. A graph's entire connectedness does not define the two strata.

## Reproduction

On a machine with Python 3, Git, elan, Lean and the pinned mathlib cache, unpack the ZIP and enter the directory containing this README. A first dependency download uses the network. A previously populated compatible cache can be supplied via `--packages`.

```sh
lake exe cache get
python3 replay.py --lean "$(lake env which lean)" \
  --packages "$PWD/.lake/packages" --output /tmp/leaf-graph-replay --jobs 4
```

Use a fresh empty output directory. For a pre-existing pinned cache only the Python command is needed. The script verifies the exact revision of Lean, mathlib and every dependency in the supplied manifest. It overrides LEAN_PATH to include only a fresh project-object directory and the third-party libraries, recompiles the entire imported local proof closure and stops on build errors or unexpected axioms. No externally built graph objects are needed. Keep the distributed manifest in place when preparing dependencies. The archive contains source and build logs rather than platform-specific Lean objects.

## What to inspect

- `src/FinalEndpoints.lean` prints the final statement types and axiom reports. `checks/logs/FinalEndpoints.log` is its fresh build output.
- `checks/logs/ProfileAudit.log` and `checks/logs/ProofAudit.log` trace the use of the original kernel and TV definitions. `checks/receipt.json` lists every module, hash, linter warning count, and every printed axiom set. Compiler warnings are retained in the logs.
- `python3 check_small.py` independently enumerates every graph and every proposal for (r,s)=(2,2),(2,3),(3,3), using exact integers and fractions. Across 168 labeled states it checks proposal counts, hub-edge addition/removal, stationary masses and the projected rate of every red-set swap. Its saved output is `checks/exact-enumeration.txt`.
- `notes/prior-art-ko.md` gives the theorem-level prior art comparison and search limits. `notes/finite-comparison-ko.md` explains the two separate costs in the sharp finite comparison. `notes/dense-johnson.md` details the finite reductions in the Gaussian proof.
- `source-lock.json` identifies upstream sources. `SHA256SUMS` checks all bundled files (except itself).

## Source and verification credit

The upstream graph formalization comes from [openai/math at 4eaee87548250b2682affda7d05d947c05554bae](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/lean/OAI/Probability/SwitchChain). `UPSTREAM-LICENSE` contains its Apache 2.0 license. Twelve upstream modules are included byte-for-byte in `src/OAI`. A thirteenth upstream source, `UnorderedPairSums.lean`, is preserved in `original/`. Its derivative `PairOrientations.lean` changes only the broad import to the local prerequisite. The replay also expands the upstream umbrella Mathlib header into the listed focused imports in its temporary staging tree. All imported graph definitions and theorem bodies are preserved.

AI assisted the proof, formalization, writing and literature work. No personal authorship or independent human mathematical review is asserted. The upstream Apache 2.0 notice is preserved and is not a blanket license for the new material; no new license is assigned here. These files substantiate the named special-family results. The shorter proof of an urn input, the established published urn profiles, and the new graph-to-urn transfer are distinct mathematical claims.

## Recorded isolated rebuild

209 modules (including the generated focused header). 307 distinct declarations have recorded axiom reports, with 327 module/theorem reports counting repeated outputs. The source compile emitted 105 warning messages, retained in full. The final declarations listed in endpoints.json each use only propext, Classical.choice and Quot.sound. The exact rational cross-check enumerated 168 labeled starting graphs.
