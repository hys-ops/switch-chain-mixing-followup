"""Independent exact enumeration. Run with Python 3; no third-party modules."""
from collections import Counter
from fractions import Fraction
from itertools import combinations
from math import comb


def matchings(a, b, c, d):
    return [((a, b), (c, d)), ((a, c), (b, d)), ((a, d), (b, c))]


def states(r, s):
    degrees = [r, s] + [1] * (r + s)
    pairs = list(combinations(range(len(degrees)), 2))
    for edges in combinations(pairs, r + s):
        counts = [0] * len(degrees)
        for a, b in edges:
            counts[a] += 1
            counts[b] += 1
        if counts == degrees:
            yield frozenset(edges)


def check(r, s):
    n = r + s + 2
    q = 12 * comb(n, 4)
    graphs = set(states(r, s))
    options = []
    for vertices in combinations(range(n), 4):
        three = [frozenset(m) for m in matchings(*vertices)]
        options.extend((a, b) for a in three for b in three if a != b)
    assert 2 * len(options) == q
    core_edge = (0, 1)
    absent = Counter(g for g in graphs if core_edge not in g)
    assert Fraction(len(absent), len(graphs)) == Fraction(2, r*s + 2)
    for g in graphs:
        row = Counter({g: q//2})
        for before, after in options:
            candidate = (g - before) | after if before <= g and after.isdisjoint(g) else g
            row[candidate] += 1
        assert sum(row.values()) == q
        assert set(row) <= graphs
        assert all(multiplicity == 1 for h, multiplicity in row.items() if h != g)
        joined = core_edge in g
        vertical = sum(count for h, count in row.items() if (core_edge in h) != joined)
        assert vertical == (2 if joined else r*s)
        if joined:
            def red(h):
                return frozenset(b for a, b in h if a == 0 and b >= 2)
            start = red(g)
            other = Counter()
            for h, count in row.items():
                if core_edge in h and red(h) != start:
                    other[red(h)] += count
            expected = {start - {a} | {b} for a in start for b in range(2, n) if b not in start}
            assert set(other) == expected and set(other.values()) == {1}
    return f"r={r}, s={s}, n={n}, Q={q}, states={len(graphs)}, hub-nonedge mass={Fraction(len(absent),len(graphs))}, all rows PASS"


if __name__ == "__main__":
    for degrees in [(2, 2), (2, 3), (3, 3)]:
        print(check(*degrees))
