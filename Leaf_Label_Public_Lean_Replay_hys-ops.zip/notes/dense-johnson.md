# Two finite reductions for the dense Bernoulli–Laplace profile

Consider the labeled Johnson slice of all k-subsets of N positions. A move exchanging an occupied and an unoccupied position has probability 1/Q in the original graph clock. Assume 2k≤N and Q≥N² with Q>0.

## Ordered overlap and total variation

Fix the starting set A and let Z(S)=|S∩A|. At every step t the probability Pᵗ(A,S) is nondecreasing in Z(S), and agrees on each overlap level. In particular, for some integer m between 0 and k+1, exactly

$$
d_{\mathrm{TV}}(P^t(A,\cdot),\pi)=P^t_A[Z\ge m]-\pi[Z\ge m].
$$

All other overlap upper tails have discrepancy at most this quantity. The order proof couples each attempted transposition with its conjugate by an exchange that increases the overlap. Transposing the two exchanged positions is the only way a single subsequent proposal can reverse both occupancies. The holding probability under Q≥N² absorbs that negative contribution. Exchanges that preserve overlap give both inequalities. Removing one unmatched label at a time then orders arbitrary pairs of states by overlap.

The Lean statements are JohnsonProfile.sorted_hit, JohnsonProfile.ordered_row, and JohnsonProfile.tv_is_overlap_tail.

## Coupling to an equilibrium copy

At overlap z, upward and downward probabilities are b(z)=(k−z)²/Q and d(z)=z(N−2k+z)/Q. On the ordered pair u≥v, take common upward probability b(u), common downward probability d(v), high-only downward probability d(u)−d(v), and low-only upward probability b(v)−b(u). The rest holds. Both components have the original overlap kernel. Their difference D=u−v falls by one with probability

$$
 d(u)-d(v)+b(v)-b(u)=ND/Q
$$

and stays fixed otherwise, including at D=0. This holds through both boundaries. For every real test function g,

$$
E[g(D_{t+1})\mid u_t,v_t]=g(D_t)+(ND_t/Q)[g(D_t-1)-g(D_t)].
$$

Starting the high coordinate at k and the low one in the hypergeometric equilibrium gives an explicit mass-one joint law. Its high marginal is the point-start Johnson overlap, its low marginal is stationary. The functions D and D(D−1) have eigenvalues 1−N/Q and 1−2N/Q. These identities allow a stationary central limit theorem and concentration of the discrepancy to supply the dynamic normal approximation.

The Lean statements are OrderedUrn.P_stoch, OrderedUrn.coupon_step, OrderedUrn.diff_factorial_eigen, OrderedUrn.high_push, and OrderedUrn.low_push.

Eskenazis and Nestoridi describe a combinatorial monotone coupling of Bernoulli–Laplace chains in §2.1 of “Cutoff for the Bernoulli–Laplace urn model with o(n) swaps,” Ann. Inst. Henri Poincaré Probab. Stat. 56 (2020), 2621–2639. These reductions do not establish priority for the coupling principle or the known dense profile.
