# Dense stationary overlap and all-start quantifiers

For a fixed labeled subset \(K\) of size \(k\) in an \(N\)-element set, let \(X=|K\cap S|\) with \(S\) uniformly distributed over the \(k\)-subsets. The stationary variance used in every normal approximation is
\[
\mu=k^2/N,\qquad \sigma^2=\frac{k^2(N-k)^2}{N^2(N-1)}.
\]
The score is \(Z=(X-\mu)/\sigma\). In particular the factor \(1-k/N\) in its standard deviation applies even when \(r,s\) have comparable sizes.

## The finite Stein estimate

Stationarity of the actual binary walk gives integration by parts
\[
  \mathbb E[(X-\mu)f(X)]
  =\mathbb E\left[\frac{(k-X)^2}{N}\{f(X+1)-f(X)\}\right].
\]
To see it, apply stationarity of the birth–death overlap generator to the discrete antiderivative \(F(x)=\sum_{j=0}^{x-1}f(j+1)\). Using \(f=1\) gives the mean; \(f(x)=x-\mu\) gives the displayed variance. Define \(A=(k-X)^2/(N\sigma^2)\). The identity \(A=(\sqrt{N-1}-Z)^2/N\) implies
\[
\mathbb EA=1,\qquad \mathbb E|1-A|\le (2+2\sqrt{N-1})/N,
\]
since \(\mathbb EZ^2=1\) and \(\mathbb E|Z|\le1\). For \(\phi(t)=\mathbb Ee^{itZ}\), testing with the phase and using \(|e^u-1-u|\le|u|^2\) for \(|u|\le1\) gives, for \(|t|\le\sigma\),
\[
 |\phi'(t)+t\phi(t)|\le t^2/\sigma+|t|(2+2\sqrt{N-1})/N.
\]
Integrating the linear differential equation from zero proves the kernel-checked finite estimate
\[
 |\phi(t)-e^{-t^2/2}|\le |t|\{t^2/\sigma+|t|(2+2\sqrt{N-1})/N\}.
\]
If \(2k\le N\), then \(\sigma\ge k/(2\sqrt N)\). In the dense graph regime \(k/\sqrt N\to\infty\) and \(N\to\infty\), the bound tends to zero at every fixed frequency. The Lévy continuity theorem and continuity of the standard normal CDF are applied to the actual finite overlap pushforward. This last passage is included in the Lean result.

The compiled endpoint is `StationaryUrn.dense_cdf` in `DenseEquilibrium.lean`. It quantifies over every choice of initial \(K_i\) and every fixed real threshold. Its compiler receipt lists exactly `propext`, `Classical.choice`, and `Quot.sound`. The advertised frequency range and constants appear in `StationaryUrn.char_error`. This finite estimate does not assert a numerical Kolmogorov or total-variation error by itself.

## Original graph and quantifier audit

The state space is every labeled simple graph on \(n=r+s+2\) vertices whose two specified vertices have degrees \(r,s\) and all remaining \(N=r+s\) vertices have degree one. The hypotheses allow \(r=s\). `Avoid.separated_exists` constructs a graph from each such degree specification. `Avoid.connected_exists` constructs a realization in which the hubs are adjacent for the growing degree regime. Its name refers to adjacency of the hubs; the resulting overall graph also has an isolated edge. Uniform control over all starts has genuine content for both orbits.

The original kernel has an explicit holding contribution \(1/2\), with accepted and rejected proposals counted using \(Q=12\binom{n}{4}\). The discrete dense and critical windows use \(t=\lfloor (Q/N)(\tfrac12\log N+c)\rfloor_+\); the sparse window replaces \(\tfrac12\log N\) with \(\log(r-1)\). The theorem concerns fixed real \(c\). No uniform-in-unbounded-window estimate follows from its quantifiers. Distances of the actual graph are computed as half of the sum of absolute differences from the uniform law over all labeled realizations.

`Avoid.worstTV` takes the literal nonempty finite maximum of those point-start distances. The transfer `GrowingInverse.worst_profile` obtains both graph shapes from the degree hypotheses. It turns an all-start uniform estimate at a fixed window into convergence of the exact maximum. Conversely, a statement about one fixed initial orbit alone would not supply this all-start conclusion.

The combined executable declaration is `TwoHubWorst.limit` in `ThreeRegimeWorst.lean`. Its arguments are the degree sequence, the five-field graph specification at each index, a regime with its numerical limit, and a real window point. No normal, Poisson, urn, or mixing limit is an assumption. The sparse endpoint has profile \(1-\exp(-e^{-c})\). The critical endpoint assumes \(k/\sqrt N\to\sqrt\alpha\) with \(\alpha>0\) and has the total variation between Poisson laws with respective means \(\alpha+\sqrt\alpha\,e^{-c}\) and \(\alpha\). The dense endpoint assumes \(k/\sqrt N\to\infty\) and has profile \(2\Phi(e^{-c}/2)-1\). The centered second-order scale is \(Q/N\) in each case.
