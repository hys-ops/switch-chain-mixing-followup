#!/usr/bin/env python3
"""Build the pinned proof closure in an empty directory without other project objects."""
import argparse
import concurrent.futures as futures
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
LEAN_REV = "5045d0056413266e57c625dcd7c365b10e377c52"
BASE_MODULES = {"Mathlib", "Lean", "Std", "Init", "Batteries"}
BASE_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
IMPORT = re.compile(r"^import\s+([\w.]+)", re.M)
AXIOMS = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]")
NO_AXIOMS = re.compile(r"'([^']+)' does not depend on any axioms")
UNEXPECTED = re.compile(r"\b(?:sorryAx|sorry|admit|axiom|native_decide|implemented_by|extern)\b")

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def source_path(module):
    return Path(*module.split(".")).with_suffix(".lean")

def check_original(data, record):
    blob = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
    require(sha(data) == record["sha256"] and blob == record["git_blob"],
            "Upstream source hash mismatch for " + str(record))

def load_sources(lock):
    pair = lock["ordered_pairs"]
    original = (ROOT / "original" / pair["path"]).read_bytes()
    check_original(original, pair)
    adapter = (ROOT / "src/PairOrientations.lean").read_bytes()
    require(adapter == original.replace(b"import Mathlib\n", b"import LeafOrbits\n", 1),
            "Unexpected change to the two-orientation adapter")
    imports = (ROOT / "mathlib-imports.txt").read_text().splitlines()
    sources = {"GraphMathlibImports": "".join(f"import {line}\n" for line in imports if line)}
    for name, record in lock["modules"].items():
        data = (ROOT / "src" / source_path(name)).read_bytes()
        require(sha(data) == record["sha256"], "Source hash mismatch in " + name)
        if "original" in record:
            check_original(data, record["original"])
        content = data.decode()
        # This source release has no occurrences of these tokens, even in comments.
        require(not UNEXPECTED.search(content), "Prohibited declaration or tactic token in " + name)
        if "original" in record and "import Mathlib\n" in content:
            require(content.count("import Mathlib\n") == 1, "Ambiguous header in " + name)
            content = content.replace("import Mathlib\n", "import GraphMathlibImports\n", 1)
        sources[name] = content
    return sources

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("lean", "packages", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--jobs", type=int, default=3)
    args = parser.parse_args()
    lean, packages, output = (path.resolve() for path in (args.lean, args.packages, args.output))
    require(args.jobs > 0, "jobs must be positive")
    output.mkdir(parents=True, exist_ok=True)
    require(not any(output.iterdir()), "Output directory must be empty")
    stage, objects, logs = [output / s for s in ("stage", "objects", "logs")]
    for directory in (stage, objects, logs):
        directory.mkdir()
    version = subprocess.check_output([lean, "--version"], text=True).strip()
    require(LEAN_REV in version, "Wrong Lean version: " + version)
    lock = json.loads((ROOT / "source-lock.json").read_text())
    paths = [str(objects)]
    revisions = {}
    for package in json.loads((ROOT / "lake-manifest.json").read_text())["packages"]:
        directory = packages / package["name"]
        revision = subprocess.check_output(["git", "-C", directory, "rev-parse", "HEAD"], text=True).strip()
        require(revision == package["rev"], "Wrong dependency version: " + package["name"])
        lib = directory / ".lake/build/lib/lean"
        require(not (lib / "OAI").exists(), "Dependency cache contains graph objects")
        paths.append(str(lib))
        revisions[package["name"]] = revision
    env = {**os.environ, "LEAN_PATH": os.pathsep.join(paths)}
    sources = load_sources(lock)
    pending = {}
    for module, content in sources.items():
        path = stage / source_path(module)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        imports = set(IMPORT.findall(content))
        require(all(dep in sources or dep.split(".")[0] in BASE_MODULES for dep in imports),
                "Missing source import in " + module)
        pending[module] = imports & sources.keys()
    records = {}

    def compile_module(name):
        path = source_path(name)
        obj = (objects / path).with_suffix(".olean")
        obj.parent.mkdir(parents=True, exist_ok=True)
        logfile = logs / (name + ".log")
        with logfile.open("wb") as stream:
            proc = subprocess.run([lean, "-j1", "-DElab.async=false", "-DautoImplicit=false",
                                   "-o", obj, path], cwd=stage, env=env, stdout=stream,
                                  stderr=subprocess.STDOUT)
        message = logfile.read_text()
        require(proc.returncode == 0, f"Lean failed on {name}\n{message}")
        require("sorryAx" not in message and "declaration uses 'sorry'" not in message,
                "Incomplete proof in " + name)
        axioms = {}
        for theorem, names in AXIOMS.findall(message):
            used = {a.strip() for a in names.split(",") if a.strip()}
            require(used <= BASE_AXIOMS, f"Unexpected axioms of {theorem}: {used - BASE_AXIOMS}")
            axioms[theorem] = sorted(used)
        for theorem in NO_AXIOMS.findall(message):
            axioms[theorem] = []
        if re.search(r"^#print axioms\s", sources[name], re.M):
            require(axioms, "No axiom output in " + name)
        return dict(source_sha256=sha((stage / path).read_bytes()), olean_sha256=sha(obj.read_bytes()),
                    log_sha256=sha(logfile.read_bytes()), axiom_checked=sorted(axioms),
                    axiom_sets=axioms, warnings=message.count("warning:"))

    with futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        running = {}
        while pending or running:
            for name in sorted(list(pending)):
                if len(running) >= args.jobs:
                    break
                if pending[name] <= records.keys():
                    del pending[name]
                    print(name, flush=True)
                    running[pool.submit(compile_module, name)] = name
            require(running, "Cycle or missing module")
            ready, _ = futures.wait(running, return_when=futures.FIRST_COMPLETED)
            for handle in ready:
                records[running.pop(handle)] = handle.result()
    required = json.loads((ROOT / "endpoints.json").read_text())
    for module, theorems in required.items():
        for theorem in theorems:
            require(theorem in records[module]["axiom_sets"], "Missing final axiom check: " + theorem)
    receipt = dict(finished_utc=dt.datetime.now(dt.timezone.utc).isoformat(),
                   lean=version, dependency_revisions=revisions, standard_axioms_only=True,
                   targets=lock["targets"], modules=dict(sorted(records.items())))
    (output / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    count = sum(len(r["axiom_checked"]) for r in records.values())
    print(f"PASS {len(records)} modules, {count} module/theorem axiom reports", flush=True)

if __name__ == "__main__":
    main()
