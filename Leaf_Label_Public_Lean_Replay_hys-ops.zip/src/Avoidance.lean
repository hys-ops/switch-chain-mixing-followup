import MarkSurvival
open Finset
open scoped BigOperators Matrix 
namespace HubMarks
noncomputable section
attribute [local instance] Classical.propDecidable
open JohnsonLower
variable {N h : ℕ}

def avoid (K : Finset (Fin N)) (S : Slice N h) : ℝ := if Disjoint K S.val then 1 else 0

theorem inclusion_exclusion (K : Finset (Fin N)) (S : Slice N h) :
    avoid K S = ∑ B∈K.powerset, (-1:ℝ)^B.card * occupied B S := by
  classical
  have he : K.powerset.filter (fun B => B⊆S.val) = (K ∩ S.val).powerset := by
    ext B; simp [Finset.subset_inter_iff]
  have hs : (∑ B ∈ (K ∩ S.val).powerset, (-1:ℝ)^B.card) =
             if K ∩ S.val=∅ then 1 else 0 := by
    have hc := Finset.sum_powerset_neg_one_pow_card (x:=K ∩ S.val)
    split_ifs at hc ⊢ <;> exact_mod_cast hc
  rw [←he,sum_filter] at hs
  unfold avoid
  simp only [disjoint_iff_inter_eq_empty]
  rw [←hs]
  apply sum_congr rfl
  intro B _
  by_cases hb : B⊆S.val <;> simp [occupied,hb]

def avoidApprox (N h a : ℕ) (Q : ℝ) (t : ℕ) : ℝ :=
  ∑ j∈range (a+1), a.choose j • ((-1:ℝ)^j*(eigen N h j Q)^t)

/-- Uniform finite error for any deterministic special labels K all present at time 0.
No choice of coordinates for K or of remaining marks enters the bound. -/
theorem finite_avoidance {Q : ℝ} (hQ : 0<Q) (cap : (h:ℝ)*(N-h) ≤ Q)
    (K : Finset (Fin N)) (t : ℕ) (S : Slice N h) (hK : K⊆S.val) :
    |((walk N h Q)^t *ᵥ avoid K) S - avoidApprox N h K.card Q t|
       ≤ (2:ℝ)^K.card * ((t:ℝ)*h/Q) := by
  classical
  let P : Matrix (Slice N h) (Slice N h) ℝ := (walk N h Q)^t
  have he : (P *ᵥ avoid K) S = ∑ B∈K.powerset,(-1:ℝ)^B.card*(P *ᵥ occupied B) S := by
    change (∑ T,P S T * avoid K T) = _
    calc
      _ = ∑ T,∑ B∈K.powerset, (-1:ℝ)^B.card*(P S T * occupied B T) := by
        apply sum_congr rfl;intro T _
        rw [inclusion_exclusion,mul_sum];apply sum_congr rfl;intro B _;ring
      _ = _ := by rw [sum_comm];apply sum_congr rfl;intro B _;rw [←mul_sum];rfl
  change |(P *ᵥ avoid K) S - _| ≤ _
  rw [he,avoidApprox,←sum_powerset_apply_card (fun j => (-1:ℝ)^j*(eigen N h j Q)^t),←sum_sub_distrib]
  apply (abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ _B∈K.powerset, (t:ℝ)*h/Q := by
      apply sum_le_sum; intro B hB
      rw [←mul_sub,abs_mul,abs_pow,abs_neg,abs_one,one_pow,one_mul]
      have H := marked_survival hQ cap B t S ((mem_powerset.mp hB).trans hK)
      rw [abs_of_nonneg H.1]
      exact H.2
    _ = _ := by simp
#print axioms finite_avoidance
end
end HubMarks
