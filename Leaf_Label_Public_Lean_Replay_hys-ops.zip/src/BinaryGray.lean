import GraphGray

open Finset JohnsonLower HubMarks PaintMix HubTransfer
open scoped Matrix
noncomputable section
namespace BinaryGray
variable {N k : ℕ}

def code (S : Slice N k) (v : Fin N) : Option Bool := if v∈S.val then some true else some false

theorem code_injective : Function.Injective (code (N:=N) (k:=k)) := by
  intro S T he
  apply Subtype.ext;ext v
  have h := congrFun he v
  by_cases hS : v∈S.val <;> by_cases hT : v∈T.val <;> simp_all [code]

theorem code_swap (S : Slice N k) (a b : Fin N) :
    code (swapSet S a b)=move (code S) a b := by
  funext v
  simp [code,swapSet,move,Finset.mem_map_equiv,Equiv.symm_swap]

theorem outside_full (S : Slice N k) : outside (code S)=univ := by
  ext v; rw [show v∈outside (code S) ↔ code S v≠none from Finset.mem_filter.trans (and_iff_right (mem_univ _))];by_cases h : v∈S.val <;> simp [code,h]

theorem binary_lift (S : Slice N k) (Q : ℝ) (hq : 0<Q) (t : ℕ) (f : Paint (Fin N)→ℝ) :
    ((walk N k Q)^t *ᵥ(f ∘ code)) S=((J (Fin N) Q)^t *ᵥ f) (code S) := by
  induction t generalizing S with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',pow_succ',←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec,
      show ((walk N k Q)^t *ᵥ (f ∘ code))=(((J (Fin N) Q)^t *ᵥ f) ∘ code) from funext ih]
    rw [swap_row Q hq.ne',GraphGray.paint_derivative _ hq]
    simp [Function.comp_def,code_swap]

theorem binary_rows (S : Slice N k) (Q : ℝ) (hq : 0<Q) (t : ℕ) :
    push code (((walk N k Q)^t) S)=((J (Fin N) Q)^t) (code S) := by
  funext y
  have h := binary_lift S Q hq t (fun z => if z=y then (1:ℝ) else 0)
  simpa [push,Matrix.mulVec,dotProduct,mul_ite] using h

/-- The point starts may agree or be one transposition apart. -/
theorem binary_adjacent (S : Slice N k) (a b : Fin N) {Q : ℝ} (hQ : 0<Q)
    (hc : (N:ℝ)^2≤2*Q) (t : ℕ) :
    tv (((walk N k Q)^t) S) (((walk N k Q)^t) (swapSet S a b)) ≤
      (1-(((N-2:ℕ):ℝ))/Q)^t := by
  have hρ : 0≤1-(((N-2:ℕ):ℝ))/Q := by
    apply sub_nonneg.mpr ((div_le_one hQ).mpr _)
    by_cases hN : 2≤N
    · have hn : (2:ℝ)≤N := by exact_mod_cast hN
      have hcast : (((N-2:ℕ):ℝ))≤N := by exact_mod_cast Nat.sub_le N 2
      nlinarith [mul_nonneg (show 0≤(N:ℝ) by positivity) (sub_nonneg.mpr hn)]
    · rw [show N-2=0 by omega,Nat.cast_zero]; exact hQ.le
  rw [← GraphGray.injective_tv _ code_injective,binary_rows _ _ hQ,binary_rows _ _ hQ,code_swap]
  by_cases h : code S a=code S b
  · have he : move (code S) a b=code S := funext (Equiv.apply_swap_eq_self h)
    simpa [he,tv] using pow_nonneg hρ t
  · have hn (x : Fin N) : code S x≠none := by unfold code; split <;> simp
    apply color_adjacent (b:=N) _ hQ (by simpa using hc)
    exact ⟨a,b,hn a,hn b,h,by rw [outside_full,card_univ,Fintype.card_fin],rfl⟩

#print axioms binary_rows
#print axioms binary_adjacent
end BinaryGray
