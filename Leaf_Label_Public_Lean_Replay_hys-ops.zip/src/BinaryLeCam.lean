import LeCam
import GrowingWindow
open HubTransfer LeafClock Finset JohnsonLower HubMarks
open scoped Matrix Classical
noncomputable section
namespace SharpClock

theorem walk_thin {N k:ℕ} (Q:ℝ) (hQ:0<Q) (a:ℝ) (ha:0<a) :
    walk N k Q=thin (walk N k a) (a/Q) := by
  ext x y
  change kernel Q x y = (1-a/Q)*(1:Matrix (Slice N k) (Slice N k) ℝ) x y+(a/Q)*kernel a x y
  by_cases h:x=y
  · subst y;simp only [kernel,ite_true,Matrix.one_apply];field_simp;ring
  · simp only [kernel,h,Ne.symm h,ite_false,Matrix.one_apply];split_ifs <;>field_simp <;>ring

theorem binary_poisson {N k:ℕ} (hN:0<N) (Q:ℝ) (hQ:0<Q) (kpos : 0<(k:ℝ)*(N-k))
    (cap:(k:ℝ)*(N-k)≤Q) (t:ℕ) (S:Slice N k) :
    tv (((walk N k Q)^t) S) (continuous (walk N k Q) t S)≤
       (t:ℝ)*(((k:ℝ)*(N-k))/Q)^2 := by
  let a:ℝ:=(k:ℝ)*(N-k)
  let p:=a/Q
  let R:=walk N k a
  have ha:0<a:=kpos
  have hr:Stochastic R:=kernel_stoch ha le_rfl
  have herr:=many_ticks R hr (p:=p) (div_nonneg ha.le hQ.le) ((div_le_one hQ).mpr cap) t S
  rw [←walk_thin Q hQ a ha] at herr
  apply herr.trans_eq' ?_
  have he : continuous (walk N k Q) (t:ℝ)=continuous R ((t:ℝ)*p) := by
    rw [clock_identity hN Q t hQ,show R=walk N k a from rfl,clock_identity hN a _ ha]
    rw [show (t:ℝ)*p*(N:ℝ)^2/(2*a)=(t:ℝ)*(N:ℝ)^2/(2*Q) by dsimp [p];field_simp]
  rw [he]
#print axioms binary_poisson
end SharpClock
