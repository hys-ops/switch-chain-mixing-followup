import Mathlib.Topology.MetricSpace.Pseudo.Basic
import Mathlib.Topology.UniformSpace.LocallyUniformConvergence
import Mathlib.Topology.Instances.Real.Lemmas
import Mathlib.Tactic
open Filter Set Topology
namespace LimitCDF

/-- Pólya's uniform convergence theorem in the form needed for varying thresholds.
No continuity in x of the approximating (usually atomic) CDFs is required. -/
theorem uniform {F : ℕ → ℝ → ℝ} {G : ℝ → ℝ}
    (hm : ∀ i, Monotone (F i)) (hG : Monotone G) (hc : Continuous G)
    (hr : ∀ i x, F i x∈Icc 0 1) (hR : ∀ x,G x∈Icc 0 1)
    (h0 : Tendsto G atBot (𝓝 0)) (h1 : Tendsto G atTop (𝓝 1))
    (hp : ∀ x,Tendsto (fun i => F i x) atTop (𝓝 (G x)))
    {ε : ℝ} (hε : 0<ε) : ∀ᶠ i in atTop,∀ x, |F i x-G x|<ε := by
  have hl (L R:ℝ) : TendstoLocallyUniformlyOn F G atTop (Icc L R) := by
    apply Metric.tendstoLocallyUniformlyOn_iff.mpr
    intro e he x _
    obtain ⟨δ,hδ,hh⟩ := Metric.continuousAt_iff.mp (hc.continuousAt (x:=x)) (e/4) (by linarith)
    let a := x-δ/2
    let b := x+δ/2
    have hax : a<x := by dsimp [a];linarith
    have hxb : x<b := by dsimp [b];linarith
    have hx1 := hh (x:=a) (by rw [Real.dist_eq,abs_of_neg (sub_neg.mpr hax)];dsimp [a];linarith)
    have hx2 := hh (x:=b) (by rw [Real.dist_eq,abs_of_pos (sub_pos.mpr hxb)];dsimp [b];linarith)
    rw [Real.dist_eq,abs_lt] at hx1 hx2
    refine ⟨Ioo a b,mem_nhdsWithin_of_mem_nhds (Ioo_mem_nhds hax hxb),?_⟩
    filter_upwards [Metric.tendsto_nhds.mp (hp a) (e/4) (by linarith), Metric.tendsto_nhds.mp (hp b) (e/4) (by linarith)] with i ia ib
    intro y hy
    rw [Real.dist_eq,abs_lt] at ia ib ⊢
    have ha := hm i hy.1.le
    have hb := hm i hy.2.le
    constructor <;> linarith [hG hy.1.le,hG hy.2.le,hx1.1,hx1.2,hx2.1,hx2.2,ia.1,ia.2,ib.1,ib.2]
  obtain ⟨L,hL⟩ := ((tendsto_order.mp h0).2 (ε/4) (by linarith)).exists
  obtain ⟨R,hRight⟩ := ((tendsto_order.mp h1).1 (1-ε/4) (by linarith)).exists
  have compact := (tendstoLocallyUniformlyOn_iff_tendstoUniformlyOn_of_compact isCompact_Icc).mp (hl L R)
  have cent := Metric.tendstoUniformlyOn_iff.mp compact ε hε
  filter_upwards [cent,Metric.tendsto_nhds.mp (hp L) (ε/4) (by linarith),
    Metric.tendsto_nhds.mp (hp R) (ε/4) (by linarith)] with i hi hli hri
  intro x
  rw [Real.dist_eq,abs_lt] at hli hri
  rcases le_total x L with hx|hx
  · rw [abs_lt];constructor <;> linarith [(hr i x).1,(hR x).1,hm i hx,hG hx,hli.2]
  rcases le_total R x with hy|hy
  · rw [abs_lt];constructor <;> linarith [(hr i x).2,(hR x).2,hm i hy,hG hy,hri.1]
  simpa [Real.dist_eq,abs_sub_comm] using hi x ⟨hx,hy⟩

#print axioms uniform
end LimitCDF
