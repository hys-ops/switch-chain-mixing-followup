import PoissonClock
import SplitKernel
open Finset HubTransfer LeafSplit
open scoped Matrix
noncomputable section
namespace LeafClock
variable {X : Type*} [Fintype X] [DecidableEq X]

lemma one_diff (P : Matrix X X ℝ) (hp : Stochastic P) (x : X) :
    tv (P x) ((1:Matrix X X ℝ) x)=1-P x x := by
  unfold tv
  change (∑ y, |(P-1) x y|)/2=_
  rw [row_abs_sub_id P hp];ring

lemma along (P : Matrix X X ℝ) (hp : Stochastic P) {p : ℝ} (h : ∀ y, 1-P y y≤p)
    (x : X) (s m : ℕ) :
    tv ((P^(s+m)) x) ((P^s) x) ≤ (m:ℝ)*p := by
  induction m with
  | zero => simp [tv]
  | succ m ih =>
    have q := rows_mix (P^(s+m)) P (1:Matrix X X ℝ) (stochastic_pow hp _) (fun y => (one_diff P hp y).le.trans (h y)) x
    rw [mul_one,←pow_succ] at q
    have w := tv_triangle ((P^(s+m+1)) x) ((P^(s+m)) x) ((P^s) x)
    simp only [←Nat.add_assoc,Nat.cast_succ];linarith
lemma span (P : Matrix X X ℝ) (hp : Stochastic P) {p : ℝ} (h : ∀ y, 1-P y y≤p)
    (x : X) (s t : ℕ) :
    tv ((P^s) x) ((P^t) x) ≤ |(s:ℝ)-t| *p := by
  rcases le_total t s with q|q
  · obtain ⟨m,rfl⟩ := Nat.exists_eq_add_of_le q
    simpa using along P hp h x t m
  · obtain ⟨m,rfl⟩ := Nat.exists_eq_add_of_le q
    rw [show tv ((P^s) x) ((P^(s+m)) x)=tv ((P^(s+m)) x) ((P^s) x) by unfold tv; congr 1;apply sum_congr rfl;intro y _;apply abs_sub_comm]
    simpa using along P hp h x s m

def continuous (P : Matrix X X ℝ) (u : ℝ) : Matrix X X ℝ := fun x y =>
  ∑' k : ℕ, mass u k*(P^k) x y

lemma entry_summable (P : Matrix X X ℝ) (hp : Stochastic P) {u : ℝ} (hu : 0≤u) (x y : X) :
    Summable (fun k : ℕ => mass u k*(P^k) x y) := by
  apply Summable.of_nonneg_of_le (fun k => mul_nonneg (mass_ge hu k) ((stochastic_pow hp k).1 _ _)) _ (total hu).summable
  intro k
  have h := Finset.single_le_sum (fun j (_ : j∈(univ:Finset X)) => (stochastic_pow hp k).1 x j) (mem_univ y)
  rw [(stochastic_pow hp k).2 x] at h
  exact mul_le_of_le_one_right (mass_ge hu _) h

/-- A Poisson number of original proposals has mean t. A bound on the move probability
gives an error valid for each individual starting state on the unmodified chain. -/
theorem discrete_continuous (P : Matrix X X ℝ) (hp : Stochastic P) {p : ℝ} (hp0 : 0≤p)
    (h : ∀ y, 1-P y y≤p) (x : X) (t : ℕ) (ht : 0<t) :
    tv (continuous P t x) ((P^t) x) ≤ Real.sqrt t * p := by
  have ht' : 0<(t:ℝ) := by exact_mod_cast ht
  let f (k : ℕ) (y : X) := mass t k*((P^k) x y-(P^t) x y)
  have hs (y : X) : Summable (fun k => f k y) := by
    simpa only [f,mul_sub] using (entry_summable P hp ht'.le x y).sub ((total ht'.le).summable.mul_right ((P^t) x y))
  have he (y : X) : continuous P t x y-(P^t) x y = ∑' k, f k y := by
    simp only [f,mul_sub,continuous]
    rw [(entry_summable P hp ht'.le x y).tsum_sub ((total ht'.le).summable.mul_right _),tsum_mul_right,(total ht'.le).tsum_eq,one_mul]
  have hab (y : X) : |∑' k, f k y| ≤ ∑' k, |f k y| := by
    simpa only [Real.norm_eq_abs] using norm_tsum_le_tsum_norm (show Summable (fun k => ‖f k y‖) from (hs y).norm)
  have htvs (k : ℕ) : ∑ y, |f k y| = mass t k*(2*tv ((P^k) x) ((P^t) x)) := by
    simp [f,abs_mul,abs_of_nonneg (mass_ge ht'.le k),←mul_sum,tv];left;ring
  have hsabs (y : X) (_ : y∈(univ:Finset X)) := (hs y).abs
  have sumAll : Summable (fun k => ∑ y, |f k y|) := summable_sum hsabs
  have hd := clock_deviation ht'
  have hh : ∑' k, ∑ y, |f k y| ≤ ∑' k : ℕ, (mass t k*|(k:ℝ)-t|)*(2*p) := by
    apply sumAll.tsum_le_tsum _ (hd.1.mul_right _)
    intro k
    rw [htvs]
    calc _ ≤ mass t k * (2*(|(k:ℝ)-t| *p)) := by exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left (span P hp h x k t) (by norm_num)) (mass_ge ht'.le _)
         _ = _ := by ring
  unfold tv
  simp_rw [he]
  have hsum := Finset.sum_le_sum (fun y (_ : y∈(univ:Finset X)) => hab y)
  rw [←Summable.tsum_finsetSum hsabs] at hsum
  rw [tsum_mul_right] at hh
  have hend := mul_le_mul_of_nonneg_right hd.2 (show 0≤2*p by positivity)
  linarith
#print axioms discrete_continuous
end LeafClock
