import UrnClock
import UrnError
open Filter Topology UrnWindow UrnWindow.Degrees HubTransfer
open scoped Matrix Classical
noncomputable section
namespace LeafClock
def sliceSize (g : Degrees) (i : ℕ) := g.r i - 1

theorem window_bound (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    (S : JohnsonLower.Slice (g.population i) (sliceSize g i)) :
    let t := g.time z c i
    let W := HubMarks.walk (g.population i) (sliceSize g i) (g.Q i)
    tv (continuous W t S) ((W^t) S) ≤ 2*Real.sqrt (g.tau z c i) := by
  dsimp only
  let N := g.N i
  let Q := g.Q i
  let k := sliceSize g i
  let t := g.time z c i
  have hn : 4≤N := (g.sizes i).2.2.1
  have hq : 0<Q := g.clk_pos i
  have hk0 : k≤g.population i := by simpa [S.property] using S.val.card_le_univ
  have hk : (k:ℝ)≤N := by change (k:ℝ)≤(g.population i:ℝ);exact_mod_cast hk0
  have hb : (k:ℝ)*(N-k)≤N^2 := by nlinarith [sq_nonneg ((k:ℝ)-N/2),sq_nonneg N]
  have hq4 := g.clock_lower i
  change N^4/4 ≤ Q at hq4
  have hbd : N^2 ≤ Q := by
    have h : (4:ℝ)≤N^2 := by nlinarith [sq_nonneg (N-2)]
    nlinarith [mul_nonneg (sub_nonneg.mpr h) (sq_nonneg N)]
  have hprob := JohnsonLower.kernel_stoch hq (hb.trans hbd)
  change tv (continuous (HubMarks.walk (g.population i) k Q) t S) (((HubMarks.walk (g.population i) k Q)^t) S) ≤ 2*Real.sqrt (g.tau z c i)
  by_cases htime : t=0
  · rw [htime,Nat.cast_zero,pow_zero,continuous_exp,zero_smul,NormedSpace.exp_zero]
    simp [tv,Real.sqrt_nonneg]
  ·
    have ht : 0<t := by omega
    have h := discrete_continuous (HubMarks.walk (g.population i) k Q) hprob
      (div_nonneg (sq_nonneg N) hq.le) (by intro y;change 1-JohnsonLower.kernel Q y y≤N^2/Q; simp only [JohnsonLower.kernel,ite_true]; linarith [div_le_div_of_nonneg_right hb hq.le]) S t ht
    apply h.trans
    change Real.sqrt (t:ℝ)*(N^2/Q) ≤ 2*Real.sqrt ((t:ℝ)/Q)
    have h1 : N^2 ≤ 2*Real.sqrt Q := by
      apply (sq_le_sq₀ (sq_nonneg N) (show 0≤2*Real.sqrt Q by positivity)).mp
      nlinarith [Real.sq_sqrt hq.le]
    rw [Real.sqrt_div (by positivity : 0≤(t:ℝ))]
    have h2 : N^2/Q ≤ 2/Real.sqrt Q := by
      have hs := Real.sqrt_pos.mpr hq
      apply (div_le_div_iff₀ hq hs).2
      nlinarith [mul_le_mul_of_nonneg_right h1 hs.le, Real.sq_sqrt hq.le]
    exact (mul_le_mul_of_nonneg_left h2 (Real.sqrt_nonneg (t:ℝ))).trans_eq (by ring)
theorem window_error_zero (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (fun i => 2*Real.sqrt (g.tau z c i)) atTop (𝓝 0) := by
  simpa using (tendsto_const_nhds (x:=(2:ℝ))).mul (Real.continuous_sqrt.continuousAt.tendsto.comp (g.tau_zero z c))
#print axioms window_bound
#print axioms window_error_zero
end LeafClock
