import PoissonClock
import Mathlib.Analysis.Normed.Group.Tannery
open Filter Topology Finset
noncomputable section
namespace CountLimit
structure Law where
  p : ℕ → ℝ
  nonneg : ∀ j, 0≤p j
  total : HasSum p 1

def pgf (A : Law) (z : ℝ) := ∑' j, A.p j*z^j
def initialSum (A : Law) (z : ℝ) (m : ℕ) := ∑ j∈range m, A.p j*z^j
lemma gen_summable (A : Law) {z:ℝ} (hz : 0≤z) (hz1 : z≤1) :
    Summable (fun j => A.p j*z^j) :=
  Summable.of_nonneg_of_le (fun j => mul_nonneg (A.nonneg j) (pow_nonneg hz j))
    (fun j => mul_le_of_le_one_right (A.nonneg j) (pow_le_one₀ hz hz1)) A.total.summable
lemma remainder (A : Law) {z:ℝ} (hz : 0≤z) (hz1 : z≤1) (m : ℕ) :
    0≤pgf A z-initialSum A z m ∧ pgf A z-initialSum A z m ≤ z^m := by
  have hg := gen_summable A hz hz1
  have hh := hg.sum_add_tsum_nat_add m
  change initialSum A z m + _ = pgf A z at hh
  rw [show pgf A z-initialSum A z m=∑' j:ℕ,A.p (j+m)*z^(j+m) by linarith]
  constructor
  · exact tsum_nonneg (fun j => mul_nonneg (A.nonneg _) (pow_nonneg hz _))
  have hb := A.total.summable.sum_add_tsum_nat_add m
  rw [A.total.tsum_eq] at hb
  have h0 := sum_nonneg (s:=range m) (fun j _ => A.nonneg j)
  calc
    _ ≤ ∑' j:ℕ,A.p (j+m)*z^m := by
      apply ((summable_nat_add_iff m).mpr hg).tsum_le_tsum _
        (((summable_nat_add_iff m).mpr A.total.summable).mul_right _)
      intro j; rw [pow_add];exact mul_le_mul_of_nonneg_left (mul_le_of_le_one_left (pow_nonneg hz m) (pow_le_one₀ hz hz1)) (A.nonneg _)
    _ ≤ z^m := by rw [tsum_mul_right];exact mul_le_of_le_one_left (pow_nonneg hz m) (by linarith)
lemma normalized (A : Law) {z:ℝ} (hz : 0<z) (hz1 : z≤1) (m : ℕ) :
    A.p m ≤ (pgf A z-initialSum A z m)/z^m ∧
      (pgf A z-initialSum A z m)/z^m ≤ A.p m+z := by
  have h := remainder A hz.le hz1 (m+1)
  simp only [initialSum,sum_range_succ,pow_succ] at h
  unfold initialSum
  rw [le_div_iff₀ (pow_pos hz m),div_le_iff₀ (pow_pos hz m)]
  constructor <;> nlinarith [h.1,h.2]

theorem coefficients (P : ℕ → Law) (A : Law)
    (hg : ∀ z:ℝ,0<z → z<1 → Tendsto (fun i => pgf (P i) z) atTop (𝓝 (pgf A z))) :
    ∀ m, Tendsto (fun i => (P i).p m) atTop (𝓝 (A.p m)) := by
  intro m;induction m using Nat.strong_induction_on with
  | h m ih =>
    apply Metric.tendsto_nhds.mpr
    intro ε hε
    let z := min (ε/4) (1/2:ℝ)
    have hz : 0<z := lt_min (by linarith) (by norm_num)
    have hz1 : z<1 := lt_of_le_of_lt (min_le_right _ _) (by norm_num)
    have hze : z≤ε/4 := min_le_left _ _
    have hprefix : Tendsto (fun i => initialSum (P i) z m) atTop (𝓝 (initialSum A z m)) :=
      tendsto_finsetSum (range m) (fun j hj => (ih j (mem_range.mp hj)).mul_const _)
    have ht := ((hg z hz hz1).sub hprefix).div_const (z^m)
    filter_upwards [Metric.tendsto_nhds.mp ht (ε/2) (by linarith)] with i hi
    rw [Real.dist_eq] at hi ⊢
    have a := normalized A hz hz1.le m
    have b := normalized (P i) hz hz1.le m
    exact abs_lt.mpr ⟨by linarith [(abs_lt.mp hi).1,a.1,a.2,b.1,b.2],
      by linarith [(abs_lt.mp hi).2,a.1,a.2,b.1,b.2]⟩

def poisson (u : ℝ) (hu : 0≤u) : Law :=
  ⟨LeafClock.mass u, LeafClock.mass_ge hu, LeafClock.total hu⟩
lemma poisson_gen (u : ℝ) (hu : 0≤u) (z : ℝ) (hz : 0≤z) :
    pgf (poisson u hu) z = Real.exp ((z-1)*u) := by
  have h := (LeafClock.total (mul_nonneg hu hz)).mul_left (Real.exp (u*z-u))
  have q : Real.exp (u*z-u) * Real.exp (-(u*z)) = Real.exp (-u) := by rw [←Real.exp_add];congr 1;ring
  have he : HasSum (fun j => (poisson u hu).p j*z^j) (Real.exp (u*z-u)*1) := by
    apply h.congr_fun
    intro j; simp only [poisson,LeafClock.mass,mul_pow]
    rw [←q];ring
  rw [pgf,he.tsum_eq,mul_one];congr 1;ring
#print axioms coefficients
#print axioms poisson_gen
end CountLimit
