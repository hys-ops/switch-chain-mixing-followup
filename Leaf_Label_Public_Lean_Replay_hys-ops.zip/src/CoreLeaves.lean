import LeafAction

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}
abbrev Host (d : Fin n→ℕ) := {v : Fin n // d v≠1}
def CoreEq (G K : GraphState n d) : Prop :=
  ∀ u v,d u≠1 → d v≠1 → (G.1.Adj u v ↔ K.1.Adj u v)

theorem unique_mate (G : GraphState n d) (x : LeafLabel d) :
    ∃ z:Fin n,∀ v,G.1.Adj x.1 v ↔ v=z := by
  have hc : (Finset.univ.filter (G.1.Adj x.1)).card=1 :=
    (G.2 x.1).trans ((Finset.mem_filter.mp x.2).2)
  obtain ⟨z,hz⟩ := Finset.card_eq_one.mp hc
  refine ⟨z,fun v => ?_⟩
  have hh : v∈Finset.univ.filter (G.1.Adj x.1) ↔ v∈ ({z}:Finset (Fin n)) := by rw [hz]
  simpa using hh

def parentVertex (G : GraphState n d) (x : LeafLabel d) := (unique_mate G x).choose
theorem adj_parent (G : GraphState n d) (x : LeafLabel d) (v : Fin n) :
    G.1.Adj x.1 v ↔ v=parentVertex G x := (unique_mate G x).choose_spec v

abbrev Attached (G : GraphState n d) (h : Host d) := {x : LeafLabel d // parentVertex G x=h.1}
abbrev FreeLeaf (G : GraphState n d) := {x : LeafLabel d // d (parentVertex G x)=1}

def leafDecomp (G : GraphState n d) :
    LeafLabel d ≃ (Σ h : Host d, Attached G h) ⊕ FreeLeaf G where
  toFun x := if h : d (parentVertex G x)=1 then Sum.inr ⟨x,h⟩
    else Sum.inl ⟨⟨parentVertex G x,h⟩,x,rfl⟩
  invFun
    | Sum.inl x => x.2.1
    | Sum.inr x => x.1
  left_inv x := by by_cases h : d (parentVertex G x)=1 <;> simp [h]
  right_inv z := by
    rcases z with ⟨⟨h,hh⟩,x,hx⟩|⟨x,hx⟩
    · change parentVertex G x=h at hx; subst h; simp [hh]
    · simp [hx]

def parentLeaf (G : GraphState n d) (x : FreeLeaf G) : LeafLabel d :=
  ⟨parentVertex G x.1,by simp [leaves,x.2]⟩

theorem parent_back (G : GraphState n d) (x : FreeLeaf G) :
    parentVertex G (parentLeaf G x)=x.1.1 := by
  apply ((adj_parent G (parentLeaf G x) x.1.1).mp _).symm
  exact ((adj_parent G x.1 _).mpr rfl).symm

def mate (G : GraphState n d) (x : FreeLeaf G) : FreeLeaf G :=
  ⟨parentLeaf G x,by rw [parent_back]; exact (Finset.mem_filter.mp x.1.2).2⟩

theorem mate_twice (G : GraphState n d) (x : FreeLeaf G) : mate G (mate G x)=x := by
  apply Subtype.ext; apply Subtype.ext
  exact parent_back G x

theorem mate_ne (G : GraphState n d) (x : FreeLeaf G) : (mate G x).1.1 ≠ x.1.1 := by
  intro h
  have he := (adj_parent G x.1 _).mpr rfl
  exact he.ne h.symm

abbrev Low (G : GraphState n d) := {x : FreeLeaf G // x.1.1 < (mate G x).1.1}
def fromLow (G : GraphState n d) (z : Low G × Bool) : FreeLeaf G :=
  if z.2 then mate G z.1.1 else z.1.1

theorem fromLow_bij (G : GraphState n d) : Function.Bijective (fromLow G) := by
  constructor
  · rintro ⟨a,b⟩ ⟨e,b'⟩ h
    cases b <;> cases b' <;> simp only [fromLow,Bool.false_eq_true,reduceCtorEq,ite_false,ite_true] at h
    · exact Prod.ext (Subtype.ext h) rfl
    · have ha := a.2
      rw [h,mate_twice] at ha
      exact False.elim (lt_asymm ha e.2)
    · have he := e.2
      rw [← h,mate_twice] at he
      exact False.elim (lt_asymm he a.2)
    · exact Prod.ext (Subtype.ext (by simpa [mate_twice] using congrArg (mate G) h)) rfl
  · intro x
    by_cases h : x.1.1 < (mate G x).1.1
    · exact ⟨(⟨x,h⟩,false),rfl⟩
    · have h' : (mate G x).1.1<x.1.1 := lt_of_le_of_ne (le_of_not_gt h) (mate_ne G x)
      refine ⟨(⟨mate G x,by simpa [mate_twice] using h'⟩,true),mate_twice G x⟩

def matchingEquivalence (G : GraphState n d) : Low G × Bool ≃ FreeLeaf G :=
  Equiv.ofBijective _ (fromLow_bij G)

theorem match_toggle (G : GraphState n d) (a : Low G) (b : Bool) :
    mate G (matchingEquivalence G (a,b))=matchingEquivalence G (a,!b) := by
  cases b
  · rfl
  · exact mate_twice G _

def leafHosts (G : GraphState n d) (h : Host d) :=
  (leaves d).filter (G.1.Adj h.1)
def coreHosts (G : GraphState n d) (h : Host d) :=
  (Finset.univ.filter (fun i : Fin n => d i≠1)).filter (G.1.Adj h.1)

theorem host_count (G : GraphState n d) (h : Host d) :
    (leafHosts G h).card+(coreHosts G h).card=d h.1 := by
  rw [← G.2 h.1]
  let s := Finset.univ.filter (G.1.Adj h.1)
  have he : leafHosts G h = s.filter (fun i => d i=1) := by
    ext v; simp [s,leafHosts,leaves,and_comm]
  have he' : coreHosts G h=s.filter (fun i => d i≠1) := by
    ext v; simp [s,coreHosts,and_comm]
  rw [he,he',Finset.card_filter_add_card_filter_not]; rfl

def attachedEquiv (G : GraphState n d) (h : Host d) : Attached G h ≃ ↥(leafHosts G h) where
  toFun x := ⟨x.1.1,Finset.mem_filter.mpr ⟨x.1.2,((adj_parent G x.1 _).mpr x.2.symm).symm⟩⟩
  invFun y := ⟨⟨y.1,(Finset.mem_filter.mp y.2).1⟩,
    ((adj_parent G _ _).mp (Finset.mem_filter.mp y.2).2.symm).symm⟩
  left_inv _ := rfl
  right_inv _ := rfl

theorem attached_card {G K : GraphState n d} (hcore : CoreEq G K) (h : Host d) :
    Fintype.card (Attached G h)=Fintype.card (Attached K h) := by
  have hcore' : coreHosts G h=coreHosts K h := by
    ext v
    by_cases hv : d v=1
    · simp [coreHosts,hv]
    · simp [coreHosts,hv,hcore _ _ h.2 hv]
  rw [Fintype.card_congr (attachedEquiv G h),Fintype.card_congr (attachedEquiv K h),Fintype.card_coe,Fintype.card_coe]
  have h1 := host_count G h
  have h2 := host_count K h
  rw [hcore'] at h1; omega

#print axioms attached_card
#print axioms matchingEquivalence
end OAI.Problem315.LeafOrbit
