import CoreLeaves

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}
variable {G K : GraphState n d}

def starEquiv (hcore : CoreEq G K) (h : Host d) : Attached G h ≃ Attached K h :=
  Fintype.equivOfCardEq (attached_card hcore h)

theorem low_card (hcore : CoreEq G K) : Fintype.card (Low G)=Fintype.card (Low K) := by
  have h1 := Fintype.card_congr (leafDecomp G)
  have h2 := Fintype.card_congr (leafDecomp K)
  have he := Fintype.card_congr (Equiv.sigmaCongrRight (starEquiv hcore))
  have h3 := Fintype.card_congr (matchingEquivalence G)
  have h4 := Fintype.card_congr (matchingEquivalence K)
  simp only [Fintype.card_sum] at h1 h2
  simp only [Fintype.card_prod,Fintype.card_bool] at h3 h4
  omega

def lowTransport (hc : CoreEq G K) : Low G ≃ Low K := Fintype.equivOfCardEq (low_card hc)

def freeTransport (hc : CoreEq G K) : FreeLeaf G ≃ FreeLeaf K :=
  (matchingEquivalence G).symm.trans (((lowTransport hc).prodCongr (Equiv.refl Bool)).trans (matchingEquivalence K))

@[simp] theorem free_chart (hc : CoreEq G K) (a : Low G) (b : Bool) :
    freeTransport hc (matchingEquivalence G (a,b))=matchingEquivalence K (lowTransport hc a,b) := by
  simp [freeTransport]

theorem free_mate (hc : CoreEq G K) (x : FreeLeaf G) :
    freeTransport hc (mate G x)=mate K (freeTransport hc x) := by
  obtain ⟨⟨a,b⟩,rfl⟩ := (matchingEquivalence G).surjective x
  simp only [match_toggle,free_chart]

def leafTransport (hc : CoreEq G K) : LeafGroup d :=
  (leafDecomp G).trans (((Equiv.sigmaCongrRight (starEquiv hc)).sumCongr (freeTransport hc)).trans (leafDecomp K).symm)

theorem leaf_free (hc : CoreEq G K) (x : FreeLeaf G) :
    leafTransport hc x.1=(freeTransport hc x).1 := by
  simp [leafTransport,leafDecomp,x.2]

theorem leaf_star (hc : CoreEq G K) (h : Host d) (x : Attached G h) :
    leafTransport hc x.1=(starEquiv hc h x).1 := by
  rcases h with ⟨v,hv⟩
  rcases x with ⟨y,hy⟩
  change parentVertex G y = v at hy
  subst v
  simp [leafTransport,leafDecomp,hv]

theorem leaf_parent (hc : CoreEq G K) (x : LeafLabel d) :
    Equiv.Perm.ofSubtype (leafTransport hc) (parentVertex G x)=parentVertex K (leafTransport hc x) := by
  by_cases h : d (parentVertex G x)=1
  · let z : FreeLeaf G := ⟨x,h⟩
    have hm : parentVertex G x ∈ leaves d := by simpa [leaves] using h
    rw [Equiv.Perm.ofSubtype_apply_of_mem _ hm]
    change (leafTransport hc (mate G z).1).1=parentVertex K (leafTransport hc z.1)
    rw [leaf_free,leaf_free,free_mate]
    rfl
  · let a : Host d := ⟨parentVertex G x,h⟩
    let z : Attached G a := ⟨x,rfl⟩
    rw [Equiv.Perm.ofSubtype_apply_of_not_mem _ (by simpa [leaves] using h)]
    change a.1=parentVertex K (leafTransport hc z.1)
    rw [leaf_star hc a z]
    exact (starEquiv hc a z).2.symm

theorem core_to_orbit (hc : CoreEq G K) : orbitMap G=orbitMap K := by
  let σ := Equiv.Perm.ofSubtype (leafTransport hc)
  have hfix : FixesCore d σ := extension_fixes _
  have hatt (x : LeafLabel d) (y : Fin n) :
      K.1.Adj (σ x.1) (σ y) ↔ G.1.Adj x.1 y := by
    have hx : σ x.1=(leafTransport hc x).1 := Equiv.Perm.ofSubtype_apply_of_mem _ x.2
    rw [hx,adj_parent,adj_parent,← leaf_parent hc]
    exact σ.injective.eq_iff
  apply Eq.symm
  apply (exists_act K G).mpr
  refine ⟨leafTransport hc,?_⟩
  apply Subtype.ext
  ext x y
  change K.1.Adj (σ x) (σ y) ↔ G.1.Adj x y
  by_cases hx : x∈leaves d
  · exact hatt ⟨x,hx⟩ y
  by_cases hy : y∈leaves d
  · exact (K.1.adj_comm _ _).trans ((hatt ⟨y,hy⟩ x).trans (G.1.adj_comm _ _))
  have hx' : d x≠1 := by simpa [leaves] using hx
  have hy' : d y≠1 := by simpa [leaves] using hy
  rw [hfix x hx',hfix y hy']
  exact (hc x y hx' hy').symm

theorem core_iff_orbit (G K : GraphState n d) : CoreEq G K ↔ orbitMap G=orbitMap K := by
  constructor
  · exact core_to_orbit
  · intro h
    obtain ⟨σ,hf,rfl⟩ := (orbit_eq G K).mp h
    intro u v hu hv
    change G.1.Adj u v ↔ G.1.Adj (σ u) (σ v)
    rw [hf u hu,hf v hv]

#print axioms core_iff_orbit
end OAI.Problem315.LeafOrbit
