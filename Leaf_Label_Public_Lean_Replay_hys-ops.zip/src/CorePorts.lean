import Crossing
open OAI.Problem315 Finset
open scoped BigOperators
noncomputable section
namespace ManyCore
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n → ℕ} {H : Finset (Fin n)}
structure Spec (H : Finset (Fin n)) (r : ℕ) (d : Fin n → ℕ) : Prop where
  hub : ∀ x∈H,d x=r
  leaf : ∀ x∉H,d x=1
  count : Hᶜ.card=H.card*r

def leavesAt (H : Finset (Fin n)) (G : GraphState n d) (a : Fin n) :=
  Hᶜ.filter (G.1.Adj a)

theorem star_lower (sp : Spec H r d) (G : GraphState n d) {a : Fin n} (ha : a∈H) :
    r+1-H.card ≤ (leavesAt H G a).card := by
  have hsub : univ.filter (G.1.Adj a) ⊆ H.erase a ∪ leavesAt H G a := by
    intro v hv
    have e := (mem_filter.mp hv).2
    by_cases h : v∈H
    · exact mem_union_left _ (mem_erase.mpr ⟨e.ne.symm,h⟩)
    · exact mem_union_right _ (mem_filter.mpr ⟨mem_compl.mpr h,e⟩)
  have hc := (card_le_card hsub).trans (card_union_le _ _)
  change graphDegree G.1 a ≤ _ at hc
  rw [G.2,sp.hub a ha,card_erase_of_mem ha] at hc
  have hh := card_pos.mpr ⟨a,ha⟩
  omega

theorem cardinal_gain_lower (sp : Spec H r d) (G : GraphState n d)
    {a b : Fin n} (ha : a∈H) (hb : b∈H) (hab : a≠b) :
    (r+1-H.card)^2 ≤ Fintype.card (TwoHub.Ports G.1 a b) := by
  let f (p : ↑(leavesAt H G a) × ↑(leavesAt H G b)) : TwoHub.Ports G.1 a b := ⟨(p.1.1,p.2.1),by
    obtain ⟨⟨x,hx⟩,⟨y,hy⟩⟩ := p
    obtain ⟨hsx,ex⟩ := mem_filter.mp hx
    obtain ⟨hsy,ey⟩ := mem_filter.mp hy
    have xoff : x∉H := mem_compl.mp hsx
    have yoff : y∉H := mem_compl.mp hsy
    have hax : a≠x := fun e => xoff (e ▸ ha)
    have hbx : b≠x := fun e => xoff (e ▸ hb)
    have hay : a≠y := fun e => yoff (e ▸ ha)
    have hby : b≠y := fun e => yoff (e ▸ hb)
    refine ⟨?_,ex,ey,?_⟩
    · have hxy : x≠y := by
        intro he; subst y
        obtain ⟨z,_,hz⟩ := TwoHub.one_neighbor G (sp.leaf x xoff)
        exact hab ((hz a ex.symm).trans (hz b ey.symm).symm)
      exact ⟨hax,hab,hay,hbx.symm,hxy,hby⟩
    · intro e
      obtain ⟨z,_,hz⟩ := TwoHub.one_neighbor G (sp.leaf x xoff)
      exact hay ((hz a ex.symm).trans (hz y e).symm)⟩
  have hi : Function.Injective f := by
    rintro ⟨x,y⟩ ⟨u,v⟩ h
    exact Prod.ext (Subtype.ext (congrArg (fun z => z.val.1) h))
      (Subtype.ext (congrArg (fun z => z.val.2) h))
  have hf := Fintype.card_le_of_injective f hi
  simp only [Fintype.card_prod,Fintype.card_coe] at hf
  rw [pow_two];exact (Nat.mul_le_mul (star_lower sp G ha) (star_lower sp G hb)).trans hf

theorem total_degree (sp : Spec H r d) : ∑ x,d x=2*(H.card*r) := by
  rw [← sum_add_sum_compl H]
  have hh : (∑ x∈H,d x) = H.card*r := by
    calc
      _ = ∑ _x∈H,r := sum_congr rfl fun x hx => sp.hub x hx
      _ = _ := by simp
  have hl : (∑ x∈Hᶜ,d x) = Hᶜ.card := by
    calc
      _ = ∑ _x∈Hᶜ,1 := sum_congr rfl fun x hx => sp.leaf x (mem_compl.mp hx)
      _ = _ := by simp
  rw [hh,hl,sp.count];omega

theorem cardinal_loss_upper (sp : Spec H r d) (G : GraphState n d) (a b : Fin n) :
    Fintype.card (TwoHub.Ports G.1ᶜ a b) ≤ 2*(H.card*r) := by
  let f (w : TwoHub.Ports G.1ᶜ a b) :
      Σ x : Fin n, {y : Fin n // G.1.Adj x y} :=
    ⟨w.val.1,w.val.2,by
      by_contra hn
      exact w.2.2.2.2 ⟨w.2.1.2.2.2.2.1,hn⟩⟩
  have hi : Function.Injective f := by
    intro p q he
    apply Subtype.ext
    exact congrArg (fun u : Σ x : Fin n,{y : Fin n // G.1.Adj x y} => (u.1,u.2.val)) he
  have hf := Fintype.card_le_of_injective f hi
  rw [Fintype.card_sigma] at hf
  have hdeg (x : Fin n) : Fintype.card {y : Fin n // G.1.Adj x y}=d x := by
    rw [Fintype.card_subtype];exact G.2 x
  simpa only [hdeg,total_degree sp] using hf

#print axioms cardinal_gain_lower
#print axioms cardinal_loss_upper
end ManyCore
