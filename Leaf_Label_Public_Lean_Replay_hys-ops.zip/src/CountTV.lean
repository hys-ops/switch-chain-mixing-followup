import CoefficientLimit
open Filter Topology
noncomputable section
namespace CountLimit
def TV (A B : Law) : ℝ := (∑' j, |A.p j-B.p j|)/2
lemma diff_sum (A B : Law) : Summable (fun j => |A.p j-B.p j|) :=
  (A.total.summable.sub B.total.summable).abs
lemma TV_eq (A B : Law) : TV A B = 1-∑' j, min (A.p j) (B.p j) := by
  have hm := Summable.of_nonneg_of_le (fun j => le_min (A.nonneg j) (B.nonneg j))
    (fun j => min_le_left (A.p j) (B.p j)) A.total.summable
  have he (j : ℕ) : |A.p j-B.p j|=(A.p j+B.p j)-2*min (A.p j) (B.p j) := by
    rcases le_total (A.p j) (B.p j) with h|h
    · rw [abs_of_nonpos (sub_nonpos.mpr h),min_eq_left h];ring
    · rw [abs_of_nonneg (sub_nonneg.mpr h),min_eq_right h];ring
  simp only [TV,he,(A.total.summable.add B.total.summable).tsum_sub (hm.mul_left 2),
    A.total.summable.tsum_add B.total.summable,tsum_mul_left,A.total.tsum_eq,B.total.tsum_eq]
  ring
lemma pointwise_TV (P : ℕ → Law) (A : Law)
    (h : ∀ j,Tendsto (fun i => (P i).p j) atTop (𝓝 (A.p j))) :
    Tendsto (fun i => TV (P i) A) atTop (𝓝 0) := by
  have ht : Tendsto (fun i => ∑' j, min ((P i).p j) (A.p j)) atTop (𝓝 (∑' j,A.p j)) := by
    apply tendsto_tsum_of_dominated_convergence A.total.summable
    · intro j;simpa using (h j).min (tendsto_const_nhds (x:=A.p j))
    · exact .of_forall (fun i j => by rw [Real.norm_eq_abs,abs_of_nonneg (le_min ((P i).nonneg j) (A.nonneg j))];exact min_le_right _ _)
  rw [A.total.tsum_eq] at ht
  simpa only [TV_eq,sub_self] using (tendsto_const_nhds (x:=(1:ℝ))).sub ht

lemma TV_comm (A B : Law) : TV A B=TV B A := by simp only [TV,abs_sub_comm (A.p _) (B.p _)]
lemma TV_tri (A B C : Law) : TV A C ≤ TV A B+TV B C := by
  unfold TV
  rw [←add_div,←(diff_sum A B).tsum_add (diff_sum B C)]
  apply div_le_div_of_nonneg_right _ (by norm_num)
  exact (diff_sum A C).tsum_le_tsum (fun j => abs_sub_le _ _ _) ((diff_sum A B).add (diff_sum B C))
theorem two_profiles (P R : ℕ → Law) (A B : Law)
    (hP : ∀ z:ℝ,0<z → z<1 → Tendsto (fun i => pgf (P i) z) atTop (𝓝 (pgf A z)))
    (hR : ∀ z:ℝ,0<z → z<1 → Tendsto (fun i => pgf (R i) z) atTop (𝓝 (pgf B z))) :
    Tendsto (fun i => TV (P i) (R i)) atTop (𝓝 (TV A B)) := by
  have hp := pointwise_TV _ _ (coefficients _ _ hP)
  have hr := pointwise_TV _ _ (coefficients _ _ hR)
  have lo := (tendsto_const_nhds (x:=TV A B)).sub (hp.add hr)
  have hi := (tendsto_const_nhds (x:=TV A B)).add (hp.add hr)
  simp only [add_zero,sub_zero] at lo hi
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le lo hi
  · intro i
    have a := TV_tri A (P i) B
    have b := TV_tri (P i) (R i) B
    rw [TV_comm A (P i)] at a
    linarith
  · intro i
    have a := TV_tri (P i) A (R i)
    have b := TV_tri A B (R i)
    rw [TV_comm B (R i)] at b
    linarith
theorem poisson_profiles (P R : ℕ → Law) {u v : ℝ} (hu : 0≤u) (hv : 0≤v)
    (hP : ∀ z:ℝ,0<z → z<1 → Tendsto (fun i => pgf (P i) z) atTop (𝓝 (Real.exp ((z-1)*u))))
    (hR : ∀ z:ℝ,0<z → z<1 → Tendsto (fun i => pgf (R i) z) atTop (𝓝 (Real.exp ((z-1)*v)))) :
    Tendsto (fun i => TV (P i) (R i)) atTop (𝓝 (TV (poisson u hu) (poisson v hv))) := by
  apply two_profiles
  · intro z hz hz1;rw [poisson_gen _ _ _ hz.le];exact hP z hz hz1
  · intro z hz hz1;rw [poisson_gen _ _ _ hz.le];exact hR z hz hz1
#print axioms two_profiles
#print axioms poisson_profiles
end CountLimit
