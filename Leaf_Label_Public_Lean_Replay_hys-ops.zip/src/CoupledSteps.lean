import MarkovTV

noncomputable section
open scoped BigOperators Matrix
namespace PaintMix
open HubTransfer
variable {X I : Type*} [Fintype X] [Fintype I] [DecidableEq X]

def walk (w : I→ℝ) (go : X→I→X) : Matrix X X ℝ :=
  fun x y => ∑ i,if go x i=y then w i else 0

theorem row_power (w : I→ℝ) (go : X→I→X) (t : ℕ) (x : X) (y : X) :
    ((walk w go)^(t+1)) x y = ∑ i,w i*((walk w go)^t) (go x i) y := by
  rw [pow_succ',Matrix.mul_apply]
  change (∑ z,(∑ i, if go x i=z then w i else 0)*((walk w go)^t) z y)=_
  simp_rw [Finset.sum_mul]
  rw [Finset.sum_comm]; simp [ite_mul]

/-- A Markovian coupling with equal or related image states can be iterated
directly in discrete time. Its one-step noncoalescence probability is rho. -/
theorem adjacent_coupling (w : I→ℝ) (hw : ∀i,0≤w i) (go : X→I→X)
    (R : X→X→Prop) (ρ : ℝ) (hρ : 0≤ρ)
    (hc : ∀x y,R x y → ∃ e : Equiv.Perm I,(∀i,w (e i)=w i) ∧
      (∀ i,go x i=go y (e i) ∨ R (go x i) (go y (e i))) ∧
      (∑ i,if go x i=go y (e i) then 0 else w i)≤ρ)
    {x y : X} (hr : R x y) (t : ℕ) :
    tv (((walk w go)^t) x) (((walk w go)^t) y) ≤ ρ^t := by
  induction t generalizing x y with
  | zero =>
    rw [pow_zero,pow_zero]
    unfold tv
    by_cases h : x=y
    · subst y; simp
    · have hdiff (z : X) : |(1:Matrix X X ℝ) x z-(1:Matrix X X ℝ) y z| = (if x=z then 1 else 0)+(if y=z then 1 else 0) := by
        by_cases hx : x=z <;> by_cases hy : y=z <;> simp_all [Matrix.one_apply]
      simp only [hdiff,Finset.sum_add_distrib,Finset.sum_ite_eq,Finset.mem_univ,ite_true]; norm_num
  | succ t ih =>
    obtain ⟨e,he,hd,ht⟩ := hc x y hr
    let K := walk w go
    have hx : (K^(t+1)) x = fun z => ∑ i,w i*(K^t) (go x i) z := funext (row_power w go t x)
    have hy : (K^(t+1)) y = fun z => ∑ i,w i*(K^t) (go y (e i)) z := by
      funext z
      rw [row_power,← Equiv.sum_comp e (fun i => w i*(K^t) (go y i) z)]
      simp_rw [he]
    change tv ((K^(t+1)) x) ((K^(t+1)) y)≤_
    rw [hx,hy]
    apply (tv_mix Finset.univ w (fun i _ => hw i) (fun i => (K^t) (go x i))
      (fun i => (K^t) (go y (e i)))).trans
    calc
      _ ≤ ∑ i,(if go x i=go y (e i) then 0 else w i)*ρ^t := by
        apply Finset.sum_le_sum
        intro i _
        by_cases heq : go x i=go y (e i)
        · simp [heq,tv]
        · simp only [heq,ite_false]
          exact mul_le_mul_of_nonneg_left (ih ((hd i).resolve_left heq)) (hw i)
      _ = _ := by rw [← Finset.sum_mul]
      _ ≤ _ := by rw [pow_succ'];exact mul_le_mul_of_nonneg_right ht (pow_nonneg hρ _)

#print axioms adjacent_coupling
end PaintMix
