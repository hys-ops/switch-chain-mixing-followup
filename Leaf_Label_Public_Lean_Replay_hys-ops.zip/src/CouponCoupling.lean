import OrderedKernel
open Finset HubTransfer
open scoped Matrix
namespace OrderedUrn
noncomputable section
attribute [local instance] Classical.propDecidable
variable {N k : ℕ} {Q : ℝ}
lemma low_le (x : Pair k) : low x≤high x := x.2
def bothUp (x : Pair k) : Pair k :=
  ⟨(up (high x),up (low x)),by change min k ((low x).val+1) ≤ min k ((high x).val+1);exact min_le_min_left _ (Nat.add_le_add_right x.2 1)⟩
def bothDown (x : Pair k) : Pair k :=
  ⟨(down (high x),down (low x)),Nat.sub_le_sub_right x.2 1⟩
def downHigh (x : Pair k) : Pair k :=
  if h : low x < high x then ⟨(down (high x),low x),by change (low x).val≤(high x).val-1;exact Nat.le_pred_of_lt h⟩ else x
def upLow (x : Pair k) : Pair k :=
  if h : low x < high x then ⟨(high x,up (low x)),by change min _ _≤(high x).val; exact min_le_of_right_le (Nat.succ_le_of_lt h)⟩ else x

def P (N k : ℕ) (Q : ℝ) : Matrix (Pair k) (Pair k) ℝ := fun x y=>
  pt (1-birth k Q (low x)-death N k Q (high x)) x y +
  pt (birth k Q (high x)) (bothUp x) y + pt (death N k Q (low x)) (bothDown x) y +
  pt (death N k Q (high x)-death N k Q (low x)) (downHigh x) y +
  pt (birth k Q (low x)-birth k Q (high x)) (upLow x) y

theorem P_apply (f : Pair k→ℝ) (x : Pair k) : (P N k Q *ᵥ f) x =
    (1-birth k Q (low x)-death N k Q (high x))*f x +
    birth k Q (high x)*f (bothUp x)+death N k Q (low x)*f (bothDown x)+
    (death N k Q (high x)-death N k Q (low x))*f (downHigh x)+
    (birth k Q (low x)-birth k Q (high x))*f (upLow x) := by
  simp only [P,Matrix.mulVec,dotProduct,add_mul,sum_add_distrib,eval_pt]

lemma birth_anti (hq : 0≤Q) {i j : Z k} (h : i≤j) : birth k Q j≤birth k Q i := by
  have hm : (j:ℝ)≤k := by exact_mod_cast Nat.le_of_lt_succ j.isLt
  have hi : (i:ℝ)≤j := by exact_mod_cast h
  apply div_le_div_of_nonneg_right _ hq;gcongr
lemma death_mono (hn : 2*k≤N) (hq : 0≤Q) {i j : Z k} (h : i≤j) : death N k Q i≤death N k Q j := by
  have hn' : 2*(k:ℝ)≤N := by exact_mod_cast hn
  have hi : (i:ℝ)≤j := by exact_mod_cast h
  apply div_le_div_of_nonneg_right _ hq;apply mul_le_mul hi (by linarith) (by linarith [show 0≤(i:ℝ) by positivity]) (by positivity)
lemma hold_nonneg (hn : 2*k≤N) (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) (x : Pair k) :
  0≤1-birth k Q (low x)-death N k Q (high x) := by
  have hk : (k:ℝ)≤N := by exact_mod_cast (show k≤N by omega)
  have h2 : 2*(k:ℝ)≤N := by exact_mod_cast hn
  have hv (z : Z k) : (z:ℝ)≤k := by exact_mod_cast Nat.le_of_lt_succ z.isLt
  have rise : ((k:ℝ)-(low x:ℝ))^2≤(k:ℝ)^2 := by gcongr <;> linarith [hv (low x),show 0≤(low x:ℝ) by positivity]
  have fall : (high x:ℝ)*((N:ℝ)-2*k+(high x:ℝ))≤(k:ℝ)*(N-k) :=
    mul_le_mul (hv _) (by linarith [hv (high x)]) (by linarith [show 0≤(high x:ℝ) by positivity]) (by positivity)
  unfold birth death
  have ht := (add_le_add rise fall).trans (show (k:ℝ)^2+k*(N-k)≤(N:ℝ)^2 by nlinarith [mul_le_mul_of_nonneg_right hk (show 0≤(N:ℝ) by positivity)])
  have hsum:= (div_le_one hQ).mpr (ht.trans hN)
  rw [add_div] at hsum;linarith

theorem P_stoch (hn : 2*k≤N) (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) : Stochastic (P N k Q) := by
  constructor
  · intro x y
    have hb := birth_anti hQ.le (low_le x)
    have hd := death_mono hn hQ.le (low_le x)
    have b : 0≤birth k Q (high x) := div_nonneg (sq_nonneg _) hQ.le
    have e : 0≤death N k Q (low x) := by
      have h2 : 2*(k:ℝ)≤N := by exact_mod_cast hn
      unfold death;apply div_nonneg _ hQ.le;apply mul_nonneg (by positivity) (by linarith [show 0≤(low x:ℝ) by positivity])
    have non {X : Type} [DecidableEq X] (w : ℝ) (p q : X) (hw : 0≤w) : 0≤pt w p q := by unfold pt;split <;> linarith
    unfold P
    exact add_nonneg (add_nonneg (add_nonneg (add_nonneg (non _ _ _ (hold_nonneg hn hQ hN x)) (non _ _ _ b)) (non _ _ _ e)) (non _ _ _ (sub_nonneg.mpr hd))) (non _ _ _ (sub_nonneg.mpr hb))
  · intro x
    have h:= P_apply (N:=N) (Q:=Q) (fun _ : Pair k=>1) x
    simp only [Matrix.mulVec,dotProduct,mul_one] at h;rw [h];ring

@[simp] lemma hi_up (x : Pair k) : high (bothUp x)=up (high x) := rfl
@[simp] lemma lo_up (x : Pair k) : low (bothUp x)=up (low x) := rfl
@[simp] lemma hi_down (x : Pair k) : high (bothDown x)=down (high x) := rfl
@[simp] lemma lo_down (x : Pair k) : low (bothDown x)=down (low x) := rfl
lemma other_hi (x : Pair k) (h : low x<high x) : high (downHigh x)=down (high x) ∧ low (downHigh x)=low x := by
  unfold downHigh;rw [dite_eq_left h];exact ⟨rfl,rfl⟩
lemma other_lo (x : Pair k) (h : low x<high x) : high (upLow x)=high x ∧ low (upLow x)=up (low x) := by
  unfold upLow;rw [dite_eq_left h];exact ⟨rfl,rfl⟩

theorem high_marginal (f : Z k→ℝ) (x : Pair k) :
    (P N k Q *ᵥ (f ∘ high)) x=(B N k Q *ᵥ f) (high x) := by
  simp only [P_apply,B_apply,Function.comp_apply,hi_up,hi_down]
  by_cases h : low x<high x
  · rw [(other_lo x h).1,(other_hi x h).1];ring
  · have e : low x=high x := le_antisymm (low_le x) (le_of_not_gt h)
    rw [e];ring

theorem low_marginal (f : Z k→ℝ) (x : Pair k) :
    (P N k Q *ᵥ (f ∘ low)) x=(B N k Q *ᵥ f) (low x) := by
  simp only [P_apply,B_apply,Function.comp_apply,lo_up,lo_down]
  by_cases h : low x<high x
  · rw [(other_lo x h).2,(other_hi x h).2];ring
  · have e : low x=high x := le_antisymm (low_le x) (le_of_not_gt h)
    rw [e];ring

#print axioms P_stoch
#print axioms high_marginal
#print axioms low_marginal
end
end OrderedUrn
