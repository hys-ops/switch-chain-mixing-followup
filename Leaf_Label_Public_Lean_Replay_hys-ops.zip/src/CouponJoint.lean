import PureDeath
import OrderedAdapter
import GapMix
open Finset HubTransfer HubDense PhysicalReduction BinaryOverlap
open scoped Matrix
namespace OrderedUrn
noncomputable section
attribute [local instance] Classical.propDecidable
variable {N k : ℕ} {Q : ℝ}

def start (y : Z k) : Pair k := ⟨(Fin.last k,y),Fin.le_last y⟩
@[simp] theorem high_start (y : Z k) : high (start y)=Fin.last k := rfl
@[simp] theorem low_start (y : Z k) : low (start y)=y := rfl
def joint (N k : ℕ) (Q : ℝ) (t : ℕ) : Pair k→ℝ := mixRow (hyperProb N k) start ((P N k Q)^t)

private theorem row_power {X Y:Type*} [Fintype X] [Fintype Y] [DecidableEq X] [DecidableEq Y]
    (π : X→Y) (K : Matrix X X ℝ) (H : Matrix Y Y ℝ)
    (hh : ∀f x,(K *ᵥ (f ∘ π)) x=(H *ᵥ f) (π x)) (t : ℕ) (f : Y→ℝ) (x : X) :
    (K^t *ᵥ (f ∘ π)) x=(H^t *ᵥ f) (π x) := by
  induction t generalizing x with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',pow_succ',←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec]
    rw [←hh (H^t *ᵥ f) x]
    apply sum_congr rfl;intro y _;rw [ih];rfl

theorem hyper_nonneg (x : Z k) : 0≤hyperProb N k x := by unfold hyperProb;positivity
theorem hyper_sum (A : JohnsonLower.Slice N k) : ∑z,hyperProb N k z=1 := by
  have h (z) : hyperProb N k z=push (level A) (unif _) z := (hypergeometric A z).symm
  have : Nonempty (JohnsonLower.Slice N k):=⟨A⟩
  have hc : (Fintype.card (JohnsonLower.Slice N k):ℝ)≠0 := by exact_mod_cast Fintype.card_ne_zero
  simp only [h,push];rw [sum_comm]
  simp only [sum_ite_eq,mem_univ,ite_true,unif,sum_const,card_univ,nsmul_eq_mul];field_simp

theorem joint_nonneg (hn : 2*k≤N) (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) (t : ℕ) (x : Pair k) : 0≤joint N k Q t x := by
  unfold joint mixRow;apply sum_nonneg;intro i _;exact mul_nonneg (hyper_nonneg i) ((stochastic_pow (P_stoch hn hQ hN) t).1 _ _)

theorem joint_sum (A : JohnsonLower.Slice N k) (hn : 2*k≤N) (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) (t : ℕ) : ∑x,joint N k Q t x=1 := by
  unfold joint mixRow;rw [sum_comm];simp_rw [←mul_sum,(stochastic_pow (P_stoch hn hQ hN) t).2,mul_one];exact hyper_sum A

private theorem push_expect {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y] (π : X→Y) (m : X→ℝ) (j : Y) :
    push π m j=∑ x,m x*(if π x=j then 1 else 0) := by
  unfold push;apply sum_congr rfl;intro x _;split <;> simp_all

private theorem eval_ind {X : Type*} [Fintype X] [DecidableEq X] (C : Matrix X X ℝ) (i j:X) :
    (C *ᵥ (fun x=>if x=j then (1:ℝ) else 0)) i=C i j := by
  change (∑ x,C i x*(if x=j then 1 else 0))=_
  rw [sum_eq_single j]
  · simp
  · intro b _ hb;simp [hb]
  · simp

theorem high_push (A : JohnsonLower.Slice N k) (Q : ℝ) (t : ℕ) :
    push high (joint N k Q t)=((B N k Q)^t) (Fin.last k) := by
  funext j;rw [push_expect,joint,mix_expect]
  let f : Z k→ℝ:=fun z=>if z=j then 1 else 0
  change (∑ i, hyperProb N k i*((P N k Q)^t *ᵥ (f ∘ high)) (start i))=_
  simp only [row_power high _ _ (fun g y=>high_marginal g y),high_start,f,eval_ind,←sum_mul,hyper_sum A,one_mul]

theorem low_push (A : JohnsonLower.Slice N k) (hn : 0<N) (hQ : Q≠0) (t : ℕ) :
    push low (joint N k Q t)=hyperProb N k := by
  funext j;rw [push_expect,joint,mix_expect]
  let f : Z k→ℝ:=fun z=>if z=j then 1 else 0
  change (∑ i, hyperProb N k i*((P N k Q)^t *ᵥ (f ∘ low)) (start i))=_
  simp only [row_power low _ _ (fun g y=>low_marginal g y),low_start,f,eval_ind]
  exact congrFun (ordered_equilibrium A hn hQ t) j

#print axioms joint_nonneg
#print axioms joint_sum
#print axioms high_push
#print axioms low_push
end
end OrderedUrn
