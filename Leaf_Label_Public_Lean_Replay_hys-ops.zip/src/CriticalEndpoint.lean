import OverlapLaw
import PoissonWindows
import GrowingWindow
open Finset Filter Topology CountLimit UrnWindow UrnWindow.Degrees HubTransfer HubMarks
open OAI.Problem315
open scoped Matrix
noncomputable section
namespace CriticalResult

def seed (g : Degrees) (i : ℕ) : JohnsonLower.Slice (g.population i) (g.ballCount i) := by
  classical
  have h : g.ballCount i≤(univ : Finset (Fin (g.population i))).card := by
    rw [card_univ,Fintype.card_fin];unfold ballCount Degrees.population;omega
  let he := Finset.exists_subset_card_eq h
  exact ⟨he.choose,he.choose_spec.2⟩

theorem binary_limit (g : Degrees) {α : ℝ} (ha : 0<α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (K : (i:ℕ) → JohnsonLower.Slice (g.population i) (g.ballCount i)) :
    Tendsto (fun i => tv (((walk _ _ (g.Q i))^(g.time .halfLogN c i)) (K i)) (unif _))
      atTop (𝓝 (critical α c)) := by
  let cap := fun i => (CriticalUrn.physical g i (g.ballCount i)).2.2
  let P := fun i => lawAt (K i) (g.Q i) (g.clk_pos i) (cap i) (g.time .halfLogN c i)
  let R := fun i => lawEquilibrium (K i)
  have hm : 0≤α+Real.sqrt α*Real.exp (-c) := by positivity
  have ans := poisson_profiles P R hm ha.le (by
    intro z hz hz1
    have e := CriticalUrn.point_window g ha.le h c K hz.le hz1.le
    apply e.congr;intro i
    unfold P lawAt
    exact (image_gen (overlap (K i)) _ _ _ z).symm) (by
    intro z hz hz1
    have e := CriticalUrn.uniform_window g ha.le h K hz.le hz1.le
    apply e.congr;intro i
    unfold R lawEquilibrium
    exact (image_gen (overlap (K i)) _ _ _ z).symm)
  have he : TV (poisson _ hm) (poisson α ha.le)=critical α c := by
    unfold TV critical poissonTV
    congr 1;apply tsum_congr;intro j
    simp [poisson,LeafClock.mass,ProbabilityTheory.poissonPMFReal,Real.coe_toNNReal _ hm,Real.coe_toNNReal _ ha.le]
  rw [he] at ans
  apply ans.congr;intro i
  exact original_binary_TV (K i) _ (g.clk_pos i) (CriticalUrn.physical g i (g.ballCount i)).1 (cap i) _

theorem critical_graph_uniform (g : Degrees) {α : ℝ} (ha : 0<α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (sp : ∀ i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    {ε:ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time .halfLogN c i) G-critical α c|<ε := by
  have he := PhysicalReduction.window_envelope_zero g .halfLogN c
  have hb := binary_limit g ha h c (seed g)
  filter_upwards [(tendsto_order.mp he).2 (ε/2) (by linarith),
    Metric.tendsto_nhds.mp hb (ε/2) (by linarith)] with i hi hbi
  rw [Real.dist_eq] at hbi
  intro G
  have hr := g.two i
  have hs := g.small i
  have hn : 4≤g.population i+2 := by unfold Degrees.population;omega
  have step := (PhysicalReduction.all_starts (sp i) hn hr (hr.trans hs) G (seed g i) (g.time .halfLogN c i)).trans
    (PhysicalReduction.window_envelope g .halfLogN c i (sp i))
  change |_-tv (((walk _ _ (g.Q i))^(g.time .halfLogN c i)) (seed g i)) (unif _)| ≤ _ at step
  have tri := abs_sub_le (tvDistanceFrom _ (d i) (g.time .halfLogN c i) G) (tv (((walk _ _ (g.Q i))^(g.time .halfLogN c i)) (seed g i)) (unif _)) (critical α c)
  linarith

#print axioms binary_limit
#print axioms critical_graph_uniform
end CriticalResult
