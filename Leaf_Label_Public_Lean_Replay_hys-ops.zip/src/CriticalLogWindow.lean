import CriticalEndpoint
import SparseScalars

/-! Alternate critical clock of Theorem 6.  Its surviving contribution is
`exp (-c)` on the log k clock, while the equilibrium overlap still tends to α. -/
open Finset Filter Topology CountLimit UrnWindow UrnWindow.Degrees HubTransfer HubMarks
open OAI.Problem315 CriticalResult CriticalUrn JohnsonLower
open scoped Matrix
noncomputable section
namespace CriticalAlternative

lemma pgf_logk (g : Degrees) {α:ℝ} (hα : 0≤α) (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c z : ℝ) :
    Tendsto (fun i=>comp (load (g.N i) (g.ballCount i))
      (pbase (g.step i) z (g.time .logK c i)) z (g.ballCount i)) atTop
       (𝓝 (Real.exp ((z-1)*(α+Real.exp (-c))))) := by
  let d := fun i => (1-g.step i)^(g.time .logK c i)
  have hm := UrnWindow.Degrees.SparseScalars.scaled_survival g c
  have hd : Tendsto d atTop (𝓝 0) := by
    apply (hm.div_atTop (k_infty g)).congr;intro i
    have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
    change g.k i*d i/g.k i=d i
    field_simp [hk.ne']
  have hp := (tendsto_const_nhds (x:=1-z)).mul hd
  simp only [mul_zero] at hp
  have hpow : Tendsto (fun i=>(1-(1-z)*d i)^(g.ballCount i)) atTop
       (𝓝 (Real.exp (-((1-z)*(Real.exp (-c)))))) := by
    apply TwoHubUnequal.moving_decay hp
    apply ((tendsto_const_nhds (x:=1-z)).mul hm).congr;intro i
    rw [ball_cast];dsimp [d,step];ring
  have hbase := (tendsto_const_nhds (x:=(1:ℝ))).sub hp
  simp only [sub_zero] at hbase
  have hex := Real.continuous_exp.continuousAt.tendsto.comp ((load_limit g hα h).neg.mul (hbase.sub_const z))
  have ht := hex.mul hpow
  change Tendsto _ _ (𝓝 (Real.exp (-α*(1-z))*Real.exp (-((1-z)*(Real.exp (-c)))))) at ht
  rw [←Real.exp_add,show -α*(1-z)+ -((1-z)*(Real.exp (-c)))=(z-1)*(α+Real.exp (-c)) by ring] at ht
  exact ht

theorem alt_point_window (g : Degrees) {α : ℝ} (hα : 0≤α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (K : (i : ℕ)→Slice (g.population i) (g.ballCount i)) {z : ℝ} (hz : 0≤z) (hz' : z≤1) :
    Tendsto (fun i => ((walk _ _ (g.Q i))^(g.time .logK c i) *ᵥ
      fun T => z^(HubMarks.overlap (K i) T)) (K i)) atTop
        (𝓝 (Real.exp ((z-1)*(α+Real.exp (-c))))) := by
  have he := allowance_zero g hα h
  have hm := pgf_logk g hα h c z
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' (by simpa only [sub_zero] using hm.sub he)
    (by simpa only [add_zero] using hm.add he)
  all_goals apply Filter.Eventually.of_forall;intro i
  all_goals obtain ⟨hn,hscale,cap⟩ := physical g i (g.ballCount i)
  all_goals have hp := slice_pgf (K i) (K i) hn (clk_pos g i) hscale cap hz hz' (g.time .logK c i)
  all_goals rw [show HubMarks.overlap (K i) (K i)=g.ballCount i by simp [HubMarks.overlap,(K i).property]] at hp
  all_goals unfold step at *;linarith [(abs_le.mp hp).1,(abs_le.mp hp).2]

theorem alt_binary_limit (g : Degrees) {α : ℝ} (ha : 0<α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (K : (i:ℕ) → JohnsonLower.Slice (g.population i) (g.ballCount i)) :
    Tendsto (fun i => tv (((walk _ _ (g.Q i))^(g.time .logK c i)) (K i)) (unif _))
      atTop (𝓝 (poissonTV (α+Real.exp (-c)) α)) := by
  let cap := fun i => (CriticalUrn.physical g i (g.ballCount i)).2.2
  let P := fun i => lawAt (K i) (g.Q i) (g.clk_pos i) (cap i) (g.time .logK c i)
  let R := fun i => lawEquilibrium (K i)
  have hm : 0≤α+Real.exp (-c) := by positivity
  have ans := poisson_profiles P R hm ha.le (by
    intro z hz hz1
    have e := alt_point_window g ha.le h c K hz.le hz1.le
    apply e.congr;intro i
    unfold P lawAt
    exact (image_gen (overlap (K i)) _ _ _ z).symm) (by
    intro z hz hz1
    have e := CriticalUrn.uniform_window g ha.le h K hz.le hz1.le
    apply e.congr;intro i
    unfold R lawEquilibrium
    exact (image_gen (overlap (K i)) _ _ _ z).symm)
  have he : TV (poisson _ hm) (poisson α ha.le)=poissonTV (α+Real.exp (-c)) α := by
    unfold TV poissonTV
    congr 1;apply tsum_congr;intro j
    simp [poisson,LeafClock.mass,ProbabilityTheory.poissonPMFReal,Real.coe_toNNReal _ hm,Real.coe_toNNReal _ ha.le]
  rw [he] at ans
  apply ans.congr;intro i
  exact original_binary_TV (K i) _ (g.clk_pos i) (CriticalUrn.physical g i (g.ballCount i)).1 (cap i) _

theorem critical_logK_graph_uniform (g : Degrees) {α : ℝ} (ha : 0<α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (sp : ∀ i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    {ε:ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time .logK c i) G-poissonTV (α+Real.exp (-c)) α|<ε := by
  have he := PhysicalReduction.window_envelope_zero g .logK c
  have hb := alt_binary_limit g ha h c (seed g)
  filter_upwards [(tendsto_order.mp he).2 (ε/2) (by linarith),
    Metric.tendsto_nhds.mp hb (ε/2) (by linarith)] with i hi hbi
  rw [Real.dist_eq] at hbi
  intro G
  have hr := g.two i
  have hs := g.small i
  have hn : 4≤g.population i+2 := by unfold Degrees.population;omega
  have step := (PhysicalReduction.all_starts (sp i) hn hr (hr.trans hs) G (seed g i) (g.time .logK c i)).trans
    (PhysicalReduction.window_envelope g .logK c i (sp i))
  change |_-tv (((walk _ _ (g.Q i))^(g.time .logK c i)) (seed g i)) (unif _)| ≤ _ at step
  have tri := abs_sub_le (tvDistanceFrom _ (d i) (g.time .logK c i) G) (tv (((walk _ _ (g.Q i))^(g.time .logK c i)) (seed g i)) (unif _)) (poissonTV (α+Real.exp (-c)) α)
  linarith

#print axioms pgf_logk
#print axioms alt_binary_limit
#print axioms critical_logK_graph_uniform
end CriticalAlternative
