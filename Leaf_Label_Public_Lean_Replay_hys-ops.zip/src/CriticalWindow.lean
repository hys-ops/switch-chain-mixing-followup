import SlicePGF
import DiscreteWindow
open Filter Topology UrnWindow UrnWindow.Degrees
namespace CriticalUrn
noncomputable section

lemma load_limit (g : Degrees) {α:ℝ} (hα : 0≤α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) :
    Tendsto (fun i=>load (g.N i) (g.ballCount i)) atTop (𝓝 α) := by
  have hh := h.pow 2
  rw [Real.sq_sqrt hα] at hh
  apply hh.congr;intro i
  rw [load,ratio,div_pow,Real.sq_sqrt (by linarith [(sizes g i).2.2.1]),ball_cast]

lemma allowance_zero (g : Degrees) {α:ℝ} (hα : 0≤α) (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) :
    Tendsto (fun i => allowance (g.N i) (g.step i) (g.ballCount i)) atTop (𝓝 0) := by
  let m := fun i => load (g.N i) (g.ballCount i)
  have hm := load_limit g hα h
  have hn (i : ℕ) : 0<g.N i := by linarith [(sizes g i).2.2.1]
  have hk (i : ℕ) : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
  have hkn : Tendsto (fun i=>g.k i/g.N i) atTop (𝓝 0) := by
    apply (hm.div_atTop (k_infty g)).congr;intro i
    dsimp [load];rw [ball_cast];field_simp [(hk i).ne']
  have hns : Tendsto (fun i=>g.N i*g.step i) atTop (𝓝 0) := by
    apply squeeze_zero (fun i=>mul_nonneg (hn i).le (step_pos g i).le) _
      ((tendsto_const_nhds (x:=(1:ℝ))).div_atTop (N_infty g))
    intro i
    rw [step,←mul_div_assoc,div_le_div_iff₀ (clk_pos g i) (hn i)]
    have hl := clock_lower g i
    have hb := sizes g i
    nlinarith [mul_nonneg (show 0≤(g.N i)^3 by positivity [hn i]) (sub_nonneg.mpr hb.2.2.1)]
  have x := ((tendsto_const_nhds (x:=(2:ℝ))).mul hkn).add
    ((hm.mul hns).add ((hm.mul (hkn.mul hns)).add ((hm.pow 2).mul (step_size g))))
  simp only [mul_zero,zero_add] at x
  apply x.congr;intro i
  dsimp [allowance,load,step];rw [ball_cast];field_simp [(hn i).ne'];ring

/-- At the manuscript's half-log clock the residual bias has exactly the critical scale. -/
lemma residual_limit (g : Degrees) {α:ℝ} (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ) :
    Tendsto (fun i=>g.k i*(1-g.step i)^(g.time .halfLogN c i)) atTop (𝓝 (Real.sqrt α*Real.exp (-c))) := by
  let t := g.time .halfLogN c
  have hdiff : Tendsto (fun i => (t i:ℝ)*Real.log (1-g.step i)+Real.log (g.N i)/2) atTop (𝓝 (-c)) := by
    have hh := ((log_clock_error g .halfLogN c).sub (rounding_limit g .halfLogN c)).sub (tendsto_const_nhds (x:=c))
    simp only [sub_zero,zero_sub] at hh
    apply hh.congr;intro i;dsimp [t,center];ring
  have hx := h.mul (Real.continuous_exp.continuousAt.tendsto.comp hdiff)
  apply hx.congr'
  filter_upwards [(tendsto_order.mp (step_size g)).2 1 (by norm_num)] with i hi
  have hn : 0<g.N i := by linarith [(sizes g i).2.2.1]
  change g.ratio i * Real.exp ((t i:ℝ)*Real.log (1-g.step i)+Real.log (g.N i)/2)=_
  rw [Real.exp_add,Real.exp_nat_mul,Real.exp_log (by change 0<1-g.N i/g.Q i;linarith),
      Real.exp_half,Real.exp_log hn,ratio]
  field_simp [(Real.sqrt_pos.mpr hn).ne'];rfl

lemma pgf_center (g : Degrees) {α:ℝ} (hα : 0≤α) (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c z : ℝ) :
    Tendsto (fun i=>comp (load (g.N i) (g.ballCount i))
      (pbase (g.step i) z (g.time .halfLogN c i)) z (g.ballCount i)) atTop
       (𝓝 (Real.exp ((z-1)*(α+Real.sqrt α*Real.exp (-c))))) := by
  let d := fun i => (1-g.step i)^(g.time .halfLogN c i)
  have hm := residual_limit g h c
  have hd : Tendsto d atTop (𝓝 0) := by
    apply (hm.div_atTop (k_infty g)).congr;intro i
    have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
    change g.k i*d i/g.k i=d i
    field_simp [hk.ne']
  have hp := (tendsto_const_nhds (x:=1-z)).mul hd
  simp only [mul_zero] at hp
  have hpow : Tendsto (fun i=>(1-(1-z)*d i)^(g.ballCount i)) atTop
       (𝓝 (Real.exp (-((1-z)*(Real.sqrt α*Real.exp (-c)))))) := by
    apply TwoHubUnequal.moving_decay hp
    apply ((tendsto_const_nhds (x:=1-z)).mul hm).congr;intro i
    rw [ball_cast];dsimp [d];ring
  have hbase := (tendsto_const_nhds (x:=(1:ℝ))).sub hp
  simp only [sub_zero] at hbase
  have hex := Real.continuous_exp.continuousAt.tendsto.comp ((load_limit g hα h).neg.mul (hbase.sub_const z))
  have ht := hex.mul hpow
  change Tendsto _ _ (𝓝 (Real.exp (-α*(1-z))*Real.exp (-((1-z)*(Real.sqrt α*Real.exp (-c)))))) at ht
  rw [←Real.exp_add,show -α*(1-z)+ -((1-z)*(Real.sqrt α*Real.exp (-c)))=(z-1)*(α+Real.sqrt α*Real.exp (-c)) by ring] at ht
  exact ht

#print axioms pgf_center
#print axioms allowance_zero
end
end CriticalUrn
