import Shape
import Loss
namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def ports_stars (sp : Spec n r d a c) (G : GraphState n d) :
    Ports G.val a c ≃ (↑(star G.val a c) × ↑(star G.val c a)) where
  toFun w :=
    (⟨w.1.1,(mem_star _ _ _ _).mpr ⟨⟨w.2.1.1.symm,w.2.1.2.2.2.1⟩,w.2.2.1⟩⟩,
     ⟨w.1.2,(mem_star _ _ _ _).mpr ⟨⟨w.2.1.2.2.2.2.2.symm,w.2.1.2.2.1.symm⟩,w.2.2.2.1⟩⟩)
  invFun w := by
    obtain ⟨⟨x,hx⟩,⟨y,hy⟩⟩ := w
    have hx' := (mem_star _ _ _ _).mp hx; have hy' := (mem_star _ _ _ _).mp hy
    have hxy : x≠y := by intro h;subst y;exact disjoint_left.mp (star_disjoint sp G) hx hy
    exact ⟨(x,y),⟨hx'.1.1.symm,sp.distinct,hy'.1.2.symm,hx'.1.2,hxy,hy'.1.1.symm⟩,
      hx'.2,hy'.2,fun e => hy'.1.2.symm (leaf_unique sp G hx'.1.1 hx'.1.2 hx'.2.symm e)⟩
  left_inv _ := rfl
  right_inv _ := rfl

/-- At every hub-disconnected state the original chain creates the hub edge with total probability r²/Q. -/
theorem A_to_B (sp : Spec n r d a c) (G : GraphState n d) (h : ¬G.val.Adj a c) :
  ∑ H∈(allGraphStates n d).filter (fun H => H.val.Adj a c),switchKernel n d G H =
    (r:ℝ)^2/(12*(n.choose 4:ℝ)) := by
  rw [mass_gain G h,Fintype.card_congr (ports_stars sp G),Fintype.card_prod]
  have ha := (star_size G.val a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
  have hc := (star_size G.val c a sp.distinct.symm).symm.trans ((G.2 c).trans sp.second)
  rw [G.val.adj_comm c a] at hc
  simp only [ite_eq_right h,add_zero] at ha hc
  rw [Fintype.card_coe,Fintype.card_coe,ha,hc,Nat.cast_mul,pow_two]

lemma ports_to_loose (sp : Spec n r d a c) (G : GraphState n d) (w : Ports G.valᶜ a c) :
    w.val.1 ∈ loose G.val a c ∧ w.val.2 ∈ loose G.val a c ∧ w.val.1≠w.val.2 := by
  obtain ⟨⟨x,y⟩,h,hax,hcy,hn⟩ := w
  obtain ⟨ha,_,hay,hxc,hxy,hc⟩ := h
  have he : G.val.Adj x y := by by_contra hh;exact hn ⟨hxy,hh⟩
  have hx : x ∈ loose G.val a c := (mem_loose _ _ _ _).mpr ⟨ha.symm,hxc,hax.2,
    fun e => hc (leaf_unique sp G ha.symm hxc e.symm he)⟩
  exact ⟨hx,loose_partner sp G hx he,hxy⟩

def edge_port (sp : Spec n r d a c) (G : GraphState n d) {x y : Fin n}
    (hx : x∈loose G.val a c) (hy : y∈loose G.val a c) (he : G.val.Adj x y) : Ports G.valᶜ a c := by
  have h := (mem_loose _ _ _ _).mp hx;have f := (mem_loose _ _ _ _).mp hy
  exact ⟨(x,y),⟨h.1.symm,sp.distinct,f.1.symm,h.2.1,he.ne,f.2.1.symm⟩,
    ⟨h.1.symm,h.2.2.1⟩,⟨f.2.1.symm,f.2.2.2⟩,fun hh => hh.2 he⟩

lemma ports_two (sp : Spec n r d a c) (G : GraphState n d) (h : G.val.Adj a c) :
   Fintype.card (Ports G.valᶜ a c)=2 := by
  obtain ⟨x,y,hxy,he,hE⟩ := loose_edge sp G h
  have hx : x∈loose G.val a c := he ▸ (by simp)
  have hy : y∈loose G.val a c := he ▸ (by simp)
  let f : Bool → Ports G.valᶜ a c := fun b => if b then edge_port sp G hx hy hE else edge_port sp G hy hx hE.symm
  have h₁ : Function.Injective f := by
    intro i j hij;cases i <;> cases j <;> try rfl
    all_goals have hh := congrArg (fun w : Ports G.valᶜ a c => w.val.1) hij
    · exact (hxy hh.symm).elim
    · exact (hxy hh).elim
  have h₂ : Function.Surjective f := by
    intro w;obtain ⟨hu,hv,hn⟩ := ports_to_loose sp G w
    rw [he,mem_insert,mem_singleton] at hu hv
    rcases hu with h₁|h₁ <;> rcases hv with h₂|h₂
    · exact (hn (h₁.trans h₂.symm)).elim
    · exact ⟨true,Subtype.ext (Prod.ext h₁.symm h₂.symm)⟩
    · exact ⟨false,Subtype.ext (Prod.ext h₁.symm h₂.symm)⟩
    · exact (hn (h₁.trans h₂.symm)).elim
  simpa using (Fintype.card_congr (Equiv.ofBijective f ⟨h₁,h₂⟩)).symm

/-- At every hub-connected state only two proposals remove the hub edge. -/
theorem B_to_A (sp : Spec n r d a c) (G : GraphState n d) (h : G.val.Adj a c) :
  ∑ H∈(allGraphStates n d).filter (fun H => ¬H.val.Adj a c),switchKernel n d G H =
    2/(12*(n.choose 4:ℝ)) := by
  rw [mass_loss G h,ports_two sp G h]; norm_num
#print axioms A_to_B
#print axioms B_to_A
end
end TwoHub
