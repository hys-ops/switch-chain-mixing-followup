import FirstExit
open Finset HubTransfer
open scoped Matrix
noncomputable section
namespace LeafSplit
variable {X : Type*} [Fintype X] [DecidableEq X]
variable (E : X → Prop) [DecidablePred E] (P : Matrix X X ℝ)
def cross (x y : X) : ℝ := if (E x ↔ E y) then 0 else P x y
def exitMass (x : X) : ℝ := ∑ y,cross E P x y
def vertical : Matrix X X ℝ := fun x y => cross E P x y+(if x=y then 1-exitMass E P x else 0)
def horizontal : Matrix X X ℝ := fun x y => (P x y-cross E P x y)+(if x=y then exitMass E P x else 0)
def incident (x y : X) : ℝ := cross E P x y / exitMass E P x

theorem decompose : P=horizontal E P + vertical E P-1 := by
  ext x y
  simp only [horizontal,vertical,Matrix.sub_apply,Matrix.add_apply,Matrix.one_apply]
  split_ifs <;> ring

theorem cross_bounds (hp : Stochastic P) (x y : X) : 0≤cross E P x y ∧ cross E P x y≤P x y := by
  unfold cross;split_ifs <;> simp [hp.1 x y]
theorem ex_bounds (hp : Stochastic P) (x : X) : 0≤exitMass E P x ∧ exitMass E P x≤1 := by
  refine ⟨sum_nonneg (fun y _ => (cross_bounds E P hp x y).1),?_⟩
  exact (sum_le_sum fun y _ => (cross_bounds E P hp x y).2).trans_eq (hp.2 x)
theorem v_stoch (hp : Stochastic P) : Stochastic (vertical E P) := by
  constructor
  · intro x y
    unfold vertical; split_ifs <;> linarith [(cross_bounds E P hp x y).1,(ex_bounds E P hp x).2]
  · intro x
    unfold vertical;rw [sum_add_distrib]
    simp [exitMass,Finset.sum_ite_eq]
theorem h_stoch (hp : Stochastic P) : Stochastic (horizontal E P) := by
  constructor
  · intro x y
    unfold horizontal;split_ifs <;> linarith [(cross_bounds E P hp x y).2,(ex_bounds E P hp x).1]
  · intro x
    unfold horizontal;rw [sum_add_distrib,sum_sub_distrib]
    simp [exitMass,hp.2 x,Finset.sum_ite_eq]

theorem v_diag (x : X) : 1-vertical E P x x=exitMass E P x := by simp [vertical,cross]
theorem h_diag (x : X) : 1-horizontal E P x x=1-P x x-exitMass E P x := by simp [horizontal,cross];ring

theorem incident_sum (x : X) (hx : exitMass E P x≠0) : ∑ y,incident E P x y=1 := by
  simp only [incident,←sum_div]; exact div_self hx
theorem exit_row (x : X) (hx : exitMass E P x ≠ 0) (y : X) :
    vertical E P x y = (1-exitMass E P x)*(1 : Matrix X X ℝ) x y+
      exitMass E P x*incident E P x y := by
  unfold vertical incident
  simp only [Matrix.one_apply]
  split_ifs <;> field_simp <;> ring
theorem exit_support (x : X) (hx : ¬E x) (y : X) (hy : ¬E y) : incident E P x y=0 := by
  simp [incident,cross,hx,hy]

/-- Exact frozen t-step row from a vertex in terms of the graph's actual one-step incident edge law. -/
theorem vertex_closed (x : X) (hx : ¬E x) (hm : exitMass E P x≠0) (t : ℕ) :
    ((frozen E (vertical E P))^t) x = fun y =>
      (1-exitMass E P x)^t*(1 : Matrix X X ℝ) x y +
      (1-(1-exitMass E P x)^t)*incident E P x y :=
  frozen_vertex E (vertical E P) x hx _ _ (exit_row E P x hm) (exit_support E P x hx) t

#print axioms vertex_closed
end LeafSplit
