import DenseGenerator
import DiscreteWindow
open Filter Topology UrnWindow
namespace HubDense
noncomputable section

def survival (g : Degrees) (c : ℝ) (i : ℕ) := (1-g.step i)^(g.time .halfLogN c i)

theorem sqrt_survival (g : Degrees) (c : ℝ) :
    Tendsto (fun i=>Real.sqrt (g.N i)*survival g c i) atTop (𝓝 (Real.exp (-c))) := by
  have ht := ((tendsto_const_nhds (x:= -c)).sub (g.rounding_limit .halfLogN c)).add (g.log_clock_error .halfLogN c)
  simp only [sub_zero,add_zero] at ht
  have hlog : Tendsto (fun i => Real.log (g.N i)/2+(g.time .halfLogN c i:ℝ)*Real.log (1-g.step i)) atTop (𝓝 (-c)) := by
    apply ht.congr;intro i;dsimp only [Degrees.center,Degrees.tau];ring
  apply (Real.continuous_exp.continuousAt.tendsto.comp hlog).congr'
  filter_upwards [(tendsto_order.mp (g.step_size)).2 1 (by norm_num)] with i hi
  have hn : 0<g.N i := by linarith [(g.sizes i).2.2.1]
  change Real.exp (_+_)=_
  rw [Real.exp_add,Real.exp_half,Real.exp_log hn,Real.exp_nat_mul,Real.exp_log (show 0<1-g.step i from sub_pos.mpr hi)]
  rfl

theorem sqrt_grows (g : Degrees) : Tendsto (fun i=>Real.sqrt (g.N i)) atTop atTop := Real.tendsto_sqrt_atTop.comp g.N_infty

theorem survival_zero (g : Degrees) (c : ℝ) : Tendsto (survival g c) atTop (𝓝 0) := by
  apply ((sqrt_survival g c).div_atTop (sqrt_grows g)).congr
  intro i
  have h : 0<Real.sqrt (g.N i) := Real.sqrt_pos.mpr (by linarith [(g.sizes i).2.2.1])
  field_simp [h.ne']

theorem gap_shift (g : Degrees) (c : ℝ) :
    Tendsto (fun i=>survival g c i*Real.sqrt (g.N i-1)) atTop (𝓝 (Real.exp (-c))) := by
  have h0 : Tendsto (fun i=>(1:ℝ)/g.N i) atTop (𝓝 0) := tendsto_const_nhds.div_atTop g.N_infty
  have hh : Tendsto (fun i=>Real.sqrt (1-1/g.N i)) atTop (𝓝 1) := by
    simpa [Function.comp_def] using (Real.continuous_sqrt.continuousAt.tendsto.comp ((tendsto_const_nhds (x:=(1:ℝ))).sub h0))
  have h := (sqrt_survival g c).mul hh
  rw [mul_one] at h
  apply h.congr;intro i
  have hn : 0<g.N i := by linarith [(g.sizes i).2.2.1]
  rw [mul_right_comm,mul_assoc,mul_comm (survival g c i),←mul_assoc,←Real.sqrt_mul hn.le]
  rw [show g.N i*(1-1/g.N i)=g.N i-1 by field_simp]

lemma sigma_ge {N k : ℝ} (hn : 2≤N) (hk : 0≤k) (h : 2*k≤N) :
    k/(2*Real.sqrt N) ≤ sig N k := by
  have h0 : 0<Real.sqrt N := Real.sqrt_pos.mpr (by linarith)
  have hs : 0<Real.sqrt (N-1) := Real.sqrt_pos.mpr (by linarith)
  have hcmp : Real.sqrt (N-1) ≤ Real.sqrt N := Real.sqrt_le_sqrt (by linarith)
  unfold sig
  rw [div_le_div_iff₀ (by positivity) (mul_pos (by linarith) hs)]
  calc
    _ ≤ k*(N*(Real.sqrt N)) := by gcongr
    _ ≤ _ := by nlinarith [mul_nonneg (mul_nonneg hk (sub_nonneg.mpr h)) h0.le]

theorem dense_gap_error (g : Degrees) (dense : Tendsto g.ratio atTop atTop) (c : ℝ) :
    Tendsto (fun i=>survival g c i*(g.k i)/(sig (g.N i) (g.k i))^2+(survival g c i)^2) atTop (𝓝 0) := by
  have hzero : Tendsto (fun i=>survival g c i*g.k i/(sig (g.N i) (g.k i))^2) atTop (𝓝 0) := by
    have hh := ((tendsto_const_nhds (x:=(4:ℝ))).mul (sqrt_survival g c)).div_atTop dense
    apply squeeze_zero _ _ hh
    · intro i
      have hn := (g.sizes i).2.2.1
      have hstep := (g.step_bound i).trans (show 1/g.N i ≤1 by rw [div_le_one (by linarith)];linarith)
      have hk : 0≤g.k i := by dsimp [Degrees.k];linarith [(g.sizes i).1]
      exact div_nonneg (mul_nonneg (pow_nonneg (sub_nonneg.mpr hstep) _) hk) (sq_nonneg _)
    · intro i
      obtain ⟨hr,hrs,hn,he⟩ := g.sizes i
      have hk : 0<g.k i := by dsimp [Degrees.k];linarith
      have hnk : 2*g.k i≤g.N i := by dsimp [Degrees.k];linarith
      have hN : 0<Real.sqrt (g.N i) := Real.sqrt_pos.mpr (by linarith)
      have hv := sigma_ge (by linarith : 2≤g.N i) hk.le hnk
      have hσ := sigma_pos (by linarith : 1<g.N i) hk (by linarith)
      have hq : 0≤survival g c i := by
        apply pow_nonneg;apply sub_nonneg.mpr
        exact (g.step_bound i).trans ((div_le_one (by linarith)).mpr (by linarith))
      have H := div_le_div_of_nonneg_left (mul_nonneg hq hk.le)
        (sq_pos_of_pos (div_pos hk (by positivity : 0<2*Real.sqrt (g.N i))))
        (pow_le_pow_left₀ (div_nonneg hk.le (by positivity)) hv 2)
      refine H.trans_eq ?_
      unfold Degrees.ratio
      field_simp [hk.ne',hN.ne'];ring
  simpa using hzero.add ((survival_zero g c).pow 2)

#print axioms gap_shift
#print axioms dense_gap_error
end
end HubDense
