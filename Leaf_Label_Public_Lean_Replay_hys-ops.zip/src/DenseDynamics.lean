import DenseGapStart
import DenseEquilibrium
import NormalShift
open Finset HubTransfer JohnsonLower HubMarks OrderedUrn BinaryOverlap PhysicalReduction Filter Topology UrnWindow 
open scoped Matrix Classical
namespace HubDense
noncomputable section

lemma cdf_push {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (π : X→Y) (p : X→ℝ) (f : Y→ℝ) (z : ℝ) :
    finiteCDF (push π p) f z=finiteCDF p (f ∘ π) z := by
  unfold finiteCDF
  have h:=sum_push π p (fun y=>if f y≤z then 1 else 0)
  simpa only [mul_ite,mul_one,mul_zero,Function.comp_apply] using h

theorem high_cdf {N k : ℕ} (K : JohnsonLower.Slice N k) {Q : ℝ} (hN : 0<N) (hQ : Q≠0) (t : ℕ) (z : ℝ) :
    finiteCDF (joint N k Q t) (fun p=>standard N k (high p:ℝ)) z=
      finiteCDF (((walk N k Q)^t) K) (score K) z := by
  let f := fun i : OrderedUrn.Z k=>standard N k (i:ℝ)
  change finiteCDF _ (f ∘ OrderedUrn.high) _ = finiteCDF _ (f ∘ level K) _
  rw [←cdf_push,←cdf_push,high_push K Q t,ordered_push K K hN hQ t,
    show level K K=Fin.last k from Fin.ext (full.mpr rfl)]
theorem low_cdf {N k : ℕ} (K : JohnsonLower.Slice N k) {Q : ℝ} (hN : 0<N) (hQ : Q≠0) (t : ℕ) (z : ℝ) :
    finiteCDF (joint N k Q t) (fun p=>standard N k (low p:ℝ)) z=
      finiteCDF (unif _) (score K) z := by
  let f := fun i : OrderedUrn.Z k=>standard N k (i:ℝ)
  change finiteCDF _ (f ∘ OrderedUrn.low) _ = finiteCDF _ (f ∘ level K) _
  rw [←cdf_push,←cdf_push,low_push K hN hQ t,show push (level K) (unif _)=hyperProb N k from funext (hypergeometric K)]

/-- Dynamical central limit theorem in the dense original discrete Johnson clock, from
the maximal overlap.  The equilibrium normal law is proved by the hypergeometric
Stein identity, then the ordered coupling displaces it by exp(-c). -/
theorem dense_dynamic_cdf (g : Degrees) (dense : Tendsto g.ratio atTop atTop) (c : ℝ)
    (K : ∀i,JohnsonLower.Slice (g.population i) (g.ballCount i)) (z : ℝ) :
    Tendsto (fun i=>∑ T,if score (K i) T≤z then
      ((walk (g.population i) (g.ballCount i) (g.Q i))^(g.time .halfLogN c i)) (K i) T else 0)
      atTop (𝓝 (NormalShift.F 0 (z-Real.exp (-c)))) := by
  let t := g.time .halfLogN c
  let p := fun i => joint (g.population i) (g.ballCount i) (g.Q i) (t i)
  let f := fun i (x : OrderedUrn.Pair (g.ballCount i))=>standard (g.N i) (g.ballCount i) (high x:ℝ)
  let l := fun i (x : OrderedUrn.Pair (g.ballCount i))=>standard (g.N i) (g.ballCount i) (low x:ℝ)
  let shift := fun i=>survival g c i*Real.sqrt (g.N i-1)
  let err := fun i=>survival g c i*g.k i/(sig (g.N i) (g.k i))^2+(survival g c i)^2
  have size (i : ℕ) : 2<g.population i ∧ 2*g.ballCount i≤g.population i ∧ 0<g.ballCount i := by
    have h:=g.two i;have h':=g.small i;unfold Degrees.population Degrees.ballCount;omega
  have hn (i) : 0<g.population i := by have:=size i;omega
  have hd : ∀ i, (∑x,p i x*(f i x-l i x-shift i)^2) ≤ err i := by
    intro i
    have M := actual_gap_mse (K i) (size i).1 (size i).2.2 (size i).2.1 (g.clk_pos i) (g.clock_square i)
      OrderedUrn.start OrderedUrn.high_start OrderedUrn.low_start (t i)
    simpa only [p,OrderedUrn.joint,f,l,shift,err,survival,Degrees.step,g.ball_cast] using M
  have hCDF (x : ℝ) : Tendsto (fun i => finiteCDF (p i) (l i) x) atTop (𝓝 (NormalShift.F 0 x)) := by
    apply (StationaryUrn.dense_cdf g dense K x).congr
    intro i
    exact (low_cdf (K i) (hn i) (g.clk_pos i).ne' (t i) x).symm
  have hp (i) := OrderedUrn.joint_nonneg (size i).2.1 (g.clk_pos i) (g.clock_square i) (t i)
  have ht (i) := OrderedUrn.joint_sum (K i) (size i).2.1 (g.clk_pos i) (g.clock_square i) (t i)
  have hh := cdf_slutsky p f l hp ht shift _ (gap_shift g c) err (dense_gap_error g dense c) hd
    (NormalShift.F 0) (continuous_iff_continuousAt.mpr (fun x=>(NormalShift.deriv_cdf 0 x).continuousAt)) hCDF z
  apply hh.congr;intro i
  exact high_cdf (K i) (hn i) (g.clk_pos i).ne' (t i) z

#print axioms dense_dynamic_cdf
end
end HubDense
