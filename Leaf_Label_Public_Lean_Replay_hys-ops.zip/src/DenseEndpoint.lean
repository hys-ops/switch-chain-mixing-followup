import NormalShift
import RealThreshold
import DiscreteWindow
import JohnsonTV
import DenseModes
open Filter Topology Set Finset ProbabilityTheory HubTransfer JohnsonLower LeafDrift
noncomputable section
namespace RealThreshold
variable {X:Type*} [Fintype X]

lemma mono (r:X→ℕ) (μ σ:ℝ) (p:X→ℝ) (hp:∀j,0≤p j) : Monotone fun x=>cdf r μ σ x p := by
  intro x y h
  apply sum_le_sum;intro j _
  by_cases h1 : ((r j:ℝ)-μ)/σ ≤ x
  · simp [h1,h1.trans h]
  · by_cases h2 : ((r j:ℝ)-μ)/σ ≤ y <;> simp [h1,h2,hp]

lemma range (r:X→ℕ) (μ σ x:ℝ) (p:X→ℝ) (hp:∀j,0≤p j) (h:∑j,p j=1) :
    cdf r μ σ x p∈Set.Icc 0 1 := by
  constructor
  · apply sum_nonneg;intro j _;split <;> simp [hp]
  · rw [←h];apply sum_le_sum;intro j _;split <;> simp [hp]

lemma normal_uniform {D:ℕ→ℝ→ℝ} {m:ℝ}
    (hm:∀i,Monotone (D i)) (hr : ∀i x, D i x∈Set.Icc 0 1)
    (hp:∀x,Tendsto (fun i=>D i x) atTop (𝓝 (NormalShift.F m x)))
    {ε:ℝ} (he:0<ε) : ∀ᶠ i in atTop,∀x,|D i x-NormalShift.F m x|<ε :=
  LimitCDF.uniform hm (monotone_cdf _) (continuous_iff_continuousAt.mpr (fun x=>(NormalShift.deriv_cdf m x).continuousAt)) hr
    (fun x=>⟨cdf_nonneg _ x,cdf_le_one _ x⟩) (tendsto_cdf_atBot _) (tendsto_cdf_atTop _) hp he

/-- Pointwise overlap CLTs imply a TV limit when the finite likelihood difference
changes sign once. Both the maximizing threshold and the state space may vary. -/
theorem from_two_cdfs (D S : ℕ→ℝ→ℝ) (A : ℕ→ℝ) {m:ℝ} (hm:0≤m)
    (md:∀i,Monotone (D i)) (ms:∀i,Monotone (S i))
    (rd:∀i x,D i x∈Set.Icc 0 1) (rs:∀i x,S i x∈Set.Icc 0 1)
    (hd:∀x,Tendsto (fun i=>D i x) atTop (𝓝 (NormalShift.F m x)))
    (hs:∀x,Tendsto (fun i=>S i x) atTop (𝓝 (NormalShift.F 0 x)))
    (hit:∀i,∃x,A i=S i x-D i x) (bound:∀i x,S i x-D i x≤A i) :
    Tendsto A atTop (𝓝 (2*NormalShift.F 0 (m/2)-1)) := by
  apply Metric.tendsto_nhds.mpr
  intro ε hε
  filter_upwards [normal_uniform md rd hd (show 0<ε/3 by linarith),
    normal_uniform ms rs hs (show 0<ε/3 by linarith)] with i di si
  obtain ⟨x,hx⟩ := hit i
  obtain ⟨eq,ub⟩ := NormalShift.normal_peak hm
  have up := ub x
  unfold NormalShift.gap at eq up
  have dx := abs_lt.mp (di x)
  have sx := abs_lt.mp (si x)
  have dm := abs_lt.mp (di (m/2))
  have sm := abs_lt.mp (si (m/2))
  rw [Real.dist_eq,abs_lt]
  constructor
  · linarith [bound i (m/2),dm.2,sm.1]
  · linarith [dx.1,sx.2]

end RealThreshold
namespace UrnWindow.Degrees

/-- The discrete binary TV at the actual quartet clock. The hypotheses are exactly
the stationary and dynamic pointwise CLTs on the true standardized overlap. -/
theorem dense_binary_of_cdfs (g:Degrees) (c:ℝ)
    (K : ∀ i,Slice (g.population i) (g.ballCount i))
    (stationary : ∀x:ℝ,Tendsto (fun i=>∑T,if HubDense.score (K i) T≤x then unif _ T else 0)
      atTop (𝓝 (NormalShift.F 0 x)))
    (dynamic : ∀x:ℝ,Tendsto (fun i=>∑T,if HubDense.score (K i) T≤x then
      ((HubMarks.walk (g.population i) (g.ballCount i) (g.Q i))^(g.time .halfLogN c i)) (K i) T else 0)
      atTop (𝓝 (NormalShift.F 0 (x-Real.exp (-c))))) :
    Tendsto (fun i=> tv (((HubMarks.walk (g.population i) (g.ballCount i) (g.Q i))^(g.time .halfLogN c i)) (K i)) (unif _))
      atTop (𝓝 (gaussian c)) := by
  let p (i : ℕ) := ((HubMarks.walk (g.population i) (g.ballCount i) (g.Q i))^(g.time .halfLogN c i)) (K i)
  let rank (i : ℕ) : Slice (g.population i) (g.ballCount i) → ℕ := JohnsonProfile.overlap (K i).val
  let μ (i : ℕ) := HubDense.mu (g.N i) (g.ballCount i)
  let σ (i : ℕ) := HubDense.sig (g.N i) (g.ballCount i)
  let D (i : ℕ) (x:ℝ) := RealThreshold.cdf (rank i) (μ i) (σ i) x (p i)
  let S (i : ℕ) (x:ℝ) := RealThreshold.cdf (rank i) (μ i) (σ i) x (unif _)
  have cap (i:ℕ) : (g.ballCount i:ℝ)*(g.N i-g.ballCount i)≤g.Q i := by
    nlinarith [sq_nonneg (g.N i-(g.ballCount i:ℝ)),sq_nonneg (g.ballCount i:ℝ),clock_square g i]
  have hp (i : ℕ) := stochastic_pow (kernel_stoch (N:=g.population i) (s:=g.ballCount i) (clk_pos g i) (cap i)) (g.time .halfLogN c i)
  have uniform_mass (i : ℕ) : ∑ S : Slice (g.population i) (g.ballCount i),unif _ S=1 := by
    letI : Nonempty (Slice (g.population i) (g.ballCount i)) := ⟨K i⟩
    simp only [unif,sum_const,card_univ,nsmul_eq_mul,one_div]
    exact mul_inv_cancel₀ (by exact_mod_cast Fintype.card_ne_zero)
  have pos (i:ℕ):0<σ i := by
    dsimp [σ,HubDense.sig]
    rw [ball_cast]
    obtain ⟨hr,hs,hn,he⟩ := sizes g i
    apply div_pos
    · exact mul_pos (by dsimp [k];linarith) (by dsimp [k];linarith)
    · exact mul_pos (by linarith) (Real.sqrt_pos.mpr (by linarith))
  have exacttv (i:ℕ) := JohnsonProfile.tv_is_overlap_tail (K i) (clk_pos g i) (clock_square g i) (g.time .halfLogN c i)
  have mx (i:ℕ) : (∃ x, tv (p i) (unif _)=S i x-D i x) ∧ ∀x,S i x-D i x≤tv (p i) (unif _) := by
    obtain ⟨⟨n,_,hn⟩,hb⟩ := exacttv i
    exact RealThreshold.cdf_max _ _ _ (((hp i).2 (K i)).trans (uniform_mass i).symm) _ _ _ (pos i) ⟨n,hn⟩ hb
  change Tendsto (fun i=>tv (p i) (unif _)) atTop (𝓝 (2*NormalShift.F 0 (Real.exp (-c)/2)-1))
  apply RealThreshold.from_two_cdfs D S _ (Real.exp_pos _).le
    (fun i=>RealThreshold.mono _ _ _ _ ((hp i).1 (K i)))
    (fun i=>RealThreshold.mono _ _ _ _ (fun j=>by unfold unif;positivity))
    (fun i x=>RealThreshold.range _ _ _ _ _ ((hp i).1 (K i)) ((hp i).2 (K i)))
    (fun i x=>RealThreshold.range _ _ _ _ _ (fun j=>by unfold unif;positivity) (uniform_mass i))
    _ stationary (fun i=>(mx i).1) (fun i=>(mx i).2)
  intro x
  rw [NormalShift.translate]
  exact dynamic x

#print axioms dense_binary_of_cdfs
end UrnWindow.Degrees
