import StationaryScales
import GaussianODE
import StationaryLevy
open Filter Topology UrnWindow HubDense JohnsonLower Finset MeasureTheory ProbabilityTheory HubTransfer
noncomputable section
namespace StationaryUrn
variable {N k : ℕ}
theorem char_error (K : Slice N k) (hN : 1<N) (hk : 0<k) (hkN : k<N) (θ : ℝ) (hθ : |θ|≤sig N k) :
    ‖char K θ-(Real.exp (-(θ^2)/2):ℂ)‖ ≤ |θ| *(θ^2/sig N k+|θ| *noise N) := by
  apply LeafNormal.ode_bound (char K) (derivative K) (char_deriv K) (char_zero K) θ
  intro u hu
  apply (residual K hN hk hkN u (hu.trans hθ)).trans
  have hv : 0<sig N k := sigma_pos (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast hN) (by exact_mod_cast hk) (by exact_mod_cast hkN)
  have hn : 0≤noise N := by unfold noise; positivity
  exact add_le_add (div_le_div_of_nonneg_right ((sq_le_sq).mpr hu) hv.le) (mul_le_mul_of_nonneg_right hu hn)

theorem dense_char (g : Degrees) (dense : Tendsto g.ratio atTop atTop)
    (K : ∀i,Slice (g.population i) (g.r i-1)) (θ : ℝ) :
    Tendsto (fun i=>char (K i) θ) atTop (𝓝 (Real.exp (-(θ^2)/2):ℂ)) := by
  have hs := sd_infty g dense
  have hd := ((tendsto_const_nhds (x:=θ^2)).div_atTop hs).add ((tendsto_const_nhds (x:=|θ|)).mul (noise_zero g))
  have hb := (tendsto_const_nhds (x:=|θ|)).mul hd
  simp only [mul_zero,add_zero] at hb
  apply tendsto_iff_dist_tendsto_zero.mpr
  simp only [dist_eq_norm]
  apply squeeze_zero' (Filter.Eventually.of_forall (fun _ => norm_nonneg _)) _ hb
  filter_upwards [hs.eventually_ge_atTop |θ|] with i hi
  obtain ⟨hn,hk,hkn,_⟩ := dense_sizes g i
  exact char_error (K i) hn hk hkn θ hi

/-- Dense hypergeometric CLT for the overlap of a uniform, fixed-size labeled
subset with any deterministic initial subset of the same size. -/
theorem dense_cdf (g : Degrees) (dense : Tendsto g.ratio atTop atTop)
    (K : ∀i,Slice (g.population i) (g.r i-1)) (x : ℝ) :
    Tendsto (fun i=>∑ S : Slice (g.population i) (g.r i-1),
      if standard (g.population i) (g.r i-1:ℕ) (HubMarks.overlap (K i) S)≤x then unif _ S else 0)
      atTop (𝓝 (cdf (gaussianReal 0 1) x)) :=
  FiniteLevy.equilibrium_of_char K (dense_char g dense K) x

#print axioms char_error
#print axioms dense_char
#print axioms dense_cdf
end StationaryUrn
