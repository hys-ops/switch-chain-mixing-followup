import CouponJoint
import OrderedAdapter
import StationaryStein
import GapCDF
open Finset HubTransfer JohnsonLower HubMarks BinaryOverlap PhysicalReduction 
open scoped Matrix Classical
namespace HubDense
noncomputable section

theorem sum_push {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (b : X→Y) (p : X→ℝ) (f : Y→ℝ) :
    (∑y,push b p y*f y)=∑x,p x*f (b x) := by
  simp only [push,sum_mul,ite_mul,zero_mul];rw [sum_comm]
  apply sum_congr rfl;intro x _;simp

theorem hyper_expect {N k : ℕ} (K : JohnsonLower.Slice N k) (f : OrderedUrn.Z k→ℝ) :
    (∑ j,hyperProb N k j*f j)=∑x:JohnsonLower.Slice N k,unif _ x*f (level K x) := by
  have he : push (level K) (unif _)=hyperProb N k := funext (hypergeometric K)
  rw [←he,sum_push]

theorem actual_gap_mse {N k : ℕ} (K : JohnsonLower.Slice N k) {Q : ℝ} (hn : 2<N) (hk : 0<k)
    (hnk : 2*k≤N) (hq : 0<Q) (hQ : (N:ℝ)^2≤Q)
    (start : OrderedUrn.Z k→OrderedUrn.Pair k) (hi : ∀j,OrderedUrn.high (start j)=Fin.last k)
    (lo : ∀j,OrderedUrn.low (start j)=j) (t : ℕ) :
    (∑ x,mixRow (hyperProb N k) start ((OrderedUrn.P N k Q)^t) x *
      (standard N k (OrderedUrn.high x : ℝ)-standard N k (OrderedUrn.low x : ℝ)-
       (1-(N:ℝ)/Q)^t*Real.sqrt (N-1:ℝ))^2) ≤
      (1-(N:ℝ)/Q)^t*k/(sig N k)^2+((1-(N:ℝ)/Q)^t)^2 := by
  open OrderedUrn in
  have D0 (x : OrderedUrn.Pair k) : 0≤OrderedUrn.diff x :=
    sub_nonneg.mpr (by exact_mod_cast (OrderedUrn.low_le x))
  have D1 (x : OrderedUrn.Pair k) : 0≤OrderedUrn.diff x*(OrderedUrn.diff x-1) := by
    by_cases h : OrderedUrn.low x=OrderedUrn.high x
    · simp [OrderedUrn.diff,h]
    · have hh : (OrderedUrn.low x).val+1≤(OrderedUrn.high x).val :=
        Nat.succ_le_of_lt (lt_of_le_of_ne (OrderedUrn.low_le x) (fun e=>h (Fin.ext e)))
      have h1 : ((OrderedUrn.low x).val:ℝ)+1≤((OrderedUrn.high x).val:ℝ) := by exact_mod_cast hh
      exact mul_nonneg (D0 _) (by unfold OrderedUrn.diff;linarith)
  have hz : 0≤1-2*((N:ℝ)/Q) := by
    have h1 : (2:ℝ)<N := by exact_mod_cast hn
    rw [←mul_div_assoc,sub_nonneg,div_le_one hq]
    nlinarith only [hQ,h1,sq_nonneg ((N:ℝ)-1)]
  have hm1 := fun x:OrderedUrn.Pair k => congrFun (OrderedUrn.diff_eigen (N:=N) (k:=k) (Q:=Q)) x
  have hm2 := fun x:OrderedUrn.Pair k => congrFun (OrderedUrn.diff_factorial_eigen (N:=N) (k:=k) (Q:=Q)) x
  have hx (j : OrderedUrn.Z k) : OrderedUrn.diff (start j)=(k:ℝ)-j := by simp [OrderedUrn.diff,hi,lo]
  have hσ := sigma_pos (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast (show 1<N by omega)) (by exact_mod_cast hk) (by exact_mod_cast (show k<N by omega))
  have h1 : ∑j,hyperProb N k j=1 := OrderedUrn.hyper_sum K
  have hm : ∀j,0≤hyperProb N k j := by intro j;unfold hyperProb;positivity
  let A := (k:ℝ)-mu N k
  have v : (∑j,hyperProb N k j*(OrderedUrn.diff (start j)-A)^2)≤(sig N k)^2 := by
    rw [hyper_expect K]
    have hv := StationaryUrn.centered_variance K (by omega)
    have he : ∀j : OrderedUrn.Z k, (OrderedUrn.diff (start j)-A)^2=(StationaryUrn.loc N k j.val)^2 :=
      fun j => by rw [hx];dsimp [A,mu,StationaryUrn.loc];ring
    simp_rw [he]
    change StationaryUrn.mean K (fun z=>(StationaryUrn.loc N k z)^2)≤_
    rw [hv,sigma_square (by exact_mod_cast (show 1<N by omega))]
    have hNr : (N:ℝ)≠0 := by exact_mod_cast (show N≠0 by omega)
    field_simp [hNr];ring_nf;exact le_rfl
  have hc := death_mixture _ (OrderedUrn.P_stoch hnk hq hQ) OrderedUrn.diff ((N:ℝ)/Q) (by positivity) hz
    D0 D1 hm1 hm2 _ hm h1 start A k (sig N k) hσ (fun j=>by rw [hx];simp) v t
  have he (x : OrderedUrn.Pair k) :
      standard N k (OrderedUrn.high x:ℝ)-standard N k (OrderedUrn.low x:ℝ)-(1-(N:ℝ)/Q)^t*Real.sqrt (N-1:ℝ)
      = (OrderedUrn.diff x-(1-(N:ℝ)/Q)^t*A)/sig N k := by
    rw [←initial_standard (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast (show 1<N by omega)) (by exact_mod_cast hk) (by exact_mod_cast (show k<N by omega))]
    unfold standard OrderedUrn.diff; dsimp [A];ring
  simpa only [he] using hc

#print axioms actual_gap_mse
end
end HubDense
