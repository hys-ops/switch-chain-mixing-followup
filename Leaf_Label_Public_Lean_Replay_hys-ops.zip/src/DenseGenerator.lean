import OverlapStep
import Mathlib.Analysis.Complex.Exponential
open Finset JohnsonLower HubMarks SparseUrn
open scoped Matrix
namespace HubDense
noncomputable section
def mu (N k : ℝ) := k^2/N
def sig (N k : ℝ) := k*(N-k)/(N*Real.sqrt (N-1))
def standard (N k : ℝ) (x : ℝ) := (x-mu N k)/sig N k
def ell (N : ℝ) := 2*(1-1/N)
def slope (N k : ℝ) := (1-2*k/N)^2/sig N k
def bracket (N k y : ℝ) := ell N+slope N k*y+(2/N)*y^2

lemma sigma_pos {N k : ℝ} (hN : 1<N) (hk : 0<k) (hNk : k<N) : 0<sig N k := by
  unfold sig;exact div_pos (mul_pos hk (sub_pos.mpr hNk)) (mul_pos (by linarith) (Real.sqrt_pos.mpr (by linarith)))

lemma sigma_square {N k : ℝ} (hN : 1<N) : (sig N k)^2 = k^2*(N-k)^2/(N^2*(N-1)) := by
  simp only [sig,div_pow,mul_pow,Real.sq_sqrt (show 0≤N-1 by linarith)]

lemma initial_standard {N k : ℝ} (hN : 1<N) (hk : 0<k) (hNk : k<N) :
    standard N k k=Real.sqrt (N-1) := by
  have hsq : 0<Real.sqrt (N-1) := Real.sqrt_pos.mpr (by linarith)
  unfold standard mu sig;field_simp [hk.ne',(sub_pos.mpr hNk).ne',(show N≠0 by linarith),hsq.ne']

/-- The exact normalized drift and bracket of the Bernoulli–Laplace overlap process. -/
theorem rates {N : ℝ} {k x : ℕ} (hN : 1<N) (hk : 0<(k:ℝ)) (hNk : (k:ℝ)<N) :
    (birth N k x-death N k x)/sig N k = -standard N k x ∧
    (birth N k x+death N k x)/(sig N k)^2 = bracket N k (standard N k x) := by
  have hn : N≠0 := by linarith
  have hs := (sigma_pos hN hk hNk).ne'
  have hv := sigma_square (k:=(k:ℝ)) hN
  constructor
  · unfold birth death standard mu;field_simp;ring
  · apply (div_eq_iff (pow_ne_zero 2 hs)).mpr
    unfold bracket ell slope standard mu birth death
    have hn1 : N-1≠0 := by linarith
    field_simp [hs,hn,hn1] at hv ⊢
    linear_combination -2*hv

/-- The first two generator modes with stationary variance normalization. -/
theorem gen_linear {N : ℝ} {k : ℕ} (hN : 1<N) (hk : 0<(k:ℝ)) (hNk : (k:ℝ)<N) (x : ℕ) :
    generator N k (fun z=>standard N k z) x = -standard N k x := by
  rw [← (rates (x:=x) hN hk hNk).1]
  unfold generator standard
  cases x with
  | zero => simp [death];ring
  | succ x => simp only [Nat.succ_sub_one,Nat.cast_succ,Nat.cast_add,Nat.cast_one];ring

theorem gen_square {N : ℝ} {k : ℕ} (hN : 1<N) (hk : 0<(k:ℝ)) (hNk : (k:ℝ)<N) (x : ℕ) :
    generator N k (fun z=>(standard N k z)^2) x =
        -ell N*(standard N k x)^2+slope N k*(standard N k x)+ell N := by
  let y := standard N k x
  let d := 1/sig N k
  have hup : standard N k (x+1:ℕ)=y+d := by simp [y,d,standard];ring
  have split : generator N k (fun z=>(standard N k z)^2) x =
     2*y*((birth N k x-death N k x)*d)+(birth N k x+death N k x)*d^2 := by
    simp only [generator,hup]
    cases x with
    | zero => simp [death,y];ring
    | succ x =>
      have hd : standard N k (x:ℝ)=standard N k (x+1:ℕ)-d := by simp [standard,d];ring
      simp only [Nat.succ_sub_one];rw [hd];dsimp [y];ring
  obtain ⟨h1,h2⟩ := rates (x:=x) hN hk hNk
  change (birth N k x-death N k x)/sig N k = -y at h1
  change (birth N k x+death N k x)/(sig N k)^2=bracket N k y at h2
  change _ = -ell N*y^2+slope N k*y+ell N
  rw [split,show (birth N k x-death N k x)*d= -y from by simpa [d,div_eq_mul_inv] using h1,
      show (birth N k x+death N k x)*d^2=bracket N k y from by simpa [d,div_eq_mul_inv] using h2]
  simp only [bracket,ell];ring

end
end HubDense
