import DenseEndpoint
import DenseDynamics
import GrowingWindow
open Filter Topology OAI.Problem315 JohnsonLower HubTransfer
namespace UrnWindow.Degrees
noncomputable section

/-- The true quartet-clock binary walk, with neither urn profile nor CLT hypothesis. -/
theorem dense_binary_profile (g:Degrees) (dense:Tendsto g.ratio atTop atTop) (c:ℝ)
    (K : ∀ i,Slice (g.population i) (g.ballCount i)) :
    Tendsto (fun i=> tv (((HubMarks.walk (g.population i) (g.ballCount i) (g.Q i))^(g.time .halfLogN c i)) (K i)) (unif _))
      atTop (𝓝 (gaussian c)) :=
  dense_binary_of_cdfs g c K (StationaryUrn.dense_cdf g dense K) (HubDense.dense_dynamic_cdf g dense c K)

private noncomputable def first_set (N k:ℕ) (hk:k≤N) : Slice N k :=
  ⟨Finset.univ.map (Fin.castLEEmb hk),by simp⟩

/-- The original finite graph chains, uniformly over all labeled starts, with the
quartet proposal clock, explicit floor, and no external urn-limit hypotheses. -/
theorem dense_graph_uniform (g:Degrees) (dense:Tendsto g.ratio atTop atTop)
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (sp : ∀ i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (c ε:ℝ) (he:0<ε) : ∀ᶠ i in atTop,∀G:GraphState (g.population i+2) (d i),
      |tvDistanceFrom _ (d i) (g.time .halfLogN c i) G - gaussian c|<ε := by
  let K (i:ℕ) := first_set (g.population i) (g.ballCount i) (by unfold population ballCount;omega)
  have btv := Metric.tendsto_nhds.mp (dense_binary_profile g dense c K) (ε/2) (by linarith)
  have err := (tendsto_order.mp (PhysicalReduction.window_envelope_zero g .halfLogN c)).2 (ε/2) (by linarith)
  filter_upwards [btv,err] with i hv hi
  rw [Real.dist_eq] at hv
  intro G
  have hn : 4≤g.population i+2 := by unfold population;have := g.two i;omega
  have h := (PhysicalReduction.all_starts (sp i) hn (g.two i) ((g.two i).trans (g.small i)) G (K i) (g.time .halfLogN c i)).trans
    (PhysicalReduction.window_envelope g .halfLogN c i (sp i))
  change |PhysicalReduction.Bdist (g.population i+2) (g.r i) (g.s i) (g.time .halfLogN c i) (K i)-gaussian c|<ε/2 at hv
  exact (abs_sub_le _ (PhysicalReduction.Bdist _ _ _ _ (K i)) _).trans_lt ((add_le_add h le_rfl).trans_lt (by linarith))

#print axioms dense_binary_profile
#print axioms dense_graph_uniform
end
end UrnWindow.Degrees
