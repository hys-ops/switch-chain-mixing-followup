import DenseGenerator
open Finset HubTransfer JohnsonLower HubMarks SparseUrn
open scoped Matrix
namespace HubDense
noncomputable section

def mixSlope (N k : ℝ) := slope N k/(ell N-1)
def mode2 (N k y : ℝ) := y^2-1-mixSlope N k*y

lemma ell_ne_one {N : ℝ} (hN : 2<N) : ell N-1≠0 := by
  unfold ell;intro h;field_simp [show N≠0 by linarith] at h;linarith

lemma gen_second_mode {N : ℝ} {k : ℕ} (hN : 2<N) (hk : 0<(k:ℝ)) (hNk : (k:ℝ)<N) (x : ℕ) :
    generator N k (fun z=>mode2 N k (standard N k z)) x =
      -ell N*mode2 N k (standard N k x) := by
  let f := fun z : ℕ => standard N k z
  let d := mixSlope N k
  have he : generator N k (fun z=>mode2 N k (f z)) x =
      generator N k (fun z=>(f z)^2) x - d*generator N k f x := by
    unfold generator mode2;dsimp only [d];ring
  change generator N k (fun z=>mode2 N k (f z)) x=_
  rw [he];dsimp only [f]
  rw [gen_square (by linarith) hk hNk,gen_linear (by linarith) hk hNk]
  unfold mode2;dsimp [d,mixSlope]
  field_simp [ell_ne_one hN];ring

lemma eigen_power {X : Type*} [Fintype X] [DecidableEq X] (P : Matrix X X ℝ) (v : X→ℝ) (q : ℝ)
    (he : ∀x,(P *ᵥ v) x=q*v x) (t : ℕ) (x : X) : (P^t *ᵥ v) x=q^t*v x := by
  induction t with
  | zero => simp
  | succ t ih =>
    rw [pow_succ,←Matrix.mulVec_mulVec,show P *ᵥ v=q • v from funext he,Matrix.mulVec_smul]
    change q*((P^t *ᵥ v) x)=_
    rw [ih,pow_succ];ring

variable {N k : ℕ}
def score (K T : Slice N k) := standard N k (overlap K T)

theorem mean_all (hN : 2<N) (hk : 0<k) (hNk : k<N) (Q : ℝ) (hQ : Q≠0) (K T : Slice N k) (t : ℕ) :
    ((walk N k Q)^t *ᵥ score K) T = (1-(N:ℝ)/Q)^t*score K T := by
  apply eigen_power;intro U
  have he := overlap_row K U Q (by omega) hQ (fun x=>standard N k x)
  rw [gen_linear (by exact_mod_cast (show 1<N by omega)) (by exact_mod_cast hk) (by exact_mod_cast hNk)] at he
  change (walk N k Q *ᵥ (fun T=>standard N k (overlap K T))) U=_
  rw [he];unfold score;ring

theorem second_all (hN : 2<N) (hk : 0<k) (hNk : k<N) (Q : ℝ) (hQ : 0<Q)
    (cap : (k:ℝ)*((N:ℝ)-k)≤Q) (K T : Slice N k) (t : ℕ) :
    ((walk N k Q)^t *ᵥ (fun S=>(score K S)^2)) T =
       1 + (1-ell N*N/Q)^t*(mode2 N k (score K T)) +
        mixSlope N k*((1-(N:ℝ)/Q)^t*score K T) := by
  let P := walk N k Q
  let f := score K
  let d := mixSlope N k
  have hp : Stochastic (P^t) := stochastic_pow (kernel_stoch hQ cap) t
  have h1 := mean_all hN hk hNk Q hQ.ne' K T t
  have h2 : (P^t *ᵥ (fun U=>mode2 N k (f U))) T = (1-ell N*N/Q)^t * mode2 N k (f T) := by
    apply eigen_power
    intro U
    have H := overlap_row K U Q (by omega) hQ.ne' (fun x=>mode2 N k (standard N k x))
    rw [gen_second_mode (by exact_mod_cast hN) (by exact_mod_cast hk) (by exact_mod_cast hNk)] at H
    change _=_
    dsimp [P,f,score];rw [H];ring
  have ht : (P^t *ᵥ (fun U=>mode2 N k (f U))) T =
      (P^t *ᵥ (fun U=>(f U)^2)) T-1-d*((P^t *ᵥ f) T) := by
    simp [Matrix.mulVec,dotProduct,mode2,mul_sub,sum_sub_distrib,hp.2,
      mul_left_comm _ (mixSlope _ _),←Finset.mul_sum,d]
  change (P^t *ᵥ f) T=_ at h1
  rw [h1,h2] at ht
  change (P^t *ᵥ (fun U=>(f U)^2)) T=_
  linarith

theorem score_self (hN : 2<N) (hk : 0<k) (hNk : k<N) (K : Slice N k) : score K K=Real.sqrt (N-1:ℝ) := by
  simp only [score,overlap,inter_self,K.property]
  exact initial_standard (by exact_mod_cast (show 1<N by omega)) (by exact_mod_cast hk) (by exact_mod_cast hNk)
#print axioms mean_all
#print axioms second_all
end
end HubDense
