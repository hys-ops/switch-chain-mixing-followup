import RestrictedTV
open Finset HubTransfer
open scoped Matrix Classical
noncomputable section
namespace RestrictedTV
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

/-- An observable with uniform marginal. Densities pulled back from this
    observable have exactly the same TV distance from equilibrium. -/
theorem density_tv (π : X→Y) (p : X→ℝ) (hp : ∀x,0≤p x) (m : ℝ) (hm : 0<m)
    (uniform : ∀y,push π p y=m) (b : Y→ℝ) :
    tv (fun x=>p x * (b (π x)/m)) p = tv b (fun _ => m) := by
  unfold tv; congr 1
  let f := fun y => |b y/m-1|
  have he (x) : |p x*(b (π x)/m)-p x|=p x*f (π x) := by
    rw [show p x*(b (π x)/m)-p x=p x*(b (π x)/m-1) by ring,abs_mul,abs_of_nonneg (hp _)]
  simp_rw [he]
  calc
    _ = ∑ y:Y,push π p y*f y := by
      simp only [push,Finset.sum_mul]
      rw [sum_comm];apply sum_congr rfl;intro x _
      simp only [ite_mul,zero_mul,Finset.sum_ite_eq,mem_univ,ite_true]
    _ = _ := by
      apply sum_congr rfl;intro y _;rw [uniform]
      dsimp [f];rw [←abs_of_pos hm,←abs_mul,abs_of_pos hm]
      congr 1;field_simp

/-- A fiber diameter for a reversible heat kernel suffices to bound the lost TV.
    The binary kernel B here is the exact row projection, with a flat reference
    and opposite directions identified by reversibility. -/
theorem diameter_density (π : X→Y) (p : X→ℝ) (hp : ∀x,0≤p x)
    (K : Matrix X X ℝ) (B : Matrix Y Y ℝ)
    (m : ℝ) (hm : 0<m) (uniform : ∀y,push π p y=m)
    (balance : ∀i y,p i*K i y=p y*K y i) (bsym : ∀i j,B i j=B j i)
    (project : ∀y,p y≠0 → push π (K y)=B (π y))
    {x : X} (hx : p x≠0) {e : ℝ}
    (diam : ∀i,p i≠0→π i=π x→tv (K i) (K x)≤e) :
    tv (K x) (fun y=>p y*(B (π x) (π y)/m)) ≤e := by
  let w := fun i => if π i=π x then p i/m else 0
  have hw (i) : 0≤w i := by
    dsimp [w];split
    · exact div_nonneg (hp _) hm.le
    · exact le_rfl
  have hw1 : ∑ i,w i=1 := by
    calc
      _ = push π p (π x)/m := by simp [w,push,Finset.sum_div,ite_div]
      _ = 1 := by rw [uniform,div_self hm.ne']
  have hclose := to_mixture w hw hw1 K (K x) (e:=e) (by
    intro i hi
    by_cases he:π i=π x
    · exact diam i (fun h=>hi (by simp [w,he,h])) he
    · exact False.elim (hi (by simp [w,he])))
  let row := fun y=>∑ i,w i*K i y
  have heq : row=fun y=>p y*(B (π x) (π y)/m) := by
    funext y
    have e1 : row y=p y/m*push π (K y) (π x) := by
      dsimp [row,w,push];rw [Finset.mul_sum]
      apply sum_congr rfl;intro i _
      by_cases h:π i=π x
      · simp only [h,ite_true];have hb:=balance i y;linear_combination hb/m
      · simp [h]
    rw [e1];by_cases hy:p y=0
    · simp [hy]
    · rw [project y hy,bsym (π y) (π x)];ring
  rw [←heq,reverse]
  exact hclose

theorem density_pair (π : X→Y) (p : X→ℝ) (hp : ∀x,0≤p x) (m : ℝ) (hm : 0<m)
    (uniform : ∀y,push π p y=m) (b c : Y→ℝ) :
    tv (fun x=>p x*(b (π x)/m)) (fun x=>p x*(c (π x)/m)) = tv b c := by
  let f := fun y => b y-c y+m
  have H := density_tv π p hp m hm uniform f
  unfold tv at *
  convert H using 3
  · congr 1;dsimp [f];field_simp;ring
  · congr 1;dsimp [f];ring

#print axioms diameter_density
end RestrictedTV
