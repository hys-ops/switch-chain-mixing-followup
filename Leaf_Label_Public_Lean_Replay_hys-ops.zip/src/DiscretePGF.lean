import Immigration
open Finset SparseUrn HubTransfer Filter Topology
open scoped Matrix
namespace CriticalUrn
noncomputable section

def pbase (a z : ℝ) (t : ℕ) := 1-(1-z)*(1-a)^t
def comp (m q z : ℝ) (x : ℕ) := Real.exp (-m*(q-z))*q^x

theorem pbase_bounds {z a : ℝ} (hz : 0≤z) (hz' : z≤1) (ha : 0≤a) (ha' : a≤1) (t:ℕ) :
    z≤pbase a z t ∧ pbase a z t≤1 := by
  unfold pbase
  have h := pow_le_one₀ (sub_nonneg.mpr ha') (by linarith : 1-a≤1) (n:=t)
  constructor <;> nlinarith [mul_le_mul_of_nonneg_left h (sub_nonneg.mpr hz'),mul_nonneg (sub_nonneg.mpr hz') (pow_nonneg (sub_nonneg.mpr ha') t)]

theorem pbase_step (a z : ℝ) (t : ℕ) : pbase a z (t+1) = pbase a z t+a*(1-pbase a z t) := by
  simp only [pbase,pow_succ];ring

theorem weighted_bound {X : Type*} [Fintype X] [DecidableEq X] (P : Matrix X X ℝ)
    (hp : Stochastic P) {f g : X→ℝ} {B : ℝ} (h : ∀x,|f x-g x|≤B) (x : X) :
    |(P*ᵥ f) x-(P*ᵥ g) x|≤B := by
  change |(∑i,P x i*f i)-(∑i,P x i*g i)|≤B
  rw [←sum_sub_distrib];simp_rw [←mul_sub]
  apply (abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑i,P x i*B := by
      apply sum_le_sum;intro i _;rw [abs_mul,abs_of_nonneg (hp.1 x i)];exact mul_le_mul_of_nonneg_left (h i) (hp.1 x i)
    _ = B := by rw [←sum_mul,hp.2,one_mul]

theorem discrete_pgf {X : Type*} [Fintype X] [DecidableEq X] (P : Matrix X X ℝ) (hp : Stochastic P)
    {N a z : ℝ} {k : ℕ} (score : X→ℕ) (hs : ∀x,score x≤k)
    (row : ∀(x:X)(f:ℕ→ℝ),(P *ᵥ (fun y => f (score y))) x = f (score x)+a*generator N k f (score x))
    (hN : 0<N) (ha : 0≤a) (ha' : a≤1) (hz : 0≤z) (hz' : z≤1)
    (t : ℕ) (x : X) :
    |((P^t) *ᵥ (fun y => z^(score y))) x-comp (load N k) (pbase a z t) z (score x)| ≤
      allowance N a k*(pbase a z t-z) := by
  let A := allowance N a k
  let m := load N k
  let v (t:ℕ) := (P^t)*ᵥ (fun x=>z^(score x))
  change |v t x-comp m (pbase a z t) z (score x)| ≤ A*(pbase a z t-z)
  induction t generalizing x with
  | zero => simp [v,pbase,comp]
  | succ t ih =>
    let q := pbase a z t
    let b := a*(1-q)
    let w := Real.exp (-m*(q-z))
    obtain ⟨h0,h1⟩ := pbase_bounds hz hz' ha ha' t
    have hq := hz.trans h0
    have hnon : 0≤m := div_nonneg (sq_nonneg _) hN.le
    have hw : 0≤w := (Real.exp_pos _).le
    have hw' : w≤1 := Real.exp_le_one_iff.mpr (mul_nonpos_of_nonpos_of_nonneg (neg_nonpos.mpr hnon) (sub_nonneg.mpr h0))
    have hA : 0≤A := by dsimp [A,allowance];change 0≤2*k/N+((k:ℝ)^2+m*k+m^2)*a;positivity
    have hb : 0≤b := mul_nonneg ha (sub_nonneg.mpr h1)
    have hpow : v (t+1)=P*ᵥ v t := by dsimp [v];rw [pow_succ',Matrix.mulVec_mulVec]
    have hprev := weighted_bound P hp (f:=v t) (g:=fun y => comp m q z (score y)) (ih) x
    have heq : (P*ᵥ (fun y=>comp m q z (score y))) x =
      w*(q^(score x)+a*generator N k (fun j=>q^j) (score x)) := by
      unfold comp
      change (∑y,P x y*(w*q^(score y)))=_
      simp_rw [mul_left_comm (P x _) w,←mul_sum]
      congr 1;exact row x _
    have hnext : comp m (pbase a z (t+1)) z (score x)=w*(Real.exp (-m*b)*(q+b)^(score x)) := by
      rw [pbase_step];unfold comp
      change Real.exp (-m*(q+b-z))*(q+b)^(score x) = _
      rw [show -m*(q+b-z) = -m*(q-z)+ -m*b by ring,Real.exp_add];dsimp [w];ring
    rw [hpow]
    apply (abs_sub_le _ ((P*ᵥ (fun y => comp m q z (score y))) x) _).trans
    have hstep := single (hx:=hs x) hN ha ha' hq h1
    change |Real.exp (-m*b)*(q+b)^(score x) - _| ≤ A*b at hstep
    rw [pbase_step]
    change _ ≤ A*(q+b-z)
    apply le_trans (b:=A*(q-z)+A*b) _ (by ring_nf; exact le_rfl)
    apply add_le_add hprev
    have hn : comp m (q+b) z (score x)=w*(Real.exp (-m*b)*(q+b)^(score x)) := by simpa only [pbase_step] using hnext
    rw [heq,hn,←mul_sub,abs_mul,abs_of_nonneg hw,abs_sub_comm]
    exact (mul_le_mul_of_nonneg_left hstep hw).trans (by nlinarith [mul_nonneg (sub_nonneg.mpr hw') (mul_nonneg hA hb)])

#print axioms discrete_pgf
end
end CriticalUrn
