import SparseDiscrete
import SparseGraph
open Filter Topology SparseUrn
namespace UrnWindow.Degrees
noncomputable section

def step (g : Degrees) (i : ℕ) := g.N i/g.Q i
lemma step_pos (g : Degrees) (i : ℕ) : 0<g.step i := by
  exact div_pos (by linarith [(sizes g i).2.2.1]) (clk_pos g i)
lemma clock_square (g : Degrees) (i : ℕ) : (g.N i)^2≤g.Q i := by
  have hn := (sizes g i).2.2.1
  have hl := clock_lower g i
  have h4 : 4≤(g.N i)^2 := by nlinarith [sq_nonneg (g.N i-2)]
  nlinarith [mul_nonneg (sq_nonneg (g.N i)) (sub_nonneg.mpr h4)]
lemma step_bound (g : Degrees) (i : ℕ) : g.step i ≤ 1/g.N i := by
  rw [step,div_le_div_iff₀ (clk_pos g i) (by linarith [(sizes g i).2.2.1])]
  nlinarith [clock_square g i]
lemma time_step (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) :
    (g.time z c i:ℝ)*g.step i = g.N i*g.tau z c i := by unfold step tau;ring

lemma log_clock_error (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (fun i => (g.time z c i:ℝ)*Real.log (1-g.step i) + g.N i*g.tau z c i) atTop (𝓝 0) := by
  have hstep : Tendsto g.step atTop (𝓝 0) := step_size g
  have hq : Tendsto (fun i => (g.time z c i:ℝ)*(g.step i)^2) atTop (𝓝 0) := by
    apply squeeze_zero (fun _ => by positivity) _ (tau_zero g z c)
    intro i
    unfold step tau
    rw [div_pow,←mul_div_assoc,div_le_div_iff₀ (sq_pos_of_pos (clk_pos g i)) (clk_pos g i)]
    nlinarith [mul_nonneg (mul_nonneg (Nat.cast_nonneg (α:=ℝ) (g.time z c i)) (clk_pos g i).le) (sub_nonneg.mpr (clock_square g i))]
  have hlow : Tendsto (fun i => -((g.time z c i:ℝ)*(g.step i)^2/(1-g.step i))) atTop (𝓝 0) := by
    simpa using (hq.div ((tendsto_const_nhds (x:=(1:ℝ))).sub hstep) (by norm_num : (1:ℝ)-0≠0)).neg
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlow tendsto_const_nhds
  · filter_upwards [(tendsto_order.mp hstep).2 1 (by norm_num)] with i hi
    have hz : 0<1-g.step i := by linarith
    have h := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hz) (Nat.cast_nonneg (α:=ℝ) (g.time z c i))
    rw [←time_step]
    calc _ = (g.time z c i:ℝ)*(1-(1-g.step i)⁻¹)+(g.time z c i:ℝ)*g.step i := by field_simp [hz.ne'];ring
         _ ≤ _ := by linarith
  · filter_upwards [(tendsto_order.mp hstep).2 1 (by norm_num)] with i hi
    have h := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos (by linarith : 0<1-g.step i))
      (Nat.cast_nonneg (α:=ℝ) (g.time z c i))
    rw [←time_step]
    linarith

def marks (g : Degrees) (j i : ℕ) := g.ballCount i+j

theorem discrete_coupon_limit (g : Degrees) (j : ℕ) (c : ℝ) :
    Tendsto (fun i => (coupon (g.step i) (g.time .logK c i))^(g.marks j i)) atTop
      (𝓝 (Real.exp (-Real.exp (-c)))) := by
  let t := g.time .logK c
  let d := fun i => (1-g.step i)^(t i)
  have hstep : Tendsto g.step atTop (𝓝 0) := step_size g
  have hpos := (tendsto_order.mp hstep).2 1 (by norm_num)
  have hdiff : Tendsto (fun i => (t i:ℝ)*Real.log (1-g.step i)+Real.log (g.k i)) atTop (𝓝 (-c)) := by
    have hh := (log_clock_error g .logK c).sub (rounding_limit g .logK c)
    have hh' := hh.sub (tendsto_const_nhds (x:=c))
    simp only [sub_zero,zero_sub] at hh'
    apply hh'.congr; intro i;dsimp [t,center];ring
  have hm : Tendsto (fun i => g.k i*d i) atTop (𝓝 (Real.exp (-c))) := by
    apply (Real.continuous_exp.continuousAt.tendsto.comp hdiff).congr'
    filter_upwards [hpos] with i hi
    have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
    simp only [Function.comp_def,Real.exp_add,Real.exp_log hk,Real.exp_nat_mul,Real.exp_log (by linarith : 0<1-g.step i),d]
    ring
  have hd : Tendsto d atTop (𝓝 0) := by
    apply (hm.div_atTop (k_infty g)).congr
    intro i
    have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
    field_simp [hk.ne']
  have hj := hm.add ((tendsto_const_nhds (x:=(j:ℝ))).mul hd)
  simp only [mul_zero,add_zero] at hj
  have hmarks : Tendsto (fun i => (g.marks j i:ℝ)*d i) atTop (𝓝 (Real.exp (-c))) := by
    apply hj.congr;intro i;simp only [marks,Nat.cast_add,ball_cast];ring
  exact TwoHubUnequal.moving_decay hd hmarks

theorem marks_error_zero (g : Degrees) (j:ℕ) (hs : Tendsto g.ratio atTop (𝓝 0)) :
    Tendsto (fun i => (g.marks j i:ℝ)^2/g.N i + (g.marks j i:ℝ)^2*g.step i) atTop (𝓝 0) := by
  have hN := N_infty g
  have hl := load_vanishes g hs
  have hj : Tendsto (fun i => (j:ℝ)^2/g.N i) atTop (𝓝 0) := tendsto_const_nhds.div_atTop hN
  have hsum := (tendsto_const_nhds (x:=(4:ℝ))).mul (hl.add hj)
  simp only [add_zero,mul_zero] at hsum
  apply squeeze_zero (fun i => add_nonneg (div_nonneg (sq_nonneg _) (by positivity))
    (mul_nonneg (sq_nonneg _) (step_pos g i).le)) _ hsum
  intro i
  have hn : 0<g.N i := by linarith [(sizes g i).2.2.1]
  have h1 := mul_le_mul_of_nonneg_left (step_bound g i) (sq_nonneg (g.marks j i:ℝ))
  rw [mul_one_div] at h1
  have h2 : (g.marks j i:ℝ)^2/g.N i ≤ 2*((g.ballCount i:ℝ)^2/g.N i+(j:ℝ)^2/g.N i) := by
    simp only [marks,Nat.cast_add]
    field_simp [hn.ne']
    nlinarith [sq_nonneg ((g.ballCount i:ℝ)-j)]
  linarith

#print axioms discrete_coupon_limit
end
end UrnWindow.Degrees
