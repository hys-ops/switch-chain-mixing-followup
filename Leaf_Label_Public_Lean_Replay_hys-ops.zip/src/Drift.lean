import CorePorts
open OAI.Problem315 Finset
open scoped BigOperators
noncomputable section
namespace ManyCore
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n → ℕ} {H : Finset (Fin n)}

def Q (n : ℕ) : ℝ := 12*(n.choose 4:ℝ)
def rate (H : Finset (Fin n)) (r : ℕ) : ℝ := ((r+1-H.card:ℕ):ℝ)^2 / Q n
def err (H : Finset (Fin n)) (r : ℕ) : ℝ := 2*(H.card*r:ℕ)/Q n

def absent (G : GraphState n d) (a b : Fin n) : ℝ := if a≠b ∧ ¬G.1.Adj a b then 1 else 0
def missing (H : Finset (Fin n)) (G : GraphState n d) : ℝ :=
  ∑ a∈H, ∑ b∈H, absent G a b
def clique (H : Finset (Fin n)) (G : GraphState n d) : Prop :=
  ∀ a∈H,∀ b∈H,a≠b → G.1.Adj a b

theorem absent_nonneg (G : GraphState n d) (a b : Fin n) : 0≤absent G a b := by
  unfold absent;split <;> norm_num
theorem absent_le_one (G : GraphState n d) (a b : Fin n) : absent G a b≤1 := by
  unfold absent;split <;> norm_num
theorem missing_nonneg (G : GraphState n d) : 0≤missing H G :=
  sum_nonneg fun a _ => sum_nonneg fun b _ => absent_nonneg G a b
theorem missing_le (G : GraphState n d) : missing H G ≤ (H.card:ℝ)^2 := by
  unfold missing
  calc
    _ ≤ ∑ a∈H, ∑ b∈H,(1:ℝ) := sum_le_sum fun a _ => sum_le_sum fun b _ => absent_le_one G a b
    _ = _ := by simp [pow_two]
theorem bad_le_missing (G : GraphState n d) :
    (if clique H G then (0:ℝ) else 1) ≤ missing H G := by
  split_ifs with h
  · exact missing_nonneg G
  · unfold clique at h;push_neg at h
    obtain ⟨a,ha,b,hb,hne,he⟩ := h
    have ha' := single_le_sum (f:= fun x => ∑ y∈H, absent G x y) (fun x _ => sum_nonneg fun y _ => absent_nonneg G x y) ha
    have hb' := single_le_sum (f:=absent G a) (fun y _ => absent_nonneg G a y) hb
    have hx : absent G a b=1 := if_pos ⟨hne,he⟩
    rw [←hx];exact hb'.trans ha'

theorem qpos (hn : 4≤n) : 0<Q n := by
  have hc : (0:ℝ)<n.choose 4 := by exact_mod_cast Nat.choose_pos hn
  unfold Q;positivity

theorem absent_step (hn : 4≤n) (sp : Spec H r d) (G : GraphState n d)
    {a b : Fin n} (ha : a∈H) (hb : b∈H) :
    (∑ F, switchKernel n d G F*absent F a b) ≤ (1-rate H r)*absent G a b+err H r := by
  have he0 : 0≤err H r := by unfold err;positivity [qpos hn]
  by_cases hab : a=b
  · subst b;simpa [absent] using he0
  have hab' : a≠b := hab
  by_cases he : G.1.Adj a b
  · have h := TwoHub.mass_loss G he
    simp only [allGraphStates,sum_filter,absent,ne_eq,hab,not_false_eq_true,true_and,mul_ite,mul_one,mul_zero] at h ⊢
    rw [h];simp only [he,not_true_eq_false,if_false,zero_add]
    apply div_le_div_of_nonneg_right _ (qpos hn).le
    exact_mod_cast cardinal_loss_upper sp G a b
  · have h := TwoHub.mass_gain G he
    simp only [allGraphStates,sum_filter] at h
    have hcom : (∑ F : GraphState n d, if ¬F.1.Adj a b then switchKernel n d G F else 0) =
        1-(∑ F : GraphState n d, if F.1.Adj a b then switchKernel n d G F else 0) := by
      apply eq_sub_of_add_eq
      rw [←sum_add_distrib]
      convert switchKernel_row_sum hn G using 1
      unfold allGraphStates
      apply sum_congr rfl;intro F _;by_cases e : F.1.Adj a b <;> simp [e]
    have hrate : rate H r ≤ (Fintype.card (TwoHub.Ports G.1 a b):ℝ)/(12*(n.choose 4:ℝ)) := by
      apply div_le_div_of_nonneg_right _ (qpos hn).le
      exact_mod_cast cardinal_gain_lower sp G ha hb hab
    simp only [absent,ne_eq,hab,not_false_eq_true,true_and,mul_ite,mul_one,mul_zero]
    rw [hcom,h,if_pos he];linarith

theorem missing_step (hn : 4≤n) (sp : Spec H r d) (G : GraphState n d) :
    (∑ F,switchKernel n d G F*missing H F) ≤
      (1-rate H r)*missing H G+(H.card:ℝ)^2*err H r := by
  unfold missing
  simp_rw [mul_sum]
  rw [sum_comm]
  calc
    _ = ∑ a∈H,∑ b∈H,∑ F,switchKernel n d G F*absent F a b := by
      apply sum_congr rfl;intro a _;exact sum_comm
    _ ≤ ∑ a∈H,∑ b∈H,((1-rate H r)*absent G a b+err H r) := by
      exact sum_le_sum fun a ha => sum_le_sum fun b hb => absent_step hn sp G ha hb
    _ = _ := by simp [sum_add_distrib,←mul_sum,pow_two];ring
#print axioms missing_step
end ManyCore
