import Loss
import OAI.Probability.SwitchChain.SwitchFoundations
import Mathlib.Analysis.SpecialFunctions.Log.Basic
namespace LeafLower
open OAI.Problem315 Finset TwoHub
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}
abbrev State (n : ℕ) (d : Fin n → ℕ) := GraphState n d
abbrev K (n : ℕ) (d : Fin n → ℕ) := switchKernel n d
def Q (n : ℕ) : ℝ := 12*(n.choose 4 : ℝ)
def mass (d : Fin n → ℕ) : ℕ := ∑ i,d i

/-- Every ordered eligible deletion port is an oriented edge of the current graph. -/
lemma ports_le (G : State n d) (a v : Fin n) : Fintype.card (Ports G.valᶜ a v) ≤ mass d := by
  classical
  let f : Ports G.valᶜ a v → (Σ x : Fin n,{y : Fin n // G.val.Adj x y}) := fun w =>
    ⟨w.1.1,w.1.2,by by_contra hn;exact w.2.2.2.2 ⟨w.2.1.2.2.2.2.1,hn⟩⟩
  have hi : Function.Injective f := by
    intro u v he;apply Subtype.ext
    have h := congrArg (fun w : (Σ x : Fin n,{y : Fin n // G.val.Adj x y}) => (w.1,w.2.1)) he;exact h
  have h := Fintype.card_le_of_injective f hi
  rw [Fintype.card_sigma] at h
  have hi' (x : Fin n) : Fintype.card {y : Fin n // G.val.Adj x y}=d x := by
    simpa only [Fintype.card_subtype,graphDegree] using G.2 x
  simpa only [hi',mass] using h

lemma loss_bound (G : State n d) {a v : Fin n} (ha : G.val.Adj a v) :
    ∑ H : State n d, (if H.val.Adj a v then 0 else K n d G H) ≤ (mass d : ℝ)/Q n := by
  classical
  have h:=TwoHub.mass_loss G ha
  calc
    _ = ∑ H∈(allGraphStates n d).filter (fun H => ¬H.val.Adj a v),K n d G H := by
      rw [Finset.sum_filter];apply sum_congr rfl;intro H _;split_ifs <;> simp_all
    _ = _ := h
    _ ≤ _ := by
      unfold Q;exact div_le_div_of_nonneg_right (by exact_mod_cast ports_le G a v) (by positivity)

def marks (W : Finset (Fin n)) (a : Fin n) (G : State n d) := W.filter (G.val.Adj a)
def z (W : Finset (Fin n)) (a : Fin n) (G : State n d) := (marks W a G).card

def lost (W : Finset (Fin n)) (a : Fin n) (G H : State n d) := marks W a G \ marks W a H

lemma lost_le_one {W : Finset (Fin n)} {a : Fin n} {G H : State n d} (h : K n d G H≠0) :
   (lost W a G H).card≤1 := by
  classical
  by_cases he : G=H
  · subst H;simp [lost]
  have hk := switchKernel_of_ne he
  have hs : SwitchStep n d G H := by by_contra hn;exact h (by simpa [hn] using hk)
  obtain ⟨p,hv,hp⟩:=hs
  apply Finset.card_le_one.mpr
  intro x hx y hy
  have hl {v} (h : v∈lost W a G H) : (removedMatching p).Adj a v := by
    obtain ⟨h1,h2⟩ := mem_sdiff.mp h
    obtain ⟨hvW,he⟩ := mem_filter.mp h1
    apply (removedMatching_adj_iff hv a v).2
    refine ⟨he,?_⟩;rw [hp]; intro hh;exact h2 (mem_filter.mpr ⟨hvW,hh⟩)
  exact TwoHub.partner_unique p.2.val.1 (hl hx) (hl hy)

lemma z_lower {W : Finset (Fin n)} {a : Fin n} {G H : State n d} (h : K n d G H≠0) :
    z W a G ≤ z W a H + 1 := by
  have hdis := Finset.card_sdiff_add_card_inter (marks W a G) (marks W a H)
  have hi := Finset.card_le_card (Finset.inter_subset_right (s₁:=marks W a G) (s₂:=marks W a H))
  have hl:=lost_le_one (W:=W) (a:=a) h
  unfold z lost at *; omega

/-- The expected number of lost marked incident edges in one actual source step. -/
theorem lost_expectation (W : Finset (Fin n)) (a : Fin n) (G : State n d) :
    ∑ H : State n d,K n d G H*((lost W a G H).card:ℝ) ≤ (z W a G:ℝ)*((mass d:ℝ)/Q n) := by
  classical
  have hc (H : State n d) : ((lost W a G H).card:ℝ) =
      ∑ v∈marks W a G, if H.val.Adj a v then (0:ℝ) else 1 := by
    have he : lost W a G H = (marks W a G).filter (fun v => ¬H.val.Adj a v) := by
      ext v;simp [lost,marks];tauto
    rw [he,←Finset.sum_boole];apply sum_congr rfl;intro v _;split_ifs <;> simp_all
  simp_rw [hc,Finset.mul_sum]
  rw [Finset.sum_comm]
  calc
    _ = ∑ v∈marks W a G, ∑ H : State n d, if H.val.Adj a v then 0 else K n d G H := by
      apply sum_congr rfl;intro v _;apply sum_congr rfl;intro H _;split_ifs <;> simp
    _ ≤ ∑ _v∈marks W a G, ((mass d:ℝ)/Q n) := by
      apply sum_le_sum;intro v hv;exact loss_bound G (mem_filter.mp hv).2
    _ = _ := by simp [z]

#print axioms loss_bound
#print axioms lost_le_one
#print axioms lost_expectation
end
end LeafLower
