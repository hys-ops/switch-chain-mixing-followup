import EdgeHazard
import LeafLabels
namespace LeafLower
open OAI.Problem315 LeafLower.Labels Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

def edgeTotal (a v : Fin n) (d : Fin n → ℕ) : ℕ := ∑ G : State n d, if G.val.Adj a v then 1 else 0

lemma edgeTotal_swap (a u v : Fin n) (hu : a≠u) (hv : a≠v) (hd : d u=d v) : edgeTotal a u d=edgeTotal a v d := by
  have h := Equiv.sum_comp (swapLabels u v hd) (fun G : State n d => if G.val.Adj a u then 1 else (0:ℕ))
  have he (G : State n d) : ((swapLabels u v hd) G).val.Adj a u ↔ G.val.Adj a v := by
    change G.val.Adj (Equiv.swap u v a) (Equiv.swap u v u) ↔ G.val.Adj a v
    rw [Equiv.swap_apply_of_ne_of_ne hu hv,Equiv.swap_apply_left]
  simpa only [he,edgeTotal] using h.symm

lemma mark_total (W : Finset (Fin n)) (a : Fin n) : ∑ G : State n d,z W a G = ∑ v∈W,edgeTotal a v d := by
  unfold edgeTotal;rw [sum_comm];apply sum_congr rfl;intro G _;simp [z,marks]

/-- Label exchangeability gives the stationary overlap estimate without
conditioning on any hub core. Degrees need only agree within the label pool. -/
theorem stationary_overlap (L W : Finset (Fin n)) (a : Fin n) (ha : a∉L) (hL : L.Nonempty)
    (hWL : W⊆L) (hd : ∀u∈L,∀v∈L,d u=d v) (hg : Graphical n d) :
    (∑ G : State n d,(z W a G:ℝ))/(Fintype.card (State n d):ℝ) ≤ (W.card:ℝ)*(d a:ℝ)/(L.card:ℝ) := by
  classical
  have : Nonempty (State n d) := hg
  obtain ⟨v₀,hv⟩:=hL
  have he v (hv' : v∈L) : edgeTotal a v d=edgeTotal a v₀ d :=
    edgeTotal_swap _ _ _ (fun e=>ha (e.symm ▸ hv')) (fun e=>ha (e.symm ▸ hv)) (hd _ hv' _ hv)
  have calcSum (S : Finset (Fin n)) (hs : S⊆L) : (∑ G : State n d,z S a G)=S.card*(edgeTotal a v₀ d) := by
    rw [mark_total];calc
      _ = ∑ _∈S,edgeTotal a v₀ d := sum_congr rfl (fun v hv => he v (hs hv))
      _ = _ := by simp
  have zle (G : State n d) : z L a G≤d a := by
    rw [←G.2 a];apply card_le_card;intro v hv;exact mem_filter.mpr ⟨mem_univ _,(mem_filter.mp hv).2⟩
  have hz : L.card*edgeTotal a v₀ d ≤ Fintype.card (State n d)*d a := by
    rw [←calcSum _ (by rfl)];simpa using (sum_le_sum (s:=univ) (fun G _=>zle G))
  have hs : (∑ G : State n d,(z W a G:ℝ)) = (W.card:ℝ)*(edgeTotal a v₀ d:ℝ) := by exact_mod_cast calcSum _ hWL
  have hlr : (0:ℝ)<L.card := by exact_mod_cast card_pos.mpr ⟨v₀,hv⟩
  have hnr : (0:ℝ)<Fintype.card (State n d) := by exact_mod_cast Fintype.card_pos
  have hz' : (L.card:ℝ)*((edgeTotal a v₀ d):ℝ)≤ (Fintype.card (State n d):ℝ)*(d a:ℝ) := by exact_mod_cast hz
  rw [hs,div_le_div_iff₀ hnr hlr]
  nlinarith only [mul_le_mul_of_nonneg_left hz' (Nat.cast_nonneg (α:=ℝ) W.card)]

#print axioms stationary_overlap
end
end LeafLower
