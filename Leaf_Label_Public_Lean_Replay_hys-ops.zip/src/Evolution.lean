import Drift
open OAI.Problem315 Finset
open scoped BigOperators
noncomputable section
namespace ManyCore
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n → ℕ} {H : Finset (Fin n)}

def row (t : ℕ) (G : GraphState n d) (f : GraphState n d → ℝ) : ℝ :=
  ∑ F,kernelPow n d t G F*f F

theorem pow_nonneg (t : ℕ) (G F : GraphState n d) : 0≤kernelPow n d t G F := by
  induction t generalizing F with
  | zero => simp [kernelPow];positivity
  | succ t ih => exact sum_nonneg fun X _ => mul_nonneg (ih X) (switchKernel_nonneg X F)

theorem pow_rows (hn : 4≤n) (t : ℕ) (G : GraphState n d) : ∑ F,kernelPow n d t G F = 1 := by
  induction t with
  | zero => simp [kernelPow]
  | succ t ih =>
    simp only [kernelPow,allGraphStates]
    rw [sum_comm]
    simp_rw [←mul_sum,show ∀ G : GraphState n d, ∑ F,switchKernel n d G F=1 from switchKernel_row_sum hn,mul_one]
    exact ih

theorem row_succ (t : ℕ) (G : GraphState n d) (f : GraphState n d → ℝ) :
    row (t+1) G f = row t G (fun X => ∑ F,switchKernel n d X F*f F) := by
  unfold row
  simp only [kernelPow,allGraphStates,sum_mul,mul_assoc,mul_sum]
  exact sum_comm

theorem row_drift {a c : ℝ} (hn : 4≤n) (ha : 0<a) (ha' : a≤1) (hc : 0≤c)
    (v : GraphState n d → ℝ)
    (hs : ∀ G,(∑ F,switchKernel n d G F*v F) ≤ (1-a)*v G+c)
    (t : ℕ) (G : GraphState n d) :
    row t G v ≤ (1-a)^t*v G+c/a := by
  have hcancel : a*(c/a)=c := by field_simp
  induction t with
  | zero => simpa [row,kernelPow] using (div_nonneg hc ha.le)
  | succ t ih =>
    rw [row_succ]
    calc
      _ ≤ ∑ F,kernelPow n d t G F*((1-a)*v F+c) :=
        sum_le_sum fun F _ => mul_le_mul_of_nonneg_left (hs F) (pow_nonneg t G F)
      _ = (1-a)*row t G v+c := by
        unfold row
        simp only [mul_add,sum_add_distrib,←sum_mul,←mul_sum,pow_rows hn,one_mul]
        congr 1
        rw [mul_sum]
        apply sum_congr rfl
        intro i _
        ring
      _ ≤ (1-a)*((1-a)^t*v G+c/a)+c :=
        add_le_add_left (mul_le_mul_of_nonneg_left ih (sub_nonneg.mpr ha')) _
      _ = _ := by rw [pow_succ];nlinarith only [hcancel]

theorem uniform_drift {a c : ℝ} (hn : 4≤n) (ha : 0<a) (hc : 0≤c)
    (v : GraphState n d → ℝ)
    (hs : ∀ G,(∑ F,switchKernel n d G F*v F) ≤ (1-a)*v G+c) :
    uniformAverage n d v ≤ c/a := by
  let k : ℝ := Fintype.card (GraphState n d)
  have hfix : (∑ G,∑ F,switchKernel n d G F*v F) = ∑ F,v F := by
    rw [sum_comm]
    apply sum_congr rfl;intro F _
    simp_rw [switchKernel_symm _ F]
    rw [←sum_mul,show ∑ G,switchKernel n d F G = 1 from switchKernel_row_sum hn F,one_mul]
  have hsum := sum_le_sum (s:=univ) (fun G _ => hs G)
  rw [hfix,sum_add_distrib,←mul_sum] at hsum
  have hconst : (∑ _ : GraphState n d,c) = k*c := by simp [k]
  rw [hconst] at hsum
  change (∑ F,v F)/k ≤ c/a
  by_cases hk : k=0
  · simp [hk,div_nonneg hc ha.le]
  have hk' : 0<k := lt_of_le_of_ne (by unfold k;positivity) (Ne.symm hk)
  apply (div_le_div_iff₀ hk' ha).mpr;linarith

def bad (H : Finset (Fin n)) (G : GraphState n d) : ℝ := if clique H G then 0 else 1

theorem bad_row (hn : 4≤n) (sp : Spec H r d) (ha : 0<rate H r) (ha' : rate H r ≤ 1)
    (t : ℕ) (G : GraphState n d) :
    row t G (bad H) ≤ (1-rate H r)^t*(H.card:ℝ)^2+(H.card:ℝ)^2*err H r/rate H r := by
  have hc : 0≤(H.card:ℝ)^2*err H r := by unfold err;positivity [qpos hn]
  calc
    _ ≤ row t G (missing H) := sum_le_sum fun F _ => mul_le_mul_of_nonneg_left (bad_le_missing F) (pow_nonneg t G F)
    _ ≤ _ := row_drift hn ha ha' hc _ (missing_step hn sp) t G
    _ ≤ _ := add_le_add_left (mul_le_mul_of_nonneg_left (missing_le G) (_root_.pow_nonneg (sub_nonneg.mpr ha') t)) _

theorem bad_uniform (hn : 4≤n) (sp : Spec H r d) (ha : 0<rate H r) :
    uniformAverage n d (bad H) ≤ (H.card:ℝ)^2*err H r/rate H r := by
  have hc : 0≤(H.card:ℝ)^2*err H r := by unfold err;positivity [qpos hn]
  apply le_trans _ (uniform_drift hn ha hc _ (missing_step hn sp))
  exact div_le_div_of_nonneg_right (sum_le_sum fun F _ => bad_le_missing F) (Nat.cast_nonneg _)

#print axioms bad_row
#print axioms bad_uniform
end ManyCore
