import SharpDiscrete
import BinaryLeCam
open Finset HubTransfer OAI.Problem315 NormedSpace JohnsonLower HubMarks LeafClock
open scoped Matrix Matrix.Norms.Operator Classical
noncomputable section
namespace SharpClock
open TwoHubUnequal PhysicalReduction
variable {n r s : ℕ} {d : Fin n→ℕ} {a c : Fin n}

def tau (n t : ℕ) : ℝ := (t:ℝ)/clock n
def paperBound (n r s t : ℕ) : ℝ :=
  (t:ℝ)*(2*r*s/clock n)^2+2/((r:ℝ)*s+2)+2*tau n t+Real.exp (-((r:ℝ)*s*tau n t))+
  2*Real.exp (-(((s:ℝ)-1)*tau n t))+Real.exp (-(((r:ℝ)+s-2)*tau n t))

/-- A rate of one per unordered pair corresponds to external ordered-pair
    proposal time N²τ/2. The scalar definition uses only k+1 states. -/
def binaryDistance (N k : ℕ) (τ : ℝ) := tridiagonalDistance N k ((N:ℝ)^2*τ/2)

theorem graph_finite (sp : Spec n r s d a c) (hr : 2≤r) (hrs : r≤s)
    (G : GraphState n d) (t : ℕ) :
    |tvDistanceFrom n d t G - binaryDistance (r+s) (r-1) (tau n t)|≤paperBound n r s t := by
  let N:=r+s
  let k:=r-1
  let S:=TwoHubHorizontal.redProjection sp G
  let Q:=clock n
  let τ:=tau n t
  let W:=HubMarks.walk N k Q
  have hn : 4≤n := by have:=sp.size;omega
  have hs:=hr.trans hrs
  have hN:0<N:=by dsimp [N];omega
  have hQ:0<Q:=clock_pos hn
  have hr' : (2:ℝ)≤r:=by exact_mod_cast hr
  have hs' : (r:ℝ)≤s:=by exact_mod_cast hrs
  have hk : (k:ℝ)=(r:ℝ)-1 := by dsimp [k];rw [Nat.cast_sub (by omega),Nat.cast_one]
  have hNr : (N:ℝ)=(r:ℝ)+s:=by exact_mod_cast (rfl : N=r+s)
  have hp : 0<(k:ℝ)*(N-k) := by rw [hk,hNr];nlinarith [mul_pos (by linarith : 0<(r:ℝ)-1) (by linarith : 0<(s:ℝ)+1)]
  have hz : (k:ℝ)*(N-k)≤(r:ℝ)*s := by rw [hk,hNr];nlinarith
  obtain ⟨h1,h2,h3⟩:=rates sp hn hr hs
  have H:=sharp_all_starts sp hn hr hs G S t
  have P:=binary_poisson hN Q hQ hp (hz.trans h1) t S
  have hw:=RestrictedTV.between ((W^t) S) (continuous W t S) (unif _)
  have hd := hw.trans P
  have ht : 0≤(N:ℝ)^2*τ/2 := div_nonneg (mul_nonneg (sq_nonneg _) (div_nonneg (Nat.cast_nonneg _) hQ.le)) (by norm_num)
  have actual : tv (continuous W t S) (unif _)=binaryDistance N k τ := by
    change tv (continuous (walk N k Q) t S) (unif _)=_
    rw [clock_identity hN Q t hQ]
    have tim : (t:ℝ)*(N:ℝ)^2/(2*Q)=(N:ℝ)^2*τ/2 := by dsimp [Q,τ,tau];ring
    rw [tim,←urnDistance_exp,urn_to_scalar S hN,scalar_to_tridiagonal S hN ht];rfl
  rw [actual] at hd
  change |Bdist n r s t S-binaryDistance N k τ|≤_ at hd
  have work := (abs_sub_le (tvDistanceFrom n d t G) (Bdist n r s t S) (binaryDistance N k τ)).trans
    (add_le_add H hd)
  change |tvDistanceFrom n d t G-binaryDistance N k τ|≤_
  apply work.trans
  have e1:=exp_bound _ _ hQ h1 t
  have e2:=exp_bound _ _ hQ h2 t
  have e3:=exp_bound _ _ hQ h3 t
  rw [Nat.cast_sub (by omega : 1≤s),Nat.cast_one] at e2
  rw [Nat.cast_sub (by omega : 2≤r+s),Nat.cast_add,Nat.cast_ofNat] at e3
  have hpsq := pow_le_pow_left₀ (div_nonneg hp.le hQ.le) (div_le_div_of_nonneg_right hz hQ.le) 2
  have hpow := mul_le_mul_of_nonneg_left hpsq (Nat.cast_nonneg (α:=ℝ) t)
  change splitCost n r s t+(1-(r:ℝ)*s/Q)^t+2*(1-((s-1:ℕ):ℝ)/Q)^t+
    (1-((r+s-2:ℕ):ℝ)/Q)^t+2/((r:ℝ)*s+2)+(t:ℝ)*(((k:ℝ)*(N-k))/Q)^2≤_
  rw [Nat.cast_sub (by omega : 1≤s),Nat.cast_one,Nat.cast_sub (by omega : 2≤r+s),Nat.cast_add,Nat.cast_ofNat]
  unfold splitCost paperBound tau
  change (t:ℝ)*(3*((r:ℝ)*s/Q)^2+2/Q)+_+_+_+_+_≤(t:ℝ)*(2*r*s/Q)^2+_+2*((t:ℝ)/Q)+_+_+_
  rw [hNr] at hpow
  dsimp only [Q] at hpow e1 e2 e3 ⊢
  linear_combination (norm:=ring_nf) hpow + e1 + 2*e2 + e3
  norm_num

theorem worst_finite (sp : Spec n r s d a c) (hr : 2≤r) (hrs : r≤s)
    (G₀ : GraphState n d) (t : ℕ) :
    sSup (Set.range (fun G:GraphState n d=>|tvDistanceFrom n d t G-binaryDistance (r+s) (r-1) (tau n t)|))
      ≤ paperBound n r s t := by
  apply _root_.csSup_le
  · exact ⟨_,G₀,rfl⟩
  · rintro y ⟨G,rfl⟩;exact graph_finite sp hr hrs G t
#print axioms graph_finite
#print axioms worst_finite
end SharpClock
