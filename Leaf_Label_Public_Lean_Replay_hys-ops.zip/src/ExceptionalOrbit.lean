import LeafShuffleTV
import CoreOrbit

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable

variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq C]

def massAt (c z : C) : ℝ := if z=c then 1 else 0

theorem tv_atom (a : C→ℝ) (ha : ∀ z,0≤a z) (hs : ∑ z,a z=1) (c : C) :
    tv a (massAt c)=1-a c := by
  have hc : a c ≤ 1 := by rw [← hs]; exact Finset.single_le_sum (fun z _ => ha z) (Finset.mem_univ c)
  have he (z : C) : |a z-massAt c z|=a z+(if z=c then 1-2*a c else 0) := by
    by_cases h : z=c
    · subst z; simp only [massAt,ite_true,abs_of_nonpos (sub_nonpos.mpr hc)]; ring
    · simp [massAt,h,abs_of_nonneg (ha z)]
  simp only [tv,he,Finset.sum_add_distrib,hs,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  ring

theorem tv_comm (a b : C→ℝ) : tv a b=tv b a := by simp only [tv,abs_sub_comm]

theorem one_atom_bound (π : X→C) (good : X→Prop) [DecidablePred good] (c : C)
    (hgood : ∀x,good x→π x=c) (a : X→ℝ) (ha : ∀ z,0≤a z) (hs : ∑ z,a z=1) :
    tv (push π a) (massAt c) ≤ ∑ z,a z*(if good z then 0 else 1) := by
  have hnon (z : C) : 0≤push π a z := by
    apply Finset.sum_nonneg; intro x _; split_ifs <;> simp [ha]
  rw [tv_atom _ hnon ((push_sum π a).trans hs)]
  rw [← hs,push,← Finset.sum_sub_distrib]
  apply Finset.sum_le_sum
  intro z _
  by_cases h : good z
  · simp [h,hgood z h]
  · by_cases h' : π z=c <;> simp [h,h',ha,hs]

theorem coarse_tv (x₀ : X) (π : X→C) (good : X→Prop) [DecidablePred good]
    (hone : ∀ x y,good x → good y → π x=π y)
    (a b : X→ℝ) (ha : ∀ z,0≤a z) (hb : ∀ z,0≤b z)
    (hsa : ∑ z,a z=1) (hsb : ∑ z,b z=1) :
    tv (push π a) (push π b) ≤ (∑ z,a z*(if good z then 0 else 1)) +
      ∑ z,b z*(if good z then 0 else 1) := by
  have h : ∃ c,∀ z,good z→π z=c := by
    by_cases hx : ∃z,good z
    · obtain ⟨x,hx⟩ := hx; exact ⟨π x,fun z hz => hone z x hz hx⟩
    · exact ⟨π x₀,fun z hz => (hx ⟨z,hz⟩).elim⟩
  obtain ⟨c,hc⟩ := h
  apply (tv_triangle _ (massAt c) _).trans
  rw [tv_comm (massAt c)]
  exact add_le_add (one_atom_bound π good c hc a ha hsa) (one_atom_bound π good c hc b hb hsb)

#print axioms coarse_tv
end OAI.Problem315.LeafOrbit
