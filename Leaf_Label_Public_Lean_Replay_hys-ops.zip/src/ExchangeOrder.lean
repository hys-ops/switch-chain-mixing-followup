import JohnsonHomogeneous
open Finset HubTransfer JohnsonLower HubMarks
open OAI.Problem315.SlicePermutationAction (relabel relabel_mul relabel_one)
open scoped Matrix
namespace JohnsonProfile
noncomputable section
attribute [local instance] Classical.propDecidable
variable {N k : ℕ}

/-- The order permits neutral exchanges within either color class and gains of
a mark. These are sufficient generators of the order by overlap with A. -/
def Sorted (A : Finset (Fin N)) (f : Slice N k → ℝ) : Prop :=
  ∀ U i j, i∈U.val → j∉U.val → (i∈A → j∈A) → f U≤f (swapSet U i j)

theorem mem_swapSet (U : Slice N k) (i j v : Fin N) : v∈(swapSet U i j).val ↔ Equiv.swap i j v∈U.val := by
  change _∈Finset.map (Equiv.swap i j).toEmbedding _ ↔ _
  rw [mem_map_equiv,Equiv.symm_swap]

theorem swap_twice (U : Slice N k) (i j : Fin N) : swapSet (swapSet U i j) i j=U := by
  apply Subtype.ext;ext v;simp only [mem_swapSet,Equiv.swap_apply_self]

theorem swap_commute_coords (U : Slice N k) (i j x y : Fin N) :
    swapSet (swapSet U x y) i j=swapSet (swapSet U i j) (Equiv.swap i j x) (Equiv.swap i j y) :=
  relabel_swap (Equiv.swap i j) U x y

theorem favorable_step {A : Finset (Fin N)} (f : Slice N k→ℝ) (hf : Sorted A f)
    {Q : ℝ} (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) : Sorted A (walk N k Q *ᵥ f) := by
  classical
  intro U i j hi hj ho
  let V:=swapSet U i j
  let δ:=f V-f U
  have hd : 0≤δ := sub_nonneg.mpr (hf U i j hi hj ho)
  have ij : i≠j := by intro h;exact hj (h ▸ hi)
  have perm (x y : Fin N) : f (swapSet U x y)-f U - 2*δ ≤ f (swapSet (swapSet U x y) i j)-f V := by
    let W:=swapSet U x y
    change f W-f U-2*δ≤f (swapSet W i j)-f V
    by_cases h1 : i∈W.val
    · by_cases h2 : j∈W.val
      · have e:=same_side W (show i∈W.val ↔ j∈W.val by tauto)
        rw [e];dsimp [δ] at *;linarith
      · have he:=hf W i j h1 h2 ho;dsimp [δ] at *;linarith
    · by_cases h2 : j∈W.val
      · have ih : i=x ∨ i=y := by
          by_contra! hh;apply h1;change i∈(swapSet U x y).val
          rwa [mem_swapSet,Equiv.swap_apply_of_ne_of_ne hh.1 hh.2]
        have jh : j=x ∨ j=y := by
          by_contra! hh;apply hj;change j∈(swapSet U x y).val at h2
          rwa [mem_swapSet,Equiv.swap_apply_of_ne_of_ne hh.1 hh.2] at h2
        have hv : W=V := by
          rcases ih with rfl|rfl <;> rcases jh with e|e <;> subst_vars <;> first
          | contradiction
          | rfl
          | apply Subtype.ext;change Finset.map _ _=Finset.map _ _;rw [Equiv.swap_comm]
        rw [hv];change _≤f (swapSet (swapSet U i j) i j)-_;rw [swap_twice];dsimp [δ];linarith
      · rw [same_side W (show i∈W.val ↔ j∈W.val by tauto)]
        dsimp [δ] at *;linarith
  let τ:=Equiv.swap i j
  have eq : (∑x:Fin N, ∑y:Fin N,(f (swapSet (swapSet U x y) i j)-f V)) =
      ∑x:Fin N,∑y:Fin N,(f (swapSet V x y)-f V) := by
    apply Fintype.sum_equiv τ _ _;intro x;apply Fintype.sum_equiv τ _ _;intro y
    rw [swap_commute_coords]
  have sumineq := sum_le_sum (s:=univ) (fun x _=>sum_le_sum (s:=univ) (fun y _=>perm x y))
  have pull : (∑x : Fin N,∑y : Fin N,(f (swapSet U x y)-f U-2*δ)) =
      (∑x : Fin N,∑y : Fin N,(f (swapSet U x y)-f U)) -(N:ℝ)^2*(2*δ) := by
    simp only [sum_sub_distrib,sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul];ring
  rw [pull,eq] at sumineq
  rw [swap_row _ hQ.ne',swap_row _ hQ.ne']
  change f U+_/(2*Q)≤f V+_/(2*Q)
  have hx : (0:ℝ)<2*Q := by positivity
  apply (le_of_mul_le_mul_right (a:=(2*Q)) · hx)
  simp only [add_mul,div_mul_cancel₀ _ hx.ne']
  have hz:=mul_le_mul_of_nonneg_right hN hd
  change f U*(2*Q)+(∑x:Fin N,∑y:Fin N,(f (swapSet U x y)-f U)) ≤
       f V*(2*Q)+(∑x:Fin N,∑y:Fin N,(f (swapSet V x y)-f V))
  dsimp [δ] at hz sumineq;linarith

theorem sorted_hit (A : Slice N k) {Q : ℝ} (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) (t : ℕ) :
    Sorted A.val (fun U=>(walk N k Q ^ t) U A) := by
  induction t with
  | zero =>
    intro U i j hi hj ho
    by_cases he : U=A
    · subst U;exact (hj (ho hi)).elim
    · simp [Matrix.one_apply,he];split <;> norm_num
  | succ t ih =>
    rw [pow_succ'];exact favorable_step _ ih hQ hN

#print axioms favorable_step
#print axioms sorted_hit
end
end JohnsonProfile
