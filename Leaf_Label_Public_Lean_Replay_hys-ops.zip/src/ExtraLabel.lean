import MarkProfile
open Finset JohnsonLower HubTransfer
open scoped Matrix
namespace HubMarks
noncomputable section
variable {N h : ℕ}

/-- Only one label distinguishes a first-jump incident vertex mark set from a joined
point mark set. Its contribution is bounded by one-site occupancy under the actual
discrete Johnson walk. -/
theorem one_missing {Q : ℝ} (hQ : 0<Q) (hcap : (h:ℝ)*((N:ℝ)-h)≤Q)
    (K : Finset (Fin N)) (S : Slice N h) (hK : K⊆S.val) (hsize : K.card+1=h) (t : ℕ) :
    |((walk N h Q)^t *ᵥ avoid K) S-((walk N h Q)^t *ᵥ avoid S.val) S| ≤
        (eigen N h 1 Q)^t + (t:ℝ)*h/Q := by
  classical
  have hc : (S.val \ K).card=1 := by rw [card_sdiff_of_subset hK,S.property];omega
  obtain ⟨x,hx⟩ := card_eq_one.mp hc
  have hx' : x∈ S.val \ K := hx ▸ mem_singleton_self x
  have he : S.val=insert x K := by
    ext y
    constructor
    · intro hy
      by_cases h : y∈K
      · exact mem_insert_of_mem h
      · have hy' : y∈S.val \ K := mem_sdiff.mpr ⟨hy,h⟩
        rw [hx,mem_singleton] at hy';simp [hy']
    · intro hy;rcases mem_insert.mp hy with rfl|hm
      · exact (mem_sdiff.mp hx').1
      · exact hK hm
  let P := (walk N h Q)^t
  have hp : Stochastic P := stochastic_pow (kernel_stoch hQ hcap) t
  have hd (T : Slice N h) : 0≤avoid K T-avoid S.val T ∧
      avoid K T-avoid S.val T ≤ occupied {x} T := by
    by_cases hdis : Disjoint K T.val <;> by_cases hm : x∈T.val <;>
      simp [avoid,occupied,he,disjoint_insert_left,hdis,hm]
  have eq : (P *ᵥ avoid K) S-(P *ᵥ avoid S.val) S=∑ T,P S T*(avoid K T-avoid S.val T) := by
    simp [Matrix.mulVec,dotProduct,mul_sub,sum_sub_distrib]
  change |(P *ᵥ avoid K) S-(P *ᵥ avoid S.val) S| ≤ _
  rw [eq,abs_of_nonneg (sum_nonneg fun T _ => mul_nonneg (hp.1 S T) (hd T).1)]
  have hi : ({x}:Finset (Fin N))⊆S.val := singleton_subset_iff.mpr (mem_sdiff.mp hx').1
  have hsur := (marked_survival hQ hcap {x} t S hi).2
  simp only [card_singleton] at hsur
  calc
    _ ≤ (P *ᵥ occupied {x}) S := sum_le_sum fun T _=>mul_le_mul_of_nonneg_left (hd T).2 (hp.1 S T)
    _ ≤ _ := by change _ - _ ≤ _ at hsur; linarith
#print axioms one_missing
end
end HubMarks
