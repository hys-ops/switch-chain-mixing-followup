import SparseSemigroup
open Finset
namespace CriticalUrn
noncomputable section

def falling : ℕ → ℝ → ℝ
  | 0, _ => 1
  | j+1,x => (x-j)*falling j x

theorem falling_up (j : ℕ) (x : ℝ) : falling (j+1) (x+1)-falling (j+1) x=(j+1)*falling j x := by
  induction j with
  | zero => simp [falling]
  | succ j ih =>
    simp only [falling,Nat.cast_succ] at ih ⊢
    linear_combination (x-j)*ih

theorem falling_shift (j : ℕ) (x : ℝ) : x*falling j (x-1)= (x-j)*falling j x := by
  induction j with
  | zero => simp [falling]
  | succ j ih =>
    simp only [falling,Nat.cast_succ]
    linear_combination (x-1-j)*ih

theorem falling_down (j x : ℕ) :
    (x:ℝ)*(falling (j+1) ((x-1:ℕ):ℝ)-falling (j+1) x) = -(j+1)*falling (j+1) x := by
  cases x with
  | zero =>
    have z (l : ℕ) : falling (l+1) 0=0 := by
      induction l with
      | zero => norm_num [falling]
      | succ l ih => rw [falling,ih,mul_zero]
    simp [z]
  | succ x =>
    have h := falling_shift (j+1) (x+1)
    simp only [Nat.succ_sub_one,Nat.cast_succ,add_sub_cancel_right] at h ⊢
    linarith

def rate (N : ℝ) (j : ℕ) := (j:ℝ)*(1-((j:ℝ)-1)/N)
def influx (N : ℝ) (k j : ℕ) := ((j:ℝ)+1)*((k:ℝ)-j)^2/N

theorem factorial_generator {N : ℝ} (hN : N≠0) (k j x : ℕ) :
    SparseUrn.generator N k (fun y => falling (j+1) y) x =
      -rate N (j+1)*falling (j+1) x+influx N k j*falling j x := by
  unfold SparseUrn.generator SparseUrn.birth SparseUrn.death rate influx
  push_cast
  rw [falling_up]
  have h := falling_down j x
  rw [div_mul_eq_mul_div,div_mul_eq_mul_div]
  field_simp
  simp only [falling] at h ⊢
  linear_combination (N-2*(k:ℝ)+x)*h

theorem falling_nat (j x:ℕ) : falling j x = (x.descFactorial j:ℝ) := by
  induction j with
  | zero => simp [falling]
  | succ j ih =>
    rw [falling,ih,Nat.descFactorial_succ]
    by_cases h : j≤x
    · push_cast [Nat.cast_sub h];rfl
    · rw [Nat.descFactorial_eq_zero_iff_lt.mpr (by omega)];simp

#print axioms factorial_generator
end
end CriticalUrn
