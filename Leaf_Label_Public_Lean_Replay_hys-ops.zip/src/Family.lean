import Evolution
import Mathlib.Data.Nat.Choose.Bounds
import Mathlib.Analysis.SpecialFunctions.Exp
open OAI.Problem315 Finset
open scoped BigOperators
noncomputable section
namespace ManyCore
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ} {H : Finset (Fin n)}

theorem q_ge_sq (hn : 8≤n) : (n:ℝ)^2≤Q n := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le hn
  have h := Nat.pow_le_choose (α:=ℝ) 4 (8+k)
  have e : 8+k+1-4 = k+5 := by omega
  rw [e] at h
  norm_num [Nat.factorial] at h
  push_cast at h ⊢
  unfold Q
  nlinarith [sq_nonneg (k:ℝ),show 0≤(k:ℝ)^3 by positivity,show 0≤(k:ℝ)^4 by positivity]

theorem family_sizes (sp : Spec H (H.card^4) d) (hh : 2≤H.card) :
    8≤n ∧ 2*H.card≤H.card^4 ∧ H.card^4≤n := by
  have hs := H.card_compl_add_card
  rw [sp.count,Fintype.card_fin] at hs
  obtain ⟨j,hj⟩ := Nat.exists_eq_add_of_le hh
  rw [hj] at hs ⊢
  constructor
  · nlinarith [Nat.zero_le (j^2),Nat.zero_le (j^3),Nat.zero_le (j^4),Nat.zero_le (j^5)]
  constructor <;> nlinarith [Nat.zero_le (j^2),Nat.zero_le (j^3),Nat.zero_le (j^4),Nat.zero_le (j^5)]

theorem family_rate (sp : Spec H (H.card^4) d) (hh : 2≤H.card) :
    0<rate H (H.card^4) ∧ rate H (H.card^4)≤1 := by
  obtain ⟨hn,hr,hrn⟩ := family_sizes sp hh
  have hQ := qpos (n:=n) (by omega)
  unfold rate
  constructor
  · have hp : 0 < H.card^4+1-H.card := by omega
    positivity
  · apply (div_le_one hQ).mpr
    have hs : ((H.card^4+1-H.card:ℕ):ℝ) ≤ n := by exact_mod_cast (show H.card^4+1-H.card≤n by omega)
    exact (_root_.pow_le_pow_left₀ (by positivity) hs 2).trans (q_ge_sq hn)

theorem family_plateau (sp : Spec H (H.card^4) d) (hh : 2≤H.card) :
    (H.card:ℝ)^2*err H (H.card^4)/rate H (H.card^4) ≤ 8/(H.card:ℝ) := by
  obtain ⟨hn,hr,_⟩ := family_sizes sp hh
  have hQ := qpos (n:=n) (by omega)
  have hd : 0< H.card^4+1-H.card := by omega
  have hd' : 0 < ((H.card^4+1-H.card:ℕ):ℝ) := by exact_mod_cast hd
  have ha : 0 < (H.card:ℝ) := by exact_mod_cast (show 0<H.card by omega)
  have hb : (H.card:ℝ)^4 ≤ 2*((H.card^4+1-H.card:ℕ):ℝ) := by
    exact_mod_cast (show H.card^4 ≤ 2*(H.card^4+1-H.card) by omega)
  have hs := _root_.pow_le_pow_left₀ (by positivity : (0:ℝ)≤(H.card:ℝ)^4) hb 2
  unfold rate err
  push_cast
  field_simp
  nlinarith [mul_nonneg (by positivity : (0:ℝ)≤(H.card:ℝ)^0) (sub_nonneg.mpr hs)]

theorem exp_decay {a : ℝ} (ha : a≤1) (t : ℕ) :
    (1-a)^t ≤ Real.exp (-a*(t:ℝ)) := by
  rw [Real.exp_mul,Real.rpow_natCast]
  exact _root_.pow_le_pow_left₀ (sub_nonneg.mpr ha) (by linarith [Real.add_one_le_exp (-a)]) _

theorem family_bad_row (sp : Spec H (H.card^4) d) (hh : 2≤H.card)
    (t : ℕ) (G : GraphState n d) :
    row t G (bad H) ≤ (H.card:ℝ)^2*Real.exp (-rate H (H.card^4)*(t:ℝ))+8/(H.card:ℝ) := by
  have hr := family_rate sp hh
  have hn := (family_sizes sp hh).1
  apply (bad_row (by omega) sp hr.1 hr.2 t G).trans
  rw [mul_comm ((1-rate H (H.card^4))^t)]
  exact add_le_add (mul_le_mul_of_nonneg_left (exp_decay hr.2 t) (by positivity)) (family_plateau sp hh)

theorem family_bad_uniform (sp : Spec H (H.card^4) d) (hh : 2≤H.card) :
    uniformAverage n d (bad H) ≤ 8/(H.card:ℝ) := by
  have hn := (family_sizes sp hh).1
  exact (bad_uniform (by omega) sp (family_rate sp hh).1).trans (family_plateau sp hh)
#print axioms family_bad_row
#print axioms family_bad_uniform
end ManyCore
