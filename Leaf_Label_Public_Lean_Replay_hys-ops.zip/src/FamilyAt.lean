import ManyHubTransfer
import PhysicalCore

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n t : ℕ} {d : Fin n→ℕ} {H : Finset (Fin n)}

theorem family_leaves_ge_two (sp : ManyCore.Spec H (H.card^4) d) (hh : 2≤H.card) :
    2 ≤ (leaves d).card := by
  rw [leaf_count_family sp hh]
  have hr := (ManyCore.family_sizes sp hh).2.1
  exact hh.trans (Nat.le_mul_of_pos_right _ (by omega))

theorem family_shuffle_transfer_at (sp : ManyCore.Spec H (H.card^4) d) (hh : 1024≤H.card)
    (ht : ManyCore.coreClock n≤t) (G : GraphState n d) :
    tvDistanceFrom n d t G ≤ (1:ℝ)/16+
      ∑ k ∈ Finset.range (t+1),weight t k (iidClock d) *
        tv (((LeafMark.shuffle (LeafLabel d))^k) 1) (unif (LeafGroup d)) := by
  have hn := (ManyCore.family_sizes sp (by omega)).1
  rw [original_tv]
  apply (graph_shuffle_transfer (by omega) (family_leaves_ge_two sp (by omega)) t G).trans
  exact add_le_add_left ((core_exceptions sp (by omega) t G).trans (ManyCore.core_error_bound sp hh ht G)) _

#print axioms family_shuffle_transfer_at
end OAI.Problem315.LeafOrbit
