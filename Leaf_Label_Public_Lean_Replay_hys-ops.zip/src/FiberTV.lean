import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Data.Matrix.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Piecewise
import Mathlib.Tactic

open scoped BigOperators Matrix
noncomputable section
namespace HubTransfer
variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq X] [DecidableEq C]

def tv {A : Type*} [Fintype A] (a b : A → ℝ) : ℝ := (∑ x, |a x-b x|)/2

def unif (X : Type*) [Fintype X] (_x : X) : ℝ := 1/(Fintype.card X : ℝ)

def push (π : X → C) (u : X → ℝ) (c : C) : ℝ :=
  ∑ x, if π x = c then u x else 0

def fiberSize (π : X → C) (c : C) : ℕ := (Finset.univ.filter (fun x => π x = c)).card

def lift (π : X → C) (v : C → ℝ) (x : X) : ℝ := v (π x)/(fiberSize π (π x) : ℝ)

/-- Averaging each row uniformly over its own fiber. -/
def avg (π : X → C) : Matrix X X ℝ :=
  fun x y => if π x = π y then 1/(fiberSize π (π y) : ℝ) else 0

theorem fiberSize_pos (π : X → C) (x : X) : 0 < fiberSize π (π x) := by
  apply Finset.card_pos.mpr
  exact ⟨x, Finset.mem_filter.mpr ⟨Finset.mem_univ _,rfl⟩⟩

theorem push_const (π : X → C) (z : ℝ) (c : C) :
    push π (fun _ => z) c = (fiberSize π c : ℝ)*z := by
  unfold push
  rw [← Finset.sum_filter, Finset.sum_const, nsmul_eq_mul]
  rfl

theorem lift_push_unif (π : X → C) : lift π (push π (unif X)) = unif X := by
  funext x
  unfold lift unif
  rw [push_const]
  have h : (fiberSize π (π x) : ℝ) ≠ 0 := by exact_mod_cast (fiberSize_pos π x).ne'
  field_simp

theorem row_avg (π : X → C) (M : Matrix X X ℝ) (x y : X) :
    (M * avg π) x y = lift π (push π (M x)) y := by
  unfold lift push
  rw [Matrix.mul_apply,Finset.sum_div]
  apply Finset.sum_congr rfl
  intro z _
  by_cases h : π z = π y <;> simp [avg,h, div_eq_mul_inv]

/-- The lift of quotient mass spreads that mass uniformly and preserves TV. -/
theorem tv_lift (π : X → C) (hs : Function.Surjective π) (a b : C → ℝ) :
    tv (lift π a) (lift π b) = tv a b := by
  have hv (c : C) : (fiberSize π c : ℝ) ≠ 0 := by
    obtain ⟨x,rfl⟩ := hs c
    exact_mod_cast (fiberSize_pos π x).ne'
  have hgrp (g : X → ℝ) :
      (∑ x,g x) = ∑ c : C, ∑ x, if π x=c then g x else 0 := by
    rw [Finset.sum_comm]; simp
  unfold tv
  congr 1
  rw [hgrp]
  apply Finset.sum_congr rfl
  intro c _
  calc
    _ = ∑ x : X, if π x=c then |a c-b c|/(fiberSize π c : ℝ) else 0 := by
      apply Finset.sum_congr rfl
      intro x _
      by_cases h : π x=c
      · simp only [h,ite_true,lift,← sub_div,abs_div,abs_of_nonneg (show 0 ≤ (fiberSize π c : ℝ) by positivity)]
      · simp [h]
    _ = |a c-b c| := by
      change push π (fun _ => |a c-b c|/(fiberSize π c:ℝ)) c = _
      rw [push_const]
      field_simp [hv c]

/-- The TV error of the fiber-averaged law is exactly the observable quotient error. -/
theorem averaged_tv (π : X → C) (hs : Function.Surjective π) (M : Matrix X X ℝ) (x : X) :
    tv ((M*avg π) x) (unif X) = tv (push π (M x)) (push π (unif X)) := by
  have h : (M*avg π) x = lift π (push π (M x)) := funext (row_avg π M x)
  rw [h, ← lift_push_unif π, tv_lift π hs, lift_push_unif]

theorem tv_triangle {A : Type*} [Fintype A] (a b c : A → ℝ) :
    tv a c ≤ tv a b + tv b c := by
  unfold tv
  rw [← add_div,← Finset.sum_add_distrib]
  exact div_le_div_of_nonneg_right (Finset.sum_le_sum fun x _ =>
    abs_sub_le (a x) (b x) (c x)) (by norm_num)

#print axioms tv_lift
#print axioms averaged_tv
end HubTransfer
