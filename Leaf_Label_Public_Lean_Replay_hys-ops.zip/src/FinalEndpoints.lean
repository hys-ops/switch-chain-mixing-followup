import ProfileAudit
import ExactFinite
import CriticalLogWindow
import FixedStrict
import WindowWidth

#check LeafResult.many_hub_theta
#check LeafResult.time_bounds
#check SharpClock.graph_finite
#check SharpClock.worst_finite
#check UrnWindow.Degrees.dense_graph_uniform
#check CriticalResult.critical_graph_uniform
#check HubMarks.sparse_graph_uniform
#check CriticalAlternative.critical_logK_graph_uniform
#check TwoHubWorst.limit
#check HubMarks.fixed_edge_uniform
#check HubMarks.fixed_vertex_uniform
#check Avoid.fixed_worst
#check Avoid.fixed_no_cutoff
#check GrowingInverse.original_time
#check GrowingInverse.original_quarter
#print axioms LeafResult.many_hub_theta
#print axioms SharpClock.graph_finite
#print axioms SharpClock.worst_finite
#print axioms TwoHubWorst.limit
#print axioms CriticalAlternative.critical_logK_graph_uniform
#print axioms Avoid.joined_eventually_farther
#print axioms GrowingInverse.original_time
#print axioms GrowingInverse.original_quarter

#check GrowingInverse.window_width
#check GrowingInverse.cutoff_ratio
#print axioms GrowingInverse.window_width
#print axioms GrowingInverse.cutoff_ratio
