import Mathlib.MeasureTheory.Measure.LevyConvergence
import Mathlib.MeasureTheory.Measure.Portmanteau
import Mathlib.MeasureTheory.Integral.Bochner.SumMeasure
import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.Probability.CDF
namespace FiniteLevy
open Filter Topology Set MeasureTheory ProbabilityTheory Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {X : Type*} [Fintype X]

def asMeasure (w y : X→ℝ) : Measure ℝ := Measure.sum (fun i => ENNReal.ofReal (w i) • Measure.dirac (y i))

theorem eval (w y : X→ℝ) {s : Set ℝ} (hs : MeasurableSet s) :
    asMeasure w y s = ∑ i, if y i∈s then ENNReal.ofReal (w i) else 0 := by
  rw [asMeasure,Measure.sum_apply _ hs,tsum_fintype]
  apply sum_congr rfl;intro i _
  simp only [Measure.smul_apply,Measure.dirac_apply' _ hs,smul_eq_mul]
  by_cases h : y i∈s <;> simp [Set.indicator,h]

theorem total (w y : X→ℝ) (hw : ∀i,0≤w i) (ht : ∑i,w i=1) : IsProbabilityMeasure (asMeasure w y) := by
  constructor
  rw [eval w y MeasurableSet.univ]
  simp only [Set.mem_univ,ite_true]
  rw [←ENNReal.ofReal_sum_of_nonneg (fun i _ => hw i),ht,ENNReal.ofReal_one]

def asProbability (w y : X→ℝ) (hw : ∀i,0≤w i) (ht : ∑i,w i=1) : ProbabilityMeasure ℝ :=
  ⟨asMeasure w y,total w y hw ht⟩

theorem char (w y : X→ℝ) (hw : ∀i,0≤w i) (θ : ℝ) :
    charFun (asMeasure w y) θ = ∑ i, (w i:ℂ)*Complex.exp ((θ:ℂ)*y i*Complex.I) := by
  rw [charFun_apply_real,asMeasure,integral_sum_dirac (by intro i;exact ENNReal.ofReal_ne_top),tsum_fintype]
  apply sum_congr rfl;intro i _
  simp [ENNReal.toReal_ofReal (hw i),Complex.real_smul]

theorem threshold (w y : X→ℝ) (hw : ∀i,0≤w i) (z : ℝ) :
    (asMeasure w y).real (Iic z) = ∑ i,if y i≤z then w i else 0 := by
  rw [measureReal_def,eval _ _ measurableSet_Iic,ENNReal.toReal_sum]
  · apply sum_congr rfl;intro i _;by_cases h : y i≤z <;> simp [h,ENNReal.toReal_ofReal (hw i)]
  · intro i _;split <;> simp

/-- Finite arrays of weights on arbitrary real support (with repeated scores allowed).
Pointwise convergence of the exact finite characteristic functions gives the CDF limit
at each threshold for any Gaussian mean. -/
theorem cdf_of_gaussian_char {Y : ℕ→Type*} [∀i,Fintype (Y i)]
    (w y : (i:ℕ)→Y i→ℝ) (hw : ∀ i j,0≤w i j) (ht : ∀i,∑j,w i j=1)
    (m : ℝ) (hc : ∀θ:ℝ,Tendsto (fun i => ∑j,(w i j:ℂ)*Complex.exp ((θ:ℂ)*y i j*Complex.I))
      atTop (𝓝 (Complex.exp ((θ:ℂ)*m*Complex.I-(θ:ℂ)^2/2)))) (z : ℝ) :
    Tendsto (fun i => ∑j,if y i j≤z then w i j else 0) atTop (𝓝 (cdf (gaussianReal m 1) z)) := by
  let p := fun i => asProbability (w i) (y i) (hw i) (ht i)
  let p₀ : ProbabilityMeasure ℝ := ⟨gaussianReal m 1,inferInstance⟩
  have weak : Tendsto p atTop (𝓝 p₀) := by
    apply ProbabilityMeasure.tendsto_of_tendsto_charFun
    intro θ
    change Tendsto (fun i=>charFun (asMeasure (w i) (y i)) θ) atTop (𝓝 (charFun (gaussianReal m 1) θ))
    simp only [char _ _ (hw _) θ,charFun_gaussianReal,NNReal.coe_one,Complex.ofReal_one,one_mul]
    exact hc θ
  haveI : NullSingletonClass (gaussianReal m 1) := nullSingletonClass_gaussianReal one_ne_zero
  have hz : (p₀:Measure ℝ) (frontier (Iic z))=0 := by
    change gaussianReal m 1 (frontier (Iic z))=0
    rw [frontier_Iic,measure_singleton]
  have conv := ProbabilityMeasure.tendsto_measure_of_null_frontier_of_tendsto' weak hz
  have h := (ENNReal.tendsto_toReal (measure_ne_top (p₀:Measure ℝ) (Iic z))).comp conv
  rw [cdf_eq_real]
  apply h.congr
  intro i;exact threshold _ _ (hw i) z

theorem cdf_standard {Y : ℕ→Type*} [∀i,Fintype (Y i)]
    (w y : (i:ℕ)→Y i→ℝ) (hw : ∀ i j,0≤w i j) (ht : ∀i,∑j,w i j=1)
    (hc : ∀θ:ℝ,Tendsto (fun i => ∑j,(w i j:ℂ)*Complex.exp ((θ:ℂ)*y i j*Complex.I))
      atTop (𝓝 (Complex.exp (-(θ:ℂ)^2/2)))) (z : ℝ) :
    Tendsto (fun i => ∑j,if y i j≤z then w i j else 0) atTop (𝓝 (cdf (gaussianReal 0 1) z)) := by
  apply cdf_of_gaussian_char w y hw ht 0 _ z
  intro θ;simpa [neg_div] using hc θ
#print axioms cdf_of_gaussian_char
#print axioms cdf_standard
end
end FiniteLevy
