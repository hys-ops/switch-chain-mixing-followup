import SplitKernel
open Finset HubTransfer
open scoped Matrix
noncomputable section
namespace LeafSplit
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- Freeze every state in the target stratum. The other rows are untouched. -/
def frozen (edge : X → Prop) [DecidablePred edge] (V : Matrix X X ℝ) : Matrix X X ℝ :=
  fun x y => if edge x then (1 : Matrix X X ℝ) x y else V x y
theorem frozen_stoch (edge : X → Prop) [DecidablePred edge] (V : Matrix X X ℝ)
    (hv : Stochastic V) : Stochastic (frozen edge V) := by
  constructor
  · intro x y;by_cases h : edge x
    · simp only [frozen,h,ite_true,Matrix.one_apply];split <;> norm_num
    · simpa [frozen,h] using hv.1 x y
  · intro x;by_cases h : edge x
    · simp [frozen,h,Matrix.one_apply]
    · simpa [frozen,h] using hv.2 x

theorem frozen_error (edge : X → Prop) [DecidablePred edge] (V : Matrix X X ℝ)
    (hv : Stochastic V) (b : ℝ) (hb : 0≤b)
    (hd : ∀ x,edge x → 1-V x x≤b) (t : ℕ) (x : X) :
    tv ((V^t) x) (((frozen edge V)^t) x) ≤ (t:ℝ)*b := by
  apply power_error V _ hv (frozen_stoch edge V hv)
  intro y;by_cases h : edge y
  · have he : frozen edge V y = (1 : Matrix X X ℝ) y := by funext z;simp [frozen,h]
    rw [he];unfold tv
    change (∑ z,|(V-1) y z|)/2 ≤ b
    rw [row_abs_sub_id V hv y];linarith [hd y h]
  · have he : frozen edge V y = V y := by funext z;simp [frozen,h]
    simp [he,tv,hb]

theorem frozen_edge (edge : X → Prop) [DecidablePred edge] (V : Matrix X X ℝ)
    (x : X) (hx : edge x) (t : ℕ) : ((frozen edge V)^t) x = (1 : Matrix X X ℝ) x := by
  induction t with
  | zero => simp
  | succ t ih =>
    funext y;rw [pow_succ,Matrix.mul_apply,ih]
    change ((1 : Matrix X X ℝ)*frozen edge V) x y = _
    rw [one_mul]
    simp [frozen,hx]

/-- From a vertex, its first exit has the prescribed law U. It then remains in the edge stratum. -/
theorem frozen_vertex (edge : X → Prop) [DecidablePred edge] (V : Matrix X X ℝ)
    (x : X) (hx : ¬edge x) (a : ℝ) (U : X → ℝ)
    (hrow : ∀ y,V x y=(1-a)*(1 : Matrix X X ℝ) x y+a*U y)
    (hsupp : ∀ y,¬edge y → U y=0) (t : ℕ) :
    ((frozen edge V)^t) x = fun y => (1-a)^t*(1 : Matrix X X ℝ) x y+(1-(1-a)^t)*U y := by
  induction t with
  | zero => funext y;simp
  | succ t ih =>
    funext y
    rw [pow_succ,Matrix.mul_apply,ih]
    simp only [add_mul,Finset.sum_add_distrib,mul_assoc,←Finset.mul_sum]
    have h1 : (∑ z,(1 : Matrix X X ℝ) x z*frozen edge V z y)=V x y := by
      change ((1 : Matrix X X ℝ)*frozen edge V) x y = _
      rw [one_mul]
      simp [frozen,hx]
    have h2 : (∑ z,U z*frozen edge V z y)=U y := by
      calc
        _ = ∑ z,U z*(1 : Matrix X X ℝ) z y := by
          apply sum_congr rfl;intro z _
          by_cases h : edge z
          · simp [frozen,h]
          · simp [hsupp z h]
        _ = _ := by simp [Matrix.one_apply,mul_ite]
    rw [h1,h2,hrow,pow_succ];ring

/-- The approximation remains valid after the full horizontal dynamics is applied. -/
theorem vertical_after_horizontal (P H V : Matrix X X ℝ)
    (hp : Stochastic P) (hh : Stochastic H) (hv : Stochastic V)
    (form : P=H+V-1) (comm : Commute V H) {u v b : ℝ} (hu : 0≤u) (hb : 0≤b)
    (hdH : ∀ x,1-H x x≤u) (hdV : ∀ x,1-V x x≤v)
    (edge : X → Prop) [DecidablePred edge] (hedge : ∀ x,edge x→1-V x x≤b)
    (t : ℕ) (x : X) :
    tv ((P^t) x) ((((frozen edge V)^t)*(H^t)) x) ≤ (t:ℝ)*(2*u*v+b) := by
  have h1 := separated_powers P H V hp hh hv form comm hu hdV hdH t x
  have h2 := tv_contract (H^t) (stochastic_pow hh t) ((V^t) x) (((frozen edge V)^t) x)
  change tv ((V^t*H^t) x) ((((frozen edge V)^t)*H^t) x) ≤ _ at h2
  have h3 := frozen_error edge V hv b hb hedge t x
  have h4 := tv_triangle ((P^t) x) ((V^t*H^t) x) ((((frozen edge V)^t)*H^t) x)
  linarith

#print axioms frozen_vertex
#print axioms vertical_after_horizontal
end LeafSplit
