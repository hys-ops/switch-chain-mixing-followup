import Family
noncomputable section
open Finset
namespace Avoid
attribute [local instance] Classical.propDecidable
variable {X : Type*} [Fintype X] [DecidableEq X]

def color (T A B : Finset X) (x : X) : Sum X (Option Bool) :=
  if x∈T then .inl x else if x∈A then .inr (some true) else if x∈B then .inr (some false) else .inr none

theorem color_fixed (T A B : Finset X) (u v : X) :
    color T A B v=.inl u ↔ v=u ∧ u∈T := by
  by_cases e : v=u
  · subst v;by_cases h : u∈T <;> by_cases q : u∈A <;> by_cases z : u∈B <;> simp [color,h,q,z]
  · by_cases h : v∈T <;> by_cases q : v∈A <;> by_cases z : v∈B <;> simp [color,h,e,q,z]

theorem color_a {T A B : Finset X} (h : Disjoint T A) (x:X) :
    color T A B x=.inr (some true) ↔ x∈A := by
  by_cases p : x∈T
  · simp [color,p,Finset.disjoint_left.mp h p]
  · by_cases q : x∈A <;> by_cases u : x∈B <;> simp [color,p,q,u]

theorem color_b {T A B : Finset X} (h : Disjoint T B) (h' : Disjoint A B) (x:X) :
    color T A B x=.inr (some false) ↔ x∈B := by
  by_cases p : x∈T
  · simp [color,p,Finset.disjoint_left.mp h p]
  · by_cases q : x∈A
    · simp [color,p,q,Finset.disjoint_left.mp h' q]
    · by_cases u : x∈B <;> simp [color,p,q,u]

theorem color_none {T A B : Finset X} (x : X) :
    color T A B x=.inr none ↔ x∈(T∪A∪B)ᶜ := by
  by_cases p : x∈T <;> by_cases q : x∈A <;> by_cases u : x∈B <;> simp [color,p,q,u]

theorem three_sets {T A B C D : Finset X} (hta : Disjoint T A) (htb : Disjoint T B)
    (hab : Disjoint A B) (htc : Disjoint T C) (htd : Disjoint T D) (hcd : Disjoint C D)
    (hac : A.card=C.card) (hbd : B.card=D.card) :
    ∃ σ : Equiv.Perm X, (∀ x∈T,σ x=x) ∧ (∀x,σ x∈C ↔ x∈A) ∧ (∀x,σ x∈D ↔ x∈B) := by
  have he (s : Sum X (Option Bool)) :
      Fintype.card {x // color T A B x=s} = Fintype.card {x // color T C D x=s} := by
    rw [Fintype.card_subtype,Fintype.card_subtype]
    cases s with
    | inl x => simp only [color_fixed]
    | inr q =>
      cases q with
      | none =>
        simp only [color_none,filter_mem_eq_inter,univ_inter,card_compl,card_union_of_disjoint
          (Finset.disjoint_union_left.mpr ⟨htb,hab⟩),card_union_of_disjoint (Finset.disjoint_union_left.mpr ⟨htd,hcd⟩),
          card_union_of_disjoint hta,card_union_of_disjoint htc,hac,hbd]
      | some b => cases b <;>
        simp only [color_a hta,color_a htc,color_b htb hab,color_b htd hcd,filter_mem_eq_inter,univ_inter,hac,hbd]
  let O := fun s => Fintype.equivOfCardEq (he s)
  let σ : Equiv.Perm X := Equiv.ofFiberEquiv O
  have hm x : color T C D (σ x)=color T A B x := Equiv.ofFiberEquiv_map O x
  refine ⟨σ,fun x hx => ?_,fun x => ?_,fun x => ?_⟩
  · exact ((color_fixed _ _ _ _ _).1 ((hm x).trans ((color_fixed _ _ _ _ _).2 ⟨rfl,hx⟩))).1
  · rw [←color_a htc (B:=D),hm,color_a hta]
  · rw [←color_b htd hcd,hm,color_b htb hab]
#print axioms three_sets
end Avoid
