import GraphGoodMass
import MarkProfile
open Filter Topology OAI.Problem315
namespace HubMarks
noncomputable section
open TwoHubUnequal

def graphError (r a : ℕ) (u : ℝ) (k : ℕ) : ℝ :=
  2*(3*(localTime r u k:ℝ)/Q r k) + (2:ℝ)^a*((localTime r u k:ℝ)*(r+1)/Q r k)
def statError (r k : ℕ) : ℝ := stationary r (k+2)+((r:ℝ)+1)^2/N r k

lemma graphError_zero (r a : ℕ) (u : ℝ) (hu : 0≤u) :
    Tendsto (graphError r a u) atTop (𝓝 0) := by
  have ht := ((tendsto_const_nhds (x:=(2:ℝ))).mul (GraphSplit.error_vanishes r hu)).add
    (rare_error r (r+1) a u hu)
  change Tendsto (fun k => 2*(3*(localTime r u k:ℝ)/Q r k) + (2:ℝ)^a*((localTime r u k:ℝ)*(r+1)/Q r k)) atTop (𝓝 0)
  simpa [Q,Nat.cast_add] using ht
lemma statError_zero {r : ℕ} (hr : 2≤r) : Tendsto (statError r) atTop (𝓝 0) := by
  have ht := (stationary_zero r (by omega)).add ((tendsto_const_nhds (x:=((r:ℝ)+1)^2)).div_atTop (Ntop r))
  change Tendsto (fun k=>stationary r (k+2)+((r:ℝ)+1)^2/N r k) atTop (𝓝 0)
  simpa using ht

/-- A uniform finite bound at an arbitrary original state turns paired event and stationarity
errors into a bound on worst-within-shape TV. -/
lemma uniform_transfer {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u) (a : ℕ)
    (D : (k : ℕ) → GraphState (r+k+4) (F.d k) → Prop) (z : ℕ→ℝ) (b : ℝ)
    (hh : ∀ᶠ k : ℕ in atTop, ∀ G : GraphState (r+k+4) (F.d k), D k G →
      |Avoid.goodMass (F.a k) (F.c k) (Avoid.marked (F.a k) (F.c k) G) (localTime r u k) G -z k|
        ≤ graphError r a u k) (ht : Tendsto z atTop (𝓝 b)) (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ k : ℕ in atTop, ∀ G : GraphState (r+k+4) (F.d k), D k G →
      |tvDistanceFrom _ (F.d k) (localTime r u k) G-(1-b)|<ε := by
  have hz : Tendsto (fun k => |z k-b|) atTop (𝓝 0) := by simpa using (ht.sub_const b).abs
  have he := ((statError_zero hr).add (graphError_zero r a u hu)).add hz
  simp only [zero_add] at he
  filter_upwards [hh,(tendsto_order.mp he).2 ε hε] with k hrow herr
  intro G hg
  let g := Avoid.goodMass (F.a k) (F.c k) (Avoid.marked (F.a k) (F.c k) G) (localTime r u k) G
  let v := tvDistanceFrom _ (F.d k) (localTime r u k) G
  have h1 : |v-(1-g)| ≤ statError r k := by
    have h := Avoid.graph_tv_initial (F.spec k) (by omega) (by omega) G (localTime r u k)
    simpa [v,g,statError,N,Nat.cast_add,add_assoc] using h
  have h2 : |g-z k|≤graphError r a u k := hrow G hg
  have he₁ : |(1-g)-(1-b)|=|g-b| := by rw [show (1-g)-(1-b) = -(g-b) by ring,abs_neg]
  have ha := abs_sub_le v (1-g) (1-b)
  rw [he₁] at ha
  exact lt_of_le_of_lt (ha.trans ((add_le_add h1 ((abs_sub_le g (z k) b).trans (add_le_add h2 le_rfl))).trans_eq (by ring))) herr

/-- The full original graph TV distance, uniformly over all hub-edge starting graphs. -/
theorem fixed_edge_uniform {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ k : ℕ in atTop, ∀ G : GraphState (r+k+4) (F.d k), G.val.Adj (F.a k) (F.c k) →
      |tvDistanceFrom _ (F.d k) (localTime r u k) G -
        (1-(1-Real.exp (-u))^(r+1))|<ε := by
  apply uniform_transfer hr F u hu (r+1) _ (fun k=>avoidApprox (r+k+2) (r+1) (r+1) (Q r k) (localTime r u k)) _ _ (avoid_approx_limit r (r+1) (r+1) u hu) ε hε
  filter_upwards [cap_eventually r (r+1)] with k hk
  intro G hg
  have rs : (2:ℝ)≤(r:ℝ)*(k+2:ℕ) := by
    exact_mod_cast (show 2≤r*(k+2) by nlinarith)
  exact edge_good (F.spec k) (by omega) (by omega) rs hk G hg (localTime r u k)

/-- The full original graph TV distance, uniformly over starts without the hub edge.
The no-first-exit factor remains of constant size on the fixed-degree window. -/
theorem fixed_vertex_uniform {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ k : ℕ in atTop, ∀ G : GraphState (r+k+4) (F.d k), ¬G.val.Adj (F.a k) (F.c k) →
      |tvDistanceFrom _ (F.d k) (localTime r u k) G -
        (1-(1-Real.exp (-(u*r)))*(1-Real.exp (-u))^r)|<ε := by
  let w := fun k => (1-(r:ℝ)*(k+2)/Q r k)^(localTime r u k)
  let z := fun k => (1-w k)*avoidApprox (r+k+2) (r+1) r (Q r k) (localTime r u k)
  have ht : Tendsto z atTop (𝓝 ((1-Real.exp (-(u*r)))*(1-Real.exp (-u))^r)) :=
    ((tendsto_const_nhds (x:=(1:ℝ))).sub (GraphSplit.first_exit_weight_limit r u hu)).mul
       (avoid_approx_limit r (r+1) r u hu)
  apply uniform_transfer hr F u hu r _ z _ _ ht ε hε
  filter_upwards [cap_eventually r (r+1)] with k hk
  intro G hg
  have rs : (2:ℝ)≤(r:ℝ)*(k+2:ℕ) := by exact_mod_cast (show 2≤r*(k+2) by nlinarith)
  have H := vertex_good (F.spec k) (by omega) (by omega) rs hk G hg (localTime r u k)
  simpa [z,w,noExit,windowApprox,windowError,graphError,Q,Nat.cast_add,Nat.add_assoc] using H

theorem fixed_edge {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (G : (k:ℕ) → GraphState (r+k+4) (F.d k))
    (hG : ∀ k,(G k).val.Adj (F.a k) (F.c k)) :
    Tendsto (fun k => tvDistanceFrom _ (F.d k) (localTime r u k) (G k)) atTop
      (𝓝 (1-(1-Real.exp (-u))^(r+1))) := by
  apply Metric.tendsto_nhds.mpr;intro ε hε
  filter_upwards [fixed_edge_uniform hr F u hu ε hε] with k h
  exact h (G k) (hG k)

theorem fixed_vertex {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (G : (k:ℕ) → GraphState (r+k+4) (F.d k))
    (hG : ∀ k,¬(G k).val.Adj (F.a k) (F.c k)) :
    Tendsto (fun k => tvDistanceFrom _ (F.d k) (localTime r u k) (G k)) atTop
      (𝓝 (1-(1-Real.exp (-(u*r)))*(1-Real.exp (-u))^r)) := by
  apply Metric.tendsto_nhds.mpr;intro ε hε
  filter_upwards [fixed_vertex_uniform hr F u hu ε hε] with k h
  exact h (G k) (hG k)

#print axioms fixed_edge_uniform
#print axioms fixed_vertex_uniform
#print axioms fixed_edge
#print axioms fixed_vertex
end
end HubMarks
