import Quantiles
import FixedWorst
namespace Avoid
open OAI.Problem315 TwoHubUnequal Finset Filter Topology
noncomputable section
variable {r : ℕ}

theorem fixed_accuracy_clock (hr : 2≤r) (F : Family r) (ε : ℝ) (he : 0<ε) (he' : ε<1) :
    Tendsto (fun k => (threshold (F.spec k) ε:ℝ)*(N r k/Q r k)) atTop (𝓝 (inverseCurve r ε)) :=
  threshold_limit_of_worst F ε he he' (fixed_worst hr F)

theorem fixed_ratio (hr : 2≤r) (F : Family r) {ε δ : ℝ} (he : 0<ε) (hed : ε<δ) (hd : δ<1) :
    Tendsto (fun k => (threshold (F.spec k) ε:ℝ)/(threshold (F.spec k) δ:ℝ)) atTop
       (𝓝 (inverseCurve r ε / inverseCurve r δ)) ∧
    1 < inverseCurve r ε / inverseCurve r δ := by
  have hp := inverse_pos (r:=r) (he.trans hed) hd
  constructor
  · have h := (fixed_accuracy_clock hr F ε he (hed.trans hd)).div
      (fixed_accuracy_clock hr F δ (he.trans hed) hd) hp.ne'
    apply h.congr;intro k
    exact mul_div_mul_right _ _ (div_pos (Npos r k) (Qpos r k)).ne'
  · exact (one_lt_div hp).mpr (inverse_separated he hed hd)

theorem fixed_no_cutoff (hr : 2≤r) (F : Family r) {ε δ : ℝ} (he : 0<ε) (hed : ε<δ) (hd : δ<1) :
    ¬ Tendsto (fun k => (threshold (F.spec k) ε:ℝ)/(threshold (F.spec k) δ:ℝ)) atTop (𝓝 1) := by
  intro h
  obtain ⟨ht,hs⟩ := fixed_ratio hr F he hed hd
  exact hs.ne' (tendsto_nhds_unique ht h)
#print axioms fixed_accuracy_clock
#print axioms fixed_no_cutoff
end
end Avoid
