import FixedWorst
open Filter Topology OAI.Problem315 TwoHubUnequal
noncomputable section
namespace Avoid
/-- Fixed-degree point-start profiles in Theorem 7 coincide at the left endpoint. -/
theorem curves_at_zero {r : ℕ} (hr : 2≤r) :
    edgeCurve r 0 = 1 ∧ vertexCurve r 0 = 1 := by
  simp [edgeCurve,vertexCurve]

/-- For positive rescaled time, the joined stratum has strictly larger asymptotic TV. -/
theorem profile_order_strict {r : ℕ} (hr : 2≤r) {u : ℝ} (hu : 0<u) :
    vertexCurve r u < edgeCurve r u := by
  have hr' : 1<(r:ℝ) := by exact_mod_cast (show 1<r by omega)
  have hx : Real.exp (-(u*r)) < Real.exp (-u) := by
    apply Real.exp_lt_exp.mpr
    nlinarith [mul_pos hu (sub_pos.mpr hr')]
  have hpos : 0<1-Real.exp (-u) :=
    sub_pos.mpr (Real.exp_lt_one_iff.mpr (neg_lt_zero.mpr hu))
  unfold vertexCurve edgeCurve
  rw [pow_succ]
  nlinarith only [mul_lt_mul_of_pos_left (sub_lt_sub_left hx 1) (pow_pos hpos r)]

/-- A uniform, eventual separation on the original labeled-graph switch chain. -/
theorem joined_eventually_farther {r : ℕ} (hr : 2≤r) (F : Family r) {u : ℝ} (hu : 0<u) :
    ∀ᶠ k in atTop, ∀ E V : GraphState (r+k+4) (F.d k),
      (E.val.Adj (F.a k) (F.c k)) → ¬(V.val.Adj (F.a k) (F.c k)) →
      tvDistanceFrom _ (F.d k) (localTime r u k) V <
        tvDistanceFrom _ (F.d k) (localTime r u k) E := by
  let e := (edgeCurve r u - vertexCurve r u)/3
  have he : 0<e := div_pos (sub_pos.mpr (profile_order_strict hr hu)) (by norm_num)
  filter_upwards [HubMarks.fixed_edge_uniform hr F u hu.le e he,
    HubMarks.fixed_vertex_uniform hr F u hu.le e he] with k hE hV
  intro E V hE' hV'
  have lo := (abs_lt.mp (hE E hE')).1
  have hi := (abs_lt.mp (hV V hV')).2
  change -e < _ - edgeCurve r u at lo
  change _ - vertexCurve r u < e at hi
  dsimp only [e] at *
  linarith
#print axioms curves_at_zero
#print axioms profile_order_strict
#print axioms joined_eventually_farther
end Avoid
