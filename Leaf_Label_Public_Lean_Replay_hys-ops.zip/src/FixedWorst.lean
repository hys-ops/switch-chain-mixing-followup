import WorstLimit
import FixedHubProfile
namespace Avoid
open OAI.Problem315 TwoHubUnequal Filter Topology
noncomputable section
/-- Unconditional limiting maximum over **all** labeled realizations of each original degree vector. -/
theorem fixed_worst {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u) :
    Tendsto (fun k => worstTV (F.spec k) (localTime r u k)) atTop (𝓝 (edgeCurve r u)) :=
  worst_limit_of_layers hr F u hu (HubMarks.fixed_edge hr F u hu) (HubMarks.fixed_vertex hr F u hu)
#print axioms fixed_worst
end
end Avoid
