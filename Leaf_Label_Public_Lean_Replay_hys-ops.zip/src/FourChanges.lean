import LeafSwap
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

lemma three_changes {G J : SimpleGraph (Fin n)} {x y z w : Fin n} (hd : FourDistinct x y z w)
    (step : ∃ p, validSwitch G p ∧ proposalResult G p=J)
    (hxy : G.Adj x y ∧ ¬J.Adj x y) (hzw : G.Adj z w ∧ ¬J.Adj z w)
    (hxz : J.Adj x z ∧ ¬G.Adj x z) :
    J=proposalResult G (fourVertexProposal x y z w hd) := by
  obtain ⟨p,hp,rfl⟩:=step
  have txz := (addedMatching_adj_iff hp x z).mpr hxz
  obtain ⟨y',w',hf,_,_,_,he⟩:=gains_normal hp txz
  have h₁ := (removedMatching_adj_iff hp x y).mpr hxy
  have h₂ := (removedMatching_adj_iff hp z w).mpr hzw
  have h₁' : (removedMatching p).Adj x y' := by rw [he];simp
  have h₂' : (removedMatching p).Adj z w' := by rw [he];simp
  obtain rfl : y'=y := partner_unique _ h₁' h₁
  obtain rfl : w'=w := partner_unique _ h₂' h₂
  rw [he]

lemma realize_diagonal (G : GraphState n d) {x y z w : Fin n} (hd : FourDistinct x y z w)
    (hxy : G.val.Adj x y) (hzw : G.val.Adj z w) (hxz : ¬G.val.Adj x z) (hyw : ¬G.val.Adj y w)
    (i j : Fin n) (hi : d i=1) (hj : d j=1)
    (hp : (i=x ∧ j=w) ∨ (i=y ∧ j=z)) :
    G.val.comap (Equiv.swap i j)=proposalResult G.val (fourVertexProposal x y z w hd) := by
  let J := G.val.comap (Equiv.swap i j)
  have ⟨d1,d2,d3,d4,d5,d6⟩:=hd
  have e1:=Ne.symm d1;have e2:=Ne.symm d2;have e3:=Ne.symm d3;have e4:=Ne.symm d4;have e5:=Ne.symm d5;have e6:=Ne.symm d6
  have h' : ¬J.Adj x y ∧ ¬J.Adj z w ∧ J.Adj x z := by
    rcases hp with ⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;>
      simp_all [J,Equiv.swap_apply_def,SimpleGraph.adj_comm]
  apply three_changes hd _ ⟨hxy,h'.1⟩ ⟨hzw,h'.2.1⟩ ⟨h'.2.2,hxz⟩
  rcases leaf_swap G i j hi hj with he|he
  · have eJ : J=G.val := he;rw [eJ] at h';exact (h'.1 hxy).elim
  · exact he

/-- The possible label-transposition generators of a nontrivial switch are the
two diagonals of its four changed adjacencies. -/
lemma only_diagonals {G H : SimpleGraph (Fin n)} {x y z w i j : Fin n} (h : FourDistinct x y z w)
    (hxy : G.Adj x y ∧ ¬H.Adj x y) (hzw : G.Adj z w ∧ ¬H.Adj z w)
    (hxz : H.Adj x z ∧ ¬G.Adj x z) (hyw : H.Adj y w ∧ ¬G.Adj y w)
    (he : G.comap (Equiv.swap i j)=H) :
    ({i,j}:Finset (Fin n))={x,w} ∨ ({i,j}:Finset (Fin n))={y,z} := by
  have hit (u v : Fin n) (hu : ¬(G.Adj u v ↔ H.Adj u v)) : u=i ∨ u=j ∨ v=i ∨ v=j := by
    by_contra! hn
    apply hu;rw [←he];change G.Adj u v ↔ G.Adj (Equiv.swap i j u) (Equiv.swap i j v)
    rw [Equiv.swap_apply_of_ne_of_ne hn.1 hn.2.1,Equiv.swap_apply_of_ne_of_ne hn.2.2.1 hn.2.2.2]
  have a₁ := hit x y (fun e=>hxy.2 (e.mp hxy.1))
  have a₂ := hit z w (fun e=>hzw.2 (e.mp hzw.1))
  have a₃ := hit x z (fun e=>hxz.2 (e.mpr hxz.1))
  have a₄ := hit y w (fun e=>hyw.2 (e.mpr hyw.1))
  obtain ⟨_,_,_,_,_,_⟩:=h
  have hh : (i=x ∧ j=w) ∨ (i=w ∧ j=x) ∨ (i=y ∧ j=z) ∨ (i=z ∧ j=y) := by grind
  rcases hh with ⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩ <;> simp [Finset.pair_comm]

#print axioms realize_diagonal
end
end TwoHubHorizontal
