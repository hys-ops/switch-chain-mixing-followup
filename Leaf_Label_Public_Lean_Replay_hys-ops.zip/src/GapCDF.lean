import GapMix
import DenseClock
open Finset Filter Topology
namespace HubDense
noncomputable section

def finiteCDF {X : Type*} [Fintype X] (p : X→ℝ) (f : X→ℝ) (z : ℝ) : ℝ :=
   ∑ x, if f x≤z then p x else 0

theorem cdf_upper {X : Type*} [Fintype X] (p f g : X→ℝ) (hp : ∀x,0≤p x)
    (z m η : ℝ) (hη : 0<η) :
    finiteCDF p f z ≤ finiteCDF p g (z-m+η) +
      (∑ x,p x*(f x-g x-m)^2)/η^2 := by
  unfold finiteCDF;rw [sum_div,←sum_add_distrib]
  apply sum_le_sum;intro x _
  by_cases hf : f x≤z <;> by_cases hg : g x≤z-m+η
  · simp only [hf,hg,ite_true];linarith [div_nonneg (mul_nonneg (hp x) (sq_nonneg (f x-g x-m))) (sq_nonneg η)]
  · simp only [hf,hg,ite_true,ite_false,zero_add]
    rw [le_div_iff₀ (sq_pos_of_pos hη)]
    apply mul_le_mul_of_nonneg_left _ (hp x)
    nlinarith [mul_nonneg (show 0≤ -(f x-g x-m)-η by linarith) (show 0≤ -(f x-g x-m)+η by linarith)]
  · simp only [hf,hg,ite_true,ite_false];exact add_nonneg (hp x) (div_nonneg (mul_nonneg (hp x) (sq_nonneg _)) (sq_nonneg η))
  · simp only [hf,hg,ite_false,zero_add];exact div_nonneg (mul_nonneg (hp x) (sq_nonneg _)) (sq_nonneg η)

theorem cdf_lower {X : Type*} [Fintype X] (p f g : X→ℝ) (hp : ∀x,0≤p x)
    (z m η : ℝ) (hη : 0<η) :
    finiteCDF p g (z-m-η) - (∑ x,p x*(f x-g x-m)^2)/η^2 ≤ finiteCDF p f z := by
  have hh := cdf_upper p g f hp (z-m-η) (-m) η hη
  rw [show (z-m-η)-(-m)+η=z by ring] at hh
  have he (x) : (g x-f x- -m)^2=(f x-g x-m)^2 := by ring
  simp_rw [he] at hh;linarith

/-- A moving deterministic shift can be removed from the mean-square coupling bound. -/
theorem mse_true_center {X : Type*} [Fintype X] (p f g : X→ℝ) (hp : ∀x,0≤p x)
    (h1 : ∑x,p x=1) (m u e : ℝ) (he : (∑x,p x*(f x-g x-m)^2)≤e) :
    (∑x,p x*(f x-g x-u)^2) ≤ 2*e+2*(m-u)^2 := by
  calc
    _ ≤ ∑x,(2*(p x*(f x-g x-m)^2)+p x*(2*(m-u)^2)) := by
      apply sum_le_sum; intro x _
      have h : (f x-g x-u)^2 ≤ 2*(f x-g x-m)^2+2*(m-u)^2 := by nlinarith [sq_nonneg ((f x-g x-m)-(m-u))]
      exact (mul_le_mul_of_nonneg_left h (hp x)).trans_eq (by ring)
    _ ≤ _ := by rw [sum_add_distrib,←mul_sum,←sum_mul,h1,one_mul];linarith

/-- Finite, changing sample spaces; a mean-square shift plus a continuous marginal limit
suffices for all pointwise CDF limits of the other marginal. -/
theorem cdf_slutsky {X : ℕ→Type*} [∀n,Fintype (X n)]
    (p f g : (n:ℕ) → X n → ℝ) (hp : ∀ n x,0≤p n x)
    (ms : ∀ n,∑ x,p n x=1) (m : ℕ→ℝ) (v : ℝ) (hm : Tendsto m atTop (𝓝 v))
    (e : ℕ→ℝ) (he0 : Tendsto e atTop (𝓝 0))
    (he : ∀ n, (∑x,p n x*(f n x-g n x-m n)^2)≤e n)
    (F : ℝ→ℝ) (hF : Continuous F)
    (hCDF : ∀ z : ℝ,Tendsto (fun n=>finiteCDF (p n) (g n) z) atTop (𝓝 (F z))) (z : ℝ) :
    Tendsto (fun n=>finiteCDF (p n) (f n) z) atTop (𝓝 (F (z-v))) := by
  let E := fun n=>∑ x,p n x*(f n x-g n x-v)^2
  have hE : Tendsto E atTop (𝓝 0) := by
    have ht := ((tendsto_const_nhds (x:=(2:ℝ))).mul he0).add
      ((tendsto_const_nhds (x:=(2:ℝ))).mul ((hm.sub_const v).pow 2))
    simp only [sub_self,zero_pow (by decide:2≠0),mul_zero,zero_add] at ht
    apply squeeze_zero (fun n=>sum_nonneg (fun x _=>mul_nonneg (hp n x) (sq_nonneg _)))
      (fun n=>mse_true_center (p n) (f n) (g n) (hp n) (ms n) (m n) v (e n) (he n)) ht
  rw [Metric.tendsto_nhds]
  intro ε hε
  obtain ⟨δ,hδ,hδ'⟩ := Metric.continuousAt_iff.mp (hF.continuousAt (x:=z-v)) (ε/3) (by linarith)
  let η := δ/2
  have hη : 0<η := by dsimp [η];linarith
  have pos : |F (z-v+η)-F (z-v)|<ε/3 := hδ' (show dist (z-v+η) (z-v)<δ by
    rw [Real.dist_eq,show z-v+η-(z-v)=η by ring,abs_of_pos hη];dsimp [η];linarith)
  have neg : |F (z-v-η)-F (z-v)|<ε/3 := hδ' (show dist (z-v-η) (z-v)<δ by
    rw [Real.dist_eq,show z-v-η-(z-v)= -η by ring,abs_neg,abs_of_pos hη];dsimp [η];linarith)
  have err := hE.div_const (η^2)
  rw [zero_div] at err
  filter_upwards [(Metric.tendsto_nhds.mp (hCDF (z-v+η))) (ε/3) (by linarith),
    (Metric.tendsto_nhds.mp (hCDF (z-v-η))) (ε/3) (by linarith),(tendsto_order.mp err).2 (ε/3) (by linarith)] with n plus minus error
  rw [Real.dist_eq,abs_lt] at plus minus ⊢
  rw [abs_lt] at pos neg
  have H := cdf_upper (p n) (f n) (g n) (hp n) z v η hη
  have L := cdf_lower (p n) (f n) (g n) (hp n) z v η hη
  change (E n)/η^2<ε/3 at error
  change _≤ _+E n/η^2 at H
  change _-E n/η^2≤_ at L
  constructor <;> linarith

#print axioms cdf_slutsky
end
end HubDense
