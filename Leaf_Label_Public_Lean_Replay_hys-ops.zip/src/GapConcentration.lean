import DenseModes
open Finset HubTransfer
open scoped Matrix
namespace HubDense
noncomputable section
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- The discrepancy pure-death chain retains a random fraction of its original gap
with second centered moment at most the expected number retained. -/
theorem pure_death_variance (P : Matrix X X ℝ) (hp : Stochastic P) (D : X→ℝ)
    (a : ℝ) (ha : 0≤a) (ha' : 0≤1-2*a)
    (hD0 : ∀x,0≤D x) (hD : ∀x,0≤D x*(D x-1))
    (m1 : ∀x,(P *ᵥ D) x=(1-a)*D x)
    (m2 : ∀x,(P *ᵥ (fun y=>D y*(D y-1))) x=(1-2*a)*(D x*(D x-1)))
    (t : ℕ) (x : X) :
    ((P^t) *ᵥ (fun y=>(D y-(1-a)^t*D x)^2)) x ≤ (1-a)^t*D x := by
  let q := (1-a)^t
  have hd := eigen_power P D (1-a) m1 t x
  have hdd := eigen_power P (fun z=>D z*(D z-1)) (1-2*a) m2 t x
  have hP := stochastic_pow hp t
  have h1 : (∑ y,(P^t) x y*D y)=q*D x := hd
  have h2 : (∑ y,(P^t) x y*(D y*(D y-1)))=(1-2*a)^t*(D x*(D x-1)) := hdd
  have hq : (1-2*a)^t≤q^2 := by
    dsimp [q];rw [←pow_mul, Nat.mul_comm, pow_mul]
    apply pow_le_pow_left₀ ha' (by nlinarith [sq_nonneg a])
  have he : (1-2*a)^t*(D x*(D x-1)) ≤ q^2*(D x*(D x-1)) :=
    mul_le_mul_of_nonneg_right hq (hD x)
  change (∑ y,(P^t) x y*(D y-q*D x)^2)≤q*D x
  have hs : (∑ y,(P^t) x y*(D y-q*D x)^2) =
      (1-2*a)^t*(D x*(D x-1))+(1-2*q*D x)*(q*D x)+(q*D x)^2 := by
    calc
      _ = ∑y, ((P^t) x y*(D y*(D y-1)) + (1-2*q*D x)*((P^t) x y*D y) + (P^t) x y*(q*D x)^2) := by
        apply sum_congr rfl;intro _ _;ring
      _ = _ := by rw [sum_add_distrib,sum_add_distrib,←mul_sum,←sum_mul,hP.2,one_mul,h1,h2]
  rw [hs]
  nlinarith only [he,mul_nonneg (sq_nonneg q) (hD0 x)]
#print axioms pure_death_variance

end
end HubDense
