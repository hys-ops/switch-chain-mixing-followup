import GapConcentration
open Finset HubTransfer
open scoped Matrix
namespace HubDense
noncomputable section
variable {X I : Type*} [Fintype X] [DecidableEq X] [Fintype I]

/-- Draw an initial pair indexed by i, then advance its exact coupling kernel. -/
def mixRow (m : I→ℝ) (start : I→X) (P : Matrix X X ℝ) (x : X) := ∑ i,m i*P (start i) x

theorem mix_expect (m : I→ℝ) (start : I→X) (P : Matrix X X ℝ) (f : X→ℝ) :
    (∑ x,mixRow m start P x * f x)=∑ i,m i*(P *ᵥ f) (start i) := by
  simp only [mixRow,sum_mul,mul_assoc];rw [sum_comm];simp_rw [←mul_sum];rfl

theorem death_mixture (P : Matrix X X ℝ) (hp : Stochastic P) (D : X→ℝ)
    (a : ℝ) (ha : 0≤a) (ha' : 0≤1-2*a)
    (hD0 : ∀x,0≤D x) (hD : ∀x,0≤D x*(D x-1))
    (m1 : ∀x,(P *ᵥ D) x=(1-a)*D x)
    (m2 : ∀x,(P *ᵥ (fun y=>D y*(D y-1))) x=(1-2*a)*(D x*(D x-1)))
    (m : I→ℝ) (mn : ∀i,0≤m i) (ms : ∑i,m i=1) (start : I→X)
    (A K σ : ℝ) (hσ : 0<σ) (hK : ∀i,D (start i)≤K)
    (hvar : (∑ i,m i*(D (start i)-A)^2)≤σ^2) (t : ℕ) :
    (∑ x,mixRow m start (P^t) x * ((D x-(1-a)^t*A)/σ)^2) ≤
       (1-a)^t*K/σ^2+((1-a)^t)^2 := by
  let q := (1-a)^t
  have hq : 0≤q := pow_nonneg (by linarith) t
  let T := P^t
  have ht : Stochastic T := stochastic_pow hp t
  have hm (i) : (T *ᵥ D) (start i)=q*D (start i) := eigen_power _ _ _ m1 _ _
  have hoff (i) : (T *ᵥ (fun x=>(D x-q*A)^2)) (start i) ≤ q*D (start i)+q^2*(D (start i)-A)^2 := by
    let z := D (start i)
    have he : (T *ᵥ (fun x=>(D x-q*A)^2)) (start i) =
       (T *ᵥ (fun x=>(D x-q*z)^2)) (start i)+q^2*(z-A)^2 := by
      change (∑x,T (start i) x*(D x-q*A)^2)=_
      calc
        _ = ∑x,(T (start i) x*(D x-q*z)^2 +
                 (2*q*(z-A))*(T (start i) x*D x) + T (start i) x*(q^2*(A^2-z^2))) := by
          apply sum_congr rfl;intro _ _;ring
        _ = _ := by
          simp only [sum_add_distrib,←mul_sum,←sum_mul,ht.2,one_mul]
          change _+(2*q*(z-A))*(T *ᵥ D) (start i)+_=_
          rw [hm]; change (∑ x,T (start i) x*(D x-q*z)^2)+ _ + _ = (∑x,T (start i) x*(D x-q*z)^2)+_
          dsimp only [z];ring
    rw [he]
    exact add_le_add (pure_death_variance P hp D a ha ha' hD0 hD m1 m2 t _) le_rfl
  change (∑ x,mixRow m start T x * ((D x-q*A)/σ)^2) ≤ q*K/σ^2+q^2
  have e : (∑ x,mixRow m start T x * ((D x-q*A)/σ)^2) =
      (∑ i,m i*(T *ᵥ (fun x=>(D x-q*A)^2)) (start i))/σ^2 := by
    calc
      _ = (∑ x,mixRow m start T x*(D x-q*A)^2)/σ^2 := by
        rw [sum_div];apply sum_congr rfl;intro _ _;ring
      _ = _ := by rw [mix_expect]
  rw [e,div_le_iff₀ (sq_pos_of_pos hσ)]
  have hh : (∑ i,m i*(T *ᵥ (fun x=>(D x-q*A)^2)) (start i)) ≤ q*K+q^2*σ^2 := by
    calc
      _ ≤ ∑ i,m i*(q*K+q^2*(D (start i)-A)^2) := by
        apply sum_le_sum;intro i _
        exact mul_le_mul_of_nonneg_left ((hoff i).trans (add_le_add (mul_le_mul_of_nonneg_left (hK i) hq) le_rfl)) (mn i)
      _ = q*K+q^2*∑ i,m i*(D (start i)-A)^2 := by
        simp only [mul_add,sum_add_distrib,←sum_mul,ms,one_mul,mul_left_comm (m _) (q^2),←mul_sum]
      _ ≤ _ := add_le_add le_rfl (mul_le_mul_of_nonneg_left hvar (sq_nonneg q))
  exact hh.trans_eq (by field_simp [hσ.ne'])
#print axioms death_mixture
end
end HubDense
