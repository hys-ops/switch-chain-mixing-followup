import Mathlib.Analysis.Calculus.MeanValue
import Mathlib.Analysis.Calculus.Deriv.Pow
import Mathlib.Analysis.SpecialFunctions.ExpDeriv
import Mathlib.Analysis.Complex.RealDeriv
import Mathlib.Tactic
noncomputable section
namespace LeafNormal
/-- A uniform residual bound in the Gaussian characteristic-function equation gives
a pointwise characteristic-function error. The argument includes negative frequencies. -/
theorem ode_bound (f d : ℝ→ℂ) (hf : ∀ x,HasDerivAt f (d x) x) (h0 : f 0=1)
    (theta B : ℝ) (hr : ∀ u,|u|≤|theta| → ‖d u+(u:ℂ)*f u‖≤B) :
    ‖f theta-(Real.exp (-(theta^2)/2):ℂ)‖≤|theta| *B := by
  let w := fun v : ℝ => Real.exp (((v*theta)^2-theta^2)/2)
  let F := fun v : ℝ => (w v:ℂ)*f (v*theta)
  let D := fun v : ℝ => ((theta*w v:ℝ):ℂ)*(d (v*theta)+((v*theta:ℝ):ℂ)*f (v*theta))
  have deriva (v : ℝ) : HasDerivAt F (D v) v := by
    have hlin : HasDerivAt (fun x:ℝ => x*theta) theta v := by simpa using (hasDerivAt_id v).mul_const theta
    have hquad : HasDerivAt (fun x:ℝ => ((x*theta)^2-theta^2)/2) (v*theta^2) v := by
      convert ((hlin.pow 2).sub_const (theta^2)).div_const 2 using 1 <;> ring
    have hweight := hquad.exp.ofReal_comp
    have hvalue := (hf (v*theta)).scomp v hlin
    apply (hweight.mul hvalue).congr_deriv
    simp [D,w,Complex.real_smul];ring
  have h := norm_image_sub_le_of_norm_deriv_le_segment_01' (fun v _ => (deriva v).hasDerivWithinAt)
    (C:=|theta| *B) (by
      intro v hv
      have hv' : |v*theta|≤|theta| := by
        rw [abs_mul,abs_of_nonneg hv.1];exact mul_le_of_le_one_left (abs_nonneg _) hv.2.le
      have hsq := (sq_le_sq).mpr hv'
      have hw : w v≤1 := Real.exp_le_one_iff.mpr (by linarith)
      have hnn : 0≤B := (norm_nonneg _).trans (hr _ hv')
      dsimp [D]
      rw [norm_mul,Complex.norm_real,Real.norm_eq_abs,abs_mul,abs_of_pos (Real.exp_pos _)]
      calc
        _ ≤ (|theta| *w v)*B := mul_le_mul_of_nonneg_left (hr _ hv') (mul_nonneg (abs_nonneg _) (Real.exp_pos _).le)
        _ ≤ _ := mul_le_mul_of_nonneg_right (mul_le_of_le_one_right (abs_nonneg _) hw) hnn)
  simpa [F,w,h0] using h
#print axioms ode_bound
end LeafNormal
