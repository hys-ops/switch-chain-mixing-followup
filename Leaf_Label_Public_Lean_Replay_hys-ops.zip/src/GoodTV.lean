import Family
noncomputable section
open Finset
namespace Avoid
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- If both measures are constant on the same good set, the full TV distance
differs from the first measure's failure probability by at most the second's. -/
theorem tv_mass (S : Finset X) (p u : X→ℝ)
    (hp : ∀i,0≤p i) (hu : ∀i,0≤u i)
    (ep : ∑i,p i=1) (eu : ∑i,u i=1)
    (flat : ∀x∈S,∀y∈S,p x-u x=p y-u y) :
    |(1/2:ℝ)*(∑i,|p i-u i|) - (1-∑i∈S,p i)| ≤ 1-∑i∈S,u i := by
  have e (w:X→ℝ) := sum_add_sum_compl S w
  let P := ∑i∈Sᶜ,p i
  let U := ∑i∈Sᶜ,u i
  have hpu : (∑i∈S,p i)-(∑i∈S,u i) = U-P := by
    dsimp [U,P];linarith [e p,e u]
  have hg : (∑i∈S,|p i-u i|)=|U-P| := by
    rw [←hpu,←sum_sub_distrib]
    by_cases hz : S.Nonempty
    · obtain ⟨x,hx⟩ := hz
      have eq i (hi : i∈S) := flat i hi x hx
      calc
        _ = ∑_i∈S,|p x-u x| := sum_congr rfl fun i hi => congrArg abs (eq i hi)
        _ = |∑ _i∈S,(p x-u x)| := by simp only [sum_const,nsmul_eq_mul,abs_mul,abs_of_nonneg (Nat.cast_nonneg (α:=ℝ) S.card)]
        _ = _ := congrArg abs (sum_congr rfl fun i hi => (eq i hi).symm)
    · simp [not_nonempty_iff_eq_empty.mp hz]
  have ub : (∑i∈Sᶜ,|p i-u i|) ≤ P+U := by
    dsimp [P,U];rw [←sum_add_distrib];apply sum_le_sum;intro i _
    exact (abs_sub (p i) (u i)).trans_eq (by rw [abs_of_nonneg (hp i),abs_of_nonneg (hu i)])
  have lb : |P-U| ≤ ∑i∈Sᶜ,|p i-u i| := by
    dsimp [P,U];rw [←sum_sub_distrib];exact abs_sum_le_sum_abs _ _
  rw [←e (fun i => |p i-u i|),hg]
  have p' : 1-∑i∈S,p i=P := by dsimp [P];linarith [e p]
  have u' : 1-∑i∈S,u i=U := by dsimp [U];linarith [e u]
  rw [p',u',abs_le]
  have hu' : 0≤U := sum_nonneg fun i _ => hu i
  have hp' : 0≤P := sum_nonneg fun i _ => hp i
  rcases le_total U P with h|h
  · rw [abs_of_nonpos (sub_nonpos.mpr h)];rw [abs_of_nonneg (sub_nonneg.mpr h)] at lb;constructor <;> linarith
  · rw [abs_of_nonneg (sub_nonneg.mpr h)];rw [abs_of_nonpos (sub_nonpos.mpr h)] at lb;constructor <;> linarith
#print axioms tv_mass
end Avoid
