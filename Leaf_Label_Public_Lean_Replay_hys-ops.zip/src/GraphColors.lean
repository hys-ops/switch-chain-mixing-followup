import GrayDiameter
import GraphMarkedPower

noncomputable section
open Finset OAI.Problem315 TwoHub TwoHubUnequal TwoHubHorizontal
open scoped Matrix
open HubTransfer PaintMix
namespace GraphGray
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n→ℕ} {a c : Fin n}

def code (a c : Fin n) (G : GraphState n d) (x : Label a c) : Option Bool :=
  if G.1.Adj a x.1 then none else if G.1.Adj c x.1 then some false else some true

theorem red_code (G : GraphState n d) (x : Label a c) :
    code a c G x=none ↔ G.1.Adj a x.1 := by unfold code; split_ifs <;> simp_all

theorem white_code (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (x : Label a c) :
    code a c G x=some false ↔ G.1.Adj c x.1 := by
  have hx := (mem_leaves _ _ _).mp x.2
  have hd : G.1.Adj a x.1 → ¬G.1.Adj c x.1 := fun h h' => sp.distinct (leaf_unique sp G hx.1 hx.2 h.symm h'.symm)
  unfold code; split_ifs <;> simp_all

theorem gray_code (G : GraphState n d) (x : Label a c) :
    code a c G x=some true ↔ x.1∈loose G.1 a c := by
  have hx := (mem_leaves _ _ _).mp x.2
  rw [mem_loose]; unfold code; split_ifs <;> simp_all

theorem loose_map (G : GraphState n d) :
    (gray (code a c G)).map (Function.Embedding.subtype (fun z => z∈leaves a c))=loose G.1 a c := by
  ext v
  constructor
  · intro h
    obtain ⟨x,hx,rfl⟩ := mem_map.mp h
    exact (gray_code G x).mp ((mem_gray _ _).mp hx)
  · intro h
    have hx : v∈leaves a c := (mem_sdiff.mp h).1
    exact mem_map.mpr ⟨⟨v,hx⟩,(mem_gray _ _).mpr ((gray_code G _).mpr h),rfl⟩

theorem gray_card (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (hg : G.1.Adj a c) :
    (gray (code a c G)).card=2 := by
  have hs := congrArg Finset.card (loose_map (a:=a) (c:=c) G)
  simpa [loose_size sp G,hg] using hs

theorem leaf_pair_iff (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d)
    (x y : Label a c) (hxy : x≠y) :
    G.1.Adj x.1 y.1 ↔ x.1∈loose G.1 a c ∧ y.1∈loose G.1 a c := by
  have hx := (mem_leaves _ _ _).mp x.2
  have hy := (mem_leaves _ _ _).mp y.2
  constructor
  · intro hh
    have u : x.1∈loose G.1 a c := (mem_loose _ _ _ _).mpr ⟨hx.1,hx.2,
      fun h => hy.1 (leaf_unique sp G hx.1 hx.2 hh h.symm),
      fun h => hy.2 (leaf_unique sp G hx.1 hx.2 hh h.symm)⟩
    exact ⟨u,loose_partner sp G u hh⟩
  · rintro ⟨u,v⟩
    have he : G.1.Adj a c := by
      by_contra hn
      have hz : loose G.1 a c=∅ := Finset.card_eq_zero.mp (by simpa [hn] using loose_size sp G)
      simpa [hz] using u
    obtain ⟨k,l,hkl,hS,hadj⟩ := loose_edge sp G he
    rw [hS] at u v
    have hne : x.1≠y.1 := fun h => hxy (Subtype.ext h)
    simp only [mem_insert,mem_singleton] at u v
    rcases u with h|h <;> rcases v with h'|h' <;> simp_all [SimpleGraph.adj_comm]

theorem code_injective (sp : TwoHubUnequal.Spec n r s d a c) : Function.Injective (code (d:=d) a c) := by
  intro G K he
  have hS : loose G.1 a c=loose K.1 a c := by rw [←loose_map G,←loose_map K,he]
  have hedge : G.1.Adj a c ↔ K.1.Adj a c := by
    have hc := congrArg Finset.card hS
    rw [loose_size sp G,loose_size sp K] at hc
    split_ifs at hc <;> simp_all
  have hA (v : Fin n) : G.1.Adj a v ↔ K.1.Adj a v := by
    by_cases h1 : v=a
    · subst v; simp
    by_cases h2 : v=c
    · subst v; exact hedge
    let x : Label a c := ⟨v,(mem_leaves _ _ _).mpr ⟨h1,h2⟩⟩
    change G.1.Adj a x.1 ↔ K.1.Adj a x.1
    rw [←red_code G x,←red_code K x,he]
  have hC (v : Fin n) : G.1.Adj c v ↔ K.1.Adj c v := by
    by_cases h1 : v=a
    · subst v; simpa [G.1.adj_comm c a,K.1.adj_comm c a] using hedge
    by_cases h2 : v=c
    · subst v; simp
    let x : Label a c := ⟨v,(mem_leaves _ _ _).mpr ⟨h1,h2⟩⟩
    change G.1.Adj c x.1 ↔ K.1.Adj c x.1
    rw [←white_code sp G x,←white_code sp K x,he]
  apply Subtype.ext; ext u v
  by_cases hu : u=a
  · subst u;exact hA v
  by_cases hu' : u=c
  · subst u;exact hC v
  by_cases hv : v=a
  · subst v;exact (G.1.adj_comm _ _).trans ((hA u).trans (K.1.adj_comm _ _))
  by_cases hv' : v=c
  · subst v;exact (G.1.adj_comm _ _).trans ((hC u).trans (K.1.adj_comm _ _))
  by_cases heq : u=v
  · subst v;simp
  let U : Label a c := ⟨u,(mem_leaves _ _ _).mpr ⟨hu,hu'⟩⟩
  let V : Label a c := ⟨v,(mem_leaves _ _ _).mpr ⟨hv,hv'⟩⟩
  have huv : U≠V := fun h => heq (congrArg Subtype.val h)
  change G.1.Adj U.1 V.1 ↔ K.1.Adj U.1 V.1
  rw [leaf_pair_iff sp G U V huv,leaf_pair_iff sp K U V huv,hS]

theorem code_permute (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d)
    (i j : Label a c) : code a c (permute sp G i j)=move (code a c G) i j := by
  funext x
  have hi := (mem_leaves _ _ _).mp i.2
  have hj := (mem_leaves _ _ _).mp j.2
  have hx : Equiv.swap i.1 j.1 x.1 = (Equiv.swap i j x).1 := by
    by_cases h : x=i
    · subst x;simp
    by_cases h' : x=j
    · subst x;simp
    rw [Equiv.swap_apply_of_ne_of_ne h h',Equiv.swap_apply_of_ne_of_ne (fun e=>h (Subtype.ext e)) (fun e=>h' (Subtype.ext e))]
  unfold code move
  change (if G.1.Adj (Equiv.swap i.1 j.1 a) (Equiv.swap i.1 j.1 x.1) then none
    else if G.1.Adj (Equiv.swap i.1 j.1 c) (Equiv.swap i.1 j.1 x.1) then some false else some true)=_
  rw [Equiv.swap_apply_of_ne_of_ne hi.1.symm hj.1.symm,Equiv.swap_apply_of_ne_of_ne hi.2.symm hj.2.symm,hx]

#print axioms code_injective
#print axioms code_permute
end GraphGray
