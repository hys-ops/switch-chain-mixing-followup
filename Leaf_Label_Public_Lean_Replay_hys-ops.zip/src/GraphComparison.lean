import SwapAdapter
import PhysicalClock
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace GraphSplit
open TwoHubUnequal LeafSplit
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

theorem quartet_lower (r k : ℕ) : (N r k)^4/4≤Q r k := by
  rw [Qexact]
  let m := N r k
  have hm : 2≤m := by unfold m N; linarith [Nat.cast_nonneg (α:=ℝ) r,Nat.cast_nonneg (α:=ℝ) k]
  have hm0 : 0≤m := by linarith
  have h1 : m*m≤(m+2)*(m+1) :=
    mul_le_mul (by linarith) (by linarith) hm0 (by linarith)
  have h2 : m/2 ≤ m-1 := by linarith
  have h3 := mul_le_mul (mul_le_mul_of_nonneg_right h1 hm0) h2 (by linarith : 0≤m/2)
      (by positivity : 0≤(m+2)*(m+1)*m)
  change m^4/4≤(m+2)*(m+1)*m*(m-1)/2
  nlinarith

theorem numerical_error (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) :
    2*(((r:ℝ)+s)^2/(2*clock n))*((r:ℝ)*s/clock n)+2/clock n ≤ 3/clock n := by
  have hQ := clock_pos hn
  have hN : ((r:ℝ)+s)^4/4 ≤ clock n := by
    obtain ⟨k,hk⟩ := Nat.exists_eq_add_of_le hs
    have h := quartet_lower r k
    have hz : n=r+k+4 := by have hsz:=sp.size;omega
    rw [hz]
    simpa only [N,Q,hk,Nat.cast_add,Nat.cast_ofNat,add_assoc,add_comm,add_left_comm] using h
  have hbal : (r:ℝ)*s ≤ ((r:ℝ)+s)^2/4 := by nlinarith [sq_nonneg ((r:ℝ)-s)]
  have hprod := mul_le_mul_of_nonneg_left hbal (sq_nonneg ((r:ℝ)+s))
  have hm : ((r:ℝ)+s)^2*((r:ℝ)*s)≤clock n := by nlinarith
  field_simp
  nlinarith

theorem graph_error_three (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s)
    (hrs : 2≤(r:ℝ)*s) (t : ℕ) (G : GraphState n d) :
    tv (kernelPow n d t G) ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G)
    ≤ 3*t/clock n := by
  exact (graph_horizontal_first_exit sp hn hrs t G).trans
    ((mul_le_mul_of_nonneg_left (numerical_error sp hn hs) (by positivity : 0≤(t:ℝ))).trans_eq (by ring))

/-- Original row from a hub-connected graph versus the pure horizontal row. -/
theorem edge_start (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s)
    (hrs : 2≤(r:ℝ)*s) (G : GraphState n d) (hg : isEdge a c G) (t : ℕ) :
    tv (kernelPow n d t G) (((H d a c)^t) G) ≤ 3*t/clock n := by
  have h := graph_error_three sp hn hs hrs t G
  have he : ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G) = ((H d a c)^t) G := by
    funext y
    rw [Matrix.mul_apply,frozen_edge (isEdge a c) (V d a c) G hg t]
    change ((1 : Matrix (GraphState n d) (GraphState n d) ℝ)*(H d a c)^t) G y=_
    rw [Matrix.one_mul]
  rwa [he] at h

/-- Original row from a hub-disconnected graph versus its complete first-exit mixture. -/
theorem vertex_start (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s)
    (hrs : 2≤(r:ℝ)*s) (G : GraphState n d) (hg : ¬isEdge a c G) (t : ℕ) :
    tv (kernelPow n d t G) (fun y =>
      (1-(r:ℝ)*s/clock n)^t*((H d a c)^t) G y+
      (1-(1-(r:ℝ)*s/clock n)^t)*((U a c G) ᵥ* (H d a c)^t) y) ≤ 3*t/clock n := by
  have h := graph_error_three sp hn hs hrs t G
  have e := vertex_row sp hn (by linarith : 0<(r:ℝ)*s) G hg t
  have he : ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G) =
      fun y => (1-(r:ℝ)*s/clock n)^t*((H d a c)^t) G y+
      (1-(1-(r:ℝ)*s/clock n)^t)*((U a c G) ᵥ* (H d a c)^t) y := by
    funext y
    rw [Matrix.mul_apply,e]
    simp only [add_mul,sum_add_distrib,mul_assoc,←Finset.mul_sum]
    congr 2
    change ((1 : Matrix (GraphState n d) (GraphState n d) ℝ)*(H d a c)^t) G y=_
    rw [Matrix.one_mul]
  rwa [he] at h

open Filter Topology
/-- For the source quartet clock and natural floor time cQ/N, the uniform error
    bound vanishes. This includes c=0 and arbitrary fixed first-hub degree. -/
theorem error_vanishes (r : ℕ) {c : ℝ} (hc : 0≤c) :
    Tendsto (fun k => 3*(localTime r c k:ℝ)/Q r k) atTop (𝓝 0) := by
  have hn : Tendsto (N r) atTop atTop := by
    have h := (tendsto_natCast_atTop_atTop (R:=ℝ)).atTop_add (tendsto_const_nhds (x:=(r:ℝ)+2))
    apply h.congr; intro k;unfold N;ring
  have hlim : Tendsto (fun k => 3*c/N r k) atTop (𝓝 0) := tendsto_const_nhds.div_atTop hn
  apply squeeze_zero _ _ hlim
  · intro k;exact div_nonneg (by positivity) (Qpos r k).le
  · intro k
    have ht : (localTime r c k:ℝ) ≤ c*Q r k/N r k := Nat.floor_le (div_nonneg (mul_nonneg hc (Qpos _ _).le) (Npos _ _).le)
    apply (div_le_div_iff₀ (Qpos r k) (Npos r k)).mpr
    have hz := (le_div_iff₀ (Npos r k)).mp ht
    linarith

/-- The probability of no first vertical jump has its own clock, with rate rs/Q. -/
theorem first_exit_weight_limit (r : ℕ) (c : ℝ) (hc : 0≤c) :
    Tendsto (fun k : ℕ => (1-((r:ℝ)*(k+2))/Q r k)^(localTime r c k))
      atTop (𝓝 (Real.exp (-(c*r)))) := by
  let load := fun k : ℕ => ((r:ℝ)*(k+2))/N r k
  have hn : Tendsto (N r) atTop atTop := by
    have h := (tendsto_natCast_atTop_atTop (R:=ℝ)).atTop_add (tendsto_const_nhds (x:=(r:ℝ)+2))
    apply h.congr; intro k;unfold N;ring
  have hl : Tendsto load atTop (𝓝 (r:ℝ)) := by
    have h : Tendsto (fun k => (r:ℝ)-((r:ℝ)^2)/N r k) atTop (𝓝 ((r:ℝ)-0)) :=
      tendsto_const_nhds.sub (tendsto_const_nhds.div_atTop hn)
    rw [sub_zero] at h
    apply h.congr;intro k;dsimp [load];field_simp [(Npos r k).ne'];unfold N;ring
  have he (k : ℕ) : load k*(N r k/Q r k)=((r:ℝ)*(k+2))/Q r k := by
    dsimp [load];field_simp [(Npos r k).ne']
  have hp : Tendsto (fun k : ℕ => ((r:ℝ)*(k+2))/Q r k) atTop (𝓝 0) := by
    simpa only [he,mul_zero] using hl.mul (scale_zero r)
  have ht := TwoHubUnequal.scaled_time r c hc
  apply moving_decay hp
  have h := ht.mul hl
  apply h.congr;intro k
  rw [←he k];ring

#print axioms edge_start
#print axioms vertex_start
#print axioms error_vanishes
#print axioms first_exit_weight_limit
end GraphSplit
