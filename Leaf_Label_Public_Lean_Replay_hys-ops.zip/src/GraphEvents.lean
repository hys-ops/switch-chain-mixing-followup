import GraphMarkedPower
import IncidentMarks
import Roles
import Avoidance
open OAI.Problem315 Finset HubTransfer
open scoped Matrix Classical
namespace HubMarks
noncomputable section
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}
open TwoHubUnequal

def mass {X : Type*} (S : Finset X) (p : X→ℝ) : ℝ := ∑ x∈S,p x

theorem mass_tv {X : Type*} [Fintype X] (S : Finset X) (p q : X→ℝ) :
    |mass S p-mass S q| ≤ 2*tv p q := by
  classical
  unfold mass tv
  rw [←sum_sub_distrib]
  apply (abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ x,|p x-q x| := sum_le_sum_of_subset_of_nonneg (subset_univ _) (fun _ _ _ => abs_nonneg _)
    _ = _ := by ring

theorem horizontal_stays (t : ℕ) (x y : GraphState n d)
    (hxy : ¬(x.val.Adj a c ↔ y.val.Adj a c)) : ((GraphSplit.H d a c)^t) x y=0 := by
  induction t generalizing x y with
  | zero =>
    have hn : x≠y := by intro h;subst y;exact hxy Iff.rfl
    simp [Matrix.one_apply,hn]
  | succ t ih =>
    rw [pow_succ',Matrix.mul_apply]
    apply sum_eq_zero;intro z _
    by_cases h : x.val.Adj a c ↔ z.val.Adj a c
    · rw [ih z y (fun hh=>hxy (h.trans hh)),mul_zero]
    · have hn : x≠z := by intro he;subst z;exact h Iff.rfl
      have H : GraphSplit.H d a c x z=0 := by
        simp [GraphSplit.H,LeafSplit.horizontal,LeafSplit.cross,GraphSplit.isEdge,h,hn]
      rw [H,zero_mul]

def goodStates (a c : Fin n) (K : Finset (Fin n)) (d : Fin n→ℕ) : Finset (GraphState n d) :=
  univ.filter (Avoid.good a c K)

theorem vertex_horizontal_mass (K : Finset (Fin n)) (t : ℕ) (G : GraphState n d) (hG : ¬G.val.Adj a c) :
    mass (goodStates a c K d) (((GraphSplit.H d a c)^t) G) = 0 := by
  apply sum_eq_zero;intro T hT
  have H := (mem_filter.mp hT).2.1
  exact horizontal_stays t G T (fun e => hG (e.mpr H))

theorem pure_event (K : Finset (Fin n)) (t : ℕ) (G : GraphState n d) (hG : G.val.Adj a c)
    {N h : ℕ} (π : GraphState n d → JohnsonLower.Slice N h) (L : Finset (Fin N))
    (coords : ∀ y : GraphState n d, y.val.Adj a c →
      (Disjoint K (Avoid.marked a c y) ↔ Disjoint L (π y).val)) :
    mass (goodStates a c K d) (((GraphSplit.H d a c)^t) G) =
       ((GraphSplit.H d a c)^t *ᵥ (avoid L ∘ π)) G := by
  classical
  unfold mass goodStates
  rw [sum_filter]
  apply sum_congr rfl;intro y _
  by_cases hy : y.val.Adj a c
  · have hc := coords y hy
    by_cases hg : Disjoint K (Avoid.marked a c y)
    · simp [Avoid.good,avoid,hy,hg,hc.mp hg]
    · simp [Avoid.good,avoid,hy,hg,mt hc.mpr hg]
  · have he := horizontal_stays t G y (fun iff => hy (iff.mp hG))
    simp [Avoid.good,hy,he]

theorem incidence_marked (sp : Spec n r s d a c) (G J : GraphState n d)
    (hg : ¬G.val.Adj a c) (hj : GraphSplit.U a c G J≠0) :
    J.val.Adj a c ∧ Avoid.marked a c G ⊆ Avoid.marked a c J := by
  have h := TwoHubHorizontal.incident_initial_marks sp G J hg hj
  have he := TwoHubUnequal.loose_size sp G
  rw [ite_eq_right hg,card_eq_zero] at he
  simpa [Avoid.marked,he] using h

theorem weighted_mass {X : Type*} [Fintype X] (A : Finset X) (P : Matrix X X ℝ)
    (U : X→ℝ) (w : ℝ) (x : X) :
    mass A (fun y=>w*P x y+(1-w)*(U ᵥ* P) y) =
       w*mass A (P x)+(1-w)* ∑ J,U J*mass A (P J) := by
  unfold mass
  rw [sum_add_distrib,←mul_sum,←mul_sum]
  congr 2
  change (∑ y∈A,∑ J,U J*P J y)=_
  rw [sum_comm];simp_rw [←mul_sum]

theorem weighted_error {X : Type*} [Fintype X] (U f : X→ℝ) (u e : ℝ)
    (hn : ∀x,0≤U x) (hm : ∑ x,U x=1) (h : ∀x,U x≠0 → |f x-u|≤e) :
    |(∑ x,U x*f x)-u|≤e := by
  have he : (∑ x,U x*f x)-u=∑ x,U x*(f x-u) := by simp [mul_sub,sum_sub_distrib,←sum_mul,hm]
  rw [he];apply (abs_sum_le_sum_abs _ _).trans
  calc
    _ ≤ ∑ x,U x*e := by
      apply sum_le_sum; intro x _
      by_cases H : U x=0
      · simp [H]
      · rw [abs_mul,abs_of_nonneg (hn x)];exact mul_le_mul_of_nonneg_left (h x H) (hn x)
    _ = _ := by rw [←sum_mul,hm,one_mul]

#print axioms pure_event
#print axioms incidence_marked
end
end HubMarks
