import GraphEvents
import GraphMarkCode
import GraphComparison
import OriginalAvoidance
open OAI.Problem315 Finset HubTransfer
open scoped Matrix Classical
namespace HubMarks
noncomputable section
open TwoHubUnequal TwoHubHorizontal
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def windowApprox (r s a n t : ℕ) := avoidApprox (r+s) (r+1) a (clock n) t
def windowError (r a n t : ℕ) : ℝ := (2:ℝ)^a*((t:ℝ)*(r+1)/clock n)
def noExit (r s n t : ℕ) : ℝ := (1-(r:ℝ)*s/clock n)^t

/-- Exact graph-to-Johnson all-times identity for the physical avoidance event after reflection. -/
theorem joined_event_projection (sp : Spec n r s d a c) (hn : 4≤n) (hs : 1≤s)
    (K : Finset (Fin n)) (hK : K⊆TwoHub.leaves a c) (t : ℕ) (G : GraphState n d) (hG : G.val.Adj a c) :
    mass (goodStates a c K d) (((GraphSplit.H d a c)^t) G) =
      ((walk (r+s) (r+1) (clock n))^t *ᵥ avoid (markLabels sp K)) (graphMarked sp hs G) := by
  rw [pure_event K t G hG (graphMarked sp hs) (markLabels sp K)
    (fun y hy => (graphMarked_disjoint sp hs y hy K hK).symm)]
  exact graph_marked_power sp hn (markCode sp) (graphMarked sp hs) (graphMarked_permute sp hs)
    t _ G hG

theorem joined_approx (sp : Spec n r s d a c) (hn : 4≤n) (hs : 1≤s)
    (cap : ((r+1:ℕ):ℝ)*((r+s:ℕ)-(r+1:ℕ):ℝ) ≤ clock n)
    (K : Finset (Fin n)) (hK : K⊆TwoHub.leaves a c) (t : ℕ)
    (G : GraphState n d) (hG : G.val.Adj a c) (hi : K⊆Avoid.marked a c G) :
    |mass (goodStates a c K d) (((GraphSplit.H d a c)^t) G) -
        windowApprox r s K.card n t| ≤ windowError r K.card n t := by
  rw [joined_event_projection sp hn hs K hK t G hG]
  have hh := finite_avoidance (clock_pos hn) cap (markLabels sp K) t (graphMarked sp hs G)
    (graphMarked_subset sp hs G hG K hi)
  simpa only [card_markLabels sp K hK,windowApprox,windowError,Nat.cast_add,Nat.cast_one] using hh

theorem edge_good (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (cap : ((r+1:ℕ):ℝ)*((r+s:ℕ)-(r+1:ℕ):ℝ) ≤ clock n)
    (G : GraphState n d) (hG : G.val.Adj a c) (t : ℕ) :
    |Avoid.goodMass a c (Avoid.marked a c G) t G - windowApprox r s (r+1) n t| ≤
      2*(3*t/clock n)+windowError r (r+1) n t := by
  let K := Avoid.marked a c G
  let A := goodStates a c K d
  have hcard : K.card = r+1 := by simp [K,Avoid.marked_card sp G,hG]
  have hk : K⊆TwoHub.leaves a c := fun _ h => (TwoHub.mem_leaves _ _ _).mpr (Avoid.marked_leaf G h)
  have h1 := (mass_tv A (kernelPow n d t G) (((GraphSplit.H d a c)^t) G)).trans
    (mul_le_mul_of_nonneg_left (GraphSplit.edge_start sp hn hs hrs G hG t) (by norm_num))
  have h2 := joined_approx sp hn (by omega) cap K hk t G hG (by rfl)
  rw [hcard] at h2
  exact (abs_sub_le _ (mass A (((GraphSplit.H d a c)^t) G)) _).trans (add_le_add h1 h2)

theorem vertex_good (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (cap : ((r+1:ℕ):ℝ)*((r+s:ℕ)-(r+1:ℕ):ℝ) ≤ clock n)
    (G : GraphState n d) (hG : ¬G.val.Adj a c) (t : ℕ) :
    |Avoid.goodMass a c (Avoid.marked a c G) t G - (1-noExit r s n t)*windowApprox r s r n t| ≤
      2*(3*t/clock n)+windowError r r n t := by
  let K := Avoid.marked a c G
  let A := goodStates a c K d
  let T := (GraphSplit.H d a c)^t
  let U := GraphSplit.U a c G
  let w := noExit r s n t
  let F := fun y => w*T G y+(1-w)*(U ᵥ* T) y
  have hh : K.card=r := by simp [K,Avoid.marked_card sp G,hG]
  have hk : K⊆TwoHub.leaves a c := fun _ h => (TwoHub.mem_leaves _ _ _).mpr (Avoid.marked_leaf G h)
  have h1 : |mass A (kernelPow n d t G)-mass A F|≤2*(3*t/clock n) :=
    (mass_tv A _ _).trans (mul_le_mul_of_nonneg_left (GraphSplit.vertex_start sp hn hs hrs G hG t) (by norm_num))
  have hu : ∀J,0≤U J := fun J => div_nonneg
    (LeafSplit.cross_bounds _ _ (GraphSplit.physical_stochastic hn) G J).1
    (LeafSplit.ex_bounds _ _ (GraphSplit.physical_stochastic hn) G).1
  have hu1 := GraphSplit.incident_mass sp hn (by linarith) G hG
  have h2 := weighted_error U (fun J => mass A (T J)) (windowApprox r s r n t) (windowError r r n t)
    hu hu1 (by
      intro J hj
      have hJ := incidence_marked sp G J hG hj
      have H := joined_approx sp hn (by omega) cap K hk t J hJ.1 hJ.2
      simpa only [hh] using H)
  have hw0 : 0≤w := by
    have hl := (LeafSplit.ex_bounds (GraphSplit.isEdge a c) (GraphSplit.chain d) (GraphSplit.physical_stochastic hn) G).2
    rw [GraphSplit.exit_vertex sp G hG] at hl
    exact pow_nonneg (sub_nonneg.mpr hl) t
  have hw1 : w≤1 := pow_le_one₀ (by
    have hl := (LeafSplit.ex_bounds (GraphSplit.isEdge a c) (GraphSplit.chain d) (GraphSplit.physical_stochastic hn) G).2
    rw [GraphSplit.exit_vertex sp G hG] at hl;exact sub_nonneg.mpr hl)
    (sub_le_self _ (div_nonneg (by positivity) (clock_pos hn).le))
  have hev : mass A F=(1-w)*(∑ J,U J*mass A (T J)) := by
    change mass A (fun y=>w*T G y+(1-w)*(U ᵥ* T) y)=_
    rw [weighted_mass,vertex_horizontal_mass K t G hG,mul_zero,zero_add]
  have h3 : |mass A F-(1-w)*windowApprox r s r n t|≤windowError r r n t := by
    rw [hev,←mul_sub,abs_mul,abs_of_nonneg (sub_nonneg.mpr hw1)]
    exact (mul_le_mul_of_nonneg_left h2 (sub_nonneg.mpr hw1)).trans
      (mul_le_of_le_one_left (h2.trans' (abs_nonneg _)) (by linarith))
  exact (abs_sub_le _ (mass A F) _).trans (add_le_add h1 h3)
#print axioms joined_event_projection
#print axioms vertex_good
#print axioms edge_good
end
end HubMarks
