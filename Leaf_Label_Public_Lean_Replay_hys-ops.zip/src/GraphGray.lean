import GraphColors
import LeafShuffleTV

noncomputable section
open Finset OAI.Problem315 TwoHub TwoHubUnequal TwoHubHorizontal
open scoped Matrix
open HubTransfer PaintMix
namespace GraphGray
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n→ℕ} {a c : Fin n}

theorem paint_derivative {V : Type*} [Fintype V] [DecidableEq V] (Q : ℝ) (hq : 0<Q)
    (x : Paint V) (f : Paint V→ℝ) : (J V Q *ᵥ f) x = f x+
      (∑ i:V,∑ j:V,(f (move x i j)-f x))/(2*Q) := by
  have he : (J V Q *ᵥ f) x=∑ i:PropStep V,cost V (1/(2*Q)) i*f (turn x i) := by
    change (∑ z,(∑ i,if turn x i=z then cost V (1/(2*Q)) i else 0)*f z)=_
    simp_rw [sum_mul];rw [sum_comm];simp [ite_mul]
  rw [he,Fintype.sum_option,Fintype.sum_prod_type]
  simp only [cost,turn,sum_sub_distrib,sum_const,card_univ,nsmul_eq_mul,← mul_sum]
  have he' : (∑ _i:V,(Fintype.card V:ℝ)*f x)=(Fintype.card V:ℝ)^2*f x := by simp [pow_two,mul_assoc]
  ring

theorem graph_paint_lift (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n)
    (f : Paint (Label a c)→ℝ) (G : GraphState n d) :
    ((GraphSplit.H d a c)*ᵥ(f ∘ code a c)) G=((J (Label a c) (clock n))*ᵥ f) (code a c G) := by
  rw [HubMarks.original_horizontal_derivative sp hn,paint_derivative _ (clock_pos hn)]
  simp [Function.comp_def,code_permute]

theorem graph_paint_pow (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (t : ℕ)
    (f : Paint (Label a c)→ℝ) (G : GraphState n d) :
    ((GraphSplit.H d a c)^t*ᵥ(f ∘ code a c)) G=((J (Label a c) (clock n))^t*ᵥ f) (code a c G) := by
  induction t generalizing G with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',pow_succ',←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec,
      show ((GraphSplit.H d a c)^t *ᵥ (f ∘ code a c))=(((J (Label a c) (clock n))^t *ᵥ f) ∘ code a c) from funext ih]
    apply graph_paint_lift sp hn

theorem row_push (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (t : ℕ)
    (G : GraphState n d) : push (code a c) (((GraphSplit.H d a c)^t) G)=
      ((J (Label a c) (clock n))^t) (code a c G) := by
  funext y
  have h := graph_paint_pow sp hn t (fun z => if z=y then (1:ℝ) else 0) G
  simpa [push,Matrix.mulVec,dotProduct,mul_ite] using h

theorem injective_tv {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (π : X→Y) (hi : Function.Injective π) (u v : X→ℝ) :
    tv (push π u) (push π v)=tv u v := by
  classical
  have he (y : Y) : |push π u y-push π v y|=push π (fun x => |u x-v x|) y := by
    by_cases hy : ∃x,π x=y
    · obtain ⟨x,rfl⟩ := hy; simp [push,hi.eq_iff]
    · have h (z:X) : π z≠y := fun eq => hy ⟨z,eq⟩
      simp [push,h]
  simp only [tv,he,LeafOrbit.push_sum]

theorem label_card (sp : TwoHubUnequal.Spec n r s d a c) : Fintype.card (Label a c)=r+s := by
  change Fintype.card ↥(leaves a c)=_
  rw [Fintype.card_coe]
  unfold leaves;rw [card_sdiff_of_subset (subset_univ _)];simp [sp.distinct,sp.size]

theorem clock_big (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) :
    (Fintype.card (Label a c):ℝ)^2≤2*clock n := by
  have h := LeafTransfer.iid_leaf_weight_bound (d:=fun _ : Fin n => 1) hn
  have hq := clock_pos hn
  have h' : (n:ℝ)^2/(4*clock n)≤1/2 := by simpa [LeafTransfer.leaves,clock] using h
  have h'' := (div_le_iff₀ (by positivity : 0<4*clock n)).mp h'
  have hs : (Fintype.card (Label a c):ℝ)≤n := by
    exact_mod_cast (show Fintype.card (Label a c)≤n by rw [label_card sp,sp.size];omega)
  nlinarith [mul_nonneg (sub_nonneg.mpr hs) (show 0≤(n:ℝ)+(Fintype.card (Label a c):ℝ) by positivity)]

theorem nonred_card (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (he : G.1.Adj a c) :
    (outside (code a c G)).card=s+1 := by
  let red := (univ:Finset (Label a c)).filter (fun x => code a c G x=none)
  have hs : red.map (Function.Embedding.subtype (fun z => z∈leaves a c)) = star G.1 a c := by
    ext v;constructor
    · intro hv;obtain ⟨x,hx,rfl⟩:=mem_map.mp hv
      exact (mem_star _ _ _ _).mpr ⟨(mem_leaves _ _ _).mp x.2,(red_code G x).mp (mem_filter.mp hx).2⟩
    · intro hv;obtain ⟨hv,ha⟩:=(mem_star _ _ _ _).mp hv
      let x : Label a c := ⟨v,(mem_leaves _ _ _).mpr hv⟩
      exact mem_map.mpr ⟨x,mem_filter.mpr ⟨mem_univ _,(red_code G x).mpr ha⟩,rfl⟩
  have hcard : red.card=(star G.1 a c).card := by rw [←hs,card_map]
  have hsize := (star_size G.1 a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
  rw [ite_eq_left he] at hsize
  have hsum := card_filter_add_card_filter_not (s:=(univ : Finset (Label a c))) (p:=fun x => code a c G x=none)
  change red.card+(outside (code a c G)).card=_ at hsum
  rw [card_univ,label_card sp] at hsum
  omega

theorem graph_gray_diameter (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (G K : GraphState n d)
    (hg : G.1.Adj a c) (hk : K.1.Adj a c) (hred : star G.1 a c=star K.1 a c) (t : ℕ) :
    tv (((GraphSplit.H d a c)^t) G) (((GraphSplit.H d a c)^t) K) ≤
      2*(1-(((s-1:ℕ):ℝ))/clock n)^t := by
  rw [←injective_tv _ (code_injective sp),row_push sp hn,row_push sp hn]
  have hr (v : Label a c) : code a c G v=none ↔ code a c K v=none := by
    have hv := (mem_leaves _ _ _).mp v.2
    have he : v.1∈star G.1 a c ↔ v.1∈star K.1 a c := by rw [hred]
    rw [red_code,red_code]
    exact ⟨fun h => ((mem_star _ _ _ _).mp (he.mp ((mem_star _ _ _ _).mpr ⟨hv,h⟩))).2,
      fun h => ((mem_star _ _ _ _).mp (he.mpr ((mem_star _ _ _ _).mpr ⟨hv,h⟩))).2⟩
  have h := two_gray hr (gray_card sp G hg) (gray_card sp K hk) (clock_pos hn) (clock_big sp hn) t
  rw [nonred_card sp G hg] at h
  simpa only [show s+1-2=s-1 by omega] using h

#print axioms graph_paint_pow
#print axioms graph_gray_diameter
end GraphGray
