import IncidentMarks
import HorizontalRow
import SwapRow
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset JohnsonLower HubMarks
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def markCode (sp : TwoHubUnequal.Spec n r s d a c) : Label a c ≃ Fin (r+s) :=
  Fintype.equivOfCardEq (by
    change Fintype.card (↥(leaves a c))=Fintype.card (Fin (r+s))
    rw [Fintype.card_coe,Fintype.card_fin]
    unfold leaves;rw [card_sdiff_of_subset (subset_univ _)];simp [sp.distinct,sp.size])

def markLabels (sp : TwoHubUnequal.Spec n r s d a c) (S : Finset (Fin n)) : Finset (Fin (r+s)) :=
  (univ.filter (fun v : Label a c => v.val ∈ S)).map (markCode sp).toEmbedding

@[simp] theorem mem_markLabels (sp : TwoHubUnequal.Spec n r s d a c) (S : Finset (Fin n)) (x : Label a c) :
    markCode sp x ∈ markLabels sp S ↔ x.val∈S := by simp [markLabels]

theorem card_markLabels (sp : TwoHubUnequal.Spec n r s d a c) (S : Finset (Fin n)) (hs : S⊆leaves a c) :
    (markLabels sp S).card=S.card := by
  unfold markLabels;rw [card_map]
  let emb : Label a c ↪ Fin n := ⟨Subtype.val,Subtype.val_injective⟩
  have he : (univ.filter (fun v : Label a c => v.val∈S)).map emb = S := by
    ext x;constructor
    · intro h;obtain ⟨v,hv,rfl⟩:=mem_map.mp h;exact (mem_filter.mp hv).2
    · intro hx;exact mem_map.mpr ⟨⟨x,hs hx⟩,mem_filter.mpr ⟨mem_univ _,hx⟩,rfl⟩
  simpa only [card_map] using congrArg Finset.card he

def marked (a c : Fin n) (G : GraphState n d) := star G.val a c ∪ loose G.val a c

theorem marked_subset (G : GraphState n d) : marked a c G ⊆ leaves a c := by
  intro x hx;rcases mem_union.mp hx with h|h
  · exact (mem_leaves _ _ _).mpr ((mem_star _ _ _ _).mp h).1
  · exact (mem_sdiff.mp h).1

theorem marked_iff (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (x : Label a c) :
    x.val∈marked a c G ↔ ¬G.val.Adj c x.val := by
  have hx := (mem_leaves _ _ _).mp x.2
  constructor
  · intro hm hc
    rcases mem_union.mp hm with h|h
    · exact sp.distinct (TwoHubUnequal.leaf_unique sp G hx.1 hx.2 ((mem_star _ _ _ _).mp h).2.symm hc.symm)
    · exact ((mem_loose _ _ _ _).mp h).2.2.2 hc
  · intro hc;by_cases ha : G.val.Adj a x.val
    · exact mem_union_left _ ((mem_star _ _ _ _).mpr ⟨hx,ha⟩)
    · exact mem_union_right _ ((mem_loose _ _ _ _).mpr ⟨hx.1,hx.2,ha,hc⟩)

theorem marked_card (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (he : G.val.Adj a c) :
    (marked a c G).card=r+1 := by
  have sa := (star_size G.val a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
  have sl := TwoHubUnequal.loose_size sp G
  rw [ite_eq_left he] at sa sl
  have dis : Disjoint (star G.val a c) (loose G.val a c) := by
    apply disjoint_left.mpr;intro x hx hy
    exact (mem_sdiff.mp hy).2 (mem_union_left _ hx)
  unfold marked;rw [card_union_of_disjoint dis];omega

def dummy (r s : ℕ) (hs : 1≤s) : Slice (r+s) (r+1) := by
  have hh : r+1≤(univ:Finset (Fin (r+s))).card := by rw [card_univ,Fintype.card_fin];omega
  exact ⟨(exists_subset_card_eq hh).choose,(exists_subset_card_eq hh).choose_spec.2⟩

def graphMarked (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G : GraphState n d) : Slice (r+s) (r+1) :=
  if he : G.val.Adj a c then ⟨markLabels sp (marked a c G),
    (card_markLabels _ _ (marked_subset G)).trans (marked_card sp G he)⟩ else dummy r s hs

theorem graphMarked_mem (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G : GraphState n d)
    (he : G.val.Adj a c) (x : Label a c) : markCode sp x∈(graphMarked sp hs G).val ↔ x.val∈marked a c G := by
  simp [graphMarked,he]

theorem graphMarked_permute (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G : GraphState n d)
    (he : G.val.Adj a c) (i j : Label a c) :
    graphMarked sp hs (permute sp G i j)=swapSet (graphMarked sp hs G) (markCode sp i) (markCode sp j) := by
  have he' := (shape_permute sp G i j).mpr he
  apply Subtype.ext;ext z
  obtain ⟨x,rfl⟩ := (markCode sp).surjective z
  change _ ↔ markCode sp x ∈ Finset.map (Equiv.swap (markCode sp i) (markCode sp j)).toEmbedding _
  rw [mem_map_equiv,Equiv.symm_swap]
  have eq : Equiv.swap (markCode sp i) (markCode sp j) (markCode sp x) = markCode sp (Equiv.swap i j x) := by
    by_cases hi : x=i
    · subst x;simp
    by_cases hj : x=j
    · subst x;simp
    rw [Equiv.swap_apply_of_ne_of_ne hi hj,Equiv.swap_apply_of_ne_of_ne (mt (markCode sp).injective.eq_iff.mp hi) (mt (markCode sp).injective.eq_iff.mp hj)]
  rw [eq,graphMarked_mem sp hs _ he',graphMarked_mem sp hs _ he,marked_iff sp,marked_iff sp]
  change (¬G.val.Adj (Equiv.swap i.val j.val c) (Equiv.swap i.val j.val x.val)) ↔ _
  rw [Equiv.swap_apply_of_ne_of_ne ((mem_leaves _ _ _).mp i.2).2.symm ((mem_leaves _ _ _).mp j.2).2.symm]
  have e₂ : Equiv.swap i.val j.val x.val=(Equiv.swap i j x).val := by
    by_cases hi : x=i
    · subst x;simp
    by_cases hj : x=j
    · subst x;simp
    rw [Equiv.swap_apply_of_ne_of_ne hi hj,Equiv.swap_apply_of_ne_of_ne (fun h=>hi (Subtype.ext h)) (fun h=>hj (Subtype.ext h))]
  rw [e₂]

theorem graphMarked_disjoint (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G : GraphState n d)
    (he : G.val.Adj a c) (K : Finset (Fin n)) (hK : K⊆leaves a c) :
    Disjoint (markLabels sp K) (graphMarked sp hs G).val ↔ Disjoint K (marked a c G) := by
  rw [disjoint_left,disjoint_left]
  constructor
  · intro h x hx hm
    let z : Label a c := ⟨x,hK hx⟩
    exact h ((mem_markLabels sp K z).mpr hx) ((graphMarked_mem sp hs G he z).mpr hm)
  · intro h y hy hm
    obtain ⟨x,rfl⟩:=(markCode sp).surjective y
    exact h ((mem_markLabels sp K x).mp hy) ((graphMarked_mem sp hs G he x).mp hm)

theorem graphMarked_subset (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G : GraphState n d)
    (he : G.val.Adj a c) (K : Finset (Fin n)) (hK : K⊆marked a c G) :
    markLabels sp K ⊆ (graphMarked sp hs G).val := by
  intro z hz
  obtain ⟨x,rfl⟩:=(markCode sp).surjective z
  exact (graphMarked_mem sp hs G he x).mpr (hK ((mem_markLabels sp K x).mp hz))

theorem incident_encoded (sp : TwoHubUnequal.Spec n r s d a c) (hs : 1≤s) (G J : GraphState n d)
    (hh : ¬G.val.Adj a c) (hU : GraphSplit.U a c G J ≠0) :
    J.val.Adj a c ∧ markLabels sp (star G.val a c) ⊆ (graphMarked sp hs J).val := by
  obtain ⟨he,sub⟩:=incident_initial_marks sp G J hh hU
  refine ⟨he,?_⟩;intro z hz;obtain ⟨x,rfl⟩:=(markCode sp).surjective z
  exact (graphMarked_mem sp hs J he x).mpr (sub ((mem_markLabels sp _ x).mp hz))

#print axioms graphMarked_permute
#print axioms incident_encoded
end
end TwoHubHorizontal
