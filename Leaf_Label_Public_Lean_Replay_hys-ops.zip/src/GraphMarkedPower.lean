import SwapRow
import HorizontalRow
import GraphSplit
open Finset OAI.Problem315 JohnsonLower
open scoped Matrix Classical
namespace HubMarks
open TwoHubUnequal TwoHubHorizontal
noncomputable section
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

theorem original_horizontal_derivative (sp : Spec n r s d a c) (hn : 4≤n)
    (G : GraphState n d) (f : GraphState n d → ℝ) :
    (GraphSplit.H d a c *ᵥ f) G = f G +
      (∑ i : Label a c, ∑ j : Label a c, (f (permute sp G i j) - f G))/(2*clock n) := by
  let g := fun y => f y-f G
  have hg : g G=0 := sub_self _
  have rr := horizontal_row sp G g hg
  have h (y) : (GraphSplit.H d a c) G y*g y =
      if (G.val.Adj a c ↔ y.val.Adj a c) then switchKernel n d G y*g y else 0 := by
    by_cases he : G=y
    · subst y;simp [hg]
    · by_cases hs : (G.val.Adj a c ↔ y.val.Adj a c) <;>
        simp [GraphSplit.H,LeafSplit.horizontal,LeafSplit.cross,GraphSplit.isEdge,GraphSplit.chain,
          hs,he]
  have hs := (LeafSplit.h_stoch (GraphSplit.isEdge (d:=d) a c) (GraphSplit.chain d) (GraphSplit.physical_stochastic (d:=d) hn)).2 G
  have he : ((GraphSplit.H d a c) *ᵥ g) G = _ := (sum_congr rfl (fun y _=>h y)).trans rr
  change (∑ y,GraphSplit.H d a c G y*(f y-f G))=_ at he
  simp_rw [mul_sub,sum_sub_distrib,←sum_mul] at he
  change (∑ y,(GraphSplit.H d a c) G y) = 1 at hs
  rw [hs,one_mul] at he
  change (∑ y, GraphSplit.H d a c G y*f y) = _
  linarith

theorem horizontal_closed (G T : GraphState n d) (hG : G.val.Adj a c) (hT : ¬T.val.Adj a c) :
    GraphSplit.H d a c G T=0 := by
  have he : G≠T := by intro e;exact hT (e ▸ hG)
  simp [GraphSplit.H,LeafSplit.horizontal,LeafSplit.cross,GraphSplit.isEdge,hG,hT,he]

/-- On the joined stratum, a leaf-transposition-equivariant marked-set map intertwines the
actual reflected switch kernel with the Johnson chain at all times in the source clock. -/
theorem graph_marked_power (sp : Spec n r s d a c) (hn : 4≤n) {N h : ℕ}
    (e : Label a c ≃ Fin N) (π : GraphState n d → Slice N h)
    (equivariance : ∀ G : GraphState n d, G.val.Adj a c → ∀ i j : Label a c,
      π (permute sp G i j) = swapSet (π G) (e i) (e j))
    (t : ℕ) (f : Slice N h → ℝ) (G : GraphState n d) (hG : G.val.Adj a c) :
    ((GraphSplit.H d a c)^t *ᵥ (f ∘ π)) G = ((walk N h (clock n))^t *ᵥ f) (π G) := by
  apply closed_projection (fun y : GraphState n d => y.val.Adj a c) _ _ _ (fun x hx y hy => horizontal_closed x y hx hy) _ t f G hG
  intro g T hT
  rw [original_horizontal_derivative sp hn,swap_row _ (clock_pos hn).ne']
  congr 2
  apply Fintype.sum_equiv e _ _
  intro i
  apply Fintype.sum_equiv e _ _
  intro j
  simp [equivariance T hT]

#print axioms original_horizontal_derivative
#print axioms graph_marked_power
end
end HubMarks
