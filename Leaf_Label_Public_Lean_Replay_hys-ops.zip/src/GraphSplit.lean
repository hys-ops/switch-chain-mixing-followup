import CutKernel
import ShapeLaw
import UpstreamDrift
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace GraphSplit
open TwoHubUnequal LeafSplit
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}
abbrev chain (d : Fin n → ℕ) := Matrix.of (switchKernel n d)
abbrev isEdge (a c : Fin n) (G : GraphState n d) := G.val.Adj a c

theorem physical_stochastic (hn : 4≤n) : Stochastic (chain d) :=
  by
  classical
  refine ⟨switchKernel_nonneg, ?_⟩
  intro G
  exact switchKernel_row_sum hn G
theorem exit_edge (sp : Spec n r s d a c) (G : GraphState n d) (hh : isEdge a c G) :
    exitMass (isEdge a c) (chain d) G=2/clock n := by
  have hh' : G.val.Adj a c := hh
  simpa [exitMass,cross,isEdge,hh',chain,clock,allGraphStates,Finset.sum_filter] using B_to_A sp G hh
theorem exit_vertex (sp : Spec n r s d a c) (G : GraphState n d) (hh : ¬isEdge a c G) :
    exitMass (isEdge a c) (chain d) G=(r:ℝ)*s/clock n := by
  have hh' : ¬G.val.Adj a c := hh
  simpa [exitMass,cross,isEdge,hh',chain,clock,allGraphStates,Finset.sum_filter] using A_to_B sp G hh

abbrev V (d : Fin n → ℕ) (a c : Fin n) := vertical (isEdge a c) (chain d)
abbrev H (d : Fin n → ℕ) (a c : Fin n) := horizontal (isEdge a c) (chain d)
abbrev U (a c : Fin n) (G : GraphState n d) := incident (isEdge a c) (chain d) G

/-- The actual first jump into the edge stratum gives a probability distribution,
    represented exactly by the original switch row divided by rs/Q on target edges. -/
theorem incident_mass (sp : Spec n r s d a c) (hn : 4≤n) (hrs : 0<(r:ℝ)*s)
    (G : GraphState n d) (hh : ¬isEdge a c G) : ∑ J,U a c G J=1 :=
  incident_sum _ _ G (by rw [exit_vertex sp G hh]; exact (div_pos hrs (clock_pos hn)).ne')

theorem vertex_row (sp : Spec n r s d a c) (hn : 4≤n) (hrs : 0<(r:ℝ)*s)
    (G : GraphState n d) (hh : ¬isEdge a c G) (t : ℕ) :
    ((frozen (isEdge a c) (V d a c))^t) G =
    fun y => (1-(r:ℝ)*s/clock n)^t * (1 : Matrix _ _ ℝ) G y +
      (1-(1-(r:ℝ)*s/clock n)^t)*U a c G y := by
  have e := exit_vertex sp G hh
  have z := vertex_closed (isEdge a c) (chain d) G hh
    (by rw [e]; exact (div_pos hrs (clock_pos hn)).ne') t
  simpa only [e] using z

theorem graph_error (sp : Spec n r s d a c) (hn : 4≤n) (hrs : 2≤(r:ℝ)*s)
    (comm : Commute (V d a c) (H d a c)) {u : ℝ} (hu : 0≤u)
    (hH : ∀ G, 1-H d a c G G≤u) (t : ℕ) (G : GraphState n d) :
    tv (kernelPow n d t G) ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G)
      ≤ (t:ℝ)*(2*u*((r:ℝ)*s/clock n)+2/clock n) := by
  have hp := physical_stochastic (d:=d) hn
  have hQ := clock_pos hn
  have hedge (y : GraphState n d) (hy : isEdge a c y) : 1-V d a c y y≤2/clock n := by
    rw [V,v_diag,exit_edge sp y hy]
  have hall (y : GraphState n d) : 1-V d a c y y≤(r:ℝ)*s/clock n := by
    by_cases h : isEdge a c y
    · exact (hedge y h).trans (div_le_div_of_nonneg_right hrs hQ.le)
    · rw [V,v_diag,exit_vertex sp y h]
  have e := vertical_after_horizontal (chain d) (H d a c) (V d a c) hp
    (h_stoch _ _ hp) (v_stoch _ _ hp) (decompose _ _) comm hu
    (show 0≤2/clock n by positivity) hH hall (isEdge a c) hedge t G
  have hmat := LeafDrift.actual_kernel_pow (n:=n) (d:=d) t
  exact (congrArg (fun M : Matrix (GraphState n d) (GraphState n d) ℝ =>
    tv (M G) ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G)) hmat).le.trans e

#print axioms vertex_row
#print axioms graph_error
end GraphSplit
