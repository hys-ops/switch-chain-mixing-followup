import OrderedAdapter
open Finset HubTransfer OAI.Problem315 Filter Topology UrnWindow UrnWindow.Degrees
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open TwoHubUnequal OrderedUrn

/-- At every discrete time t, a graph with the authors' proposal clock can be
    compared directly with a (r−1+1)-state birth/death matrix. -/
theorem graph_to_ordered {n r s : ℕ} {d : Fin n→ℕ} {a b : Fin n}
    (sp : Spec n r s d a b) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) (t : ℕ) :
    |tvDistanceFrom n d t G -
      tv (((B (r+s) (r-1) (clock n))^t) (Fin.last (r-1))) (hyperProb (r+s) (r-1))|
      ≤ discreteError n r s t := by
  let S := TwoHubHorizontal.redProjection sp G
  have h:=all_starts sp hn hr hs G S t
  unfold Bdist at h
  rwa [←ordered_distance S (by omega) (clock_pos hn).ne' t]

theorem tridiagonal_bound (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    {d : Fin (g.population i+2) → ℕ} {a b : Fin (g.population i+2)}
    (sp : Spec (g.population i+2) (g.r i) (g.s i) d a b)
    (G : GraphState _ d) :
    |tvDistanceFrom _ d (g.time z c i) G -
       tridiagonalDistance (g.population i) (g.r i-1) (g.external i (g.tau z c i))|≤
      envelope g z c i := by
  let S:=TwoHubHorizontal.redProjection sp G
  have h := scalar_bound g z c i sp G S
  have hn : 0<g.r i+g.s i := by have:=g.two i;omega
  have ht : 0≤g.external i (g.tau z c i) := by
    unfold Degrees.external Degrees.tau;have:=g.clk_pos i;positivity
  rw [scalar_to_tridiagonal S hn ht] at h;exact h

/-- The paper's input can be phrased entirely using a (k+1)-state
    matrix exponential and explicit hypergeometric weights. -/
theorem tridiagonal_profiles (g : Degrees)
    (d : (i:ℕ)→Fin (g.population i+2)→ℕ) (a b : (i:ℕ)→Fin (g.population i+2))
    (sp : ∀i,Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (paper : g.UrnProfileInput (fun i=>tridiagonalDistance (g.population i) (g.r i-1)))
    (z : Regime) (hz : z.holds g) (c : ℝ) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time z.window c i) G-z.curve c|<ε := by
  let S (i : ℕ) : Slice (g.r i) (g.s i) := by
    have hh : g.r i-1≤(univ : Finset (Fin (g.r i+g.s i))).card := by rw [card_univ,Fintype.card_fin];omega
    exact ⟨(exists_subset_card_eq hh).choose,(exists_subset_card_eq hh).choose_spec.2⟩
  apply profile_from_urn g d a b sp S z c (paper z hz).1.continuousAt _ hε
  intro w
  apply ((paper z hz).2 w).congr'
  have hp:=((g.center_infty z.window).atTop_add (tendsto_const_nhds (x:=w))).eventually_ge_atTop 0
  filter_upwards [hp] with i hi
  have hn : 0<g.r i+g.s i := by have:=g.two i;omega
  change 0≤g.center z.window i+w at hi
  have ht : 0≤g.N i*(g.center z.window i+w)/2 := div_nonneg (mul_nonneg (Nat.cast_nonneg _) hi) (by norm_num)
  exact ((urn_to_scalar (S i) hn _).trans (scalar_to_tridiagonal (S i) hn ht)).symm
#print axioms graph_to_ordered
#print axioms tridiagonal_bound
#print axioms tridiagonal_profiles
end PhysicalReduction
