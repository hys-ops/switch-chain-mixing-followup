import UrnTransfer
import Mathlib.Probability.Distributions.Gaussian.Real
import Mathlib.Probability.Distributions.Poisson.Basic
import Mathlib.Probability.CDF

open Filter Topology ProbabilityTheory OAI.Problem315
namespace UrnWindow.Degrees
noncomputable section

def ratio (g : Degrees) (i : ℕ) : ℝ := g.k i/Real.sqrt (g.N i)
def gaussian (c:ℝ) : ℝ := 2*(cdf (gaussianReal 0 1)) (Real.exp (-c)/2)-1
def poissonTV (m n : ℝ) : ℝ := (∑' j : ℕ, |poissonPMFReal m.toNNReal j-poissonPMFReal n.toNNReal j|)/2
def critical (a c : ℝ) := poissonTV (a+Real.sqrt a*Real.exp (-c)) a
def gumbel (c:ℝ) := 1-Real.exp (-Real.exp (-c))

inductive Regime
  | dense
  | critical (α : ℝ)
  | sparse

def Regime.window : Regime → Center
  | .dense | .critical _ => .halfLogN
  | .sparse => .logK

def Regime.curve : Regime → ℝ → ℝ
  | .dense => gaussian
  | .critical α => UrnWindow.Degrees.critical α
  | .sparse => gumbel

def Regime.holds (g : Degrees) : Regime → Prop
  | .dense => Tendsto g.ratio atTop atTop
  | .critical α => 0<α ∧ Tendsto g.ratio atTop (𝓝 (Real.sqrt α))
  | .sparse => Tendsto g.ratio atTop (𝓝 0)

/-- An explicit input interface for the published scalar urn profile in three regimes.
Time is the rate-one, two independent samples with replacement clock. -/
def UrnProfileInput (g : Degrees) (urn : ℕ → ℝ → ℝ) : Prop :=
  ∀ z : Regime, z.holds g → Continuous z.curve ∧ ∀ w : ℝ,
    Tendsto (fun i => urn i (g.N i*(g.center z.window i+w)/2)) atTop (𝓝 (z.curve w))

/-- No graph assumptions are encoded as abstract distances: the conclusion is the
upstream discrete graph TV from each actual labeled starting state. The structural
two-hub hypothesis and finite comparison are explicit inputs. -/
theorem full_graph_profiles (g : Degrees)
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (_family : ∀ i, TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (urn : ℕ → ℝ → ℝ) (hD : ∀ i, Antitone (urn i)) (hOTS : g.UrnProfileInput urn)
    (z : Regime) (hz : z.holds g) (c : ℝ)
    (finite_comparison : ∀ i (x : GraphState (g.population i+2) (d i)),
      |tvDistanceFrom _ (d i) (g.time z.window c i) x -
        urn i (g.external i (g.tau z.window c i))| ≤ g.error z.window c i)
    {ε : ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ x : GraphState (g.population i+2) (d i),
      |tvDistanceFrom _ (d i) (g.time z.window c i) x-z.curve c|<ε :=
  uniform_transfer g z.window c (fun i x => tvDistanceFrom _ (d i) (g.time z.window c i) x)
    urn z.curve finite_comparison hD (hOTS z hz).1.continuousAt (hOTS z hz).2 hε

#print axioms full_graph_profiles
end
end UrnWindow.Degrees
