import GrayCoupling

noncomputable section
open scoped BigOperators Matrix
namespace PaintMix
open HubTransfer
attribute [local instance] Classical.propDecidable
variable {V : Type*} [Fintype V] [DecidableEq V]

def good (x : Paint V) (i j : V) (a : Pair V) : Prop :=
  let p := couplePair x i j a
  move x a.1 a.2=move (move x i j) p.1 p.2

theorem good_reverse (x : Paint V) (i j : V) (a b : V) (ha : x a≠none) (hb : x b≠none) :
    good x i j (a,b) → good x i j (b,a) := by
  unfold good
  rw [pair_pos x i j _ ⟨ha,hb⟩,pair_pos x i j _ ⟨hb,ha⟩]
  dsimp only
  rw [coupled_outside,coupled_outside]
  rw [show move x b a = move x a b by funext z; exact congrArg (fun s : Equiv.Perm V => x (s z)) (Equiv.swap_comm b a)]
  exact id

def oriented (x : Paint V) (i j : V) (z : ↥(others x i j) × Bool) : Pair V :=
  if z.2 then (partner x i j z.1.1,z.1.1) else (z.1.1,partner x i j z.1.1)

theorem partner_off (x : Paint V) (i j w : V) : partner x i j w∉others x i j := by
  by_cases h : x w=x j <;> simp [others,partner,h]

theorem oriented_injective (x : Paint V) (i j : V) : Function.Injective (oriented x i j) := by
  rintro ⟨a,k⟩ ⟨b,l⟩ he
  cases k <;> cases l <;> simp only [oriented,Bool.false_eq_true,ite_false,ite_true,Prod.mk.injEq] at he
  · exact Prod.ext (Subtype.ext he.1) rfl
  · exact (partner_off x i j b.1 (he.1 ▸ a.2)).elim
  · exact (partner_off x i j a.1 (he.1.symm ▸ b.2)).elim
  · exact Prod.ext (Subtype.ext he.2) rfl

theorem oriented_good (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none) (hd : x i≠x j)
    (z : ↥(others x i j) × Bool) : good x i j (oriented x i j z) := by
  rcases z with ⟨w,k⟩
  have hw := (Finset.mem_filter.mp (Finset.mem_erase.mp (Finset.mem_erase.mp w.2).2).2).2
  have hp : x (partner x i j w.1)≠none := by unfold partner; split <;> assumption
  cases k
  · exact cures x i j hi hj hd w
  · exact good_reverse x i j _ _ hw hp (cures x i j hi hj hd w)

theorem good_many (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none) (hd : x i≠x j) :
    2*((outside x).card-2) ≤ (Finset.univ.filter (good x i j)).card := by
  classical
  let f (z : ↥(others x i j) × Bool) : ↥(Finset.univ.filter (good x i j)) :=
    ⟨oriented x i j z,Finset.mem_filter.mpr ⟨Finset.mem_univ _,oriented_good x i j hi hj hd z⟩⟩
  have hh := Fintype.card_le_of_injective f (fun _ _ he => oriented_injective x i j (congrArg Subtype.val he))
  have hmi : i∈outside x := Finset.mem_filter.mpr ⟨Finset.mem_univ _,hi⟩
  have hmj : j∈(outside x).erase i := Finset.mem_erase.mpr
    ⟨fun h => hd (congrArg x h.symm),Finset.mem_filter.mpr ⟨Finset.mem_univ _,hj⟩⟩
  change Fintype.card (↥(others x i j) × Bool) ≤ Fintype.card ↥(Finset.univ.filter (good x i j)) at hh
  rw [Fintype.card_prod,Fintype.card_bool,Fintype.card_coe,Fintype.card_coe] at hh
  simpa only [others,
    Finset.card_erase_of_mem hmj,Finset.card_erase_of_mem hmi,Nat.sub_sub,Nat.reduceAdd,mul_comm] using hh

theorem bad_weight (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none) (hd : x i≠x j)
    (p : ℝ) (hp : 0≤p) :
    let e := Equiv.optionCongr (pairPerm x i j hi hj)
    (∑ a : PropStep V,if turn x a=turn (move x i j) (e a) then 0 else cost V p a)
      ≤ 1-2*((((outside x).card-2:ℕ):ℝ))*p := by
  classical
  dsimp only
  rw [Fintype.sum_option]
  have hdif : x≠move x i j := by
    intro he
    exact hd (by simpa [move] using congrFun he i)
  have hbad (a : Pair V) : (if turn x (some a)=turn (move x i j)
      ((Equiv.optionCongr (pairPerm x i j hi hj)) (some a)) then 0 else cost V p (some a)) =
      (if ¬good x i j a then p else 0) := by
    rcases a with ⟨u,v⟩
    have he : turn x (some (u,v))=turn (move x i j) ((Equiv.optionCongr (pairPerm x i j hi hj)) (some (u,v))) ↔ good x i j (u,v) := by
      change move x u v = turn (move x i j) (some (couplePair x i j (u,v))) ↔ _
      generalize hq : couplePair x i j (u,v)=q
      rcases q with ⟨q,r⟩
      unfold good
      rw [hq]; rfl
    by_cases h : good x i j (u,v)
    · rw [ite_eq_left (he.mpr h),ite_eq_right (not_not.mpr h)]
    · rw [ite_eq_right (fun z => h (he.mp z)),ite_eq_left h]; rfl
  simp_rw [hbad]
  rw [← Finset.sum_filter]
  simp only [Finset.sum_const,nsmul_eq_mul]
  change (if x=move x i j then 0 else 1-(Fintype.card V:ℝ)^2*p) + _ ≤ _
  rw [ite_eq_right hdif]
  have hsum := Finset.card_filter_add_card_filter_not (s:=(Finset.univ:Finset (Pair V))) (p:=good x i j)
  have hh := good_many x i j hi hj hd
  have hcnt : (((Finset.univ.filter (fun a => ¬good x i j a)).card:ℝ) +
      2*((((outside x).card-2:ℕ):ℝ))) ≤ (Fintype.card V:ℝ)^2 := by
    have ht : (Finset.univ.filter (fun a => ¬good x i j a)).card+2*((outside x).card-2)≤
        Fintype.card V * Fintype.card V := by
      rw [← Fintype.card_prod,← Finset.card_univ]
      omega
    simpa [pow_two] using (show (((Finset.univ.filter (fun a => ¬good x i j a)).card:ℝ)+
        2*((((outside x).card-2:ℕ):ℝ))) ≤ (Fintype.card V:ℝ)*(Fintype.card V:ℝ) by exact_mod_cast ht)
  linarith [mul_le_mul_of_nonneg_right hcnt hp]

#print axioms good_many
#print axioms bad_weight
end PaintMix
