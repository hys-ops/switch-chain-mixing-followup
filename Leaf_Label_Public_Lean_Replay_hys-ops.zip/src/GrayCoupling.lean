import CoupledSteps
import Mathlib.GroupTheory.Perm.Support

noncomputable section
open scoped BigOperators Matrix
namespace PaintMix
open HubTransfer
variable {V : Type*} [Fintype V] [DecidableEq V]
abbrev Paint (V : Type*) := V → Option Bool
abbrev Pair (V : Type*) := V × V
abbrev PropStep (V : Type*) := Option (Pair V)
def move (x : Paint V) (i j : V) : Paint V := fun v => x (Equiv.swap i j v)
def outside (x : Paint V) := Finset.univ.filter (fun v => x v ≠ none)
def Adj (b : ℕ) (x y : Paint V) : Prop :=
  ∃ i j, x i≠none ∧ x j≠none ∧ x i≠x j ∧ (outside x).card=b ∧ y=move x i j

def cost (V : Type*) [Fintype V] (p : ℝ) : PropStep V → ℝ
  | none => 1-(Fintype.card V:ℝ)^2*p
  | some _ => p
def turn (x : Paint V) : PropStep V → Paint V
  | none => x
  | some (a,b) => move x a b

theorem natural_swap (s : Equiv.Perm V) (a b v : V) :
    s (Equiv.swap a b v) = Equiv.swap (s a) (s b) (s v) :=
  congrArg (fun e:Equiv.Perm V => e v) (Equiv.mul_swap_eq_swap_mul s a b)

theorem outside_move (x : Paint V) (i j : V) : (outside (move x i j)).card=(outside x).card := by
  apply Finset.card_bijective (Equiv.swap i j) (Equiv.swap i j).bijective
  intro v; change (v∈Finset.univ.filter (fun z => move x i j z≠none)) ↔ _; rw [Finset.mem_filter]; simp [outside,move]

theorem outside_invariant (x : Paint V) {i j : V} (hi : x i≠none) (hj : x j≠none) (v : V) :
    x (Equiv.swap i j v)≠none ↔ x v≠none := by
  by_cases h1 : v=i
  · subst v; simp [hi,hj]
  by_cases h2 : v=j
  · subst v; simp [hi,hj]
  rw [Equiv.swap_apply_of_ne_of_ne h1 h2]

/-- Conjugate only proposals with both ends outside red; on other proposals
apply the same transposition to both chains, transporting the discrepancy. -/
def couplePair (x : Paint V) (i j : V) (a : Pair V) : Pair V :=
  if x a.1≠none ∧ x a.2≠none then (Equiv.swap i j a.1,Equiv.swap i j a.2) else a

theorem pair_pos (x : Paint V) (i j : V) (a : Pair V) (h : x a.1≠none ∧ x a.2≠none) :
    couplePair x i j a = (Equiv.swap i j a.1,Equiv.swap i j a.2) := if_pos h

theorem pair_neg (x : Paint V) (i j : V) (a : Pair V) (h : ¬(x a.1≠none ∧ x a.2≠none)) :
    couplePair x i j a = a := if_neg h

def pairPerm (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none) : Equiv.Perm (Pair V) :=
  Function.Involutive.toPerm (f:=couplePair x i j) (by
    intro a
    by_cases h : x a.1≠none ∧ x a.2≠none
    · have h' := And.intro ((outside_invariant x hi hj _).mpr h.1) ((outside_invariant x hi hj _).mpr h.2)
      rw [pair_pos x i j a h,pair_pos x i j _ h']; simp
    · rw [pair_neg x i j a h,pair_neg x i j a h])

theorem coupled_outside (x : Paint V) (i j a b : V) :
    move (move x i j) (Equiv.swap i j a) (Equiv.swap i j b)=move (move x a b) i j := by
  funext v; unfold move
  have h := natural_swap (Equiv.swap i j) a b (Equiv.swap i j v)
  rw [Equiv.swap_apply_self] at h
  rw [←h,Equiv.swap_apply_self]

theorem coupled_common (x : Paint V) (i j a b : V) :
    move (move x i j) a b=move (move x a b) (Equiv.swap a b i) (Equiv.swap a b j) :=
  (coupled_outside x a b i j).symm

theorem images_related (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none)
    (hd : x i≠x j) (a b : V) :
    let p := couplePair x i j (a,b)
    move x a b = move (move x i j) p.1 p.2 ∨
      Adj (outside x).card (move x a b) (move (move x i j) p.1 p.2) := by
  dsimp only
  by_cases h : x a≠none ∧ x b≠none
  · rw [pair_pos x i j (a,b) h]; simp only [coupled_outside]
    by_cases he : move x a b i=move x a b j
    · exact Or.inl (funext (fun v => (Equiv.apply_swap_eq_self he v).symm))
    · exact Or.inr ⟨i,j,(outside_invariant x h.1 h.2 i).mpr hi,
        (outside_invariant x h.1 h.2 j).mpr hj,he,outside_move x a b,rfl⟩
  · rw [pair_neg x i j (a,b) h]; simp only [coupled_common x i j a b]
    right
    refine ⟨Equiv.swap a b i,Equiv.swap a b j,?_,?_,?_,outside_move x a b,rfl⟩
    all_goals simp [move,hi,hj,hd]

theorem bool_exhaust {a b c : Option Bool} (ha : a≠none) (hb : b≠none) (hc : c≠none) (hd : a≠b) :
    c=a ∨ c=b := by
  cases a with | none => contradiction | some a =>
    cases b with | none => contradiction | some b =>
      cases c with | none => contradiction | some c =>
        cases a <;> cases b <;> cases c <;> simp_all

def others (x : Paint V) (i j : V) := ((outside x).erase i).erase j
def partner (x : Paint V) (i j w : V) := if x w=x j then i else j

theorem cures (x : Paint V) (i j : V) (hi : x i≠none) (hj : x j≠none) (hd : x i≠x j)
    (w : ↥(others x i j)) :
    let v := partner x i j w.1
    move x w.1 v = move (move x i j) (couplePair x i j (w.1,v)).1 (couplePair x i j (w.1,v)).2 := by
  have hwj := (Finset.mem_erase.mp w.2).1
  have hwi := (Finset.mem_erase.mp (Finset.mem_erase.mp w.2).2).1
  have hw := (Finset.mem_filter.mp (Finset.mem_erase.mp (Finset.mem_erase.mp w.2).2).2).2
  have hij : i≠j := fun z => hd (congrArg x z)
  dsimp only
  have hp : x (partner x i j w.1)≠none := by unfold partner; split <;> assumption
  rw [pair_pos x i j _ ⟨hw,hp⟩]; simp only [coupled_outside]
  apply funext
  intro v
  apply (Equiv.apply_swap_eq_self ?_ v).symm
  unfold move partner
  by_cases h : x w.1=x j
  · rw [ite_eq_left h,Equiv.swap_apply_right,Equiv.swap_apply_of_ne_of_ne hwj.symm hij.symm,h]
  · rw [ite_eq_right h,Equiv.swap_apply_right,Equiv.swap_apply_of_ne_of_ne hwi.symm hij]
    exact ((bool_exhaust hi hj hw hd).resolve_right h).symm

#print axioms images_related
#print axioms cures
end PaintMix
