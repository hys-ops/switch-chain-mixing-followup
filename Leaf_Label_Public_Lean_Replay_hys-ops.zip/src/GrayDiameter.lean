import GrayWalk

noncomputable section
open scoped BigOperators Matrix
namespace PaintMix
open HubTransfer
attribute [local instance] Classical.propDecidable
variable {V : Type*} [Fintype V] [DecidableEq V]

def gray (x : Paint V) := Finset.univ.filter (fun v => x v=some true)

theorem mem_gray (x : Paint V) (v : V) : v∈gray x ↔ x v=some true := by
  simp only [gray,Finset.mem_filter,Finset.mem_univ,true_and]

theorem gray_move (x : Paint V) (i j : V) :
    gray (move x i j)=(gray x).map (Equiv.swap i j).toEmbedding := by
  ext v
  simp only [mem_gray,Finset.mem_map_equiv,Equiv.symm_swap,move]

theorem paint_eq_of_gray {x y : Paint V}
    (ho : ∀v,x v=none ↔ y v=none) (hg : gray x=gray y) : x=y := by
  funext v
  have hnone := ho v
  have hgray : x v=some true ↔ y v=some true := by
    rw [←mem_gray,←mem_gray,hg]
  cases hx : x v with
  | none => exact ((hnone.mp hx).symm)
  | some a =>
    cases hy : y v with
    | none => exact (by simp [hx,hy] at hnone)
    | some b => cases a <;> cases b <;> simp_all

theorem reduce_diff {x y : Paint V} (hred : ∀v,x v=none ↔ y v=none)
    (hcard : (gray x).card=(gray y).card) (hne : x≠y) :
    ∃ (z : Paint V), Adj (outside x).card x z ∧ (∀v,z v=none ↔ y v=none) ∧
      (gray z).card=(gray y).card ∧ ((gray z) \ gray y).card + 1 = ((gray x) \ gray y).card := by
  have hxy : gray x≠gray y := fun h => hne (paint_eq_of_gray hred h)
  have h1 : ¬gray x⊆gray y := fun h => hxy (Finset.eq_of_subset_of_card_le h hcard.ge)
  have h2 : ¬gray y⊆gray x := fun h => hxy ((Finset.eq_of_subset_of_card_le h hcard.le).symm)
  obtain ⟨i,hi,hiy⟩ := Finset.not_subset.mp h1
  obtain ⟨j,hj,hjx⟩ := Finset.not_subset.mp h2
  have hii := (mem_gray x i).mp hi
  have hjj := (mem_gray y j).mp hj
  have hxi : x i≠none := by simp [hii]
  have hxj : x j≠none := fun e => by have h := (hred j).mp e; simp [hjj] at h
  have hn : x i≠x j := fun h => hjx ((mem_gray x j).mpr (h ▸ hii))
  have hne' : i≠j := fun h => hjx (h ▸ hi)
  refine ⟨move x i j,⟨i,j,hxi,hxj,hn,rfl,rfl⟩,?_,?_,?_⟩
  · intro v
    have h := outside_invariant x hxi hxj v
    simpa only [move,not_iff_not] using (not_congr (h.trans ((not_congr (hred v)))) )
  · rw [gray_move,Finset.card_map,hcard]
  · have hs : gray (move x i j) \ gray y=(gray x \ gray y).erase i := by
      ext v
      by_cases hvi : v=i
      · subst v; have hnq : x j ≠ some true := fun h => hjx ((mem_gray x j).mpr h); simp [mem_gray,move,hnq]
      by_cases hvj : v=j
      · subst v; simp [hj]
      simp only [Finset.mem_sdiff,Finset.mem_erase,mem_gray,move,Equiv.swap_apply_of_ne_of_ne hvi hvj]
      simp [hvi]
    rw [hs,Finset.card_erase_add_one (Finset.mem_sdiff.mpr ⟨hi,hiy⟩)]

theorem gray_path {x y : Paint V} (hred : ∀v,x v=none ↔ y v=none)
    (hcard : (gray x).card=(gray y).card) {Q : ℝ} (hQ : 0<Q)
    (hclock : (Fintype.card V:ℝ)^2 ≤ 2*Q) (t : ℕ) :
    tv (((J V Q)^t) x) (((J V Q)^t) y) ≤
      (((gray x \ gray y).card):ℝ) * (1-((((outside x).card-2:ℕ):ℝ))/Q)^t := by
  generalize hm : (gray x \ gray y).card = m
  induction m using Nat.strong_induction_on generalizing x with
  | h m ih =>
    by_cases hxy : x=y
    · subst y
      have hzero : m=0 := by simpa using hm.symm
      simp [hzero,tv]
    obtain ⟨z,hadj,hr,hc,he⟩ := reduce_diff hred hcard hxy
    have he' := ih (gray z \ gray y).card (by omega) hr hc rfl
    have hbase : (outside z).card=(outside x).card := by
      obtain ⟨i,j,_,_,_,_,rfl⟩ := hadj; exact outside_move _ _ _
    rw [hbase] at he'
    apply (tv_triangle _ (((J V Q)^t) z) _).trans
    apply (add_le_add (color_adjacent hadj hQ hclock t) he').trans_eq
    have he'' : (m:ℝ)=((gray z \ gray y).card:ℝ)+1 := by exact_mod_cast (show m=_ by omega)
    rw [he''];ring

theorem two_gray {x y : Paint V} (hred : ∀v,x v=none ↔ y v=none)
    (hx : (gray x).card=2) (hy : (gray y).card=2) {Q : ℝ} (hQ : 0<Q)
    (hclock : (Fintype.card V:ℝ)^2 ≤ 2*Q) (t : ℕ) :
    tv (((J V Q)^t) x) (((J V Q)^t) y) ≤
      2*(1-((((outside x).card-2:ℕ):ℝ))/Q)^t := by
  apply (gray_path hred (hx.trans hy.symm) hQ hclock t).trans
  have hlen : (gray x \ gray y).card ≤ 2 := (Finset.card_le_card Finset.sdiff_subset).trans_eq hx
  have hn : (((outside x).card-2:ℕ):ℝ) ≤ (Fintype.card V:ℝ) := by
    exact_mod_cast ((Nat.sub_le _ _).trans (Finset.card_le_univ _))
  have hg : 2≤Fintype.card V := hx ▸ Finset.card_le_univ (gray x)
  have hg' : (2:ℝ)≤Fintype.card V := by exact_mod_cast hg
  have hQ' : (((outside x).card-2:ℕ):ℝ) ≤ Q := by
    nlinarith [mul_nonneg (show 0≤(Fintype.card V:ℝ) by positivity) (sub_nonneg.mpr hg')]
  exact mul_le_mul_of_nonneg_right (by exact_mod_cast hlen)
    (pow_nonneg (sub_nonneg.mpr ((div_le_one hQ).mpr hQ')) _)

#print axioms gray_path
#print axioms two_gray
end PaintMix
