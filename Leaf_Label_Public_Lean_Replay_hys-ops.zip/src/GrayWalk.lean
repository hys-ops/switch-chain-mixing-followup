import GrayCount

noncomputable section
open scoped BigOperators Matrix
namespace PaintMix
open HubTransfer
attribute [local instance] Classical.propDecidable
variable {V : Type*} [Fintype V] [DecidableEq V]

def J (V : Type*) [Fintype V] [DecidableEq V] (Q : ℝ) : Matrix (Paint V) (Paint V) ℝ :=
  walk (cost V (1/(2*Q))) turn

theorem turn_some (x : Paint V) (a : Pair V) : turn x (some a)=move x a.1 a.2 := by cases a; rfl

theorem color_adjacent {b : ℕ} {x y : Paint V} (hr : Adj b x y)
    {Q : ℝ} (hQ : 0<Q) (hclock : (Fintype.card V:ℝ)^2 ≤ 2*Q) (t : ℕ) :
    tv (((J V Q)^t) x) (((J V Q)^t) y) ≤ (1-(((b-2:ℕ):ℝ))/Q)^t := by
  let p := 1/(2*Q)
  have hp : 0≤p := by dsimp [p]; positivity
  have hc : (Fintype.card V:ℝ)^2*p≤1 := by
    dsimp [p]; rw [one_div,← div_eq_mul_inv]
    exact (div_le_one (by positivity)).mpr hclock
  have hw (a : PropStep V) : 0≤cost V p a := by
    cases a with | none => exact sub_nonneg.mpr hc | some a => exact hp
  have hρ : 0≤1-(((b-2:ℕ):ℝ))/Q := by
    obtain ⟨i,j,hi,hj,hd,hb,_⟩ := hr
    have hb' : b≤Fintype.card V := hb ▸ Finset.card_le_univ (outside x)
    have hbi : 2≤(outside x).card := by
      have hij : i≠j := fun h => hd (congrArg x h)
      have hsub : {i,j} ⊆ outside x := by
        intro z hz; rcases Finset.mem_insert.mp hz with rfl | h
        · exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,hi⟩
        · obtain rfl := Finset.mem_singleton.mp h; exact Finset.mem_filter.mpr ⟨Finset.mem_univ _,hj⟩
      simpa [hij] using Finset.card_le_card hsub
    have hN : (2:ℝ)≤Fintype.card V := by exact_mod_cast (show 2≤Fintype.card V by omega)
    have hn : (((b-2:ℕ):ℝ))≤Fintype.card V := by exact_mod_cast (show b-2≤Fintype.card V by omega)
    apply sub_nonneg.mpr ((div_le_one hQ).mpr _)
    nlinarith [mul_nonneg (show 0≤(Fintype.card V:ℝ) by positivity) (sub_nonneg.mpr hN)]
  apply adjacent_coupling (cost V p) hw turn (Adj b) _ hρ _ hr
  intro A B h
  obtain ⟨i,j,hi,hj,hd,hb,rfl⟩ := h
  let e := Equiv.optionCongr (pairPerm A i j hi hj)
  refine ⟨e,?_,?_,?_⟩
  · rintro (_|a) <;> rfl
  · rintro (_|⟨u,v⟩)
    · exact Or.inr ⟨i,j,hi,hj,hd,hb,rfl⟩
    · change (turn A (some (u,v)) = turn (move A i j) (some (couplePair A i j (u,v))) ∨
        Adj b (turn A (some (u,v))) (turn (move A i j) (some (couplePair A i j (u,v)))))
      simp only [turn_some];simpa only [hb] using images_related A i j hi hj hd u v
  · have h := bad_weight A i j hi hj hd p hp
    apply h.trans_eq
    rw [hb]; dsimp [p]; field_simp

theorem cost_sum (V : Type*) [Fintype V] (p : ℝ) : ∑ a:PropStep V,cost V p a=1 := by
  rw [Fintype.sum_option]
  simp [cost,Fintype.card_prod,pow_two]

theorem J_stochastic {Q : ℝ} (hQ : 0<Q) (hclock : (Fintype.card V:ℝ)^2≤2*Q) :
    Stochastic (J V Q) := by
  let p := 1/(2*Q)
  have hw (a : PropStep V) : 0≤cost V p a := by
    cases a with
    | none =>
      apply sub_nonneg.mpr
      change (Fintype.card V:ℝ)^2*(1/(2*Q))≤1
      rw [one_div,← div_eq_mul_inv]; exact (div_le_one (by positivity)).mpr hclock
    | some a => dsimp [cost,p]; positivity
  constructor
  · intro x y; apply Finset.sum_nonneg;intro i _; split_ifs; exact hw i; exact le_rfl
  · intro x
    change (∑ y:Paint V,∑ i:PropStep V, if turn x i=y then cost V p i else 0)=1
    rw [Finset.sum_comm]
    simpa using cost_sum V p

#print axioms color_adjacent
#print axioms J_stochastic
end PaintMix
