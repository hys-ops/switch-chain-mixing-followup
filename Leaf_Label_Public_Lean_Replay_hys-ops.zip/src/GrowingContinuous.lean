import GrowingWindow
import UrnSemigroup
import GraphWindows
open Finset HubTransfer OAI.Problem315 Filter Topology UrnWindow UrnWindow.Degrees
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open TwoHubUnequal

theorem external_exact (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    (S : Slice (g.r i) (g.s i)) :
    let t:=g.time z c i
    tv (LeafClock.continuous (HubMarks.walk (g.population i) (g.r i-1) (g.Q i)) t S) (unif _) =
      urnDistance S (g.external i (g.tau z c i)) := by
  dsimp only
  have hN : 0<g.population i := by unfold Degrees.population;have :=g.two i;omega
  rw [LeafClock.clock_identity hN (g.Q i) (g.time z c i) (g.clk_pos i),urnDistance_exp]
  rw [show (g.time z c i:ℝ)*(g.population i:ℝ)^2/(2*g.Q i)=g.external i (g.tau z c i) by unfold Degrees.external Degrees.tau;ring]
  rfl

def envelope (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) :=
  g.error z c i+g.tau z c i+2*Real.sqrt (g.tau z c i)

/-- Complete finite comparison. One side is the authors' original discrete
    labeled graph chain, the other is the actual rate-one binary urn semigroup. -/
theorem continuous_bound (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    {d : Fin (g.population i+2) → ℕ} {a b : Fin (g.population i+2)}
    (sp : Spec (g.population i+2) (g.r i) (g.s i) d a b)
    (G : GraphState _ d) (S : Slice (g.r i) (g.s i)) :
    |tvDistanceFrom _ d (g.time z c i) G - urnDistance S (g.external i (g.tau z c i))|≤
      envelope g z c i := by
  let t:=g.time z c i
  let W:=HubMarks.walk (g.population i) (g.r i-1) (g.Q i)
  let E:=LeafClock.continuous W t S
  let D:=(W^t) S
  have hn : 4≤g.population i+2 := by unfold Degrees.population;have :=g.two i;omega
  have A := (all_starts sp hn (g.two i) ((g.two i).trans (g.small i)) G S t).trans
    (window_envelope g z c i sp)
  have B:=LeafClock.window_bound g z c i S
  have C:=RestrictedTV.between D E (unif _)
  rw [RestrictedTV.reverse D E] at C
  have C':=C.trans B
  have he : tv E (unif _)=urnDistance S (g.external i (g.tau z c i)):=external_exact g z c i S
  rw [he] at C'
  exact (abs_sub_le _ (tv D (unif _)) _).trans (add_le_add A C')

theorem envelope_zero (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (envelope g z c) atTop (𝓝 0) := by
  change Tendsto (fun i => g.error z c i + g.tau z c i + 2*Real.sqrt (g.tau z c i)) atTop (𝓝 0)
  simpa using (window_envelope_zero g z c).add (LeafClock.window_error_zero g z c)

/-- External input names a *specific* urn and limiting curve, with the published
    time normalization. No graph-to-urn comparison or monotonicity is assumed. -/
theorem profile_from_urn (g : Degrees)
    (d : (i:ℕ)→Fin (g.population i+2)→ℕ) (a b : (i:ℕ)→Fin (g.population i+2))
    (sp : ∀i,Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (S : (i:ℕ)→Slice (g.r i) (g.s i))
    (z : Regime) (c : ℝ) (hc : ContinuousAt z.curve c)
    (external_profile : ∀w:ℝ,Tendsto (fun i=>urnDistance (S i) (g.N i*(g.center z.window i+w)/2))
      atTop (𝓝 (z.curve w)))
    {ε : ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time z.window c i) G-z.curve c|<ε := by
  have hd (i:ℕ) : Antitone (urnDistance (S i)) := urn_antitone _ (by
    have :=g.two i;omega)
  have H:=g.rounded_binary_limit z.window c (fun i=>urnDistance (S i)) z.curve hd hc external_profile
  have hh:=Metric.tendsto_nhds.mp H (ε/2) (by linarith)
  have he:=(tendsto_order.mp (envelope_zero g z.window c)).2 (ε/2) (by linarith)
  filter_upwards [hh,he] with i hhi hei
  rw [Real.dist_eq] at hhi
  intro G
  have A:=continuous_bound g z.window c i (sp i) G (S i)
  exact (abs_sub_le _ (urnDistance (S i) (g.external i (g.tau z.window c i))) _).trans_lt
    (by linarith : _ + _ < ε)

/-- Direct adapter to the literature's three named regimes. -/
theorem named_profiles (g : Degrees)
    (d : (i:ℕ)→Fin (g.population i+2)→ℕ) (a b : (i:ℕ)→Fin (g.population i+2))
    (sp : ∀i,Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (S : (i:ℕ)→Slice (g.r i) (g.s i))
    (paper : g.UrnProfileInput (fun i=>urnDistance (S i)))
    (z : Regime) (hz : z.holds g) (c : ℝ) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time z.window c i) G-z.curve c|<ε :=
  profile_from_urn g d a b sp S z c (paper z hz).1.continuousAt (paper z hz).2 hε
#print axioms continuous_bound
#print axioms envelope_zero
#print axioms named_profiles
end PhysicalReduction
