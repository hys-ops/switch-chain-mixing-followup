import VertexReduction
import JohnsonHomogeneous
import UrnError
open Finset HubTransfer OAI.Problem315 Filter Topology
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open RestrictedTV TwoHubUnequal TwoHubHorizontal GraphSplit UrnWindow UrnWindow.Degrees
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def discreteError (n r s t : ℕ) : ℝ :=
  3*t/clock n +noexit n r s t+gray n s t+adjerr n r s t+stationary r s

theorem rates (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s) :
    (r:ℝ)*s≤clock n ∧ ((s-1:ℕ):ℝ)≤clock n ∧ ((r+s-2:ℕ):ℝ)≤clock n := by
  have h:=GraphGray.clock_big sp hn
  rw [GraphGray.label_card sp,Nat.cast_add] at h
  have h1 : (2:ℝ)≤r := by exact_mod_cast hr
  have h2 : (2:ℝ)≤s := by exact_mod_cast hs
  have hh := mul_nonneg (show 0≤(r:ℝ)+s by positivity) (show 0≤(r:ℝ)+s-2 by linarith)
  have hN : (r:ℝ)+s≤clock n := by nlinarith
  rw [Nat.cast_sub (by omega : 1≤s),Nat.cast_sub (by omega : 2≤r+s),Nat.cast_add,Nat.cast_one,Nat.cast_ofNat]
  exact ⟨by nlinarith [sq_nonneg ((r:ℝ)-s)],by linarith,by linarith⟩

theorem discrete_choice (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) (t : ℕ) : ∃ S : Slice r s,
      |tvDistanceFrom n d t G-Bdist n r s t S| ≤ discreteError n r s t := by
  have hrs : 2≤(r:ℝ)*s := by
    have hr' : (2:ℝ)≤r := by exact_mod_cast hr
    have hs' : (2:ℝ)≤s := by exact_mod_cast hs
    nlinarith [mul_le_mul hr' hs' (by norm_num) (by positivity : (0:ℝ)≤r)]
  by_cases he:G.val.Adj a c
  · refine ⟨redProjection sp G,(edge_binary sp hn hs hrs G he t).trans ?_⟩
    obtain ⟨ha,_,hb⟩:=rates sp hn hr hs
    have h1:=pow_nonneg (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr ha)) t
    have h2:=pow_nonneg (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr hb)) t
    unfold discreteError;linarith
  · obtain ⟨J,hJ⟩:=support_some sp hn (by linarith) G he
    exact ⟨redProjection sp J,vertex_binary sp hn hs hrs G J he hJ t⟩

/-- Every labeled graph start can be compared with the same, arbitrarily
    prescribed point of the red binary slice. -/
theorem all_starts (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) (S : Slice r s) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t S|≤discreteError n r s t := by
  obtain ⟨T,h⟩:=discrete_choice sp hn hr hs G t
  unfold Bdist at h ⊢
  rw [←JohnsonProfile.tv_start_independent (clock_pos hn).ne' T S t];exact h

theorem exp_bound (x Q : ℝ) (hQ : 0<Q) (hx : x≤Q) (t : ℕ) :
    (1-x/Q)^t ≤ Real.exp (-(x*((t:ℝ)/Q))) := by
  have he : 1-x/Q ≤ Real.exp (-(x/Q)) := by linarith [Real.add_one_le_exp (-(x/Q))]
  have hp := pow_le_pow_left₀ (sub_nonneg.mpr ((div_le_one hQ).mpr hx)) he t
  rw [←Real.exp_nat_mul] at hp
  convert hp using 2;ring

/-- Explicit common envelope across all three growing-degree windows. -/
theorem window_envelope (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    {d : Fin (g.population i+2) → ℕ} {a b : Fin (g.population i+2)}
    (sp : Spec (g.population i+2) (g.r i) (g.s i) d a b) :
    discreteError (g.population i+2) (g.r i) (g.s i) (g.time z c i) ≤
        g.error z c i+g.tau z c i := by
  let r:=g.r i
  let s:=g.s i
  let n:=g.population i+2
  let t:=g.time z c i
  have hr : 2≤r := g.two i
  have hs : 2≤s := hr.trans (g.small i)
  have hn : 4≤n := by dsimp [n,Degrees.population];change 2≤g.r i at hr;omega
  obtain ⟨ha,hb,hc⟩:=rates sp hn hr hs
  have h1 := exp_bound _ _ (clock_pos hn) ha t
  have h2 := exp_bound _ _ (clock_pos hn) hb t
  have h3 := exp_bound _ _ (clock_pos hn) hc t
  change noexit n r s t≤Real.exp (-((r:ℝ)*s*g.tau z c i)) at h1
  change (1-((s-1:ℕ):ℝ)/clock n)^t≤Real.exp (-(((s-1:ℕ):ℝ)*g.tau z c i)) at h2
  change adjerr n r s t≤Real.exp (-(((r+s-2:ℕ):ℝ)*g.tau z c i)) at h3
  rw [Nat.cast_sub (by omega : 1≤s),Nat.cast_one] at h2
  rw [Nat.cast_sub (by omega : 2≤r+s),Nat.cast_ofNat,Nat.cast_add] at h3
  unfold Degrees.error
  rw [(g.sizes i).2.2.2]
  change 3*(t:ℝ)/clock n + noexit n r s t+2*(1-((s-1:ℕ):ℝ)/clock n)^t+
    adjerr n r s t+2/((r:ℝ)*s+2) ≤
    (t:ℝ)*(2*(r:ℝ)*s/clock n)^2+2/((r:ℝ)*s+2)+2*g.tau z c i+
    Real.exp (-((r:ℝ)*s*g.tau z c i))+2*Real.exp (-(((s:ℝ)-1)*g.tau z c i))+
    Real.exp (-((((r:ℝ)+s)-2)*g.tau z c i))+g.tau z c i
  have ht : (t:ℝ)/clock n=g.tau z c i := rfl
  rw [Nat.cast_sub (by omega : 1≤s),Nat.cast_one]
  rw [show 3*(t:ℝ)/clock n=3*g.tau z c i by rw [←ht];ring]
  linarith [mul_nonneg (by positivity : 0≤(t:ℝ)) (sq_nonneg (2*(r:ℝ)*s/clock n))]

theorem window_envelope_zero (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (fun i=>g.error z c i+g.tau z c i) atTop (𝓝 0) := by
  simpa using (g.error_zero z c).add (g.tau_zero z c)

#print axioms all_starts
#print axioms window_envelope
end PhysicalReduction
