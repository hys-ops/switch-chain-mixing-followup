import MarkovTV
open Finset HubTransfer
open scoped Matrix
noncomputable section
namespace LeafDrift
variable {X : Type*} [Fintype X] [DecidableEq X]

def obs (p f : X → ℝ) : ℝ := ∑ y, p y*f y
def ind (E : Finset X) (x : X) : ℝ := if x ∈ E then 1 else 0
omit [DecidableEq X] in
theorem row_mul (A B : Matrix X X ℝ) (x : X) (f : X → ℝ) :
    obs ((A*B) x) f = obs (A x) (fun j => obs (B j) f) := by
  unfold obs
  simp only [Matrix.mul_apply,Finset.sum_mul,Finset.mul_sum,mul_assoc]
  rw [Finset.sum_comm]

omit [DecidableEq X] in
theorem obs_mono {p f g : X → ℝ} (hp : ∀ x, 0 ≤ p x) (hf : ∀ x, f x ≤ g x) :
    obs p f ≤ obs p g :=
  sum_le_sum (fun y _ => mul_le_mul_of_nonneg_left (hf y) (hp y))
omit [DecidableEq X] in
theorem obs_add (p f g : X → ℝ) :
    obs p (fun y => f y+g y) = obs p f+obs p g := by simp [obs,mul_add,sum_add_distrib]
omit [DecidableEq X] in
theorem obs_scale (p f : X → ℝ) (a : ℝ) :
    obs p (fun y => a*f y) = a*obs p f := by
  unfold obs;rw [mul_sum];apply sum_congr rfl;intro y _;ring
omit [DecidableEq X] in
theorem obs_const (p : X → ℝ) (hp : ∑ y, p y=1) (a : ℝ) :
    obs p (fun _ => a) = a := by simp [obs,←sum_mul,hp]
theorem add_drift_iter (P : Matrix X X ℝ) (hp : Stochastic P) (F : X → ℝ) (c : ℝ)
    (hd : ∀ x, obs (P x) F ≤ F x+c) (t : ℕ) (x : X) :
    obs ((P^t) x) F ≤ F x+(t:ℝ)*c := by
  induction t with
  | zero => simp [obs,Matrix.one_apply]
  | succ t ih =>
    rw [pow_succ,row_mul]
    have hPt := stochastic_pow hp t
    calc
      _ ≤ obs ((P^t) x) (fun y => F y+c) := obs_mono (hPt.1 x) hd
      _ = obs ((P^t) x) F+c := by rw [obs_add,obs_const _ (hPt.2 x)]
      _ ≤ _ := by push_cast;linarith

/-- Probability of an event minus its comparison mass is at most half the ℓ¹ distance. -/
theorem event_gap {p w : X → ℝ} (hp : ∑ x,p x=1) (hw : ∑ x,w x=1) (E : Finset X) :
    obs p (ind E)-obs w (ind E) ≤ tv p w := by
  let u := fun x => p x-w x
  have hu : ∑ x, u x=0 := by simp [u,sum_sub_distrib,hp,hw]
  have h : 2*∑ x,u x*ind E x = ∑ x,(2*ind E x-1)*u x := by
    simp_rw [sub_mul,one_mul,Finset.sum_sub_distrib,hu,sub_zero,mul_assoc,←Finset.mul_sum]
    congr 1;apply sum_congr rfl;intro y _;ring
  have hh := Finset.abs_sum_le_sum_abs (fun x => (2*ind E x-1)*u x) univ
  rw [←h,abs_mul,abs_of_pos (by norm_num : (0:ℝ)<2)] at hh
  have he (x : X) : |(2*ind E x-1)*u x|=|u x| := by by_cases hx : x∈E <;> norm_num [ind,hx]
  simp only [he] at hh
  have hx := le_abs_self (∑ x,u x*ind E x)
  have hsub : obs p (ind E)-obs w (ind E)=∑ x,u x*ind E x := by simp [obs,u,sub_mul,sum_sub_distrib]
  rw [hsub]; change _ ≤ (∑ x,|u x|)/2; linarith

/-- A finite-time certificate requiring only an upward drift bound for F and a
    first-moment bound for Z under the comparison law. No eigenvector or spectral gap input. -/
theorem tv_lower (P : Matrix X X ℝ) (hp : Stochastic P) (w F Z : X → ℝ)
    (hw : ∑ x, w x=1) (hw0 : ∀ x, 0≤w x) (hF : ∀ x, 0≤F x) (hZ : ∀ x, 0≤Z x)
    (x : X) {c B L mu : ℝ} (hB : 0<B) (hL : 0<L)
    (hinit : F x=0) (hd : ∀ j, obs (P j) F ≤ F j+c)
    (hbad : ∀ y, Z y ≤ B → L ≤ F y) (hmean : obs w Z ≤ mu) (t : ℕ) :
    1-(t:ℝ)*c/L-mu/B ≤ tv ((P^t) x) w := by
  classical
  let E := univ.filter (fun y => B<Z y)
  let p := (P^t) x
  have hPt := stochastic_pow hp t
  have hp1 : ∑ y,p y=1 := hPt.2 x
  have hp0 : ∀ y,0≤p y := hPt.1 x
  have hin (y : X) : L*(1-ind E y) ≤ F y := by
    by_cases hh : B<Z y
    · simpa [E,ind,hh] using hF y
    · simpa [E,ind,hh] using hbad y (not_lt.mp hh)
  have hout (y : X) : B*ind E y ≤ Z y := by
    by_cases hh : B<Z y
    · simpa [E,ind,hh] using hh.le
    · simpa [E,ind,hh] using hZ y
  have a := obs_mono hp0 hin
  rw [obs_scale] at a
  have hsub : obs p (fun y => 1-ind E y)=1-obs p (ind E) := by
    simp [obs,mul_sub,sum_sub_distrib,hp1]
  rw [hsub] at a
  have hd' : obs p F ≤ (t:ℝ)*c := by simpa [p,hinit] using add_drift_iter P hp F c hd t x
  have b := obs_mono hw0 hout
  rw [obs_scale] at b
  have h1 : 1-obs p (ind E) ≤ (t:ℝ)*c/L := (le_div_iff₀ hL).mpr (by linarith)
  have h2 : obs w (ind E) ≤ mu/B := (le_div_iff₀ hB).mpr (by linarith)
  have h3 := event_gap hp1 hw E
  change _ ≤ tv p w
  linarith

#print axioms add_drift_iter
#print axioms tv_lower
end LeafDrift
