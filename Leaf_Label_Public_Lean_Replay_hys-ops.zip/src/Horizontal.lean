import FourChanges
import UnequalShape
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset
open TwoHubUnequal (Spec)
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def Witness (a c : Fin n) (G H : GraphState n d) (e : Finset (Fin n)) : Prop :=
  ∃i ∈ leaves a c, ∃j ∈ leaves a c,e={i,j} ∧ G.val.comap (Equiv.swap i j)=H.val

/-- Distinct disjoint leaf-leaf edges cannot coexist in this family. -/
lemma no_four_leaves (sp : Spec n r s d a c) (G : GraphState n d) {x y z w : Fin n}
    (hd : FourDistinct x y z w) (hxy : G.val.Adj x y) (hzw : G.val.Adj z w)
    (hx : x∈leaves a c) (hy : y∈leaves a c) (hz : z∈leaves a c) (hw : w∈leaves a c) : False := by
  have loose_of {u v : Fin n} (hu : u∈leaves a c) (hv : v∈leaves a c) (hg : G.val.Adj u v) : u∈loose G.val a c := by
    have hu':=(mem_leaves _ _ _).mp hu
    have hv':=(mem_leaves _ _ _).mp hv
    exact (mem_loose _ _ _ _).mpr ⟨hu'.1,hu'.2,fun he=>hv'.1 (TwoHubUnequal.leaf_unique sp G hu'.1 hu'.2 hg he.symm),
      fun he=>hv'.2 (TwoHubUnequal.leaf_unique sp G hu'.1 hu'.2 hg he.symm)⟩
  have sub : ({x,y,z,w}: Finset (Fin n)) ⊆ loose G.val a c := by
    intro v hv;simp only [mem_insert,mem_singleton] at hv
    rcases hv with rfl|rfl|rfl|rfl
    · exact loose_of hx hy hxy
    · exact loose_of hy hx hxy.symm
    · exact loose_of hz hw hzw
    · exact loose_of hw hz hzw.symm
  have h:=card_le_card sub
  obtain ⟨d1,d2,d3,d4,d5,d6⟩:=hd
  rw [TwoHubUnequal.loose_size sp] at h
  split_ifs at h <;> simp [d1,d2,d3,d4,d5,d6] at h

/-- Each nontrivial within-shape move is realized by exactly one unordered
transposition of the designated leaves, even when the two hub degrees differ. -/
theorem unique_horizontal (sp : Spec n r s d a c) (G H : GraphState n d)
    (same : G.val.Adj a c ↔ H.val.Adj a c) (step : SwitchStep n d G H) :
    ∃! e : Finset (Fin n),Witness a c G H e := by
  obtain ⟨p,hp,he⟩:=step
  have hn : p.1.val.Nonempty := card_pos.mp (by rw [p.1.2];decide)
  obtain ⟨x,hx⟩ := hn
  obtain ⟨z,hxz,_⟩ := (p.2.val.2.property x).1 hx
  obtain ⟨y,w,hd,hxy,hzw,hyw,hp4⟩ := gains_normal hp hxz
  have hr₁ : (removedMatching p).Adj x y := by rw [hp4];simp
  have hr₂ : (removedMatching p).Adj z w := by rw [hp4];simp
  have ht₂ : (addedMatching p).Adj y w := by rw [hp4];simp
  have c₁ := (removedMatching_adj_iff hp _ _).mp hr₁
  have c₂ := (removedMatching_adj_iff hp _ _).mp hr₂
  have c₃ := (addedMatching_adj_iff hp _ _).mp hxz
  have c₄ := (addedMatching_adj_iff hp _ _).mp ht₂
  rw [he] at c₁ c₂ c₃ c₄
  have hit (u v : Fin n) (diff : ¬(G.val.Adj u v ↔ H.val.Adj u v)) : u∈leaves a c ∨ v∈leaves a c := by
    by_contra! hn'
    have hub_of (i : Fin n) (hi : i∉leaves a c) : i=a ∨ i=c := by by_contra! hn;exact hi ((mem_leaves _ _ _).mpr hn)
    rcases hub_of _ hn'.1 with rfl|rfl <;> rcases hub_of _ hn'.2 with rfl|rfl
    · exact diff (by simp)
    · exact diff same
    · exact diff ((G.val.adj_comm _ _).trans (same.trans (H.val.adj_comm _ _)))
    · exact diff (by simp)
  have h₁ := hit x y (fun e=>c₁.2 (e.mp c₁.1))
  have h₂ := hit z w (fun e=>c₂.2 (e.mp c₂.1))
  have h₃ := hit x z (fun e=>c₃.2 (e.mpr c₃.1))
  have h₄ := hit y w (fun e=>c₄.2 (e.mpr c₄.1))
  have al : (x∈leaves a c ∧ w∈leaves a c) ∨ (y∈leaves a c ∧ z∈leaves a c) := by tauto
  have hwit (i j : Fin n) (hi : i∈leaves a c) (hj : j∈leaves a c)
      (ord : (i=x ∧ j=w) ∨ (i=y ∧ j=z)) : Witness a c G H {i,j} := by
    have dg {v} (hv : v∈leaves a c) := sp.leaf v ((mem_leaves _ _ _).mp hv).1 ((mem_leaves _ _ _).mp hv).2
    refine ⟨i,hi,j,hj,rfl,?_⟩
    rw [realize_diagonal G hd hxy hzw c₃.2 hyw i j (dg hi) (dg hj) ord,←hp4,he]
  have anyW {e} (we : Witness a c G H e) : (e={x,w} ∨ e={y,z}) ∧ e⊆leaves a c := by
    obtain ⟨i,hi,j,hj,rfl,hJ⟩:=we
    exact ⟨only_diagonals hd c₁ c₂ c₃ c₄ hJ,by intro v hv;rcases mem_insert.mp hv with rfl|hv;exact hi;exact (mem_singleton.mp hv) ▸ hj⟩
  rcases al with ⟨hx,hw⟩|⟨hy,hz⟩
  · refine ⟨{x,w},hwit x w hx hw (Or.inl ⟨rfl,rfl⟩),?_⟩
    intro e he;obtain ⟨h,sub⟩:=anyW he
    rcases h with h|rfl
    · exact h
    · exact (no_four_leaves sp G hd hxy hzw hx (sub (by simp)) (sub (by simp)) hw).elim
  · refine ⟨{y,z},hwit y z hy hz (Or.inr ⟨rfl,rfl⟩),?_⟩
    intro e he;obtain ⟨h,sub⟩:=anyW he
    rcases h with rfl|h
    · exact (no_four_leaves sp G hd hxy hzw (sub (by simp)) hy hz (sub (by simp))).elim
    · exact h

#print axioms unique_horizontal
end
end TwoHubHorizontal
