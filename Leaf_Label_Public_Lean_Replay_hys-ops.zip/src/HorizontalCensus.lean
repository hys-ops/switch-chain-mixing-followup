import PhysicalReduction
open Finset OAI.Problem315 TwoHub TwoHubUnequal TwoHubHorizontal GraphGray PaintMix HubTransfer
open scoped Matrix Classical
noncomputable section
namespace SharpClock
variable {n r s : ℕ} {d : Fin n→ℕ} {a c : Fin n}
def flag {X : Type*} [DecidableEq X] (u v : X) : ℝ := if u=v then 1 else 0

theorem total_colors {V : Type*} [Fintype V] (x: V→Option Bool) :
    (∑ i,flag (x i) none)+(∑ i,flag (x i) (some false))+(∑ i,flag (x i) (some true))=Fintype.card V := by
  simp only [←sum_add_distrib]
  calc _ = ∑ _i:V,(1:ℝ) := by
         apply sum_congr rfl;intro i _;rcases x i with _|b
         · norm_num [flag]
         · cases b <;> norm_num [flag]
       _ = _ := by simp

theorem unequal_pairs {V : Type*} [Fintype V] (x : V→Option Bool) :
    (∑ i,∑ j, (if x i=x j then (0:ℝ) else 1)) =
      (Fintype.card V:ℝ)^2-(∑ i,flag (x i) none)^2-(∑ i,flag (x i) (some false))^2-
        (∑ i,flag (x i) (some true))^2 := by
  have eqc (i j: V) : (if x i=x j then (0:ℝ) else 1)=1-
    flag (x i) none*flag (x j) none-flag (x i) (some false)*flag (x j) (some false)-
    flag (x i) (some true)*flag (x j) (some true) := by
    cases x i with
    | none => cases x j with
              | none =>norm_num [flag]
              | some b=>cases b <;> norm_num [flag]
    | some a => cases x j with
                | none=>cases a <;> norm_num [flag]
                | some b=>cases a <;> cases b <;> norm_num [flag]
  simp_rw [eqc,Finset.sum_sub_distrib,←Finset.mul_sum,←Finset.sum_mul]
  simp [pow_two,nsmul_eq_mul]

theorem red_count (sp : Spec n r s d a c) (G : GraphState n d) :
    (∑ i:Label a c,flag (code a c G i) none)+ (if G.val.Adj a c then 1 else 0)=r := by
  let red:Finset (Label a c):=univ.filter (fun x=>code a c G x=none)
  have hs : red.map (Function.Embedding.subtype (fun z => z∈leaves a c)) = star G.1 a c := by
    ext v;constructor
    · intro hv;obtain ⟨x,hx,rfl⟩:=mem_map.mp hv
      exact (mem_star _ _ _ _).mpr ⟨(mem_leaves _ _ _).mp x.2,(red_code G x).mp (mem_filter.mp hx).2⟩
    · intro hv;obtain ⟨hv,ha⟩:=(mem_star _ _ _ _).mp hv
      let x : Label a c := ⟨v,(mem_leaves _ _ _).mpr hv⟩
      exact mem_map.mpr ⟨x,mem_filter.mpr ⟨mem_univ _,(red_code G x).mpr ha⟩,rfl⟩
  have hsize := (star_size G.1 a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
  have hcard : red.card=(star G.1 a c).card := by rw [←hs,card_map]
  have he : (∑ i:Label a c,flag (code a c G i) none)=(red.card:ℝ) := by simp [red,flag]
  rw [he,hcard];split_ifs with h <;> simp [h] at hsize ⊢ <;> exact_mod_cast hsize

theorem gray_count (sp : Spec n r s d a c) (G : GraphState n d) :
    (∑ i:Label a c,flag (code a c G i) (some true))=if G.val.Adj a c then 2 else 0 := by
  have hs := congrArg Finset.card (loose_map (a:=a) (c:=c) G)
  rw [card_map,loose_size sp G] at hs
  have he : (∑ i:Label a c,flag (code a c G i) (some true))=((PaintMix.gray (code a c G)).card:ℝ) := by
    simp [PaintMix.gray,flag]
  rw [he];split_ifs with h
  · rw [ite_eq_left h] at hs;exact_mod_cast hs
  · rw [ite_eq_right h] at hs;exact_mod_cast hs

theorem horizontal_sharp (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) : 1-GraphSplit.H d a c G G ≤ 3*((r:ℝ)*s)/(2*clock n) := by
  let x:=code a c G
  let f:=fun y : Paint (Label a c) => if y=x then (0:ℝ) else 1
  have h := graph_paint_lift sp hn f G
  rw [paint_derivative _ (clock_pos hn)] at h
  have hid : ((GraphSplit.H d a c) *ᵥ(f ∘ code a c)) G=1-GraphSplit.H d a c G G := by
    let H:=GraphSplit.H d a c
    have hh := (LeafSplit.h_stoch (GraphSplit.isEdge a c) (GraphSplit.chain d) (GraphSplit.physical_stochastic hn)).2 G
    have ef(y) : (f ∘ code a c) y = 1-(1:Matrix (GraphState n d) (GraphState n d) ℝ) y G := by
      simp [f,x,Matrix.one_apply,(code_injective sp).eq_iff];split <;> norm_num
    change (∑ y,H G y*(f ∘ code a c) y)=_
    simp_rw [ef,mul_sub,mul_one,Finset.sum_sub_distrib]
    rw [show (∑ y,H G y)=1 from hh]
    change 1-(H*(1:Matrix (GraphState n d) (GraphState n d) ℝ)) G G=_
    rw [Matrix.mul_one]
  rw [hid] at h
  have he (i j:Label a c) : move x i j=x ↔ x i=x j := by
    constructor
    · intro ht;have hz:=congrFun ht i;simpa [move] using hz.symm
    · intro h;exact funext (Equiv.apply_swap_eq_self h)
  change 1-GraphSplit.H d a c G G=f x+(∑ i,∑ j,(f (move x i j)-f x))/(2*clock n) at h
  simp only [f,ite_true,sub_zero,zero_add,he] at h
  rw [h]
  apply div_le_div_of_nonneg_right _ (by have:=clock_pos hn;positivity)
  rw [unequal_pairs,GraphGray.label_card sp,Nat.cast_add]
  have H1:=red_count sp G
  have H2:=gray_count sp G
  have H3:=total_colors x
  rw [GraphGray.label_card sp,Nat.cast_add] at H3
  change (∑ i,flag (x i) none)+_= _ at H1
  change (∑ i,flag (x i) (some true))=_ at H2
  have a1:(2:ℝ)≤r:=by exact_mod_cast hr
  have a2:(2:ℝ)≤s:=by exact_mod_cast hs
  by_cases hh:G.val.Adj a c
  · rw [ite_eq_left hh] at H1 H2
    have w : (∑ i,flag (x i) (some false))=(s:ℝ)-1 := by linarith
    have v : (∑ i,flag (x i) none)=(r:ℝ)-1 := by linarith
    rw [v,w,H2];nlinarith [mul_nonneg (sub_nonneg.mpr a1) (sub_nonneg.mpr a2)]
  · rw [ite_eq_right hh,add_zero] at H1
    rw [ite_eq_right hh] at H2
    have w : (∑ i,flag (x i) (some false))=(s:ℝ) := by linarith
    rw [H1,w,H2];nlinarith [mul_nonneg (by positivity : 0≤(r:ℝ)) (by positivity : 0≤(s:ℝ))]
#print axioms horizontal_sharp
end SharpClock
