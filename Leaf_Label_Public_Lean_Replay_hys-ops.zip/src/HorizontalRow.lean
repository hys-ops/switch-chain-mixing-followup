import Horizontal
import LeafLabels
import ShapeLaw
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub TwoHubUnequal Finset LeafLower.Labels
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}
abbrev Label (a c : Fin n) := ↥(leaves a c)

def permute (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (i j : Label a c) : GraphState n d :=
  swapLabels i.val j.val ((sp.leaf _ ((mem_leaves _ _ _).mp i.2).1 ((mem_leaves _ _ _).mp i.2).2).trans
    (sp.leaf _ ((mem_leaves _ _ _).mp j.2).1 ((mem_leaves _ _ _).mp j.2).2).symm) G

theorem permute_self (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (i : Label a c) : permute sp G i i=G := by
  apply Subtype.ext;change G.val.comap (Equiv.swap i.val i.val)=G.val;ext;simp

theorem permute_comm (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (i j : Label a c) : permute sp G i j=permute sp G j i := by
  apply Subtype.ext;change G.val.comap (Equiv.swap i.val j.val)=G.val.comap (Equiv.swap j.val i.val);rw [Equiv.swap_comm]

theorem shape_permute (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (i j : Label a c) :
    (permute sp G i j).val.Adj a c ↔ G.val.Adj a c := by
  have hi := (mem_leaves _ _ _).mp i.2; have hj := (mem_leaves _ _ _).mp j.2
  change G.val.Adj (Equiv.swap i.val j.val a) (Equiv.swap i.val j.val c) ↔ _
  rw [Equiv.swap_apply_of_ne_of_ne hi.1.symm hj.1.symm,Equiv.swap_apply_of_ne_of_ne hi.2.symm hj.2.symm]

theorem permute_step (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (i j : Label a c) (hm : permute sp G i j≠G) :
    SwitchStep n d G (permute sp G i j) := by
  have hi := (mem_leaves _ _ _).mp i.2; have hj := (mem_leaves _ _ _).mp j.2
  rcases leaf_swap G i.val j.val (sp.leaf _ hi.1 hi.2) (sp.leaf _ hj.1 hj.2) with he|he
  · exact (hm (Subtype.ext he)).elim
  · exact he

/-- A labeled neighbor has exactly two ordered swap generators if nontrivially
reachable horizontally, and zero otherwise. -/
theorem ordered_count (sp : TwoHubUnequal.Spec n r s d a c) (G H : GraphState n d) (diff : G≠H) :
  (∑ i:Label a c,∑ j:Label a c,if permute sp G i j=H then (1:ℝ) else 0)=
    if (G.val.Adj a c ↔ H.val.Adj a c) ∧ SwitchStep n d G H then 2 else 0 := by
  classical
  split_ifs with edge
  · obtain ⟨e,⟨i,hi,j,hj,rfl,he⟩,unq⟩:=unique_horizontal sp G H edge.1 edge.2
    let u : Label a c := ⟨i,hi⟩
    let v : Label a c := ⟨j,hj⟩
    have ht : permute sp G u v=H := Subtype.ext he
    have huv : u≠v := by intro hh;rw [hh,permute_self] at ht;exact diff ht
    have equiv (p q : Label a c) : permute sp G p q=H ↔ (p=u ∧ q=v) ∨ (p=v ∧ q=u) := by
      constructor
      · intro eq
        have hpair := unq {p.val,q.val} ⟨p.val,p.2,q.val,q.2,rfl,congrArg Subtype.val eq⟩
        have hs : ({p.val,q.val}:Set (Fin n))={u.val,v.val} := by
          simpa only [coe_pair] using congrArg (fun l : Finset (Fin n) => (l:Set (Fin n))) hpair
        rcases Set.pair_eq_pair_iff.mp hs with h|h
        · exact Or.inl ⟨Subtype.ext h.1,Subtype.ext h.2⟩
        · exact Or.inr ⟨Subtype.ext h.1,Subtype.ext h.2⟩
      · rintro (⟨rfl,rfl⟩|⟨rfl,rfl⟩)
        · exact ht
        · rw [permute_comm];exact ht
    have eqind (p q : Label a c) : (if permute sp G p q=H then (1:ℝ) else 0)=
       (if p=u then (if q=v then 1 else 0) else 0)+(if p=v then (if q=u then 1 else 0) else 0) := by
      rw [if_congr (equiv p q) rfl rfl];split_ifs <;> simp_all
    simp only [eqind,sum_add_distrib]
    simp [Finset.sum_ite_irrel];norm_num
  · have none (i j : Label a c) : permute sp G i j≠H := by
      intro he;subst H;exact edge ⟨(shape_permute sp G i j).symm,permute_step sp G i j diff.symm⟩
    simp [none]

/-- Exact horizontal part of the actual row, tested on any observable vanishing at G. -/
theorem horizontal_row (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d)
    (f : GraphState n d → ℝ) (hf : f G=0) :
    (∑ H : GraphState n d,if (G.val.Adj a c ↔ H.val.Adj a c) then switchKernel n d G H*f H else 0)
      =(∑ i:Label a c,∑ j:Label a c,f (permute sp G i j))/(2*clock n) := by
  classical
  have one (H : GraphState n d) :
      (if (G.val.Adj a c ↔ H.val.Adj a c) then switchKernel n d G H*f H else 0)=
        (∑ i:Label a c,∑ j:Label a c,if permute sp G i j=H then f H else 0)/(2*clock n) := by
    by_cases hh : G=H
    · subst H;simp [hf]
    have hsum : (∑ i:Label a c,∑ j:Label a c,if permute sp G i j=H then f H else 0)=
        (∑ i:Label a c,∑ j:Label a c,if permute sp G i j=H then (1:ℝ) else 0)*f H := by
      simp only [sum_mul,ite_mul,one_mul,zero_mul]
    rw [hsum,ordered_count sp G H hh,switchKernel_of_ne hh]
    unfold clock;by_cases h₁ : G.val.Adj a c ↔ H.val.Adj a c <;> by_cases h₂ : SwitchStep n d G H <;> simp [h₁,h₂] <;> ring
  rw [sum_congr rfl (fun H _=>one H),←Finset.sum_div]
  congr 1
  rw [sum_comm]
  apply sum_congr rfl;intro i _;rw [sum_comm]
  apply sum_congr rfl;intro j _;simp

#print axioms ordered_count
#print axioms horizontal_row
end
end TwoHubHorizontal
