import Physical
import Family
import LeafShuffleTV
import ShuffleTV
open scoped BigOperators Matrix
open LeafLower.Star Finset OAI.Problem315 HubTransfer OAI.Problem315.LeafOrbit OAI.Problem315.LeafTransfer
noncomputable section
namespace LeafResult
def hubs (h r : ℕ) := (L h r)ᶜ
theorem card_hubs (h r : ℕ) : (hubs h r).card=h := by
  classical
  have z := (L h r).card_compl_add_card
  rw [card_L,Fintype.card_fin] at z
  change (L h r)ᶜ.card=h
  unfold n at z
  exact Nat.add_right_cancel z
theorem spec (h r : ℕ) : ManyCore.Spec (hubs h r) r (deg h r) := by
  constructor
  · intro v hv
    obtain ⟨z,rfl⟩ := (code h r).surjective v
    cases z with
    | inl i => exact hub_degree i
    | inr j =>
      have hm : code h r (.inr j) ∈ L h r := mem_map.mpr ⟨j,mem_univ _,rfl⟩
      exact False.elim (mem_compl.mp hv hm)
  · intro v hv
    exact leaf_degree (by simpa [hubs] using hv)
  · rw [card_hubs]
    change ((L h r)ᶜ)ᶜ.card=h*r
    rw [compl_compl,card_L]
theorem leaf_eq {h r : ℕ} (hr:1<r) : leaves (deg h r)=L h r := by
  ext v
  simp only [leaves,mem_filter,mem_univ,true_and]
  constructor
  · intro hd
    by_contra hv
    have hh := (spec h r).hub v (mem_compl.mpr hv)
    omega
  · exact leaf_degree
def clock (v:ℕ) := ⌈1024*(v:ℝ)^3*(1+Real.log v)⌉₊
theorem leaf_error {h:ℕ} (hh:2≤h) :
    let v := n h (h^4)
    let d := deg h (h^4)
    let t := clock v
    (∑ k∈Finset.range (t+1), weight t k (iidClock d)*
      tv (((LeafMark.shuffle (LeafLabel d))^k) 1) (unif (LeafGroup d))) ≤ 1/32 := by
  dsimp only
  let v := n h (h^4)
  let d := deg h (h^4)
  let N := h*h^4
  have hr : 1<h^4 := lt_of_lt_of_le hh (Nat.le_self_pow (by decide) _)
  have hN : 0<N := by dsimp [N]; positivity
  have hn : 4≤v := by
    dsimp [v,n]; have : 2≤h^4 := hr; nlinarith
  have hL : (leaves d).card=N := by rw [leaf_eq hr,card_L]
  have hC : Fintype.card (LeafLabel d)=N := by simpa [LeafLabel] using hL
  haveI : Nonempty (LeafLabel d) := Fintype.card_pos_iff.mp (hC ▸ hN)
  have hQ : 0 < (12*(v.choose 4:ℝ)) := by
    have := Nat.choose_pos hn; positivity
  have hQ' : 12*(v.choose 4:ℝ)≤(v:ℝ)^4 := by
    have z := Nat.choose_le_pow_div (α:=ℝ) 4 v
    norm_num [Nat.factorial] at z; linarith [pow_nonneg (Nat.cast_nonneg (α:=ℝ) v) 4]
  have hvr : 0<(v:ℝ) := by exact_mod_cast (show 0<v by omega)
  have hNr : 0<(N:ℝ) := by exact_mod_cast hN
  have hNv : (N:ℝ) ≤ v := by exact_mod_cast (show N≤v by dsimp [N,v,n];omega)
  have hv2 : (v:ℝ)≤2*N := by
    exact_mod_cast (show v≤2*N by dsimp [v,N,n]; nlinarith [Nat.mul_le_mul_left h (show 1≤h^4 by omega)])
  have hp : 0 < iidClock d := by unfold iidClock; rw [hL]; positivity
  have hpl : iidClock d≤1 := (iid_leaf_weight_bound (d:=d) hn).trans (by norm_num)
  apply (LeafMark.thinned_shuffle (clock v) (1:LeafGroup d) hp hpl).trans
  rw [hC]
  apply (div_le_iff₀ (by positivity)).2
  have ht := Nat.le_ceil (1024*(v:ℝ)^3*(1+Real.log v))
  have hlog := Real.log_le_log hNr hNv
  have hlog0 : 0≤Real.log (v:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤v by omega))
  have hclock : (clock v:ℝ)+1≥1024*(v:ℝ)^3*(1+Real.log v) := by
    change (⌈_⌉₊:ℝ)+1≥_; linarith
  have hra : 1≤(N:ℝ) := by exact_mod_cast hN
  unfold iidClock; rw [hL]
  change 2*(N:ℝ)*(1+Real.log N) ≤ 1/32*(((clock v:ℝ)+1)*((N:ℝ)^2/(4*(12*(v.choose 4:ℝ)))))
  rw [← mul_div_assoc,← mul_div_assoc]
  apply (le_div_iff₀ (by positivity)).2
  have prod1 := mul_le_mul_of_nonneg_left hlog hNr.le
  have p1 := mul_le_mul_of_nonneg_right hQ' (show 0≤256*(N:ℝ)*(1+Real.log v) by positivity)
  have p2 := mul_le_mul_of_nonneg_right hv2 (show 0≤256*(v:ℝ)^3*(N:ℝ)*(1+Real.log v) by positivity)
  have p3 := mul_le_mul_of_nonneg_right hclock (sq_nonneg (N:ℝ))
  nlinarith [mul_le_mul_of_nonneg_right prod1 (show 0≤256*(12*(v.choose 4:ℝ)) by positivity),
    mul_nonneg (sq_nonneg (N:ℝ)) (show 0≤512*(v:ℝ)^3*(1+Real.log v) by positivity)]
#print axioms spec
#print axioms leaf_error
end LeafResult
