import Falling
import SparseDiscrete
open Finset SparseUrn
namespace CriticalUrn
noncomputable section

def load (N:ℝ) (k:ℕ) := (k:ℝ)^2/N
def allowance (N a:ℝ) (k:ℕ) := (2*k:ℝ)/N+((k:ℝ)^2+load N k*k+(load N k)^2)*a

/-- The probability of exactly one success in x Bernoulli trials is at most one. -/
lemma one_success {q:ℝ} (hq : 0≤q) (hq1 : q≤1) (x:ℕ) :
    (x:ℝ)*(1-q)*q^(x-1) ≤ 1-q^x := by
  induction x with
  | zero => simp
  | succ x ih =>
    cases x with
    | zero => simp
    | succ x =>
      simp only [Nat.succ_sub_one, Nat.cast_succ, pow_succ] at ih ⊢
      have h := mul_nonneg (sub_nonneg.mpr hq1) (sub_nonneg.mpr (pow_le_one₀ hq hq1 (n:=x+1)))
      rw [pow_succ] at h
      nlinarith only [mul_le_mul_of_nonneg_right ih hq,h]

lemma discrepancy_id {N q : ℝ} (hN : N≠0) (k x:ℕ) :
    generator N k (fun j=>q^j) x =
    (x:ℝ)*(1-q)*q^(x-1) - load N k*(1-q)*q^x -
     ((x:ℝ)*(2*k-x)/N)*(1-q)^2*q^(x-1) := by
  unfold generator birth death load
  cases x with
  | zero => simp;ring
  | succ j => simp only [Nat.cast_succ,Nat.succ_sub_one,pow_succ];field_simp;ring

lemma residual {N q : ℝ} {k x:ℕ} (hN : 0<N) (hx : x≤k) (hq : 0≤q) (hq1 : q≤1) :
    0 ≤ ((x:ℝ)*(2*k-x)/N)*(1-q)^2*q^(x-1) ∧
    ((x:ℝ)*(2*k-x)/N)*(1-q)^2*q^(x-1) ≤ (2*k/N)*(1-q) := by
  have hx' : (x:ℝ)≤k := by exact_mod_cast hx
  have hdiff : 0≤2*(k:ℝ)-x := by linarith [Nat.cast_nonneg (α:=ℝ) k]
  have hz := one_success hq hq1 x
  have ha := pow_nonneg hq x
  have hb : (x:ℝ)*(1-q)*q^(x-1)≤1 := by linarith
  have H := mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left hb hdiff) (sub_nonneg.mpr hq1)
  have H' := mul_nonneg (Nat.cast_nonneg (α:=ℝ) x) (sub_nonneg.mpr hq1)
  constructor
  · positivity
  · field_simp
    nlinarith only [H,H']

lemma exp_remainder {y:ℝ} (hy : 0≤y) :
    0≤Real.exp (-y)-(1-y) ∧ Real.exp (-y)-(1-y)≤y^2 := by
  have a := Real.add_one_le_exp (-y)
  have h : Real.exp (-y)≤1/(1+y) := by
    rw [Real.exp_neg,inv_eq_one_div]
    apply one_div_le_one_div_of_le (by linarith)
    linarith [Real.add_one_le_exp y]
  have b : 1/(1+y)≤(1-y)+y^2 := by
    rw [div_le_iff₀ (by linarith : 0<1+y)];nlinarith [show 0≤y^3 by positivity]
  constructor <;> linarith

lemma power_increment {a b:ℝ} (ha : 0≤a) (hb : 0≤b) (hc : a+b≤1) (x:ℕ) :
    0≤(a+b)^x-a^x ∧ (a+b)^x-a^x ≤ x*b := by
  induction x with
  | zero => simp
  | succ x ih =>
    have old := mul_le_mul_of_nonneg_right ih.2 ha
    have prev := mul_nonneg (sub_nonneg.mpr (show a≤1 by linarith)) (mul_nonneg (Nat.cast_nonneg (α:=ℝ) x) hb)
    have other := mul_le_mul_of_nonneg_right (pow_le_one₀ (add_nonneg ha hb) hc (n:=x)) hb
    rw [pow_succ,pow_succ,Nat.cast_succ]
    constructor <;> nlinarith [mul_nonneg ih.1 ha,mul_nonneg (pow_nonneg (add_nonneg ha hb) x) hb]

/-- The compensated discrete overlap kernel has the immigration–death generating function to
a summable error even when k²/N tends to a positive constant. -/
theorem single {k x:ℕ} {N a q:ℝ} (hx : x≤k) (hN : 0<N) (ha : 0≤a) (ha1 : a≤1)
    (hq : 0≤q) (hq1 : q≤1) :
    |Real.exp (-load N k*(a*(1-q)))*(q+a*(1-q))^x -
       (q^x+a*generator N k (fun j=>q^j) x)| ≤ allowance N a k*(a*(1-q)) := by
  let b := a*(1-q)
  let m := load N k
  let R := ((x:ℝ)*(2*k-x)/N)*(1-q)^2*q^(x-1)
  have hb : 0≤b := mul_nonneg ha (sub_nonneg.mpr hq1)
  have hb' : q+b≤1 := by dsimp [b];nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hq1)]
  have hba : b≤a := by dsimp [b];nlinarith [mul_nonneg ha hq]
  have hm : 0≤m := div_nonneg (sq_nonneg _) hN.le
  have hr := residual hN hx hq hq1
  change 0≤R ∧ R≤2*k/N*(1-q) at hr
  have h0 := discrepancy_id hN.ne' k x (q:=q)
  change generator N k (fun j=>q^j) x=(x:ℝ)*(1-q)*q^(x-1)-m*(1-q)*q^x-R at h0
  have v : 0≤(q+b)^x := pow_nonneg (add_nonneg hq hb) x
  have v' : (q+b)^x≤1 := pow_le_one₀ (add_nonneg hq hb) hb' (n:=x)
  have hrem := exp_remainder (mul_nonneg hm hb)
  let e := Real.exp (-(m*b))-(1-m*b)
  change 0≤e ∧ e≤(m*b)^2 at hrem
  have he := mul_le_mul hrem.2 v' v (by positivity)
  have de := power_increment hq hb hb' x
  have dx : (x:ℝ)≤k := by exact_mod_cast hx
  have tx := second_order hq hb hb' x
  change 0≤(q+b)^x-q^x-(x:ℝ)*b*q^(x-1) ∧ _ at tx
  change _ ∧ (q+b)^x-q^x-(x:ℝ)*b*q^(x-1)≤(x:ℝ)^2*b^2 at tx
  have sexp : Real.exp (-m*b)=(1-m*b)+e := by dsimp [e];rw [neg_mul];ring
  change |Real.exp (-m*b)*(q+b)^x - _| ≤ allowance N a k*b
  rw [sexp,h0,abs_le]
  have hxupper : (x:ℝ)^2*b^2≤(k:ℝ)^2*a*b := by
    calc _ ≤ (k:ℝ)^2*b^2 := by gcongr
         _ ≤ _ := by nlinarith [mul_nonneg (sq_nonneg (k:ℝ)) (mul_nonneg hb (sub_nonneg.mpr hba))]
  have cross := mul_le_mul_of_nonneg_left ((de.2).trans (mul_le_mul_of_nonneg_right dx hb)) (mul_nonneg hm hb)
  have cross0 := mul_nonneg (mul_nonneg hm hb) de.1
  have small (C:ℝ) (h:0≤C) : C*b^2≤C*a*b := by nlinarith [mul_nonneg h (mul_nonneg hb (sub_nonneg.mpr hba))]
  have hit := mul_le_mul_of_nonneg_left hr.2 ha
  have hit' : a*R≤2*k/N*b := by dsimp [b];nlinarith only [hit]
  have pos := mul_nonneg ha hr.1
  have bound₀ : 0≤2*k/N*b := by positivity
  have b1 : 0≤(k:ℝ)^2*a*b := by positivity
  have b2 : 0≤m*k*a*b := by positivity
  have b3 : 0≤m^2*a*b := by positivity
  unfold allowance
  change _ ∧ _ ≤ (2*k/N+((k:ℝ)^2+m*k+m^2)*a)*b
  have eq : (x:ℝ)*b*q^(x-1)=a*((x:ℝ)*(1-q)*q^(x-1)) := by dsimp [b];ring
  have eq2 : m*b*q^x=a*(m*(1-q)*q^x) := by dsimp [b];ring
  constructor <;> nlinarith only [tx.1,tx.2,hxupper,eq,eq2,mul_nonneg hrem.1 v, he, cross,cross0,small (m*k) (by positivity),small (m^2) (sq_nonneg _),hit',pos,bound₀,b1,b2,b3]
#print axioms single
end
end CriticalUrn
