import GraphSplit
import JohnsonIncidence
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

/-- Original first entrance only charges vertices obtained from a valid crossing port. -/
theorem incident_port {G J : GraphState n d} (hh : ¬G.val.Adj a c) (hU : GraphSplit.U a c G J ≠0) :
    J.val.Adj a c ∧ ∃ w : Ports G.val a c, TwoHubUnequal.crossingState G w=J := by
  have hJ : J.val.Adj a c := by
    by_contra hj;apply hU
    simp [GraphSplit.U,LeafSplit.incident,LeafSplit.cross,GraphSplit.isEdge,hh,hj]
  have hne : G≠J := by intro e;exact hh (e ▸ hJ)
  have hrow : switchKernel n d G J≠0 := by
    intro e;apply hU
    simp [GraphSplit.U,LeafSplit.incident,LeafSplit.cross,GraphSplit.isEdge,GraphSplit.chain,hh,hJ,e]
  have hs : SwitchStep n d G J := by
    by_contra no;rw [switchKernel_of_ne hne,ite_eq_right no] at hrow;exact hrow rfl
  exact ⟨hJ,((TwoHubUnequal.crossing_bijection G hh).2 J hJ).mp hs⟩

/-- Every joined graph charged by the actual first entrance law still contains
all original small-hub neighbors among its marked neighbors and loose pair. -/
theorem incident_initial_marks (sp : TwoHubUnequal.Spec n r s d a c) (G J : GraphState n d)
    (hh : ¬G.val.Adj a c) (hU : GraphSplit.U a c G J ≠0) :
    J.val.Adj a c ∧ star G.val a c ⊆ star J.val a c ∪ loose J.val a c := by
  obtain ⟨hJ,w,rfl⟩ := incident_port hh hU
  obtain ⟨he,hl,_,_⟩:=TwoHubUnequal.johnson_incidence sp G hh w
  refine ⟨hJ,?_⟩
  rw [he,hl]
  intro z hz;by_cases e : z=w.val.1
  · exact mem_union_right _ (mem_insert.mpr (Or.inl e))
  · exact mem_union_left _ (mem_erase.mpr ⟨e,hz⟩)

#print axioms incident_initial_marks
end
end TwoHubHorizontal
