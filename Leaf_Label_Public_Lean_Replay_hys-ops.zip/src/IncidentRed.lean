import RedProjection
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset JohnsonLower HubMarks
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

theorem incident_red_erase (sp : TwoHubUnequal.Spec n r s d a c) (G J : GraphState n d)
    (hh : ¬G.val.Adj a c) (hU : GraphSplit.U a c G J≠0) :
    ∃ x : Label a c, markCode sp x ∈ markLabels sp (star G.val a c) ∧
      (redProjection sp J).val = (markLabels sp (star G.val a c)).erase (markCode sp x) := by
  obtain ⟨hJ,w,rfl⟩:=incident_port hh hU
  let x : Label a c:=⟨w.1.1,(mem_leaves _ _ _).mpr ⟨w.2.1.1.symm,w.2.1.2.2.2.1⟩⟩
  have hStar : x.val∈star G.val a c := (mem_star _ _ _ _).mpr ⟨(mem_leaves _ _ _).mp x.2,w.2.2.1⟩
  refine ⟨x,(mem_markLabels sp _ x).mpr hStar,?_⟩
  have hs := (TwoHubUnequal.johnson_incidence sp G hh w).1
  ext z;obtain ⟨y,rfl⟩:=(markCode sp).surjective z
  simp only [redProjection,dite_eq_left hJ,hs,mem_markLabels,mem_erase]
  exact and_congr_left fun _=> by
    change (y.val≠x.val) ↔ markCode sp y≠markCode sp x
    simp only [(markCode sp).injective.ne_iff,Subtype.coe_ne_coe]

theorem incident_red_swap (sp : TwoHubUnequal.Spec n r s d a c) (G J L : GraphState n d)
    (hh : ¬G.val.Adj a c) (hJ : GraphSplit.U a c G J≠0) (hL : GraphSplit.U a c G L≠0) :
    ∃ i j : Fin (r+s), redProjection sp L=swapSet (redProjection sp J) i j := by
  obtain ⟨x,hx,hS⟩:=incident_red_erase sp G J hh hJ
  obtain ⟨y,hy,hT⟩:=incident_red_erase sp G L hh hL
  let i:= markCode sp x;let j:=markCode sp y
  refine ⟨i,j,Subtype.ext ?_⟩
  ext q;change _ ↔ q∈Finset.map (Equiv.swap i j).toEmbedding _
  rw [mem_map_equiv,Equiv.symm_swap,hS,hT]
  change q∈(markLabels sp (star G.val a c)).erase j ↔ Equiv.swap i j q∈(markLabels sp (star G.val a c)).erase i
  change i∈_ at hx; change j∈_ at hy
  by_cases h : i=j
  · rw [h];simp
  by_cases he : q=i
  · subst q;rw [Equiv.swap_apply_left];simp [h,Ne.symm h,hx,hy]
  by_cases he' : q=j
  · subst q;rw [Equiv.swap_apply_right];simp
  rw [Equiv.swap_apply_of_ne_of_ne he he'];simp [he,he']

#print axioms incident_red_swap
end
end TwoHubHorizontal
