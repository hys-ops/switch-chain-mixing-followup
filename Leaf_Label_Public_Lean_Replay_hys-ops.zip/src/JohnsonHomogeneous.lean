import SwapRow
import OAI.Probability.SwitchChain.SlicePermutationAction
open Finset HubTransfer JohnsonLower HubMarks OAI.Problem315.SlicePermutationAction
open scoped Matrix
namespace JohnsonProfile
noncomputable section
variable {N k : ℕ}
lemma relabel_swap (σ : Equiv.Perm (Fin N)) (S : JohnsonLower.Slice N k) (i j : Fin N) :
    relabel σ (swapSet S i j)=swapSet (relabel σ S) (σ i) (σ j) := by
  apply Subtype.ext
  change (S.val.map _).map _ = (S.val.map _).map _
  rw [map_map,map_map];congr 1
  apply Function.Embedding.ext;intro x
  change σ (Equiv.swap i j x)=Equiv.swap (σ i) (σ j) (σ x)
  by_cases h : x=i
  · subst x;simp
  by_cases hj : x=j
  · subst x;simp
  rw [Equiv.swap_apply_of_ne_of_ne h hj,Equiv.swap_apply_of_ne_of_ne (mt σ.injective.eq_iff.mp h) (mt σ.injective.eq_iff.mp hj)]

theorem kernel_relabel {Q : ℝ} (hQ : Q≠0) (σ : Equiv.Perm (Fin N)) (S T : JohnsonLower.Slice N k) (t : ℕ) :
    ((walk N k Q)^t) (relabel σ S) (relabel σ T)=((walk N k Q)^t) S T := by
  let A:=relabelEquiv (q:=k) σ
  have row (f : JohnsonLower.Slice N k→ℝ) (x : JohnsonLower.Slice N k) : (walk N k Q *ᵥ (f ∘ A)) x=(walk N k Q *ᵥ f) (A x) := by
    simp only [swap_row _ hQ,Function.comp_apply,A,relabelEquiv_apply,relabel_swap]
    congr 2;apply Fintype.sum_equiv σ _ _;intro i;apply Fintype.sum_equiv σ _ _;intro j;rfl
  let f : JohnsonLower.Slice N k→ℝ:=fun R=>if R=A T then 1 else 0
  have h:=closed_projection (fun _=>True) _ _ A (fun _ _ _ hy => (hy trivial).elim) (fun g x _=>row g x) t f S trivial
  have eq (R : JohnsonLower.Slice N k) : A R=A T ↔ R=T := A.injective.eq_iff
  have ee (V : JohnsonLower.Slice N k) (F : JohnsonLower.Slice N k→ℝ) :
     (∑ i,F i*(if i=V then (1:ℝ) else 0))=F V := by
    rw [sum_eq_single V]
    · simp
    · intro b _ hb;simp [hb]
    · simp
  change (∑ i, ((walk N k Q)^t) S i*(if A i=A T then (1:ℝ) else 0)) =
    ∑ i, ((walk N k Q)^t) (A S) i*(if i=A T then 1 else 0) at h
  simp only [eq,ee] at h
  exact h.symm

theorem tv_start_independent {Q : ℝ} (hQ : Q≠0) (S T : JohnsonLower.Slice N k) (t : ℕ) :
    tv (((walk N k Q)^t) S) (unif _) = tv (((walk N k Q)^t) T) (unif _) := by
  obtain ⟨σ,hs⟩:=exists_relabel_eq S T
  subst T
  have he:= Equiv.sum_comp (relabelEquiv (q:=k) σ) (fun W=>|((walk N k Q)^t) (relabel σ S) W-unif _ W|)
  unfold tv unif
  simp only [relabelEquiv_apply,kernel_relabel hQ,unif] at he
  rw [he]

#print axioms tv_start_independent
end
end JohnsonProfile
