import ShapeLaw
namespace TwoHubUnequal
open OAI.Problem315 Finset
open TwoHub (Ports Gains gainEquiv makePort star mem_star loose mem_loose)
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

/-- Perform a vertical move from a vertex using a pair in the two vertex stars. -/
def crossingState (G : GraphState n d) (w : Ports G.val a c) : GraphState n d :=
  fourVertexState G a w.val.1 c w.val.2 w.2.1

lemma crossing_adj (G : GraphState n d) (h : ¬G.val.Adj a c) (w : Ports G.val a c) :
    (crossingState G w).val.Adj a c := (makePort h w).2

theorem crossing_mass (G : GraphState n d) (h : ¬G.val.Adj a c) (w : Ports G.val a c) :
    switchKernel n d G (crossingState G w) = 1/clock n := by
  have hn : G ≠ crossingState G w := by
    intro he
    exact h (he ▸ crossing_adj G h w)
  have hstep : SwitchStep n d G (crossingState G w) :=
    switchStep_fourVertexState _ _ _ _ _ _ w.2.2.1 w.2.2.2.1 h w.2.2.2.2
  rw [switchKernel_of_ne hn,ite_eq_left hstep]
  rfl

/-- Every proposal between different shapes appears once and goes to its incident edge. -/
theorem crossing_bijection (G : GraphState n d) (h : ¬G.val.Adj a c) :
    Function.Injective (crossingState (a:=a) (c:=c) G) ∧
    ∀ H : GraphState n d, H.val.Adj a c → (SwitchStep n d G H ↔ ∃ w : Ports G.val a c, crossingState G w = H) := by
  constructor
  · intro w z he
    have hv (v : Ports G.val a c) : validSwitch G.val ((makePort h v).val) :=
      (validSwitch_fourVertexProposal_iff _ _ _ _ _ _).mpr ⟨v.2.2.1,v.2.2.2.1,h,v.2.2.2.2⟩
    apply (gainEquiv h).injective
    apply Subtype.ext
    exact proposalResult_injective_on_valid (hv w) (hv z) (congrArg Subtype.val he)
  · intro H hH
    constructor
    · rintro ⟨p,_,hp⟩
      let q : Gains G.val a c := ⟨p,hp ▸ hH⟩
      obtain ⟨w,hw⟩ := (gainEquiv h).surjective q
      refine ⟨w,Subtype.ext ?_⟩
      have hw' := congrArg Subtype.val hw
      change (fourVertexProposal a w.val.1 c w.val.2 _) = p at hw'
      change proposalResult G.val _ = H.val
      rwa [hw']
    · rintro ⟨w,rfl⟩
      exact switchStep_fourVertexState _ _ _ _ _ _ w.2.2.1 w.2.2.2.1 h w.2.2.2.2

/-- With old small-hub set S and chosen labels x,y the new small hub attaches to S minus x,
and the two loose labels are x,y.  Its two Johnson endpoints are S and (S minus x) plus y. -/
theorem johnson_incidence (sp : Spec n r s d a c) (G : GraphState n d)
    (h : ¬G.val.Adj a c) (w : Ports G.val a c) :
    star (crossingState G w).val a c = (star G.val a c).erase w.val.1 ∧
    loose (crossingState G w).val a c = {w.val.1,w.val.2} ∧
    insert w.val.1 (star (crossingState G w).val a c) = star G.val a c ∧
    insert w.val.2 (star (crossingState G w).val a c) =
      insert w.val.2 ((star G.val a c).erase w.val.1) := by
  obtain ⟨⟨x,y⟩,hd,hax,hcy,hxy⟩ := w
  let w : Ports G.val a c := ⟨(x,y),hd,hax,hcy,hxy⟩
  let H := crossingState G w
  change star H.val a c = (star G.val a c).erase x ∧ loose H.val a c = {x,y} ∧
       insert x (star H.val a c) = star G.val a c ∧
       insert y (star H.val a c) = insert y ((star G.val a c).erase x)
  have hx : x ∈ star G.val a c := (mem_star _ _ _ _).mpr ⟨⟨hd.1.symm,hd.2.2.2.1⟩,hax⟩
  have hs : star H.val a c = (star G.val a c).erase x := by
    ext z
    simp only [mem_star,mem_erase]
    change _ ∧ (proposalResult G.val (fourVertexProposal a x c y hd)).Adj a z ↔ _
    rw [proposalResult_fourVertex_adj_first _ _ _ _ _ _ hax hcy h hxy]
    tauto
  have he : H.val.Adj x y := by
    apply (proposalResult_fourVertex_adj _ _ _ _ _ _ hax hcy h hxy x y).mpr
    tauto
  obtain ⟨u,v,huv,huvset,huvedge⟩ := loose_edge sp H (crossing_adj G h w)
  have hnax : ¬ H.val.Adj a x := fun hh =>
    hd.2.2.1 (leaf_unique sp H hd.1.symm hd.2.2.2.1 hh.symm he)
  have hncx : ¬ H.val.Adj c x := fun hh =>
    hd.2.2.2.2.2 (leaf_unique sp H hd.1.symm hd.2.2.2.1 hh.symm he)
  have hxl := (mem_loose _ _ _ _).mpr ⟨hd.1.symm,hd.2.2.2.1,hnax,hncx⟩
  have hyl := loose_partner sp H hxl he
  have hle : ({x,y} : Finset (Fin n)) ⊆ loose H.val a c := by
    intro z hz
    rcases (mem_insert.mp hz) with rfl|hzy
    · exact hxl
    · exact (mem_singleton.mp hzy) ▸ hyl
  have heq : ({x,y} : Finset (Fin n)) = loose H.val a c := by
    apply Finset.eq_of_subset_of_card_le hle
    simp [huvset,huv,hd.2.2.2.2.1]
  exact ⟨hs,heq.symm,hs ▸ insert_erase hx,congrArg (insert y) hs⟩

#print axioms crossing_bijection
#print axioms crossing_mass
#print axioms johnson_incidence
end
end TwoHubUnequal
