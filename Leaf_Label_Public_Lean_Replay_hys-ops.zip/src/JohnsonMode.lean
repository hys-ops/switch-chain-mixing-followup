import JohnsonStep
import HarmonicDrift
open Finset HubTransfer LeafDrift
namespace JohnsonLower
noncomputable section
variable {N s : ℕ}
def mark (A : Slice N s) (i : Fin N) : ℝ := if i∈A.val then 1 else 0
def count (A S : Slice N s) : ℝ := ∑ i ∈ S.val, mark A i
def overlap (A S : Slice N s) : ℝ := count A S - (s:ℝ)^2/N

theorem count_change (A S : Slice N s) (i : ↥S.val) (j : ↥S.valᶜ) :
    count A (change S i j) = count A S + mark A j-mark A i := by
  have hj : j.val ∉ S.val := mem_compl.mp j.property
  have he := sum_erase_add S.val (mark A) i.property
  unfold count change
  rw [sum_insert (fun h => hj (mem_of_mem_erase h))]
  linarith
theorem count_self (A : Slice N s) : count A A = s := by
  classical
  unfold count mark
  simp [A.property]
theorem sum_mark (A : Slice N s) : (∑ i,mark A i) = s := by
  classical
  simp [mark,A.property]
theorem sum_mark_out (A S : Slice N s) :
    (∑ j : ↥S.valᶜ,mark A j) = (s:ℝ)-count A S := by
  have h := Finset.sum_add_sum_compl S.val (mark A)
  rw [sum_mark] at h
  rw [sum_coe_sort];unfold count;linarith

theorem overlap_eigen {Q : ℝ} (hQ : Q ≠ 0) (hN : 0<N) (A S : Slice N s) :
    obs (kernel Q S) (overlap A)=(1-N/Q)*overlap A S := by
  classical
  have hn : (N:ℝ) ≠ 0 := by exact_mod_cast hN.ne'
  rw [obs,row_apply]
  have hj (i : ↥S.val) (j : ↥S.valᶜ) :
      overlap A (change S i j) = (overlap A S+mark A j)-mark A i := by
    unfold overlap;rw [count_change];ring
  simp only [hj,sum_sub_distrib,sum_add_distrib,sum_const,card_univ,nsmul_eq_mul,cardinal,cardout,sum_mark_out,←mul_sum]
  rw [sum_coe_sort]
  unfold overlap count
  field_simp [hn,hQ]
  <;> ring

theorem increment_square {Q : ℝ} (hQ : 0≤Q) (A S : Slice N s) :
    obs (kernel Q S) (fun T => (overlap A T-overlap A S)^2) ≤ (s:ℝ)*(N-s)/Q := by
  rw [obs,row_apply];simp only [sub_self,zero_pow (by decide : 2≠0),mul_zero,zero_add]
  apply div_le_div_of_nonneg_right _ hQ
  calc
    _ ≤ ∑ i : ↥S.val,∑ j : ↥S.valᶜ,(1:ℝ) := by
      apply sum_le_sum;intro i _;apply sum_le_sum;intro j _
      have e : overlap A (change S i j)-overlap A S=mark A j-mark A i := by
        unfold overlap;rw [count_change];ring
      rw [e];unfold mark;split_ifs <;> norm_num
    _ = _ := by simp only [sum_const,card_univ,nsmul_eq_mul,cardinal,cardout,mul_one]

#print axioms overlap_eigen
#print axioms increment_square
end
end JohnsonLower
