import MarkovTV
open Finset HubTransfer
noncomputable section
namespace JohnsonLower
abbrev Slice (N s : ℕ) := {S : Finset (Fin N) // S.card=s}
variable {N s : ℕ}

def change (S : Slice N s) (i : ↥S.val) (j : ↥S.valᶜ) : Slice N s :=
  ⟨insert j.val (S.val.erase i.val), by
    have hj : j.val ∉ S.val := mem_compl.mp j.property
    have hi := card_erase_add_one i.property
    rw [card_insert_of_notMem (fun hm => hj (mem_of_mem_erase hm))]
    exact hi.trans S.property⟩
def edge (S T : Slice N s) : Prop := ∃ (i : ↥S.val) (j : ↥S.valᶜ), change S i j = T

theorem change_diff (S : Slice N s) (i : ↥S.val) (j : ↥S.valᶜ) (v : Fin N) :
    v ∈ S.val ∧ v ∉ (change S i j).val ↔ v=i.val := by
  have hj : j.val ∉ S.val := mem_compl.mp j.property
  by_cases h : v=i.val
  · subst v
    have hij : i.val ≠ j.val := fun he => hj (he ▸ i.property)
    simp [change,hij,i.property]
  · simp [change,h]; tauto
theorem change_new (S : Slice N s) (i : ↥S.val) (j : ↥S.valᶜ) (v : Fin N) :
    v ∈ (change S i j).val ∧ v ∉ S.val ↔ v=j.val := by
  have hj : j.val ∉ S.val := mem_compl.mp j.property
  by_cases h : v=j.val <;> simp_all [change]
theorem inj_change (S : Slice N s) : Function.Injective
    (fun p : (↥S.val × ↥S.valᶜ) => change S p.1 p.2) := by
  rintro ⟨i,j⟩ ⟨u,v⟩ h
  change change S i j=change S u v at h
  have h₁ := (change_diff S i j i).mpr rfl
  have h₂ := (change_new S i j j).mpr rfl
  rw [h] at h₁ h₂
  exact Prod.ext (Subtype.ext ((change_diff S u v i).mp h₁)) (Subtype.ext ((change_new S u v j).mp h₂))
theorem change_ne (S : Slice N s) (i : ↥S.val) (j : ↥S.valᶜ) : change S i j ≠ S := by
  have h := (change_diff S i j i).mpr rfl
  intro e;rw [e] at h; exact h.2 h.1
theorem edge_symm {S T : Slice N s} (h : edge S T) : edge T S := by
  obtain ⟨i,j,rfl⟩ := h
  let j' : ↥(change S i j).val := ⟨j,(change_new S i j j).mpr rfl |>.1⟩
  let i' : ↥(change S i j).valᶜ := ⟨i,mem_compl.mpr ((change_diff S i j i).mpr rfl).2⟩
  refine ⟨j',i',Subtype.ext ?_⟩
  ext v
  have hj := mem_compl.mp j.property
  by_cases h : v=i.val
  · subst v; simp [change,i',j',i.property]
  · by_cases h' : v=j.val
    · subst v; simp [change,i',j',h,hj]
    · simp [change,i',j',h,h']

open Classical in
def kernel (Q : ℝ) (S T : Slice N s) : ℝ :=
  if T=S then 1-(s:ℝ)*(N-s)/Q else if edge S T then 1/Q else 0

theorem kernel_symm (Q : ℝ) (S T : Slice N s) : kernel Q S T = kernel Q T S := by
  classical
  by_cases H : T=S
  · subst T;rfl
  · simp [kernel,H,Ne.symm H, show edge S T ↔ edge T S from ⟨edge_symm,edge_symm⟩]

theorem row_apply (Q : ℝ) (S : Slice N s) (f : Slice N s → ℝ) :
    (∑ T, kernel Q S T*f T) = (1-(s:ℝ)*(N-s)/Q)*f S +
      (∑ i : ↥S.val, ∑ j : ↥S.valᶜ, f (change S i j))/Q := by
  classical
  let g := fun p : ↥S.val × ↥S.valᶜ => change S p.1 p.2
  have himg : ∀ T : Slice N s, (if edge S T then f T else 0) =
       ∑ p : ↥S.val × ↥S.valᶜ, if g p=T then f (g p) else 0 := by
    intro T
    by_cases h : edge S T
    · obtain ⟨i,j,he⟩ := h
      have he' : edge S T := ⟨i,j,he⟩
      rw [ite_eq_left he', ← he]
      have hg : Function.Injective g := inj_change S
      change f (g (i,j)) = ∑ p, if g p=g (i,j) then f (g p) else 0
      simp [hg.eq_iff]
    · rw [ite_eq_right h]
      symm;apply sum_eq_zero; intro p _
      rw [ite_eq_right fun e => h ⟨p.1,p.2,e⟩]
  have hs : (∑ T : Slice N s, if edge S T then f T else 0) =
      ∑ i : ↥S.val, ∑ j : ↥S.valᶜ, f (change S i j) := by
    simp_rw [himg];rw [sum_comm];simp [Fintype.sum_prod_type,g]
  have ht (T : Slice N s) : kernel Q S T*f T =
      (if T=S then (1-(s:ℝ)*(N-s)/Q)*f S else 0) +
      (if edge S T then f T else 0)/Q := by
    by_cases h : T=S
    · subst T; have hn : ¬edge S S := by rintro ⟨i,j,h⟩;exact change_ne S i j h
      simp [kernel,hn]
    · by_cases e : edge S T <;> simp [kernel,h,e,div_eq_mul_inv,mul_comm]
  simp_rw [ht]; rw [sum_add_distrib,←sum_div,hs];simp

theorem cardinal (S : Slice N s) : (Fintype.card ↥S.val : ℝ)=s := by simp [S.property]
theorem cardout (S : Slice N s) : (Fintype.card ↥S.valᶜ : ℝ)=(N:ℝ)-s := by
  have ha : s ≤ N := by simpa [S.property] using S.val.card_le_univ
  simp [S.property,Nat.cast_sub ha]

theorem kernel_stoch {Q : ℝ} (Spos : 0 < Q) (hb : (s:ℝ)*(N-s) ≤ Q) :
    Stochastic (kernel (N:=N) (s:=s) Q) := by
  classical
  constructor
  · intro S T;unfold kernel;split_ifs
    · exact sub_nonneg.mpr ((div_le_one Spos).mpr hb)
    · positivity
    · rfl
  · intro S
    have hh := row_apply Q S (fun _ => 1)
    simp only [mul_one,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,cardinal,cardout] at hh
    rw [hh]
    ring
end JohnsonLower
