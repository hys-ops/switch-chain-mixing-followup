import JohnsonMode
import MomentBound
import Mathlib.Analysis.SpecialFunctions.Log.Basic
open Finset HubTransfer LeafDrift LeafMoment
namespace JohnsonLower
noncomputable section
variable {N s : ℕ}

theorem square_bound {Q : ℝ} (hQ : 0<Q) (hN : 0<N) (hQN : (N:ℝ)≤Q)
    (hb : (s:ℝ)*(N-s)≤Q) (A S : Slice N s) :
    obs (kernel Q S) (fun T => (overlap A T)^2) ≤
    (1-N/Q)^2*(overlap A S)^2 + (1-(1-N/Q)^2)*((N:ℝ)/4) := by
  have hp := kernel_stoch (N:=N) (s:=s) hQ hb
  have e := overlap_eigen hQ.ne' hN A S
  have inc := increment_square hQ.le A S
  let Z := overlap A
  change obs (kernel Q S) Z=(1-(N:ℝ)/Q)*Z S at e
  have eq : (fun T => (Z T-Z S)^2) = fun T => (Z T^2 + (-2*Z S)*Z T) + Z S^2 := by funext T; ring
  change obs (kernel Q S) (fun T => (Z T-Z S)^2)≤_ at inc
  rw [eq,obs_add,obs_add,obs_scale,obs_const _ (hp.2 S),e] at inc
  have ha0 : 0≤(N:ℝ)/Q := by positivity
  have ha1 : (N:ℝ)/Q≤1 := (div_le_one hQ).mpr hQN
  have hbudget : (s:ℝ)*(N-s)/Q ≤ (1-(1-N/Q)^2)*((N:ℝ)/4) := by
    calc
      _ ≤ ((N:ℝ)^2/4)/Q := by
        apply div_le_div_of_nonneg_right _ hQ.le
        nlinarith [sq_nonneg ((s:ℝ)-N/2)]
      _ = ((N:ℝ)/Q)*((N:ℝ)/4) := by ring
      _ ≤ _ := by
        apply mul_le_mul_of_nonneg_right _ (by positivity)
        nlinarith [mul_nonneg ha0 (sub_nonneg.mpr ha1)]
  change obs (kernel Q S) (fun T => Z T^2) ≤ (1-(N:ℝ)/Q)^2*(Z S)^2+_
  nlinarith [mul_nonneg (sq_nonneg ((N:ℝ)/Q)) (sq_nonneg (Z S))]

theorem unif_stationary {Q : ℝ} (hQ : 0<Q) (hb : (s:ℝ)*(N-s)≤Q)
    (f : Slice N s → ℝ) :
    obs (unif _) (fun y => obs (kernel Q y) f) = obs (unif _) f := by
  have hp := kernel_stoch (N:=N) (s:=s) hQ hb
  have hcol (y : Slice N s) : ∑ z,kernel Q z y=1 := by
    simp_rw [kernel_symm Q _ y];exact hp.2 y
  simp only [obs,unif,←mul_sum]
  congr 1
  rw [sum_comm]
  simp_rw [←sum_mul,hcol,one_mul]

private theorem bias_exponential {Q N : ℝ} (hN : 0<N) (hq : 2*N≤Q) :
    Real.exp (-(2*N/Q)) ≤ 1-N/Q := by
  have hp : 0<Q := by linarith
  have hz : 0≤1-N/Q := sub_nonneg.mpr ((div_le_one hp).mpr (by linarith))
  have hprod : 1≤(1-N/Q)*(1+2*N/Q) := by
    apply le_of_mul_le_mul_right _ (sq_pos_of_pos hp)
    field_simp
    nlinarith [mul_le_mul_of_nonneg_left hq hN.le]
  rw [Real.exp_neg,inv_le_iff_one_le_mul₀ (Real.exp_pos _)]
  exact hprod.trans (mul_le_mul_of_nonneg_left (by linarith [Real.add_one_le_exp (2*N/Q)]) hz)

theorem signal {Q N s : ℝ} {t : ℕ} (hN : 0<N) (hQ : 2*N≤Q)
    (hl : N/4≤s) (hu : s≤3*N/4) (ht : 4*N*t ≤ Q*Real.log (N/1024)) :
    16*(N/4) ≤ ((1-N/Q)^t*(s-s^2/N))^2 := by
  have hq : 0<Q := by linarith
  have hm : N/16≤s-s^2/N := by
    have hs := mul_le_mul hl (show N/4≤N-s by linarith) (by positivity) (by linarith)
    field_simp [hN.ne']
    nlinarith
  have he := Real.exp_le_exp.mpr (neg_le_neg ((div_le_iff₀ hq).mpr
    (show 4*N*t≤Real.log (N/1024)*Q by linarith)))
  rw [Real.exp_neg,Real.exp_log (by positivity : 0<N/1024),inv_div] at he
  have hb := pow_le_pow_left₀ (Real.exp_pos _).le (bias_exponential hN hQ) t
  have hh := mul_self_le_mul_self (pow_pos (Real.exp_pos _) _).le hb
  have hi : Real.exp (-(4*N*(t:ℝ)/Q)) =
      Real.exp (-(2*N/Q))^t * Real.exp (-(2*N/Q))^t := by
    rw [←Real.exp_nat_mul,←Real.exp_add];congr 1;ring
  rw [hi] at he
  have he' : 1024/N ≤ ((1-N/Q)^t)^2 := by nlinarith
  have hs2 := mul_self_le_mul_self (show 0≤N/16 by positivity) hm
  have hm2 : (N/16)^2 ≤ (s-s^2/N)^2 := by nlinarith
  have hy := mul_le_mul he' hm2 (sq_nonneg _) (by positivity)
  have hz : (1024/N)*(N/16)^2=4*N := by field_simp;ring
  rw [hz] at hy
  nlinarith [hy]

/-- An actual, explicit half-L1 lower bound for the finite Johnson transition,
    in the original per-neighbor 1/Q clock. -/
theorem johnson_tv_lower {Q : ℝ} (hN : 0<N) (hq : 2*(N:ℝ)≤Q)
    (hb : (s:ℝ)*(N-s)≤Q) (hl : (N:ℝ)/4≤s) (hu : (s:ℝ)≤3*N/4)
    (S : Slice N s) (t : ℕ) (ht : 4*(N:ℝ)*t ≤ Q*Real.log ((N:ℝ)/1024)) :
    (1:ℝ)/2 ≤ tv (((Matrix.of (kernel Q))^t) S) (unif _) := by
  have : Nonempty (Slice N s) := ⟨S⟩
  have hN' : (0:ℝ)<N := by exact_mod_cast hN
  have hQ : 0<Q := by linarith
  have hp := kernel_stoch (N:=N) (s:=s) hQ hb
  have hA0 : 0<1-(N:ℝ)/Q := sub_pos.mpr ((div_lt_one hQ).mpr (by linarith))
  have hA1 : 1-(N:ℝ)/Q<1 := by
    have : 0<(N:ℝ)/Q := by positivity
    linarith
  have ha : (1-(N:ℝ)/Q)^2<1 := by nlinarith [mul_pos (sub_pos.mpr hA1) (show 0<1+(1-(N:ℝ)/Q) by linarith)]
  have hw : (∑ x : Slice N s, unif _ x) = 1 := by
    have hc : (Fintype.card (Slice N s):ℝ)≠0 := by exact_mod_cast Fintype.card_ne_zero
    simp only [unif,sum_const,card_univ,nsmul_eq_mul,one_div,mul_inv_cancel₀ hc]
  have hw0 (x : Slice N s) : 0≤unif _ x := by unfold unif;positivity
  have hs := square_bound hQ hN (by linarith) hb S
  have hu2 := stationary_square (kernel Q) hp (unif _) (overlap S) hw hw0
    (unif_stationary hQ hb) _ _ ha hs
  have hcenter : overlap S S=(s:ℝ)-s^2/N := by rw [overlap,count_self]
  have hm := signal hN' hq hl hu ht
  apply half_tv (kernel Q) hp _ _ hw hw0 _ _ (by positivity) (overlap_eigen hQ.ne' hN S) hs hu2 S t rfl
  · rw [hcenter]
    have hs0 : 0<(s:ℝ) := by linarith
    have hf : 0<(N:ℝ)-s := by linarith
    have hle : 0<(s:ℝ)-s^2/N := by
      rw [sub_pos,div_lt_iff₀ hN'];nlinarith [mul_pos hs0 hf]
    positivity
  · rwa [hcenter]

#print axioms johnson_tv_lower
end
end JohnsonLower
