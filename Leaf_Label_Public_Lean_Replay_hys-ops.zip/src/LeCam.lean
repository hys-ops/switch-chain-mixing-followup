import UrnSemigroup
open Finset HubTransfer LeafClock PhysicalReduction LeafSplit
open scoped Matrix Classical
noncomputable section
namespace SharpClock
variable {X : Type*} [Fintype X] [DecidableEq X]

theorem shared_part (a b w : X→ℝ) (ha : ∀x,w x≤a x) (hb : ∀x,w x≤b x)
    (h1 : ∑ x,a x=1) (h2 : ∑ x,b x=1) : tv a b≤1-∑ x,w x := by
  unfold tv
  apply (div_le_iff₀ (by norm_num : (0:ℝ)<2)).mpr
  calc
    _ ≤ ∑ x, (a x-w x+(b x-w x)) := by
      apply sum_le_sum;intro x _
      have e:=abs_sub (a x-w x) (b x-w x)
      rw [sub_sub_sub_cancel_right,abs_of_nonneg (sub_nonneg.mpr (ha x)),abs_of_nonneg (sub_nonneg.mpr (hb x))] at e;exact e
    _ = _ := by simp [sum_add_distrib,sum_sub_distrib,h1,h2];ring

def thin (R : Matrix X X ℝ) (p:ℝ) := (1-p) • (1:Matrix X X ℝ) +p • R

theorem thin_stoch (R : Matrix X X ℝ) (hr : Stochastic R) {p : ℝ} (hp : 0≤p) (hp' : p≤1) :
    Stochastic (thin R p) := by
  refine ⟨?_,?_⟩
  · intro x y;simp only [thin,Matrix.add_apply,Matrix.smul_apply,smul_eq_mul,Matrix.one_apply]
    split_ifs <;> first| positivity| nlinarith [mul_nonneg hp (hr.1 x y)]
  · intro x;simp [thin,Matrix.one_apply,Finset.sum_add_distrib,←mul_sum,hr.2]

theorem one_tick (R : Matrix X X ℝ) (hr : Stochastic R) {p:ℝ} (hp : 0≤p) (hp' : p≤1) (x : X) :
    tv (thin R p x) (continuous R p x)≤p^2 := by
  let I := (1:Matrix X X ℝ)
  let w := fun y => (1-p)*I x y+mass p 1*R x y
  have he : 1-p≤Real.exp (-p) := by linarith [Real.add_one_le_exp (-p)]
  have hL : mass p 1≤p := by
    have he' : Real.exp (-p)≤1 := Real.exp_le_one_iff.mpr (by linarith)
    simpa [mass] using mul_le_of_le_one_left hp he'
  have ha (y) : w y ≤ thin R p x y := by
    change _ ≤ (1-p)*I x y+p*R x y;dsimp [w]
    gcongr;exact hr.1 x y
  have hb (y) : w y≤continuous R p x y := by
    have hh:= (entry_summable R hr hp x y).sum_le_tsum (range 2)
      (fun j _=>mul_nonneg (mass_ge hp j) ((stochastic_pow hr j).1 _ _))
    simp only [sum_range_succ,sum_range_zero,zero_add,pow_zero,pow_one] at hh
    apply le_trans _ hh
    dsimp [w,I];gcongr
    · simp [Matrix.one_apply];split <;> norm_num
    · simpa [mass] using he
  have sw : ∑ y,w y=1-p+mass p 1 := by
    simp [w,I,sum_add_distrib,←mul_sum,hr.2,Matrix.one_apply]
  have H:=shared_part _ _ w ha hb ((thin_stoch R hr hp hp').2 x) ((continuous_stoch R hr hp).2 x)
  rw [sw] at H;unfold mass at H;norm_num at H
  nlinarith [mul_le_mul_of_nonneg_right he hp]

theorem many_ticks (R:Matrix X X ℝ) (hr:Stochastic R) {p:ℝ} (hp:0≤p) (hp':p≤1) (t:ℕ) (x:X) :
    tv (((thin R p)^t) x) (continuous R ((t:ℝ)*p) x) ≤ (t:ℝ)*p^2 := by
  have c : continuous R ((t:ℝ)*p)=(continuous R p)^t := by
    induction t with
    | zero => simp [continuous_exp]
    | succ t ih => rw [Nat.cast_succ,add_mul,one_mul,continuous_plus,ih,pow_succ]
  rw [c]
  exact power_error (thin R p) (continuous R p) (thin_stoch R hr hp hp') (continuous_stoch R hr hp)
    (one_tick R hr hp hp') t x
#print axioms many_ticks
end SharpClock
