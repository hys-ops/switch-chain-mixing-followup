import LeafOrbitTransfer
import PairOrientations
import Mathlib.GroupTheory.Perm.Support

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

abbrev LeafLabel (d : Fin n → ℕ) := ↥(leaves d)
abbrev LeafGroup (d : Fin n → ℕ) := Equiv.Perm (LeafLabel d)

theorem extension_fixes (g : LeafGroup d) : FixesCore d (Equiv.Perm.ofSubtype g) := by
  intro v hv
  exact Equiv.Perm.ofSubtype_apply_of_not_mem _ (by simpa [leaves] using hv)

def act (g : LeafGroup d) : Equiv.Perm (GraphState n d) :=
  graphPerm (Equiv.Perm.ofSubtype g) (extension_fixes g)

theorem act_one (G : GraphState n d) : act (1:LeafGroup d) G=G := by
  apply Subtype.ext
  change G.1.comap (Equiv.Perm.ofSubtype (1:LeafGroup d))=_
  rw [map_one]; ext; rfl

theorem act_mul (g h : LeafGroup d) (G : GraphState n d) : act (g*h) G=act h (act g G) := by
  apply Subtype.ext
  change G.1.comap (Equiv.Perm.ofSubtype (g*h))=_
  rw [map_mul]; rfl

theorem exists_act (G H : GraphState n d) : orbitMap G=orbitMap H ↔ ∃ g : LeafGroup d,act g G=H := by
  rw [orbit_eq]
  constructor
  · rintro ⟨σ,hf,rfl⟩
    have hm (v : Fin n) : σ v ∈ leaves d ↔ v∈leaves d := by simp [leaves,preserves σ hf]
    refine ⟨σ.subtypePerm hm,?_⟩
    apply Subtype.ext
    change G.1.comap (Equiv.Perm.ofSubtype (σ.subtypePerm hm)) = G.1.comap σ
    rw [Equiv.Perm.ofSubtype_subtypePerm hm (fun v hv => by
      by_contra h; exact hv (hf v (by simpa [leaves] using h)))]
  · rintro ⟨g,rfl⟩
    exact ⟨Equiv.Perm.ofSubtype g,extension_fixes g,rfl⟩

theorem act_swap_flip (i j : LeafLabel d) (a : Anchor d) (ha : {i.1,j.1}=a.1)
    (G : GraphState n d) : act (Equiv.swap i j) G=flip a G := by
  have hp := (anchor_spec a).choose_spec
  have hs : ({i.1,j.1}:Set (Fin n)) = {(anchor_spec a).choose.1,(anchor_spec a).choose.2} := by
    simpa only [Finset.coe_pair] using congrArg (fun z : Finset (Fin n) => (z:Set (Fin n))) (ha.trans hp.2.1)
  have he : Equiv.swap i.1 j.1 = vertexSwap a := by
    rcases Set.pair_eq_pair_iff.mp hs with h|h
    · simp only [vertexSwap, h.1,h.2]
    · simp only [vertexSwap,h.1,h.2,Equiv.swap_comm]
  apply Subtype.ext
  change G.1.comap (Equiv.Perm.ofSubtype (Equiv.swap i j))=G.1.comap (vertexSwap a)
  rw [Equiv.Perm.ofSubtype_swap_eq,he]

/-- Summing over ordered *distinct* leaf labels counts each unordered swap exactly twice. -/
theorem pair_sum (f : LeafGroup d → ℝ) (g : Anchor d → ℝ)
    (hagree : ∀ (i j : LeafLabel d) (a : Anchor d), {i.1,j.1}=a.1 → f (Equiv.swap i j)=g a) :
    (∑ i : LeafLabel d,∑ j : LeafLabel d, if i≠j then f (Equiv.swap i j) else 0)=2*∑ a:Anchor d,g a := by
  let F (s : Finset (Fin n)) := if h : s∈leafPairs d then g ⟨s,h⟩ else 0
  have he (i j : LeafLabel d) (hij : i≠j) : f (Equiv.swap i j)=F {i.1,j.1} := by
    have hmem : {i.1,j.1} ∈ leafPairs d := Finset.mem_powersetCard.mpr
      ⟨by intro x hx; rcases Finset.mem_insert.mp hx with rfl|h; exact i.2; exact (Finset.mem_singleton.mp h) ▸ j.2, by simp [show i.1≠j.1 from fun h => hij (Subtype.ext h)]⟩
    simpa [F,hmem] using hagree i j ⟨_,hmem⟩ rfl
  have hmain := UnorderedPairSums.sum_offDiag_eq_two_mul (leaves d) F
  have hoff : (leaves d).offDiag=((leaves d) ×ˢ (leaves d)).filter (fun p : Fin n×Fin n => p.1≠p.2) := by
    ext p; simp [Finset.mem_offDiag,and_assoc]
  rw [hoff,Finset.sum_filter,Finset.sum_product] at hmain
  have hl : (∑ i : LeafLabel d,∑ j : LeafLabel d, if i≠j then f (Equiv.swap i j) else 0)=
      ∑ i ∈ leaves d,∑ j ∈ leaves d,if i≠j then F {i,j} else 0 := by
    rw [← Finset.sum_attach (leaves d)]
    apply Finset.sum_congr rfl
    intro i _
    rw [← Finset.sum_attach (leaves d)]
    apply Finset.sum_congr rfl
    intro j _
    by_cases hij : i=j
    · subst j; simp
    · simp [hij,show i.1≠j.1 from fun h => hij (Subtype.ext h),he i j hij]
  rw [hl,hmain]
  congr 1
  change (∑ a ∈ leafPairs d,F a)=∑ a:Anchor d,g a
  rw [← Finset.sum_attach (leafPairs d)]
  apply Finset.sum_congr rfl
  intro a _
  simp [F,a.2]

#print axioms exists_act
#print axioms pair_sum
end OAI.Problem315.LeafOrbit
