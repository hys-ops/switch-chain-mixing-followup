import LeafIID
import Minorization

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} (d : Fin n → ℕ)
abbrev chain : Matrix (GraphState n d) (GraphState n d) ℝ := switchKernel n d
abbrev iidMatrix : Matrix (GraphState n d) (GraphState n d) ℝ := iidLeaf
abbrev iidClock : ℝ := ((leaves d).card:ℝ)^2/(4*(12*(n.choose 4:ℝ)))

/-- Graph instantiation. The three partition/commutation hypotheses are explicit. -/
theorem leaf_quotient_transfer {C : Type*} [Fintype C] [DecidableEq C] (hn : 4 ≤ n)
    (π : GraphState n d → C) (hs : Function.Surjective π)
    (hTP : Commute (iidMatrix d) (chain d)) (hET : avg π * iidMatrix d = avg π)
    (hEP : Commute (avg π) (chain d)) (t : ℕ) (G : GraphState n d) :
    tv (((chain d)^t) G) (unif (GraphState n d)) ≤
      tv (push π (((chain d)^t) G)) (push π (unif (GraphState n d))) +
        ∑ k ∈ Finset.range (t+1),weight t k (iidClock d)*tv (((iidMatrix d)^k) G) (avg π G) := by
  apply quotient_transfer_minorized π hs (chain d) (iidMatrix d) (iidClock d)
    (by unfold iidClock; positivity) (lt_of_le_of_lt (iid_leaf_weight_bound hn) (by norm_num))
    _ iidLeaf_stochastic (iid_leaf_minorization hn) hTP hET hEP
  exact ⟨switchKernel_nonneg, fun x => by simpa [allGraphStates] using switchKernel_row_sum hn x⟩

#print axioms leaf_quotient_transfer
end OAI.Problem315.LeafTransfer
