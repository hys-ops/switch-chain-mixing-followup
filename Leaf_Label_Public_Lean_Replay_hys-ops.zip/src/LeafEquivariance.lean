import LeafBridge

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.LeafOrbit
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

/-- Degrees of a pullback graph are the degrees at its relabeled vertices. -/
theorem degree_comap (G : SimpleGraph (Fin n)) (σ : Equiv.Perm (Fin n)) (v : Fin n) :
    graphDegree (G.comap σ) v = graphDegree G (σ v) := by
  classical
  unfold graphDegree
  apply Finset.card_bijective σ σ.bijective
  intro i
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, SimpleGraph.comap_adj]

/-- Relabel labeled realizations using an actual degree-preserving permutation. -/
def labelEquiv (σ : Equiv.Perm (Fin n)) (hσ : ∀ v, d (σ v) = d v) :
    Equiv.Perm (GraphState n d) where
  toFun G := ⟨G.1.comap σ, fun v => (degree_comap G.1 σ v).trans ((G.2 (σ v)).trans (hσ v))⟩
  invFun G := ⟨G.1.comap σ.symm, fun v => (degree_comap G.1 σ.symm v).trans <| by
    rw [G.2 (σ.symm v), ← hσ (σ.symm v), σ.apply_symm_apply]⟩
  left_inv G := by apply Subtype.ext; ext u v; simp
  right_inv G := by apply Subtype.ext; ext u v; simp

theorem swap_preserves_degree (i j : Fin n) (hd : d i = d j) :
    ∀ v, d (Equiv.swap i j v) = d v := by
  intro v
  by_cases hi : v = i
  · subst v; simp [hd]
  by_cases hj : v = j
  · subst v; simp [hd]
  rw [Equiv.swap_apply_of_ne_of_ne hi hj]

def fourEquiv (σ : Equiv.Perm (Fin n)) : Equiv.Perm (FourSet n) where
  toFun S := ⟨S.1.map σ.symm.toEmbedding, by simp [S.2]⟩
  invFun S := ⟨S.1.map σ.toEmbedding, by simp [S.2]⟩
  left_inv S := by apply Subtype.ext; ext v; simp
  right_inv S := by apply Subtype.ext; ext v; simp

theorem mem_fourEquiv (σ : Equiv.Perm (Fin n)) (S : FourSet n) (v : Fin n) :
    v ∈ (fourEquiv σ S).1 ↔ σ v ∈ S.1 := by
  change v ∈ S.1.map σ.symm.toEmbedding ↔ _
  simp

private theorem perfect_comap (σ : Equiv.Perm (Fin n)) {S T : Finset (Fin n)}
    (hm : ∀ v, v ∈ T ↔ σ v ∈ S) {M : SimpleGraph (Fin n)}
    (h : IsPerfectMatchingOn S M) : IsPerfectMatchingOn T (M.comap σ) := by
  intro v
  constructor
  · intro hv
    obtain ⟨w, hw,hu⟩ := (h (σ v)).1 ((hm v).1 hv)
    refine ⟨σ.symm w, ?_, ?_⟩
    · change M.Adj (σ v) (σ (σ.symm w))
      simpa using hw
    · intro z hz
      apply σ.injective
      rw [σ.apply_symm_apply]
      exact hu _ hz
  · intro hv w hw
    exact (h (σ v)).2 (fun hs => hv ((hm v).2 hs)) (σ w) hw

def matchingEquiv (σ : Equiv.Perm (Fin n)) (S : FourSet n) :
    PerfectMatching S ≃ PerfectMatching (fourEquiv σ S) where
  toFun M := ⟨M.1.comap σ, perfect_comap σ (mem_fourEquiv σ S) M.2⟩
  invFun M := ⟨M.1.comap σ.symm, perfect_comap σ.symm (fun v => by
    rw [mem_fourEquiv, σ.apply_symm_apply]) M.2⟩
  left_inv M := by apply Subtype.ext; ext u v; simp
  right_inv M := by apply Subtype.ext; ext u v; simp

def proposalEquiv (σ : Equiv.Perm (Fin n)) : Equiv.Perm (SwitchProposal n) :=
  Equiv.sigmaCongr (fourEquiv σ) fun S =>
    Equiv.subtypeEquiv ((matchingEquiv σ S).prodCongr (matchingEquiv σ S))
      (fun p => by
        change p.1 ≠ p.2 ↔ (matchingEquiv σ S) p.1 ≠ (matchingEquiv σ S) p.2
        simp)

theorem valid_comap_iff (σ : Equiv.Perm (Fin n)) (G : SimpleGraph (Fin n))
    (p : SwitchProposal n) : validSwitch (G.comap σ) (proposalEquiv σ p) ↔ validSwitch G p := by
  change ((∀ ⦃u v⦄, (removedMatching p).Adj (σ u) (σ v) → G.Adj (σ u) (σ v)) ∧
    (∀ ⦃u v⦄, (addedMatching p).Adj (σ u) (σ v) → ¬G.Adj (σ u) (σ v))) ↔ _
  constructor
  · rintro ⟨hr,ha⟩
    constructor
    · intro u v h
      simpa using @hr (σ.symm u) (σ.symm v) (by simpa using h)
    · intro u v h
      simpa using @ha (σ.symm u) (σ.symm v) (by simpa using h)
  · rintro ⟨hr,ha⟩
    exact ⟨fun {_ _} h => hr h, fun {_ _} h => ha h⟩

theorem result_comap (σ : Equiv.Perm (Fin n)) (G : SimpleGraph (Fin n)) (p : SwitchProposal n) :
    proposalResult (G.comap σ) (proposalEquiv σ p) = (proposalResult G p).comap σ := by
  by_cases h : validSwitch G p
  · rw [proposalResult, ite_eq_left ((valid_comap_iff σ G p).2 h), proposalResult, ite_eq_left h]
    rfl
  · rw [proposalResult, ite_eq_right (fun ht => h ((valid_comap_iff σ G p).1 ht)), proposalResult, ite_eq_right h]

theorem comap_injective (σ : Equiv.Perm (Fin n)) :
    Function.Injective (fun G : SimpleGraph (Fin n) => G.comap σ) := by
  intro G H he
  have he' := congrArg (fun M : SimpleGraph (Fin n) => M.comap σ.symm) he
  simpa using he'

/-- Relabeling commutes with the original lazy kernel, including rejected
proposals and the diagonal holding probability. -/
theorem switchKernel_labelEquiv (σ : Equiv.Perm (Fin n)) (hs : ∀ v, d (σ v) = d v)
    (G H : GraphState n d) :
    switchKernel n d (labelEquiv σ hs G) (labelEquiv σ hs H) = switchKernel n d G H := by
  classical
  have hc :
      ((allProposals n).filter (fun p => proposalResult (labelEquiv σ hs G).1 p =
        (labelEquiv σ hs H).1)).card =
      ((allProposals n).filter (fun p => proposalResult G.1 p = H.1)).card := by
    symm
    apply Finset.card_bijective (proposalEquiv σ) (proposalEquiv σ).bijective
    intro p
    simp only [allProposals,Finset.mem_filter,Finset.mem_univ,true_and]
    change (proposalResult G.1 p = H.1) ↔ proposalResult (G.1.comap σ) (proposalEquiv σ p) = H.1.comap σ
    rw [result_comap]
    exact (comap_injective σ).eq_iff.symm
  unfold switchKernel
  rw [hc]
  simp

#print axioms switchKernel_labelEquiv
end OAI.Problem315.LeafOrbit
