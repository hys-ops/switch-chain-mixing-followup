import LeafMinorization

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

/-- Two independent uniformly chosen leaves are swapped; the empty leaf set holds. -/
def iidLeaf (G H : GraphState n d) : ℝ :=
  (if G=H then ((leaves d).card:ℝ)⁻¹ else 0) +
    (1-((leaves d).card:ℝ)⁻¹)*rawLeaf G H

private theorem inv_le_one (m : ℕ) : (m:ℝ)⁻¹≤1 := by
  cases m with
  | zero => norm_num
  | succ k => apply inv_le_one_of_one_le₀; exact_mod_cast Nat.succ_pos k

theorem iidLeaf_stochastic : (∀ G H : GraphState n d, 0 ≤ iidLeaf G H) ∧
    ∀ G : GraphState n d,(∑ H,iidLeaf G H)=1 := by
  constructor
  · intro G H
    have hw := sub_nonneg.mpr (inv_le_one (leaves d).card)
    unfold iidLeaf
    have hr : 0 ≤ rawLeaf G H := by unfold rawLeaf; split_ifs <;> positivity
    split_ifs <;> positivity
  · intro G
    simp [iidLeaf,Finset.sum_add_distrib,← Finset.mul_sum,rawLeaf_row]

theorem iid_leaf_weight_bound (hn : 4≤n) :
    ((leaves d).card:ℝ)^2/(4*(12*(n.choose 4:ℝ))) ≤ 1/2 := by
  have h4 : (0:ℝ) < n.choose 4 := by exact_mod_cast Nat.choose_pos hn
  apply (div_le_iff₀ (by positivity)).2
  have hN : ((leaves d).card:ℝ)≤(n:ℝ) := by exact_mod_cast (show (leaves d).card ≤ n by simpa using Finset.card_le_univ (leaves d))
  have hx := leaf_count_le (fun _ : Fin n => 1) hn
  have hc : n.choose 2 ≤ 6*n.choose 4 := by simpa [leafPairs,leaves] using hx
  have hc' : (n.choose 2:ℝ) ≤ 6*(n.choose 4:ℝ) := by exact_mod_cast hc
  rw [Nat.cast_choose_two] at hc'
  have hnr : (4:ℝ)≤n := by exact_mod_cast hn
  nlinarith [sq_nonneg ((n:ℝ)-1),mul_nonneg (sub_nonneg.mpr hN) (show 0≤(n:ℝ)+(leaves d).card by positivity),mul_nonneg (show 0≤(n:ℝ) by positivity) (show 0≤(n:ℝ)-2 by linarith)]

theorem iid_leaf_minorization (hn : 4≤n) (G H : GraphState n d) :
    ((leaves d).card:ℝ)^2/(4*(12*(n.choose 4:ℝ)))*iidLeaf G H ≤ switchKernel n d G H := by
  by_cases he : G=H
  · subst H
    have hw := sub_nonneg.mpr (inv_le_one (leaves d).card)
    have hle : iidLeaf G G≤1 := by
      simp only [iidLeaf,ite_true]
      nlinarith [mul_nonneg hw (sub_nonneg.mpr (rawLeaf_le_one G G))]
    exact ((mul_le_mul_of_nonneg_left hle (by positivity)).trans_eq (mul_one _)).trans
      ((iid_leaf_weight_bound (d:=d) hn).trans (switchKernel_self_ge_half G))
  · by_cases hzero : (leaves d).card=0
    · simpa [hzero] using switchKernel_nonneg G H
    have hN : ((leaves d).card:ℝ)≠0 := by exact_mod_cast hzero
    have hQ : (n.choose 4:ℝ)≠0 := by exact_mod_cast (Nat.choose_pos hn).ne'
    apply le_trans _ (leaf_minorization hn G H)
    apply le_of_eq
    simp only [iidLeaf,lazyLeaf,he,ite_false,zero_add,leafPairs,Finset.card_powersetCard,Nat.cast_choose_two]
    field_simp
    ring

#print axioms iidLeaf_stochastic
#print axioms iid_leaf_weight_bound
#print axioms iid_leaf_minorization
end OAI.Problem315.LeafTransfer
