import OAI.Probability.SwitchChain.Definitions
/- The four elementary relabeling declarations below are extracted from the earlier
LabelComparison proof. This module needs only the published state and degree definitions. -/
namespace LeafLower.Labels
open OAI.Problem315
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}
/-- Degrees of a pullback graph are the degrees at its relabeled vertices. -/
theorem degree_comap (G : SimpleGraph (Fin n)) (σ : Equiv.Perm (Fin n)) (v : Fin n) :
    graphDegree (G.comap σ) v = graphDegree G (σ v) := by
  classical
  unfold graphDegree
  apply Finset.card_bijective σ σ.bijective
  intro i
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, SimpleGraph.comap_adj]

/-- Relabel labeled realizations using an actual degree-preserving permutation. -/
def labelEquiv (σ : Equiv.Perm (Fin n)) (hσ : ∀ v, d (σ v) = d v) :
    Equiv.Perm (GraphState n d) where
  toFun G := ⟨G.1.comap σ, fun v => (degree_comap G.1 σ v).trans ((G.2 (σ v)).trans (hσ v))⟩
  invFun G := ⟨G.1.comap σ.symm, fun v => (degree_comap G.1 σ.symm v).trans <| by
    rw [G.2 (σ.symm v), ← hσ (σ.symm v), σ.apply_symm_apply]⟩
  left_inv G := by apply Subtype.ext; ext u v; simp
  right_inv G := by apply Subtype.ext; ext u v; simp

theorem swap_preserves_degree (i j : Fin n) (hd : d i = d j) :
    ∀ v, d (Equiv.swap i j v) = d v := by
  intro v
  by_cases hi : v = i
  · subst v; simp [hd]
  by_cases hj : v = j
  · subst v; simp [hd]
  rw [Equiv.swap_apply_of_ne_of_ne hi hj]

def swapLabels (i j : Fin n) (hd : d i = d j) : Equiv.Perm (GraphState n d) :=
  labelEquiv (Equiv.swap i j) (swap_preserves_degree i j hd)

end
end LeafLower.Labels
