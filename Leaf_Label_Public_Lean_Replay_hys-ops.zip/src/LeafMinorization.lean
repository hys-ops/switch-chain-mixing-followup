import LeafSwitch

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

def leaves (d : Fin n → ℕ) := Finset.univ.filter (fun i => d i=1)
def leafPairs (d : Fin n → ℕ) := (leaves d).powersetCard 2
abbrev Anchor (d : Fin n → ℕ) := ↥(leafPairs d)

private theorem pairSpec (a : Anchor d) :
    ∃ p : Fin n × Fin n,p.1≠p.2 ∧ a.1={p.1,p.2} ∧ d p.1=1 ∧ d p.2=1 := by
  obtain ⟨hsub,hcard⟩ := Finset.mem_powersetCard.mp a.2
  obtain ⟨i,j,hi,he⟩ := Finset.card_eq_two.mp hcard
  have h1 : i ∈ a.1 := by rw [he]; simp
  have h2 : j ∈ a.1 := by rw [he]; simp
  exact ⟨(i,j),hi,he,(Finset.mem_filter.mp (hsub h1)).2,(Finset.mem_filter.mp (hsub h2)).2⟩

def flip (a : Anchor d) (G : GraphState n d) : GraphState n d := by
  let p := (pairSpec a).choose
  have hp := (pairSpec a).choose_spec
  let σ := Equiv.swap p.1 p.2
  refine ⟨G.1.comap σ,fun x => ?_⟩
  have he : graphDegree (G.1.comap σ) x=graphDegree G.1 (σ x) := by
    unfold graphDegree
    apply Finset.card_bijective σ σ.bijective
    intro w
    simp only [Finset.mem_filter,Finset.mem_univ,true_and,SimpleGraph.comap_adj]
  rw [he,G.2]
  by_cases h1 : x=p.1
  · subst x; simp [σ,hp.2.2.1,hp.2.2.2,p]
  by_cases h2 : x=p.2
  · subst x; simp [σ,hp.2.2.1,hp.2.2.2,p]
  exact congrArg d (Equiv.swap_apply_of_ne_of_ne h1 h2)

theorem flip_witness (G H : GraphState n d) (hm : G≠H) (a : Anchor d) (ha : flip a G=H) :
    ∃ p : SwitchProposal n,validSwitch G.1 p ∧ proposalResult G.1 p=H.1 ∧
      a.1 ∈ SwitchPairFiber.crossingPairs p := by
  have sp := (pairSpec a).choose_spec
  have hH := congrArg Subtype.val ha
  have h := leaf_swap_witness G H hm _ _ sp.1 sp.2.2.1 sp.2.2.2 hH.symm
  obtain ⟨p,hp,hr,hc⟩ := h
  exact ⟨p,hp,hr,Eq.mp (congrArg (fun s => s ∈ SwitchPairFiber.crossingPairs p) sp.2.1.symm) hc⟩

def hits (G H : GraphState n d) : Finset (Anchor d) := Finset.univ.filter (fun a => flip a G=H)

theorem hits_at_most_two (G H : GraphState n d) (hm : G≠H) : (hits G H).card ≤ 2 := by
  classical
  by_cases ht : (hits G H).Nonempty
  · obtain ⟨a,ha⟩ := ht
    obtain ⟨p,hp,hr,_⟩ := flip_witness G H hm a (Finset.mem_filter.mp ha).2
    rw [← SwitchPairFiber.crossingPairs_card p hp]
    apply Finset.card_le_card_of_injOn (fun b : Anchor d => b.1) _ (fun _ _ _ _ h => Subtype.ext h)
    intro b hb
    obtain ⟨q,hq,hr',hbq⟩ := flip_witness G H hm b (Finset.mem_filter.mp hb).2
    have he := proposalResult_injective_on_valid hq hp (hr'.trans hr.symm)
    simpa [he] using hbq
  · simp [Finset.not_nonempty_iff_eq_empty.mp ht]

theorem leaf_count_le (d : Fin n → ℕ) (hn : 4≤n) :
    (leafPairs d).card ≤ 6*n.choose 4 := by
  have hL : (leaves d).card ≤ n := by
    simpa using Finset.card_le_univ (leaves d)
  have he := Nat.choose_mul (n:=n) (k:=4) (s:=2) (by decide)
  rw [show Nat.choose 4 2=6 by decide] at he
  norm_num at he
  have ht : 0 < (n-2).choose 2 := Nat.choose_pos (by omega)
  have h := Nat.mul_le_mul_left (n.choose 2) ht
  rw [leafPairs,Finset.card_powersetCard]
  exact (Nat.choose_le_choose 2 hL).trans (by nlinarith)

def rawLeaf (G H : GraphState n d) : ℝ :=
  if (leafPairs d).card=0 then (if G=H then 1 else 0)
  else ((hits G H).card : ℝ)/(leafPairs d).card

/-- With probability one half hold. Otherwise uniformly choose one unordered
leaf pair and relabel its two leaves. With fewer than two leaves the walk holds. -/
def lazyLeaf (G H : GraphState n d) : ℝ :=
  (if G=H then (1:ℝ)/2 else 0) + rawLeaf G H/2

theorem rawLeaf_le_one (G H : GraphState n d) : rawLeaf G H ≤ 1 := by
  unfold rawLeaf
  split_ifs with h h' <;> try norm_num
  apply (div_le_iff₀ (by exact_mod_cast Nat.pos_of_ne_zero h)).2
  rw [one_mul]
  exact_mod_cast (show (hits G H).card≤(leafPairs d).card by
    simpa using Finset.card_le_univ (hits G H))

theorem rawLeaf_row (G : GraphState n d) : (∑ H,rawLeaf G H)=1 := by
  classical
  by_cases h : (leafPairs d).card=0
  · simp [rawLeaf,h]
  · simp only [rawLeaf,h,ite_false,← Finset.sum_div,← Nat.cast_sum]
    have he : (∑ H : GraphState n d,(hits G H).card) = (leafPairs d).card := by
      have h' := Finset.sum_card_fiberwise_eq_card_filter
        (Finset.univ : Finset (Anchor d)) (Finset.univ : Finset (GraphState n d)) (fun a => flip a G)
      simpa [hits] using h'
    rw [he,div_self (by exact_mod_cast h)]

theorem lazyLeaf_stochastic : (∀ G H : GraphState n d, 0≤lazyLeaf G H) ∧
    ∀ G : GraphState n d, (∑ H,lazyLeaf G H)=1 := by
  constructor
  · intro G H; unfold lazyLeaf rawLeaf; split_ifs <;> positivity
  · intro G
    simp [lazyLeaf,Finset.sum_add_distrib,← Finset.sum_div,rawLeaf_row]
    norm_num

/-- Entrywise minorization of the published discrete kernel by the lazy uniform
leaf-transposition chain. The factor two on colliding leaf swaps is accounted for. -/
theorem leaf_minorization (hn : 4 ≤ n) (G H : GraphState n d) :
    ((leafPairs d).card : ℝ)/(12*(n.choose 4:ℝ)) * lazyLeaf G H ≤ switchKernel n d G H := by
  let Q : ℝ := 12*(n.choose 4 : ℝ)
  let c : ℕ := (leafPairs d).card
  have hQ : 0 < Q := by
    have : (0:ℝ) < n.choose 4 := by exact_mod_cast Nat.choose_pos hn
    dsimp [Q]; positivity
  have hc : (c:ℝ)/Q ≤ 1/2 := by
    apply (div_le_iff₀ hQ).2
    have h' : (c:ℝ)≤6*(n.choose 4:ℝ) := by exact_mod_cast leaf_count_le d hn
    dsimp [Q]; linarith
  change (c:ℝ)/Q * _ ≤ _
  by_cases h : G=H
  · subst H
    have hle : lazyLeaf G G ≤ 1 := by
      simp only [lazyLeaf,ite_true]; linarith [rawLeaf_le_one G G]
    exact ((mul_le_mul_of_nonneg_left hle (div_nonneg (Nat.cast_nonneg _) hQ.le)).trans_eq
      (mul_one _)).trans (hc.trans (switchKernel_self_ge_half G))
  · by_cases hc0 : c=0
    · rw [hc0]; simpa using switchKernel_nonneg G H
    have hcn : (c:ℝ) ≠ 0 := by exact_mod_cast hc0
    have hraw : (c:ℝ)/Q*lazyLeaf G H=((hits G H).card:ℝ)/(2*Q) := by
      simp only [lazyLeaf,h,ite_false,zero_add,rawLeaf]
      change (c:ℝ)/Q * ((if c=0 then _ else ((hits G H).card:ℝ)/c) / 2) = _
      rw [ite_eq_right hc0]
      field_simp
    rw [hraw]
    by_cases ht : (hits G H).Nonempty
    · obtain ⟨a,ha⟩ := ht
      obtain ⟨p,hvalid,hres,_⟩ := flip_witness G H h a (Finset.mem_filter.mp ha).2
      rw [switchKernel_of_ne h, ite_eq_left (show SwitchStep n d G H from ⟨p,hvalid,hres⟩)]
      change _ ≤ 1/Q
      have htwo : ((hits G H).card:ℝ)≤2 := by exact_mod_cast hits_at_most_two G H h
      apply (div_le_div_iff₀ (by positivity : 0 < 2*Q) hQ).2
      nlinarith [mul_nonneg (sub_nonneg.mpr htwo) hQ.le]
    · rw [Finset.not_nonempty_iff_eq_empty.mp ht]
      simpa using switchKernel_nonneg G H

#print axioms hits_at_most_two
#print axioms lazyLeaf_stochastic
#print axioms leaf_minorization
end OAI.Problem315.LeafTransfer
