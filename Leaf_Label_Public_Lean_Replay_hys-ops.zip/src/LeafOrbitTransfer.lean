import LeafOrbits

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

def permStep {X : Type*} [DecidableEq X] (e : Equiv.Perm X) : Matrix X X ℝ :=
  fun x y => if e x=y then 1 else 0

theorem step_commutes {X : Type*} [Fintype X] [DecidableEq X] (e : Equiv.Perm X)
    (K : Matrix X X ℝ) (hi : ∀ x y,K (e x) (e y)=K x y) : Commute (permStep e) K := by
  ext x y
  rw [Matrix.mul_apply,Matrix.mul_apply]
  classical
  have lhs : (∑ z,(if e x=z then (1:ℝ) else 0)*K z y)=K (e x) y := by simp [ite_mul]
  rw [show (∑ z,permStep e x z*K z y)=_ from lhs]
  simp only [permStep,mul_ite,mul_one,mul_zero,← e.eq_symm_apply,Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  simpa using hi x (e.symm y)

abbrev rawMatrix (d : Fin n → ℕ) : Matrix (GraphState n d) (GraphState n d) ℝ := rawLeaf

theorem raw_expr (d : Fin n → ℕ) : rawMatrix d =
    if (leafPairs d).card=0 then 1
    else (((leafPairs d).card:ℝ)⁻¹) • ∑ a : Anchor d, permStep (anchorPerm a) := by
  ext G H
  by_cases hz : (leafPairs d).card=0
  · simp [rawMatrix,rawLeaf,hz,Matrix.one_apply]
  · simp only [rawMatrix,rawLeaf,hz,ite_false,Matrix.smul_apply,smul_eq_mul,Matrix.sum_apply,permStep]
    rw [Finset.sum_boole,div_eq_inv_mul]
    simp [hits,flip_eq]

theorem iid_expr (d : Fin n → ℕ) : iidMatrix d =
    ((leaves d).card:ℝ)⁻¹ • (1 : Matrix (GraphState n d) (GraphState n d) ℝ) +
      (1-((leaves d).card:ℝ)⁻¹) • rawMatrix d := by
  ext G H
  change (if G=H then _ else _) + _ = _ + (1-((leaves d).card:ℝ)⁻¹)*rawLeaf G H
  by_cases h : G=H <;> simp [Matrix.one_apply,h]

theorem iid_commutes (d : Fin n → ℕ) : Commute (iidMatrix d) (chain d) := by
  rw [iid_expr,raw_expr]
  apply Commute.add_left ((Commute.one_left _).smul_left _)
  apply Commute.smul_left
  split_ifs
  · exact Commute.one_left _
  · apply Commute.smul_left
    apply Commute.sum_left
    intro a _
    exact step_commutes (anchorPerm a) _ (switchKernel_labelEquiv _ (preserves _ (swap_fixes a)))

theorem hits_symm (G H : GraphState n d) : hits G H=hits H G := by
  ext a
  simp only [hits,Finset.mem_filter,Finset.mem_univ,true_and]
  constructor
  · rintro rfl; exact flip_invol _ _
  · rintro rfl; exact (flip_invol _ _)

theorem iid_symm (G H : GraphState n d) : iidLeaf G H=iidLeaf H G := by
  by_cases h : G=H
  · subst H; rfl
  · simp [iidLeaf,rawLeaf,h,Ne.symm h,hits_symm G H]

theorem iid_fiber_supported (G H : GraphState n d) (h : orbitMap G≠orbitMap H) :
    iidLeaf G H=0 := by
  have hne : G≠H := fun e => h (congrArg orbitMap e)
  have hh : hits G H=∅ := by
    apply Finset.eq_empty_iff_forall_notMem.mpr
    intro a ha
    have he := (Finset.mem_filter.mp ha).2
    exact h ((orbit_eq _ _).mpr ⟨vertexSwap a,swap_fixes a,(flip_eq a G).symm.trans he⟩)
  simp [iidLeaf,rawLeaf,hne,hh]

theorem iid_orbit_absorbs (d : Fin n → ℕ) : avg orbitMap * iidMatrix d = avg orbitMap := by
  apply avg_absorbs _ _ iid_fiber_supported
  intro G
  simp_rw [show ∀ H : GraphState n d,iidMatrix d H G=iidMatrix d G H from fun H => iid_symm H G]
  exact iidLeaf_stochastic.2 G

theorem graph_orbit_transfer (hn : 4 ≤ n) (t : ℕ) (G : GraphState n d) :
    tv (((chain d)^t) G) (unif (GraphState n d)) ≤
      tv (push orbitMap (((chain d)^t) G)) (push orbitMap (unif (GraphState n d))) +
      ∑ k ∈ Finset.range (t+1), weight t k (iidClock d)*tv (((iidMatrix d)^k) G) (avg orbitMap G) :=
  leaf_quotient_transfer d hn orbitMap orbit_surjective (iid_commutes d) (iid_orbit_absorbs d)
    (orbit_commute _ _ chain_orbit_invariant) t G

#print axioms iid_commutes
#print axioms iid_orbit_absorbs
#print axioms graph_orbit_transfer
end OAI.Problem315.LeafOrbit
