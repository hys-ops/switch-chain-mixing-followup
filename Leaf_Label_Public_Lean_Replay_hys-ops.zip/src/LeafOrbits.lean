import LeafEquivariance
import OrbitAveraging

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

/-- A permitted relabeling fixes every vertex whose degree differs from one. -/
def FixesCore (d : Fin n → ℕ) (σ : Equiv.Perm (Fin n)) := ∀ i,d i≠1 → σ i=i

theorem preserves (σ : Equiv.Perm (Fin n)) (hσ : FixesCore d σ) : ∀ v,d (σ v)=d v := by
  intro v
  by_cases hv : d v=1
  · rw [hv]
    by_contra h
    have h' := σ.injective (hσ (σ v) h)
    exact h ((congrArg d h').trans hv)
  · rw [hσ v hv]

theorem fixed_symm (σ : Equiv.Perm (Fin n)) (hσ : FixesCore d σ) : FixesCore d σ.symm := by
  intro i hi
  exact σ.symm_apply_eq.mpr (hσ i hi).symm

def graphPerm (σ : Equiv.Perm (Fin n)) (hf : FixesCore d σ) : Equiv.Perm (GraphState n d) :=
  labelEquiv σ (preserves σ hf)

def orbitRel (G H : GraphState n d) : Prop :=
  ∃ (σ : Equiv.Perm (Fin n)) (hf : FixesCore d σ), graphPerm σ hf G = H

theorem orbit_refl (G : GraphState n d) : orbitRel G G := by
  refine ⟨1,fun _ _ => rfl,?_⟩
  apply Subtype.ext; ext; rfl

theorem orbit_symm {G H : GraphState n d} : orbitRel G H → orbitRel H G := by
  rintro ⟨σ,hf,rfl⟩
  refine ⟨σ.symm,fixed_symm σ hf,?_⟩
  apply Subtype.ext; ext u v
  simp [graphPerm,labelEquiv]

theorem orbit_trans {G H K : GraphState n d} : orbitRel G H → orbitRel H K → orbitRel G K := by
  rintro ⟨σ,hσ,rfl⟩ ⟨τ,hτ,rfl⟩
  refine ⟨σ*τ,fun v hv => ?_,rfl⟩
  change σ (τ v) = v
  rw [hτ v hv,hσ v hv]

def leafSetoid (d : Fin n → ℕ) : Setoid (GraphState n d) where
  r := orbitRel
  iseqv := ⟨orbit_refl,orbit_symm,orbit_trans⟩

abbrev LeafQuot (d : Fin n → ℕ) := Quotient (leafSetoid d)
def orbitMap (G : GraphState n d) : LeafQuot d := Quotient.mk (leafSetoid d) G
theorem orbit_surjective : Function.Surjective (orbitMap (d:=d)) := Quotient.mk_surjective
instance : Fintype (LeafQuot d) := Fintype.ofSurjective _ orbit_surjective
noncomputable instance : DecidableEq (LeafQuot d) := Classical.decEq _
theorem orbit_eq (G H : GraphState n d) : orbitMap G=orbitMap H ↔ orbitRel G H := Quotient.eq

theorem chain_orbit_invariant : OrbitInvariant (orbitMap (d:=d)) (chain d) := by
  intro G H h
  obtain ⟨σ,hf,he⟩ := (orbit_eq G H).mp h
  exact ⟨graphPerm σ hf,he,fun Z => ((orbit_eq Z _).mpr ⟨σ,hf,rfl⟩).symm,
    switchKernel_labelEquiv σ (preserves σ hf)⟩

/-- A public reconstruction of the unordered anchor; existential witnesses in
Lean's choice are invariant under replacement of a proof of the same proposition. -/
theorem anchor_spec (a : Anchor d) :
    ∃ p : Fin n × Fin n,p.1≠p.2 ∧ a.1={p.1,p.2} ∧ d p.1=1 ∧ d p.2=1 := by
  obtain ⟨hsub,hcard⟩ := Finset.mem_powersetCard.mp a.2
  obtain ⟨i,j,hi,he⟩ := Finset.card_eq_two.mp hcard
  have h1 : i ∈ a.1 := by rw [he]; simp
  have h2 : j ∈ a.1 := by rw [he]; simp
  exact ⟨(i,j),hi,he,(Finset.mem_filter.mp (hsub h1)).2,(Finset.mem_filter.mp (hsub h2)).2⟩

def vertexSwap (a : Anchor d) := Equiv.swap (anchor_spec a).choose.1 (anchor_spec a).choose.2

theorem swap_fixes (a : Anchor d) : FixesCore d (vertexSwap a) := by
  intro i hi
  have hp := (anchor_spec a).choose_spec
  exact Equiv.swap_apply_of_ne_of_ne (fun h => hi (h ▸ hp.2.2.1)) (fun h => hi (h ▸ hp.2.2.2))

def anchorPerm (a : Anchor d) : Equiv.Perm (GraphState n d) := graphPerm (vertexSwap a) (swap_fixes a)

theorem flip_eq (a : Anchor d) (G : GraphState n d) : flip a G=anchorPerm a G := by
  apply Subtype.ext; rfl

theorem flip_invol (a : Anchor d) (G : GraphState n d) : flip a (flip a G)=G := by
  apply Subtype.ext; ext x y
  change G.1.Adj (Equiv.swap _ _ (Equiv.swap _ _ x)) (Equiv.swap _ _ (Equiv.swap _ _ y)) ↔ G.1.Adj x y
  simp

#print axioms chain_orbit_invariant
#print axioms flip_eq
end OAI.Problem315.LeafOrbit
