import LeafAction
import LeafShuffleMatrix

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

theorem step_apply {X : Type*} [Fintype X] [DecidableEq X] (e : Equiv.Perm X) (f : X→ℝ) (x : X) :
    (permStep e *ᵥ f) x = f (e x) := by simp [Matrix.mulVec,dotProduct,permStep,ite_mul]

theorem iid_apply (hN : 2≤(leaves d).card) (f : GraphState n d → ℝ) (G : GraphState n d) :
    (iidMatrix d *ᵥ f) G =
      (∑ i:LeafLabel d,∑ j:LeafLabel d,f (act (Equiv.swap i j) G))/((leaves d).card:ℝ)^2 := by
  let N : ℝ := (leaves d).card
  let C : ℝ := (leafPairs d).card
  let F (g : LeafGroup d) := f (act g G)
  let B (a : Anchor d) := f (anchorPerm a G)
  have hsplit := pair_sum F B (fun i j a ha => congrArg f ((act_swap_flip i j a ha G).trans (flip_eq a G)))
  have hdecomp (i j : LeafLabel d) : F (Equiv.swap i j) =
      (if i=j then f G else 0) + (if i≠j then F (Equiv.swap i j) else 0) := by
    by_cases h : i=j
    · subst j; simp [F]; exact congrArg f (act_one G)
    · simp [h]
  have htotal : (∑ i:LeafLabel d,∑ j:LeafLabel d,F (Equiv.swap i j))=
      N*f G+2*(∑ a:Anchor d,B a) := by
    conv_lhs => enter [2,i,2,j]; rw [hdecomp]
    simp only [Finset.sum_add_distrib,Finset.sum_ite_eq,Finset.mem_univ,ite_true,Finset.sum_const,
      Finset.card_univ,Fintype.card_coe,nsmul_eq_mul,hsplit,N]
  have hcn : (leafPairs d).card≠0 := by
    rw [leafPairs,Finset.card_powersetCard]; exact (Nat.choose_pos hN).ne'
  have hc : C = N*(N-1)/2 := by simp [C,N,leafPairs,Nat.cast_choose_two]
  have hC : C≠0 := by dsimp [C]; exact_mod_cast hcn
  have hNr : N≠0 := by dsimp [N]; exact_mod_cast (show (leaves d).card≠0 by omega)
  rw [iid_expr,raw_expr,ite_eq_right hcn,Matrix.add_mulVec,Matrix.smul_mulVec,Matrix.smul_mulVec,
    Matrix.smul_mulVec,Matrix.one_mulVec,Matrix.sum_mulVec]
  simp only [Pi.add_apply,Pi.smul_apply,smul_eq_mul,Finset.sum_apply,step_apply]
  change N⁻¹*f G+(1-N⁻¹)*(C⁻¹*(∑ a:Anchor d,B a))=(∑ i:LeafLabel d,∑ j:LeafLabel d,F (Equiv.swap i j))/N^2
  rw [htotal]
  field_simp
  nlinarith [congrArg (fun x : ℝ => 2*x*(∑ a:Anchor d,B a)) hc]

theorem shuffle_lift (hN : 2≤(leaves d).card) (G : GraphState n d) (f : GraphState n d → ℝ) :
    (LeafMark.shuffle (LeafLabel d) *ᵥ fun x => f (act x G))=
    fun x => (iidMatrix d *ᵥ f) (act x G) := by
  funext x
  rw [LeafMark.shuffle_apply,iid_apply hN]
  simp [act_mul]

theorem shuffle_pow_lift (hN : 2≤(leaves d).card) (G : GraphState n d) (f : GraphState n d → ℝ) (k : ℕ) :
    ((LeafMark.shuffle (LeafLabel d))^k *ᵥ fun x => f (act x G)) =
    fun x => ((iidMatrix d)^k *ᵥ f) (act x G) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [pow_succ',pow_succ',← Matrix.mulVec_mulVec,ih,shuffle_lift hN,← Matrix.mulVec_mulVec]

theorem shuffle_row_push (hN : 2≤(leaves d).card) (G : GraphState n d) (k : ℕ) :
    push (fun g : LeafGroup d => act g G) (((LeafMark.shuffle (LeafLabel d))^k) 1) =
    ((iidMatrix d)^k) G := by
  funext H
  have h := congrFun (shuffle_pow_lift hN G (fun z => if z=H then (1:ℝ) else 0) k) 1
  simpa [Matrix.mulVec,dotProduct,mul_ite,push,act_one] using h

#print axioms iid_apply
#print axioms shuffle_row_push
end OAI.Problem315.LeafOrbit
