import MarkovTV
import Mathlib.GroupTheory.Perm.Finite
open scoped BigOperators Matrix
noncomputable section
namespace LeafMark
def shuffle (A : Type*) [Fintype A] [DecidableEq A] : Matrix (Equiv.Perm A) (Equiv.Perm A) ℝ :=
  fun x y => (∑ i:A, ∑ j:A, if x*Equiv.swap i j=y then (1:ℝ) else 0) / (Fintype.card A : ℝ)^2
variable {A : Type*} [Fintype A] [DecidableEq A]
abbrev G (A : Type*) := Equiv.Perm A
theorem shuffle_apply (f : G A → ℝ) (x : G A) :
  (shuffle A *ᵥ f) x = (∑ i:A, ∑ j:A, f (x*Equiv.swap i j))/(Fintype.card A:ℝ)^2 := by
  classical
  simp only [shuffle,Matrix.mulVec,dotProduct,div_mul_eq_mul_div,← Finset.sum_div,Finset.sum_mul]
  congr 1
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  rw [Finset.sum_comm]
  simp [ite_mul]
end LeafMark
