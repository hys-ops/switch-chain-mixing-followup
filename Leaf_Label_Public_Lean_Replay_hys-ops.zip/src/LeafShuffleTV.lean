import LeafShuffleLift

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

theorem push_sum {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (π : X→Y) (f : X→ℝ) : ∑ y,push π f y=∑ x,f x := by
  classical
  simp [push,Finset.sum_comm (s:=Finset.univ) (t:=Finset.univ) (f:=fun y x => if π x=y then f x else 0)]

theorem tv_push_le {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (π : X→Y) (a b : X→ℝ) : tv (push π a) (push π b) ≤ tv a b := by
  classical
  unfold tv
  apply div_le_div_of_nonneg_right _ (by norm_num)
  rw [← push_sum π (fun x => |a x-b x|)]
  apply Finset.sum_le_sum
  intro y _
  unfold push
  rw [← Finset.sum_sub_distrib]
  apply (Finset.abs_sum_le_sum_abs _ _).trans_eq
  apply Finset.sum_congr rfl
  intro x _
  by_cases h : π x=y <;> simp [h]

theorem uniform_group_push (G : GraphState n d) :
    push (fun g : LeafGroup d => act g G) (unif (LeafGroup d)) = avg orbitMap G := by
  let π := fun g : LeafGroup d => act g G
  let u := push π (unif (LeafGroup d))
  have const_on (A B : GraphState n d) (hs : orbitMap A=orbitMap B) : u A=u B := by
    obtain ⟨h,rfl⟩ := (exists_act A B).mp hs
    change (∑ g:LeafGroup d, if act g G = A then 1/(Fintype.card (LeafGroup d):ℝ) else 0) =
      ∑ g:LeafGroup d, if act g G = act h A then 1/(Fintype.card (LeafGroup d):ℝ) else 0
    rw [← Equiv.sum_comp (Equiv.mulRight h) (fun g : LeafGroup d =>
      if act g G=act h A then 1/(Fintype.card (LeafGroup d):ℝ) else 0)]
    simp [act_mul]
  have hon (H : GraphState n d) (h : orbitMap G≠orbitMap H) : u H=0 := by
    apply Finset.sum_eq_zero
    intro g _
    apply ite_eq_right
    exact fun he => h ((exists_act G H).mpr ⟨g,he⟩)
  have point (H : GraphState n d) : u H=if orbitMap H=orbitMap G then u G else 0 := by
    by_cases h : orbitMap H=orbitMap G
    · simp [h,const_on H G h]
    · simp [h,hon H (Ne.symm h)]
  have hnorm : (∑ H,u H)=1 := by
    rw [show u=push π (unif (LeafGroup d)) from rfl,push_sum]
    simp [unif,ne_of_gt (Nat.cast_pos.mpr Fintype.card_pos)]
  have hcount : (fiberSize orbitMap (orbitMap G):ℝ)*u G=1 := by
    rw [← hnorm]
    conv_rhs => enter [2,H]; rw [point H]
    exact (push_const orbitMap (u G) (orbitMap G)).symm
  have hu : u G=1/(fiberSize orbitMap (orbitMap G):ℝ) := by
    apply (eq_div_iff (by exact_mod_cast (fiberSize_pos orbitMap G).ne')).2
    simpa [mul_comm] using hcount
  funext H
  change u H=_
  by_cases h : orbitMap H=orbitMap G
  · simp [point H,h,hu,avg]
  · simp [point H,h,Ne.symm h,avg]

theorem fiber_tv_le_shuffle (hN : 2≤(leaves d).card) (G : GraphState n d) (k : ℕ) :
    tv (((iidMatrix d)^k) G) (avg orbitMap G) ≤
      tv (((LeafMark.shuffle (LeafLabel d))^k) 1) (unif (LeafGroup d)) := by
  rw [← shuffle_row_push hN,← uniform_group_push]
  exact tv_push_le _ _ _

theorem graph_shuffle_transfer (hn : 4 ≤ n) (hN : 2≤(leaves d).card) (t : ℕ) (G : GraphState n d) :
    tv (((chain d)^t) G) (unif (GraphState n d)) ≤
      tv (push orbitMap (((chain d)^t) G)) (push orbitMap (unif (GraphState n d))) +
      ∑ k ∈ Finset.range (t+1), weight t k (iidClock d) *
        tv (((LeafMark.shuffle (LeafLabel d))^k) 1) (unif (LeafGroup d)) := by
  apply (graph_orbit_transfer hn t G).trans
  apply add_le_add_right
  apply Finset.sum_le_sum
  intro k _
  apply mul_le_mul_of_nonneg_left (fiber_tv_le_shuffle hN G k)
  apply weight_nonneg (by unfold iidClock; positivity)
  exact (iid_leaf_weight_bound hn).trans (by norm_num)

#print axioms uniform_group_push
#print axioms fiber_tv_le_shuffle
#print axioms graph_shuffle_transfer
end OAI.Problem315.LeafOrbit
