import Shape
namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ}

private lemma swap_fixed {G : SimpleGraph (Fin n)} {s t : Fin n}
    (same : ∀ z,z≠s → z≠t → (G.Adj s z ↔ G.Adj t z)) : G.comap (Equiv.swap s t)=G := by
  ext x y; change G.Adj (Equiv.swap s t x) (Equiv.swap s t y) ↔ G.Adj x y
  by_cases e : s=t
  · subst t;simp
  by_cases h1 : x=s <;> by_cases h2 : x=t <;> by_cases h3 : y=s <;> by_cases h4 : y=t <;>
    subst_vars <;> simp_all [Equiv.swap_apply_def,G.adj_comm]
  exact (same x h1 h2).symm.trans (G.adj_comm _ _)

/-- Interchanging any two degree-one labels is either the identity on the graph,
or the result of one actual valid proposal from the source's switch chain. -/
theorem leaf_swap {d : Fin n → ℕ} (S : GraphState n d) (s t : Fin n)
    (hs : d s=1) (ht : d t=1) : S.val.comap (Equiv.swap s t)=S.val ∨
      ∃ p : SwitchProposal n, validSwitch S.val p ∧ proposalResult S.val p=S.val.comap (Equiv.swap s t) := by
  let G:=S.val
  obtain ⟨u,hsu,hU⟩ := one_neighbor S hs
  obtain ⟨v,htv,hV⟩ := one_neighbor S ht
  have ls (z) : G.Adj s z ↔ z=u := ⟨fun h => hU _ h,fun e=> e ▸ hsu⟩
  have lt (z) : G.Adj t z ↔ z=v := ⟨fun h => hV _ h,fun e=> e ▸ htv⟩
  by_cases hst : s=t
  · subst t;left;ext x y;simp
  by_cases huv : u=v
  · left;apply swap_fixed;intro z _ _; change G.Adj s z ↔ G.Adj t z;rw [ls,lt,huv]
  by_cases hut : u=t
  · subst u;have hsv := hV _ hsu.symm;subst v
    left;apply swap_fixed;intro z hzs hzt;change G.Adj s z ↔ G.Adj t z;simp [ls,lt,hzs,hzt]
  have hsv : s≠v := by intro h;subst v;exact hut (hU _ htv.symm).symm
  have hf : FourDistinct s u v t := ⟨hsu.ne,hsv,hst,huv,hut,htv.ne.symm⟩
  have hn₁ : ¬G.Adj s v := fun h=> huv (hU _ h).symm
  have hn₂ : ¬G.Adj u t := fun h=> huv (hV _ h.symm)
  right;refine ⟨fourVertexProposal s u v t hf,(validSwitch_fourVertexProposal_iff _ _ _ _ _ _).2 ⟨hsu,htv.symm,hn₁,hn₂⟩,?_⟩
  let P:=proposalResult G (fourVertexProposal s u v t hf)
  let J:=G.comap (Equiv.swap s t)
  have eqfixed (z w : Fin n) (hws : w ≠ s) (hwt : w≠t) : (Equiv.swap s t z=w) ↔ z=w := by
    have hw : Equiv.swap s t w=w := Equiv.swap_apply_of_ne_of_ne hws hwt
    conv_lhs => rhs;rw [←hw]
    exact (Equiv.swap s t).injective.eq_iff
  have rs (z) : P.Adj s z ↔ J.Adj s z := by
    change (proposalResult G _).Adj s z ↔ G.Adj (Equiv.swap s t s) (Equiv.swap s t z)
    rw [proposalResult_fourVertex_adj_first G s u v t hf hsu htv.symm hn₁ hn₂,Equiv.swap_apply_left,ls,lt,eqfixed z v hsv.symm htv.ne.symm]
    tauto
  have rt (z) : P.Adj t z ↔ J.Adj t z := by
    change (proposalResult G _).Adj t z ↔ G.Adj (Equiv.swap s t t) (Equiv.swap s t z)
    rw [proposalResult_fourVertex_adj G s u v t hf hsu htv.symm hn₁ hn₂,Equiv.swap_apply_right,ls,lt,eqfixed z u hsu.ne.symm hut]
    simp only [Ne.symm hst,Ne.symm hut,htv.ne,false_and,false_or,true_and,eq_self];tauto
  change P=J
  ext x y
  by_cases hx : x=s
  · subst x; exact rs y
  by_cases hxt : x=t
  · subst x; exact rt y
  by_cases hy : y=s
  · subst y;exact (P.adj_comm _ _).trans ((rs x).trans (J.adj_comm _ _))
  by_cases hyt : y=t
  · subst y;exact (P.adj_comm _ _).trans ((rt x).trans (J.adj_comm _ _))
  change (proposalResult G _).Adj x y ↔ G.Adj (Equiv.swap s t x) (Equiv.swap s t y)
  rw [proposalResult_fourVertex_adj G s u v t hf hsu htv.symm hn₁ hn₂,Equiv.swap_apply_of_ne_of_ne hx hxt,Equiv.swap_apply_of_ne_of_ne hy hyt]
  simp [hx,hxt,hy,hyt]
#print axioms leaf_swap
end
end TwoHub
