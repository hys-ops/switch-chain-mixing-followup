import OAI.Probability.SwitchChain.PairTradeSwitch
import OAI.Probability.SwitchChain.ProposalUniqueness
import OAI.Probability.SwitchChain.KernelNormalization

open scoped BigOperators
noncomputable section
namespace OAI.Problem315.LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}
private theorem unique_neighbor (G : GraphState n d) (i : Fin n) (hi : d i=1) :
    ∃ u : Fin n, ∀ x, G.1.Adj i x ↔ x=u := by
  have hc : (Finset.univ.filter (G.1.Adj i)).card=1 := (G.2 i).trans hi
  obtain ⟨u,hu⟩ := Finset.card_eq_one.mp hc
  refine ⟨u,fun x => ?_⟩
  have hm : x ∈ Finset.univ.filter (G.1.Adj i) ↔ x ∈ ({u}: Finset (Fin n)) := by rw [hu]
  simpa using hm

private theorem rows_ext (A B : SimpleGraph (Fin n)) (i j : Fin n)
    (hi : ∀ w,A.Adj i w ↔ B.Adj i w) (hj : ∀ w,A.Adj j w ↔ B.Adj j w)
    (ho : ∀ x y,x≠i → x≠j → y≠i → y≠j → (A.Adj x y ↔ B.Adj x y)) : A=B := by
  ext x y
  by_cases hxi : x=i
  · subst x; exact hi y
  by_cases hxj : x=j
  · subst x; exact hj y
  by_cases hyi : y=i
  · subst y; exact (A.adj_comm x i).trans ((hi x).trans (B.adj_comm i x))
  by_cases hyj : y=j
  · subst y; exact (A.adj_comm x j).trans ((hj x).trans (B.adj_comm j x))
  exact ho x y hxi hxj hyi hyj

private theorem twin_fixed (G : SimpleGraph (Fin n)) (i j : Fin n) (hij : i≠j)
    (ht : ∀ w,w≠i → w≠j → (G.Adj i w ↔ G.Adj j w)) : G.comap (Equiv.swap i j)=G := by
  apply rows_ext _ _ i j
  · intro w
    by_cases hwi : w=i
    · subst w; simp
    by_cases hwj : w=j
    · subst w; simp [SimpleGraph.adj_comm]
    simpa [Equiv.swap_apply_of_ne_of_ne hwi hwj] using (ht w hwi hwj).symm
  · intro w
    by_cases hwi : w=i
    · subst w; simp [SimpleGraph.adj_comm]
    by_cases hwj : w=j
    · subst w; simp
    simpa [Equiv.swap_apply_of_ne_of_ne hwi hwj] using ht w hwi hwj
  · intro x y hxi hxj hyi hyj
    simp [Equiv.swap_apply_of_ne_of_ne hxi hxj,Equiv.swap_apply_of_ne_of_ne hyi hyj]

/-- A nontrivial exchange of two leaves has an actual valid switch witness,
and the exchanged leaf pair is one of this proposal's two crossing pairs. -/
theorem leaf_swap_witness (G H : GraphState n d) (hm : G≠H)
    (i j : Fin n) (hij : i≠j) (di : d i=1) (dj : d j=1)
    (hH : H.1=G.1.comap (Equiv.swap i j)) :
    ∃ p : SwitchProposal n, validSwitch G.1 p ∧ proposalResult G.1 p=H.1 ∧
      ({i,j} : Finset (Fin n)) ∈ SwitchPairFiber.crossingPairs p := by
  obtain ⟨u,hu⟩ := unique_neighbor G i di
  obtain ⟨v,hv⟩ := unique_neighbor G j dj
  have hne : G.1.comap (Equiv.swap i j) ≠ G.1 :=
    fun h => hm (Subtype.ext (hH.trans h).symm)
  have hnij : ¬G.1.Adj i j := by
    intro ha
    apply hne (twin_fixed G.1 i j hij ?_)
    intro w hwi hwj
    rw [hu,hv,← (hu j).1 ha,← (hv i).1 ha.symm]
    simp [hwi,hwj]
  have huv : u≠v := by
    intro h
    apply hne (twin_fixed G.1 i j hij ?_)
    intro w _ _
    rw [hu,hv,h]
  have hiu : G.1.Adj i u := (hu _).2 rfl
  have hjv : G.1.Adj j v := (hv _).2 rfl
  have hju : j≠u := fun h => hnij ((hu j).2 h)
  have hiv : i≠v := fun h => hnij (((hv i).2 h).symm)
  have hdist : FourDistinct i u v j :=
    ⟨G.1.ne_of_adj hiu,hiv,hij,huv,hju.symm,(G.1.ne_of_adj hjv).symm⟩
  have hnv : ¬G.1.Adj i v := fun h => huv ((hu v).1 h).symm
  have hnu : ¬G.1.Adj u j := fun h => huv ((hv u).1 h.symm)
  let p := fourVertexProposal i u v j hdist
  refine ⟨p,(validSwitch_fourVertexProposal_iff ..).2 ⟨hiu,hjv.symm,hnv,hnu⟩,
    ?_,PairFiber.fourVertexProposal_mem_crossingPairs i u v j hdist⟩
  rw [hH]
  have pre (b : Fin n) (hbi : b≠i) (hbj : b≠j) (w : Fin n) :
      Equiv.swap i j w = b ↔ w=b := by
    calc
      _ ↔ Equiv.swap i j w=Equiv.swap i j b := by rw [Equiv.swap_apply_of_ne_of_ne hbi hbj]
      _ ↔ _ := (Equiv.swap i j).injective.eq_iff
  have hiu' := G.1.ne_of_adj hiu
  have hjv' := G.1.ne_of_adj hjv
  apply rows_ext _ _ i j
  · intro w
    rw [proposalResult_fourVertex_adj_first _ _ _ _ _ hdist hiu hjv.symm hnv hnu,hu]
    simp only [SimpleGraph.comap_adj,Equiv.swap_apply_left,hv,pre v hiv.symm hjv'.symm]
    tauto
  · intro w
    rw [proposalResult_fourVertex_adj _ _ _ _ _ hdist hiu hjv.symm hnv hnu,hv]
    simp only [SimpleGraph.comap_adj,Equiv.swap_apply_right,hu,pre u hiu'.symm hju.symm]
    simp [hij.symm,hju,hjv']
  · intro x y hxi hxj hyi hyj
    rw [proposalResult_fourVertex_adj _ _ _ _ _ hdist hiu hjv.symm hnv hnu]
    simp [hxi,hxj,hyi,hyj,Equiv.swap_apply_of_ne_of_ne hxi hxj,
      Equiv.swap_apply_of_ne_of_ne hyi hyj]

#print axioms leaf_swap_witness
end OAI.Problem315.LeafTransfer
