import PortCount
namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ}
lemma valid_complement (G : SimpleGraph (Fin n)) (p : SwitchProposal n) :
   validSwitch G p ↔ validSwitch Gᶜ (reverseProposal p) := by
  constructor
  · intro h;constructor
    · intro u v hN; change (addedMatching p).Adj u v at hN
      exact ⟨hN.ne,h.2 hN⟩
    · intro u v hM hh; change (removedMatching p).Adj u v at hM
      exact hh.2 (h.1 hM)
  · intro h;constructor
    · intro u v hM;by_contra hn;exact h.2 hM ⟨hM.ne,hn⟩
    · intro u v hN;exact (h.1 hN).2

lemma loss_gain (G : SimpleGraph (Fin n)) (p : SwitchProposal n) {a c : Fin n} (h : G.Adj a c) :
    ¬(proposalResult G p).Adj a c ↔ (proposalResult Gᶜ (reverseProposal p)).Adj a c := by
  have hc : ¬Gᶜ.Adj a c := fun hh => hh.2 h
  by_cases hp : validSwitch G p
  · have hr := removedMatching_adj_iff hp a c
    have ht := addedMatching_adj_iff ((valid_complement _ _).mp hp) a c
    rw [addedMatching_reverse] at ht
    tauto
  · have hp' := mt (valid_complement G p).mpr hp
    simp [proposalResult,hp,hp',h,hc]

def lostEquiv {G : SimpleGraph (Fin n)} {a c : Fin n} (h : G.Adj a c) :
    {p : SwitchProposal n // ¬(proposalResult G p).Adj a c} ≃ Gains Gᶜ a c where
  toFun p := ⟨reverseProposal p.1,(loss_gain _ _ h).mp p.2⟩
  invFun p := ⟨reverseProposal p.1,(loss_gain _ _ h).mpr (by simpa using p.2)⟩
  left_inv p := Subtype.ext (reverseProposal_reverse _)
  right_inv p := Subtype.ext (reverseProposal_reverse _)

private lemma same_filter {α : Type*} (s : Finset α) {f g : α → Prop} {i : DecidablePred f} {j : DecidablePred g} (h : ∀x,f x ↔ g x) : @Finset.filter _ f i s = @Finset.filter _ g j s := by
  obtain rfl : f=g := funext fun x => propext (h x)
  obtain rfl : i=j := Subsingleton.elim _ _;rfl

lemma mass_loss {d : Fin n → ℕ} (G : GraphState n d) {a c : Fin n} (h : G.val.Adj a c) :
  ∑ H∈(allGraphStates n d).filter (fun H => ¬H.val.Adj a c),switchKernel n d G H =
    (Fintype.card (Ports G.valᶜ a c):ℝ)/(12*(n.choose 4:ℝ)) := by
  trans (((allProposals n).filter (fun p => ¬(proposalResult G.val p).Adj a c)).card:ℝ)/(12*(n.choose 4:ℝ))
  · convert! mass_of_event G (fun H => ¬H.val.Adj a c) (not_not.mpr h) using 1 <;> congr 2
    apply congrArg Finset.card
    exact same_filter _ (fun _ => Iff.rfl)
  congr 1
  have hi := (lostEquiv h).trans (gainEquiv (show ¬G.valᶜ.Adj a c from fun hh => hh.2 h)).symm
  have hk := Fintype.card_congr hi
  rw [Fintype.card_subtype] at hk
  exact_mod_cast hk

#print axioms mass_loss
end
end TwoHub
