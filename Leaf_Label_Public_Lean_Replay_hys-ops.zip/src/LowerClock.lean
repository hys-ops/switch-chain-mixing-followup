import UpstreamDrift
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Nat.Choose.Bounds
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace LeafDrift

/-- A bad state has relatively few of the originally marked neighbors. -/
theorem log_potential_barrier {h r z : ℝ} (hh : 25≤h) (hr : h≤r)
    (hz : 0≤z) (hbad : z≤4*r/h) :
    Real.log h/2 ≤ Real.log ((r+1)/(z+1)) := by
  have hp : 0<h := by linarith
  have rp : 0<r := by linarith
  have hz1 : 0<z+1 := by linarith
  have hbk := (le_div_iff₀ hp).mp hbad
  have lower : h/5≤(r+1)/(z+1) := by
    apply (le_div_iff₀ hz1).mpr
    nlinarith
  have hp5 : 0<h/5 := by positivity
  have hsq : h≤(h/5)^2 := by nlinarith [mul_nonneg hp.le (sub_nonneg.mpr hh)]
  have hl := Real.log_le_log hp hsq
  rw [Real.log_pow] at hl
  linarith [Real.log_le_log hp5 lower]

theorem harmonic_clock {Q N h r c mu : ℝ} {t : ℕ}
    (hh : 25≤h) (hr : h≤r) (hQ : 0<Q) (hN : 0<N)
    (hc : c≤2*N/Q) (hm : mu≤r/h) (ht : (t:ℝ) ≤ Q*Real.log h/(16*N)) :
    (1:ℝ)/2 ≤ 1-(t:ℝ)*c/(Real.log h/2)-mu/(4*r/h) := by
  have hp : 0<h := by linarith
  have rp : 0<r := by linarith
  have hlog : 0<Real.log h := Real.log_pos (by linarith)
  have hb : 0<4*r/h := by positivity
  have e1 : mu/(4*r/h) ≤ 1/4 := (div_le_iff₀ hb).mpr (hm.trans_eq (by ring))
  have e2 : (t:ℝ)*c ≤ Real.log h/8 := by
    calc
      _ ≤ (t:ℝ)*(2*N/Q) := mul_le_mul_of_nonneg_left hc (by positivity)
      _ ≤ (Q*Real.log h/(16*N))*(2*N/Q) :=
        mul_le_mul_of_nonneg_right ht (by positivity)
      _ = _ := by field_simp; ring
  have ee : (t:ℝ)*c/(Real.log h/2)≤1/4 := (div_le_iff₀ (by positivity)).mpr (by linarith)
  linarith

theorem marked_lower {n : ℕ} {d : Fin n → ℕ} (hn : 4≤n)
    (Z : GraphState n d → ℝ) (G : GraphState n d)
    {Q N h r c : ℝ} (hh : 25≤h) (hr : h≤r) (hQ : 0<Q) (hN : 0<N)
    (hc : c≤2*N/Q) (hZ : ∀ y, 0≤Z y) (hle : ∀ y,Z y≤r) (hinit : Z G=r)
    (hd : ∀ g, (∑ y,switchKernel n d g y*Real.log ((r+1)/(Z y+1))) ≤
         Real.log ((r+1)/(Z g+1))+c)
    (hmean : uniformAverage n d Z ≤r/h)
    (t : ℕ) (ht : (t:ℝ) ≤ Q*Real.log h/(16*N)) :
    (1:ℝ)/2 ≤ tvDistanceFrom n d t G := by
  have hp : 0<h := by linarith
  have rp : 0<r := by linarith
  let F := fun y => Real.log ((r+1)/(Z y+1))
  have hF (y) : 0≤F y := by
    apply Real.log_nonneg
    apply (one_le_div (by linarith [hZ y])).mpr
    linarith [hle y]
  have hi : F G=0 := by simp [F,hinit,show r+1≠0 by linarith]
  have hb : 0<4*r/h := by positivity
  have hl : 0<Real.log h/2 := by positivity [Real.log_pos (by linarith : 1<h)]
  have hlow := actual_tv_lower hn F Z hF hZ G hb hl hi hd
    (fun y hy => log_potential_barrier hh hr (hZ y) hy) hmean t
  exact (harmonic_clock hh hr hQ hN hc (le_refl _) ht).trans hlow

/-- An elementary explicit lower bound for the quartet clock, on the ambient vertex count. -/
theorem choose_clock (n : ℕ) (hn : 8≤n) : (n:ℝ)^4/32 ≤ 12*(n.choose 4:ℝ) := by
  have hh := Nat.pow_le_choose (α:=ℝ) 4 n
  have hnat : n ≤ 2*(n+1-4) := by omega
  have hcast : (n:ℝ) ≤ 2*((n+1-4:ℕ):ℝ) := by exact_mod_cast hnat
  have hreal : (n:ℝ)/2 ≤ ((n+1-4:ℕ):ℝ) := by linarith
  have hpow := pow_le_pow_left₀ (show (0:ℝ) ≤ n/2 by positivity) hreal 4
  have he : n+1-4=n-3 := by omega
  rw [he] at hpow
  norm_num [Nat.factorial] at hh
  linarith

/-- In the concrete growing-hub family, every time below an explicit ambient n³ log n
    clock is covered by the drift lower bound. -/
theorem polynomial_clock {h : ℕ} (hh : 25≤h) :
    ((h+h^5:ℕ):ℝ)^3*Real.log ((h+h^5:ℕ):ℝ)/3072 ≤
       (12*((h+h^5).choose 4:ℝ))*Real.log (h:ℝ)/(16*(h^5:ℕ)) := by
  let n := h+h^5
  have hp : 0<(h:ℝ) := by exact_mod_cast (by omega : 0<h)
  have h5 : (0:ℝ)<(h^5:ℕ) := by positivity
  have hhn : h≤h^5 := Nat.le_self_pow (by decide) _
  have hn : 8≤n := by dsimp [n];omega
  have hn0 : (0:ℝ)<n := by exact_mod_cast (by omega : 0<n)
  have hNn : ((h^5:ℕ):ℝ) ≤ n := by exact_mod_cast (show h^5≤n by dsimp [n];omega)
  have hsmall : (n:ℝ) ≤ (h:ℝ)^6 := by
    have han : n ≤ 2*(h^5) := by dsimp [n];omega
    have ha : (n:ℝ) ≤ 2*(h:ℝ)^5 := by exact_mod_cast han
    have h2 : (2:ℝ)≤h := by exact_mod_cast (show 2≤h by omega)
    have hs := mul_le_mul_of_nonneg_right h2 (show (0:ℝ)≤(h:ℝ)^5 by positivity)
    nlinarith [show (h:ℝ)^6=(h:ℝ)*(h:ℝ)^5 by ring]
  have hl := Real.log_le_log hn0 hsmall
  norm_num [Real.log_pow] at hl
  have hhlog : 0≤Real.log (h:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤h by omega))
  change (n:ℝ)^3*Real.log (n:ℝ)/3072 ≤ (12*(n.choose 4:ℝ))*Real.log (h:ℝ)/(16*(h^5:ℕ))
  apply (le_div_iff₀ (by positivity)).mpr
  calc
    _ ≤ (((n:ℝ)^3*(6*Real.log (h:ℝ)))/3072)*(16*n) := by
      gcongr
    _ = ((n:ℝ)^4/32)*Real.log (h:ℝ) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right (choose_clock n hn) hhlog

#print axioms marked_lower
#print axioms polynomial_clock
end LeafDrift
