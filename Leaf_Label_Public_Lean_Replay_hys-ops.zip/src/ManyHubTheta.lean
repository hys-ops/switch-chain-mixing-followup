import HubIndex
import FamilyAt
import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Analysis.Complex.ExponentialBounds
import Mathlib.Analysis.Asymptotics.Defs
noncomputable section
namespace LeafResult
open LeafLower.Star OAI.Problem315 LeafOrbit Filter Asymptotics
attribute [local instance] Classical.propDecidable
abbrev vertices (h:ℕ) := n h (h^4)
abbrev degreeVector (h:ℕ) := deg h (h^4)

/-- This uses the published worst-start, TV one-quarter predicate. -/
theorem actual_upper {h:ℕ} (hh : 1024≤h) : MixedAt (vertices h) (degreeVector h) (clock (vertices h)) := by
  let H := hubs h (h^4)
  have hc : H.card=h := card_hubs _ _
  have sp : ManyCore.Spec H (H.card^4) (degreeVector h) := by rw [hc]; exact spec h (h^4)
  intro G
  have a := family_shuffle_transfer_at sp (show 1024≤H.card by rwa [hc]) (show ManyCore.coreClock (vertices h)≤clock (vertices h) by rfl) G
  linarith [leaf_error (show 2≤h by omega)]

/-- The value on a nonmixing input defaults to zero; actual_upper proves existence
on every input used in the eventual theorem. -/
def quarterTime (h:ℕ) : ℕ :=
  if he : ∃ t,MixedAt (vertices h) (degreeVector h) t then mixingTime (vertices h) (degreeVector h) he else 0

theorem time_bounds {h:ℕ} (hh:1024≤h) :
    (vertices h:ℝ)^3*Real.log (vertices h)/3072 < quarterTime h ∧
    (quarterTime h:ℝ) ≤ 2049*(vertices h:ℝ)^3*Real.log (vertices h) := by
  have he : ∃ t,MixedAt (vertices h) (degreeVector h) t := ⟨_,actual_upper hh⟩
  rw [quarterTime,dif_pos he]
  constructor
  · exact polynomial_mixingTime (by omega) he
  · have ha : mixingTime (vertices h) (degreeVector h) he ≤ clock (vertices h) := Nat.find_min' he (actual_upper hh)
    have h8 : 4≤vertices h := by dsimp [vertices,n];omega
    have hlog : 1≤Real.log (vertices h:ℝ) := by
      rw [Real.le_log_iff_exp_le (by positivity : 0<(vertices h:ℝ))]
      exact Real.exp_one_lt_d9.le.trans (by linarith [show (4:ℝ)≤vertices h by exact_mod_cast h8])
    have hpow : 1≤(vertices h:ℝ)^3 := one_le_pow₀ (by exact_mod_cast (show 1≤vertices h by omega))
    have hc := Nat.ceil_lt_add_one (show 0≤ 1024*(vertices h:ℝ)^3*(1+Real.log (vertices h)) by positivity)
    have hr : (mixingTime _ _ he : ℝ) ≤ clock (vertices h) := by exact_mod_cast ha
    unfold clock at hr
    nlinarith [mul_le_mul_of_nonneg_left hlog (show 0≤1024*(vertices h:ℝ)^3 by positivity), one_le_mul_of_one_le_of_one_le hpow hlog]

/-- Index h is the number of hubs and n(h)=h+h^5 is the actual number of vertices. -/
theorem many_hub_theta :
    (fun h:ℕ => (quarterTime h:ℝ)) =Θ[atTop] (fun h:ℕ => (vertices h:ℝ)^3 * Real.log (vertices h)) := by
  constructor
  · apply isBigO_iff.mpr
    refine ⟨2049,?_⟩
    filter_upwards [eventually_ge_atTop 1024] with h hh
    have hn : 1≤vertices h := by dsimp [vertices,n];omega
    have hl : 0≤Real.log (vertices h:ℝ) := Real.log_nonneg (by exact_mod_cast hn)
    simpa [Real.norm_eq_abs,abs_of_nonneg (show 0≤(vertices h:ℝ)^3*Real.log (vertices h) by positivity),abs_of_nonneg hl,mul_assoc]
      using (time_bounds hh).2
  · apply isBigO_iff.mpr
    refine ⟨3072,?_⟩
    filter_upwards [eventually_ge_atTop 1024] with h hh
    have hn : 1≤vertices h := by dsimp [vertices,n];omega
    have hl : 0≤Real.log (vertices h:ℝ) := Real.log_nonneg (by exact_mod_cast hn)
    change ‖(vertices h:ℝ)^3*Real.log (vertices h)‖≤3072*‖(quarterTime h:ℝ)‖
    simp only [Real.norm_eq_abs,abs_of_nonneg (show 0≤(vertices h:ℝ)^3*Real.log (vertices h) by positivity),abs_of_nonneg (Nat.cast_nonneg (α:=ℝ) (quarterTime h))]
    linarith [(time_bounds hh).1]

#print axioms actual_upper
#print axioms time_bounds
#print axioms many_hub_theta
end LeafResult
