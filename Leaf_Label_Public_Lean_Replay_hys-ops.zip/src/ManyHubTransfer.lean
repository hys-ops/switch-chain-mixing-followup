import ExceptionalOrbit
import Family

noncomputable section
open scoped BigOperators Matrix
open HubTransfer
namespace OAI.Problem315.LeafOrbit
open LeafTransfer
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n→ℕ} {H : Finset (Fin n)}

theorem clique_one_orbit (sp : ManyCore.Spec H r d) (G K : GraphState n d)
    (hg : ManyCore.clique H G) (hk : ManyCore.clique H K) : orbitMap G=orbitMap K := by
  apply core_to_orbit
  intro u v hu hv
  have hu' : u∈H := by by_contra h; exact hu (sp.leaf u h)
  have hv' : v∈H := by by_contra h; exact hv (sp.leaf v h)
  by_cases h : u=v
  · subst v; simp
  · exact iff_of_true (hg u hu' v hv' h) (hk u hu' v hv' h)

theorem original_pow (t : ℕ) (G K : GraphState n d) : ((chain d)^t) G K=kernelPow n d t G K := by
  induction t generalizing G K with
  | zero => simp [kernelPow,Matrix.one_apply]
  | succ t ih =>
    rw [pow_succ,Matrix.mul_apply]
    change (∑ z,((chain d)^t) G z*switchKernel n d z K) = ∑ z,kernelPow n d t G z*switchKernel n d z K
    simp only [ih]

theorem original_tv (t : ℕ) (G : GraphState n d) :
    tvDistanceFrom n d t G=tv (((chain d)^t) G) (unif (GraphState n d)) := by
  simp [tvDistanceFrom,tv,unif,original_pow,stateCount,allGraphStates]; ring

theorem core_exceptions (sp : ManyCore.Spec H r d) (hn : 4≤n) (t : ℕ) (G : GraphState n d) :
    tv (push orbitMap (((chain d)^t) G)) (push orbitMap (unif (GraphState n d))) ≤
    ManyCore.row t G (ManyCore.bad H)+uniformAverage n d (ManyCore.bad H) := by
  letI : Nonempty (GraphState n d) := ⟨G⟩
  have h := coarse_tv G orbitMap (ManyCore.clique H) (clique_one_orbit sp)
    (fun z => kernelPow n d t G z) (unif (GraphState n d))
    (ManyCore.pow_nonneg t G) (fun _ => by unfold unif; positivity) (ManyCore.pow_rows hn t G)
    (by simp [unif,ne_of_gt (Nat.cast_pos.mpr Fintype.card_pos)])
  have he : ∑ z:GraphState n d,unif _ z*(if ManyCore.clique H z then (0:ℝ) else 1) =
      uniformAverage n d (ManyCore.bad H) := by
    simp only [unif,uniformAverage,ManyCore.bad,stateCount,allGraphStates,Finset.card_univ,div_eq_inv_mul,mul_one,← Finset.mul_sum]
  rw [he] at h
  rw [show ((chain d)^t) G = (fun z => kernelPow n d t G z) from funext (original_pow t G)]
  exact h

theorem leaf_count_family (sp : ManyCore.Spec H (H.card^4) d) (hh : 2≤H.card) :
    (leaves d).card=H.card*(H.card^4) := by
  have hr := (ManyCore.family_sizes sp hh).2.1
  have he : leaves d=Hᶜ := by
    ext v
    by_cases hv : v∈H
    · simp [leaves,hv,sp.hub v hv,show H.card ≠1 by omega]
    · simp [leaves,hv,sp.leaf v hv]
  rw [he,sp.count]

theorem family_shuffle_transfer (sp : ManyCore.Spec H (H.card^4) d) (hh : 2≤H.card)
    (t : ℕ) (G : GraphState n d) :
    tvDistanceFrom n d t G ≤
      (H.card:ℝ)^2*Real.exp (-ManyCore.rate H (H.card^4)*(t:ℝ))+16/(H.card:ℝ) +
      ∑ k ∈ Finset.range (t+1),weight t k (iidClock d) *
        tv (((LeafMark.shuffle (LeafLabel d))^k) 1) (unif (LeafGroup d)) := by
  have hn := (ManyCore.family_sizes sp hh).1
  have hN : 2≤(leaves d).card := by
    rw [leaf_count_family sp hh]
    have hr := (ManyCore.family_sizes sp hh).2.1
    exact hh.trans (Nat.le_mul_of_pos_right _ (by omega))
  rw [original_tv]
  apply (graph_shuffle_transfer (by omega) hN t G).trans
  apply add_le_add_left
  apply (core_exceptions sp (by omega) t G).trans
  have h := add_le_add (ManyCore.family_bad_row sp hh t G) (ManyCore.family_bad_uniform sp hh)
  apply h.trans_eq
  ring

#print axioms clique_one_orbit
#print axioms original_tv
#print axioms family_shuffle_transfer
end OAI.Problem315.LeafOrbit
