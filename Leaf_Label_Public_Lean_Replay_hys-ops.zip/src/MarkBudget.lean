import MarkClock
import Mathlib.NumberTheory.Harmonic.Bounds
open scoped BigOperators
noncomputable section
namespace LeafMark
theorem tail_bound (n m : ℕ) : tail n m 0 ≤ budget n 0/((m:ℝ)+1) := by
  apply (le_div_iff₀ (by positivity)).2
  have ha : Antitone (fun i => tail n i 0) := antitone_nat_of_succ_le (tail_antitone n 0)
  calc
    _ = ∑ _i ∈ Finset.range (m+1), tail n m 0 := by simp [nsmul_eq_mul]; ring
    _ ≤ ∑ i ∈ Finset.range (m+1),tail n i 0 :=
      Finset.sum_le_sum fun i hi => ha (Nat.le_of_lt_succ (Finset.mem_range.mp hi))
    _ ≤ _ := tail_sum _ _ _

theorem budget_log {n : ℕ} (hn : 0<n) : budget n 0 ≤ 2*n*(1+Real.log n) := by
  have hnr : 0<(n:ℝ) := by exact_mod_cast hn
  let H := ∑ j ∈ Finset.range n, ((j:ℝ)+1)⁻¹
  have hh : H=(harmonic n : ℝ) := by simp [H,harmonic,Rat.cast_sum]
  have href : (∑ j ∈ Finset.range n, ((n:ℝ)-j)⁻¹)=H := by
    dsimp only [H]
    rw [← Finset.sum_range_reflect (fun j => ((j:ℝ)+1)⁻¹) n]
    apply Finset.sum_congr rfl
    intro j hj
    have hj' := Finset.mem_range.mp hj
    congr 1
    rw [Nat.cast_sub (by omega),Nat.cast_sub (by omega : 1≤n),Nat.cast_one]
    ring
  calc
    budget n 0 ≤ ∑ j ∈ Finset.range n, (n:ℝ)*(((n:ℝ)-j)⁻¹+((j:ℝ)+1)⁻¹) := by
      unfold budget
      rw [← Finset.range_eq_Ico]
      apply Finset.sum_le_sum
      intro j hj
      have hj' : (j:ℝ)<n := by exact_mod_cast Finset.mem_range.mp hj
      have hz : 0<(n:ℝ)-j := by linarith
      have hz' : 0<(j:ℝ)+1 := by positivity
      unfold chance
      rw [inv_div]
      field_simp
      nlinarith
    _ = 2*n*H := by rw [← Finset.mul_sum,Finset.sum_add_distrib,href]; dsimp [H]; ring
    _ ≤ _ := mul_le_mul_of_nonneg_left (hh ▸ harmonic_le_one_add_log n) (by positivity)

#print axioms budget_log
end LeafMark
