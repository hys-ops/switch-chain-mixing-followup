import MarkovTV
import Mathlib.Analysis.SpecialFunctions.Log.Basic
open scoped BigOperators
noncomputable section
namespace LeafMark
def chance (n k : ℕ) : ℝ := ((n:ℝ)-k)*(k+1)/(n:ℝ)^2

theorem chance_pos {n k : ℕ} (hk : k<n) : 0<chance n k := by
  unfold chance
  have : (k:ℝ)<n := by exact_mod_cast hk
  have hn : 0 < (n:ℝ) := by exact_mod_cast (show 0<n by omega)
  exact div_pos (mul_pos (sub_pos.mpr this) (by positivity)) (by positivity)

theorem chance_le {n k : ℕ} (hk : k<n) : chance n k≤1 := by
  have hn : 0 < (n:ℝ) := by exact_mod_cast (show 0<n by omega)
  have h₁ : (k:ℝ)+1≤n := by exact_mod_cast hk
  have h₂ : (n:ℝ)-k ≤ n := by linarith [Nat.cast_nonneg (α:=ℝ) k]
  unfold chance
  apply (div_le_iff₀ (sq_pos_of_pos hn)).2
  rw [one_mul,pow_two]
  exact mul_le_mul h₂ h₁ (by positivity) hn.le

/-- Tail of the number of iid ordered draws needed to mark all labels,
starting with k marked labels. -/
def tail (n : ℕ) : ℕ → ℕ → ℝ
  | 0,k => if k<n then 1 else 0
  | t+1,k => if k<n then (1-chance n k)*tail n t k+chance n k*tail n t (k+1) else 0

theorem tail_end (n t k : ℕ) (h : n≤k) : tail n t k=0 := by
  cases t <;> simp [tail,not_lt.mpr h]

theorem tail_nonneg (n t k : ℕ) : 0≤tail n t k := by
  induction t generalizing k with
  | zero => simp [tail]; split <;> norm_num
  | succ t ih =>
    by_cases h:k<n
    · simp only [tail,ite_eq_left h]
      exact add_nonneg (mul_nonneg (sub_nonneg.mpr (chance_le h)) (ih _))
        (mul_nonneg (chance_pos h).le (ih _))
    · simp [tail,h]

theorem tail_antitone (n k t : ℕ) : tail n (t+1) k ≤ tail n t k := by
  induction t generalizing k with
  | zero =>
    by_cases h:k<n
    · simp only [tail,ite_eq_left h]
      split <;> nlinarith [(chance_pos h).le]
    · simp [tail,h]
  | succ t ih =>
    by_cases h:k<n
    · change (if k<n then _ else _) ≤ _
      rw [ite_eq_left h]
      conv_rhs => rw [tail,ite_eq_left h]
      exact add_le_add (mul_le_mul_of_nonneg_left (ih _) (sub_nonneg.mpr (chance_le h)))
        (mul_le_mul_of_nonneg_left (ih _) (chance_pos h).le)
    · simp [tail,h]

def budget (n k : ℕ) := ∑ j ∈ Finset.Ico k n, (chance n j)⁻¹

theorem tail_sum (n k m : ℕ) : ∑ i ∈ Finset.range m,tail n i k ≤ budget n k := by
  by_cases h:k<n
  · have hnext := tail_sum n (k+1) m 
    have recur : ∀ t,tail n (t+1) k-tail n t k =
        chance n k*(tail n t (k+1)-tail n t k) := by
      intro t; rw [tail,ite_eq_left h]; ring
    have tel := Finset.sum_range_sub (fun i => tail n i k) m
    simp_rw [recur] at tel
    rw [← Finset.mul_sum,Finset.sum_sub_distrib] at tel
    have hz : tail n 0 k=1 := by simp [tail,h]
    rw [hz] at tel
    have hn := tail_nonneg n m k
    have hb : budget n k= (chance n k)⁻¹+budget n (k+1) := by
      unfold budget
      rw [Finset.sum_eq_sum_Ico_succ_bot h]
    rw [hb]
    have pos := chance_pos h
    have hi := mul_inv_cancel₀ pos.ne'
    apply (mul_le_mul_iff_right₀ pos).mp
    rw [mul_add,hi]
    nlinarith [mul_le_mul_of_nonneg_left hnext pos.le] 
  · simp [budget,Finset.Ico_eq_empty_of_le (by omega : n≤k),fun i => tail_end n i k (by omega)]
termination_by n-k
decreasing_by omega
end LeafMark
