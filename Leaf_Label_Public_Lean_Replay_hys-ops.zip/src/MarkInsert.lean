import LeafShuffleMatrix
open scoped BigOperators Matrix
noncomputable section
namespace LeafMark
variable {A : Type*} [Fintype A] [DecidableEq A]
def mean (f : G A → ℝ) := (∑ x,f x)/(Fintype.card (G A):ℝ)
def fixedOutside (S : Finset A) (p : G A) : Prop := ∀ a, a ∉ S → p a=a
def marked (S : Finset A) (f : G A → ℝ) : Prop :=
  ∀ p : G A, fixedOutside S p → ∀ x, f (x*p)=f x
def insertion (S : Finset A) (i : A) (f : G A → ℝ) (x : G A) :=
  ∑ j ∈ insert i S,f (x*Equiv.swap i j)

theorem marked_empty (f : G A → ℝ) : marked ∅ f := by
  intro p hp x
  have h : p=1 := Equiv.ext (fun a => hp a (by simp))
  simp [h]

theorem marked_full {f : G A → ℝ} (h : marked Finset.univ f) (x:G A) : f x=mean f := by
  have hc (z:G A) : f z=f x := by
    simpa using h (x⁻¹*z) (fun _ ha => False.elim (ha (Finset.mem_univ _))) x
  have hn : (Fintype.card (G A):ℝ)≠0 := by exact_mod_cast Fintype.card_ne_zero
  unfold mean
  simp_rw [hc]; simp [nsmul_eq_mul,hn]

theorem inserted_marked {S : Finset A} {i : A} {f : G A → ℝ} (hf : marked S f) :
    marked (insert i S) (insertion S i f) := by
  classical
  intro p hp x
  let U := insert i S
  have mem_iff (j:A) : p j ∈ U ↔ j∈U := by
    constructor
    · intro hj
      by_contra hc
      rw [hp j hc] at hj
      exact hc hj
    · intro hj
      by_contra hn
      have e := p.injective (hp _ hn)
      exact hn (e.symm ▸ hj)
  have hb (j:A) (hj:j∈U) : f (x*p*Equiv.swap i j)=f (x*Equiv.swap i (p j)) := by
    let a := Equiv.swap i (p j)
    let b := Equiv.swap i j
    let q := a*p*b
    have hq : fixedOutside S q := by
      intro z hz
      by_cases he:z=i
      · subst z
        simp [q,a,b,Equiv.Perm.mul_apply]
      have hu : z∉U := by simpa [U,he,hz]
      have hjz : z≠j := fun h => hu (h ▸ hj)
      have hpz : z≠p j := fun h => hu (h ▸ (mem_iff j).2 hj)
      simp [q,a,b,Equiv.Perm.mul_apply,Equiv.swap_apply_of_ne_of_ne he hjz,
        hp z hu,Equiv.swap_apply_of_ne_of_ne he hpz]
    have he : x*a*q=x*p*b := by simp [q,a,mul_assoc]
    exact (he ▸ hf q hq (x*a))
  unfold insertion
  calc
    _ = ∑ j ∈ U,f (x*Equiv.swap i (p j)) := Finset.sum_congr rfl hb
    _ = _ := by
      apply Finset.sum_bij (fun j _ => p j)
      · exact fun j hj => (mem_iff _).2 hj
      · exact fun _ _ _ _ h => p.injective h
      · intro y hy; exact ⟨p.symm y,(mem_iff _).1 (by simpa [U] using hy),by simp⟩
      · intros; rfl

theorem mean_insertion (S : Finset A) (i : A) (f : G A → ℝ) :
    mean (insertion S i f)=((insert i S).card:ℝ)*mean f := by
  classical
  unfold mean insertion
  rw [Finset.sum_comm]
  have h (j:A) : (∑ x : G A,f (x*Equiv.swap i j))=∑ x,f x :=
    Equiv.sum_comp (Equiv.mulRight (Equiv.swap i j)) f
  simp_rw [h]
  simp [nsmul_eq_mul,mul_div_assoc]

theorem heat_translate (f : G A → ℝ) (p : G A) (t : ℕ) (x:G A) :
    ((shuffle A)^t *ᵥ (fun z => f (z*p))) x=((shuffle A)^t *ᵥ f) (x*p) := by
  induction t generalizing x with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',← Matrix.mulVec_mulVec,← Matrix.mulVec_mulVec,shuffle_apply,shuffle_apply]
    simp_rw [ih,mul_assoc,Equiv.swap_mul_eq_mul_swap p,← mul_assoc]
    congr 1
    have h (i:A) : (∑ j:A, ((shuffle A)^t *ᵥ f) (x*p*Equiv.swap (p⁻¹ i) (p⁻¹ j))) =
        ∑ j:A, ((shuffle A)^t *ᵥ f) (x*p*Equiv.swap (p⁻¹ i) j) :=
      Equiv.sum_comp p.symm (fun z => ((shuffle A)^t *ᵥ f) (x*p*Equiv.swap (p⁻¹ i) z))
    simp_rw [h]
    exact Equiv.sum_comp p.symm (fun i => ∑ j:A, ((shuffle A)^t *ᵥ f) (x*p*Equiv.swap i j))

theorem heat_insertion (S : Finset A) (i:A) (f:G A→ℝ) (t:ℕ) (x:G A) :
    ((shuffle A)^t *ᵥ insertion S i f) x =
    ∑ j ∈ insert i S,((shuffle A)^t *ᵥ f) (x*Equiv.swap i j) := by
  unfold insertion
  change (∑ z, ((shuffle A)^t) x z * (∑ j ∈ insert i S,f (z*Equiv.swap i j)))=_
  simp_rw [Finset.mul_sum]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl fun j _ => heat_translate f _ _ _

#print axioms inserted_marked
end LeafMark
