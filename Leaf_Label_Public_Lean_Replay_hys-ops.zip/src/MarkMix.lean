import MarkInsert
import MarkBudget
open scoped BigOperators Matrix
noncomputable section
namespace LeafMark
variable {A : Type*} [Fintype A] [DecidableEq A] [Nonempty A]
theorem shuffle_const (c:ℝ) (x:G A) (t:ℕ) : ((shuffle A)^t *ᵥ (fun _ => c)) x=c := by
  induction t generalizing x with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',← Matrix.mulVec_mulVec,shuffle_apply]
    simp_rw [ih]
    simp [nsmul_eq_mul,Fintype.card_ne_zero,div_eq_iff, mul_comm,mul_left_comm,pow_two]

/-- Broder's insertion argument, encoded as a pointwise lower bound on the heat kernel. -/
theorem mark_mix (t:ℕ) (S : Finset A) (f : G A → ℝ) (hf : marked S f)
    (hnf : ∀ z, 0≤f z) (x:G A) :
    (1-tail (Fintype.card A) t S.card)*mean f ≤ ((shuffle A)^t *ᵥ f) x := by
  induction t generalizing S f x with
  | zero =>
    by_cases hc:S.card < Fintype.card A
    · simpa [tail,hc] using hnf x
    · have hs : S=Finset.univ := Finset.eq_univ_of_card S (le_antisymm (Finset.card_le_univ _) (not_lt.mp hc))
      subst S; simp [tail,marked_full hf]
  | succ t ih =>
    let n := Fintype.card A
    let k := S.card
    by_cases hk : k<n
    · let F := (shuffle A)^t *ᵥ f
      let a := (1-tail n t k)*mean f
      let b := (1-tail n t (k+1))*mean f
      have hF (z:G A) : a≤F z := ih S f hf hnf z
      have hg (i:A) (hi:i∉S) : ((k:ℝ)+1)*b ≤ ∑ j ∈ insert i S, F (x*Equiv.swap i j) := by
        have h := ih (insert i S) (insertion S i f) (inserted_marked hf)
          (fun z => Finset.sum_nonneg fun j _ => hnf _) x
        rw [heat_insertion,mean_insertion,Finset.card_insert_of_notMem hi,Nat.cast_add_one] at h
        dsimp [b,k,n,F]; convert h using 1 <;> ring
      have hr (i:A) : (n:ℝ)*a+(if i∈S then 0 else ((k:ℝ)+1)*(b-a)) ≤
          ∑ j:A,F (x*Equiv.swap i j) := by
        by_cases hi:i∈S
        · simp only [hi,ite_true,add_zero]
          simpa [n,nsmul_eq_mul] using
            (Finset.sum_le_sum (s:=Finset.univ) (fun (j:A) _ => hF (x*Equiv.swap i j)))
        · simp only [hi,ite_false]
          let U := insert i S
          have hc : (Uᶜ.card:ℝ)=(n:ℝ)-((k:ℝ)+1) := by
            rw [Finset.card_compl,Nat.cast_sub (Finset.card_le_univ _),Finset.card_insert_of_notMem hi,Nat.cast_add_one]
          have hbad := Finset.sum_le_sum (s:=Uᶜ) (fun j _ => hF (x*Equiv.swap i j))
          simp only [Finset.sum_const,nsmul_eq_mul,hc] at hbad
          rw [← Finset.sum_add_sum_compl U (fun j => F (x*Equiv.swap i j))]
          linarith [hg i hi]
      have HH := Finset.sum_le_sum (s:=Finset.univ) fun i _ => hr i
      rw [Finset.sum_add_distrib] at HH
      have hc : (∑ i:A, if i∈S then (0:ℝ) else ((k:ℝ)+1)*(b-a)) =
          ((n:ℝ)-k)*(((k:ℝ)+1)*(b-a)) := by
        rw [← Finset.sum_add_sum_compl S]
        have h0 : (∑ i ∈ S, if i∈S then (0:ℝ) else ((k:ℝ)+1)*(b-a))=0 :=
          Finset.sum_eq_zero fun i hi => by simp [hi]
        rw [h0,zero_add]
        calc
          _ = ∑ _i ∈ Sᶜ, ((k:ℝ)+1)*(b-a) := Finset.sum_congr rfl (fun j hj => if_neg (Finset.mem_compl.mp hj))
          _ = _ := by simp [Finset.card_compl,Nat.cast_sub (Finset.card_le_univ S),n,k,nsmul_eq_mul]
      rw [hc,Finset.sum_const,nsmul_eq_mul,Finset.card_univ] at HH
      rw [pow_succ',← Matrix.mulVec_mulVec,shuffle_apply]
      have hn : 0<(n:ℝ) := by exact_mod_cast Fintype.card_pos
      apply (le_div_iff₀ (sq_pos_of_pos hn)).2
      change (1-tail n (t+1) k)*mean f*(n:ℝ)^2 ≤ _
      rw [tail,ite_eq_left hk]
      calc
        _ = (n:ℝ)*((n:ℝ)*a)+((n:ℝ)-k)*(((k:ℝ)+1)*(b-a)) := by
          dsimp [a,b,chance]; field_simp; ring
        _ ≤ _ := HH
    · have hs : S=Finset.univ := Finset.eq_univ_of_card S
          (le_antisymm (Finset.card_le_univ _) (not_lt.mp hk))
      subst S
      have he : f=fun _ => mean f := funext (marked_full hf)
      simp only [Finset.card_univ,tail_end _ _ _ le_rfl,sub_zero,one_mul]
      conv_rhs => rw [he,shuffle_const]

#print axioms mark_mix
end LeafMark
