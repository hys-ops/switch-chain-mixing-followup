import Avoidance
import PhysicalClock
open Filter Topology Finset JohnsonLower
open scoped Matrix
namespace HubMarks
noncomputable section
open TwoHubUnequal
lemma choose_clock_degree (r h j : ℕ) (u : ℝ) (hu : 0≤u) :
    Tendsto (fun k => (eigen (r+k+2) h j (Q r k)) ^ (localTime r u k)) atTop
        (𝓝 ((Real.exp (-u))^j)) := by
  let b := fun k:ℕ => (j:ℝ)*(1-(h:ℝ)/N r k)
  let p := fun k:ℕ => (j:ℝ)*(N r k-(h:ℝ))/Q r k
  have hb : Tendsto b atTop (𝓝 (j:ℝ)) := by
    have hh : Tendsto (fun k => (h:ℝ)/N r k) atTop (𝓝 0) := tendsto_const_nhds.div_atTop (Ntop r)
    simpa [b] using (tendsto_const_nhds (x:=(j:ℝ))).mul ((tendsto_const_nhds (x:=(1:ℝ))).sub hh)
  have he k : b k*(N r k/Q r k)=p k := by
    dsimp [b,p];field_simp [(Npos r k).ne']
  have hp : Tendsto p atTop (𝓝 0) := by simpa only [he,mul_zero] using hb.mul (scale_zero r)
  have ht : Tendsto (fun k => (localTime r u k:ℝ)*p k) atTop (𝓝 (u*j)) := by
    apply ((scaled_time r u hu).mul hb).congr;intro k;rw [←he];ring
  have heq : Real.exp (-(u*j)) = (Real.exp (-u))^j := by rw [←Real.exp_nat_mul];congr 1;ring
  simpa [eigen,p,N,heq] using moving_decay hp ht

lemma rare_error (r h a : ℕ) (u : ℝ) (hu : 0≤u) :
    Tendsto (fun k => (2:ℝ)^a*((localTime r u k:ℝ)*h/Q r k)) atTop (𝓝 0) := by
  have hh : Tendsto (fun k => (h:ℝ)/N r k) atTop (𝓝 0) := tendsto_const_nhds.div_atTop (Ntop r)
  have ht := (tendsto_const_nhds (x:=(2:ℝ)^a)).mul ((scaled_time r u hu).mul hh)
  simp only [mul_zero] at ht
  apply ht.congr;intro k
  field_simp [(Npos r k).ne']

lemma cap_eventually (r h : ℕ) :
    ∀ᶠ k : ℕ in atTop, (h:ℝ)*((r+k+2:ℕ)- (h:ℝ)) ≤ Q r k := by
  have ht := (tendsto_const_nhds (x:=(h:ℝ))).mul (scale_zero r)
  simp only [mul_zero] at ht
  filter_upwards [(tendsto_order.mp ht).2 1 (by norm_num)] with k hk
  rw [←mul_div_assoc,div_lt_one (Qpos r k)] at hk
  push_cast
  have he : (h:ℝ)*((r:ℝ)+k+2) < Q r k := hk
  nlinarith [sq_nonneg (h:ℝ)]

lemma avoid_approx_limit (r h a : ℕ) (u : ℝ) (hu : 0≤u) :
    Tendsto (fun k => avoidApprox (r+k+2) h a (Q r k) (localTime r u k)) atTop
      (𝓝 ((1-Real.exp (-u))^a)) := by
  classical
  have ht : Tendsto (fun k => ∑ j∈range (a+1), a.choose j •
      ((-1:ℝ)^j*(eigen (r+k+2) h j (Q r k))^(localTime r u k))) atTop
      (𝓝 (∑ j∈range (a+1),a.choose j • ((-1:ℝ)^j*(Real.exp (-u))^j))) := by
    apply tendsto_finsetSum
    intro j _
    simpa only [nsmul_eq_mul] using
      (tendsto_const_nhds (x:=(a.choose j:ℝ))).mul
        ((tendsto_const_nhds (x:=(-1:ℝ)^j)).mul (choose_clock_degree r h j u hu))
  have he : (∑ j∈range (a+1),a.choose j • ((-1:ℝ)^j*(Real.exp (-u))^j)) = (1-Real.exp (-u))^a := by
    rw [show 1-Real.exp (-u) = -Real.exp (-u)+1 by ring,add_pow]
    apply sum_congr rfl
    intro j _
    simp only [nsmul_eq_mul,one_pow,mul_one,←mul_pow]
    ring
  rw [he] at ht
  exact ht

/-- For a fixed number of marks, uniformly over every admissible point start M and chosen
K of a fixed size a contained in M, the probability of avoiding K after floor(uQ/N)
steps tends to (1-e^-u)^a.  Includes u=0, a=0, and both a=r,r+1. -/
theorem avoidance_uniform (r h a : ℕ) (u : ℝ) (hu : 0≤u) (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ k : ℕ in atTop, ∀ (K : Finset (Fin (r+k+2))) (M : Slice (r+k+2) h),
      K.card=a → K⊆M.val →
      |((walk (r+k+2) h (Q r k))^(localTime r u k) *ᵥ avoid K) M -
           (1-Real.exp (-u))^a| < ε := by
  let A := fun k => avoidApprox (r+k+2) h a (Q r k) (localTime r u k)
  let z := (1-Real.exp (-u))^a
  have hh : Tendsto (fun k => |A k-z|) atTop (𝓝 0) := by
    simpa [A,z] using ((avoid_approx_limit r h a u hu).sub_const z).abs
  have hh' := (rare_error r h a u hu).add hh
  simp only [add_zero] at hh'
  filter_upwards [cap_eventually r h,(tendsto_order.mp hh').2 ε hε] with k hk ht
  intro K M hK hm
  have hp := finite_avoidance (Qpos r k) hk K (localTime r u k) M hm
  rw [hK] at hp
  exact (abs_sub_le _ (A k) z).trans_lt (lt_of_le_of_lt (add_le_add hp le_rfl) ht)
#print axioms avoidance_uniform
end
end HubMarks
