import JohnsonStep
open Finset HubTransfer
open scoped Matrix BigOperators
namespace HubMarks
noncomputable section
attribute [local instance] Classical.propDecidable
open JohnsonLower
variable {N h : ℕ}

def occupied (B : Finset (Fin N)) (S : Slice N h) : ℝ := if B⊆S.val then 1 else 0
def eigen (N h j : ℕ) (Q : ℝ) : ℝ := 1-(j:ℝ)*((N:ℝ)-h)/Q

/-- For containment of fixed B, a successful full occupancy loses exactly j(N-h)
swaps; from noncontainment at most h swaps enter. -/
theorem row_occupancy (Q : ℝ) (hQ : 0<Q) (B : Finset (Fin N)) (S : Slice N h) :
    0 ≤ ((kernel Q) *ᵥ occupied B) S - eigen N h B.card Q*occupied B S ∧
    ((kernel Q) *ᵥ occupied B) S - eigen N h B.card Q*occupied B S ≤ (h:ℝ)/Q := by
  classical
  change _ ≤ (∑ T,kernel Q S T*occupied B T) - _ ∧
      (∑ T,kernel Q S T*occupied B T) - _ ≤ _
  rw [row_apply]
  by_cases hb : B⊆S.val
  · have each (i : ↥S.val) (j : ↥S.valᶜ) : occupied B (change S i j) =
          if i.val∉B then 1 else 0 := by
        have hji : j.val≠i.val := by intro he;exact (mem_compl.mp j.property) (he ▸ i.property)
        have hh : B⊆(change S i j).val ↔ i.val∉B := by
          constructor
          · intro hx hi; exact ((change_diff S i j i).mpr rfl).2 (hx hi)
          · intro hi v hv
            have hh : v≠i.val := by intro e;exact hi (e ▸ hv)
            exact mem_insert_of_mem (mem_erase.mpr ⟨hh,hb hv⟩)
        simp [occupied,hh]
    have cnt : (∑ i : ↥S.val, if i.val∉B then (1:ℝ) else 0) = (h:ℝ)-B.card := by
      rw [sum_coe_sort S.val (fun i => if i∉B then (1:ℝ) else 0), sum_boole,
        filter_notMem_eq_sdiff,card_sdiff_of_subset hb,Nat.cast_sub (card_le_card hb),S.property]
    simp_rw [each,sum_const,card_univ,nsmul_eq_mul,cardout,←mul_sum,cnt]
    rw [show occupied B S=1 from ite_eq_left hb]
    unfold eigen
    constructor
    · apply le_of_eq;ring
    · have h' : (0:ℝ) ≤ (h:ℝ)/Q := div_nonneg (by positivity) hQ.le
      linarith [show (1-(h:ℝ)*(N-h)/Q)*1+
        (((N:ℝ)-h)*((h:ℝ)-B.card))/Q - (1-(B.card:ℝ)*(N-h)/Q)*1=0 by ring]
  · obtain ⟨z,hz,hzS⟩ := Finset.not_subset.mp hb
    let z' : ↥S.valᶜ := ⟨z,mem_compl.mpr hzS⟩
    have upper (i : ↥S.val) (j : ↥S.valᶜ) : occupied B (change S i j) ≤ if j=z' then 1 else 0 := by
      by_cases he : j=z'
      · simp [he,occupied];split <;> norm_num
      · have hn : ¬B⊆(change S i j).val := by
          intro hh; have H := (change_new S i j z).mp ⟨hh hz,hzS⟩
          exact he (Subtype.ext H.symm)
        simp [he,occupied,hn]
    have hu : (∑ i : ↥S.val,∑ j : ↥S.valᶜ, occupied B (change S i j)) ≤ (h:ℝ) := by
      calc
        _ ≤ ∑ i : ↥S.val,∑ j : ↥S.valᶜ, if j=z' then (1:ℝ) else 0 :=
          sum_le_sum fun i _ => sum_le_sum fun j _ => upper i j
        _ = _ := by simp [S.property]
    rw [show occupied B S=0 from ite_eq_right hb]
    simp only [mul_zero,zero_add,sub_zero]
    refine ⟨div_nonneg (sum_nonneg fun i _ => sum_nonneg fun j _ => ?_) hQ.le,
      div_le_div_of_nonneg_right hu hQ.le⟩
    unfold occupied;split <;> norm_num

/-- An approximate eigenfunction on a finite stochastic matrix. -/
theorem power_bounds {X : Type*} [Fintype X] [DecidableEq X] (P : Matrix X X ℝ)
    (hP : Stochastic P) (f : X → ℝ) {g e : ℝ} (hg : 0≤g) (hg' : g≤1)
    (he : ∀ x, 0 ≤ (P *ᵥ f) x-g*f x ∧ (P *ᵥ f) x-g*f x ≤ e)
    (t : ℕ) (x : X) :
    0 ≤ (P^t *ᵥ f) x - g^t*f x ∧ (P^t *ᵥ f) x-g^t*f x ≤ (t:ℝ)*e := by
  have he0 : 0≤e := (he x).1.trans (he x).2
  induction t with
  | zero => simp
  | succ t ih =>
    have hp := stochastic_pow hP t
    let q := fun y => (P *ᵥ f) y - g*f y
    have hq : (P^t *ᵥ q) x = (P^(t+1) *ᵥ f) x - g*((P^t *ᵥ f) x) := by
      rw [pow_succ,←Matrix.mulVec_mulVec]
      simp [Matrix.mulVec,dotProduct,q,mul_sub,sum_sub_distrib,mul_left_comm _ g,←mul_sum]
    have hl : 0≤(P^t *ᵥ q) x := sum_nonneg fun y _ => mul_nonneg (hp.1 x y) (he y).1
    have hu : (P^t *ᵥ q) x ≤ e := by
      change (∑ y,(P^t) x y*q y) ≤ e
      calc
        _ ≤ ∑ y,(P^t) x y*e := sum_le_sum fun y _ => mul_le_mul_of_nonneg_left (he y).2 (hp.1 x y)
        _ = e := by rw [←sum_mul,hp.2,one_mul]
    rw [hq] at hl hu
    rw [pow_succ g,Nat.cast_succ]
    constructor
    · nlinarith [mul_nonneg hg ih.1]
    · nlinarith [mul_le_mul_of_nonneg_left ih.2 hg,mul_nonneg (sub_nonneg.mpr hg')
        (mul_nonneg (Nat.cast_nonneg t) he0)]

def walk (N h : ℕ) (Q : ℝ) : Matrix (Slice N h) (Slice N h) ℝ := kernel Q

theorem marked_survival {Q : ℝ} (hQ : 0<Q) (cap : (h:ℝ)*((N:ℝ)-h) ≤ Q)
    (B : Finset (Fin N)) (t : ℕ) (S : Slice N h) (hb : B⊆S.val) :
    0 ≤ ((walk N h Q)^t *ᵥ occupied B) S - (eigen N h B.card Q)^t ∧
        ((walk N h Q)^t *ᵥ occupied B) S - (eigen N h B.card Q)^t ≤ (t:ℝ)*h/Q := by
  have hn : (0:ℝ)≤(N:ℝ)-h := sub_nonneg.mpr (by exact_mod_cast (show h≤N by simpa [S.property] using S.val.card_le_univ))
  have hj : (B.card:ℝ)≤h := by exact_mod_cast S.property ▸ card_le_card hb
  have hg : 0≤eigen N h B.card Q :=
    sub_nonneg.mpr ((div_le_one hQ).mpr ((mul_le_mul_of_nonneg_right hj hn).trans cap))
  have hg' : eigen N h B.card Q≤1 := by unfold eigen;exact sub_le_self _ (div_nonneg (mul_nonneg (by positivity) hn) hQ.le)
  simpa only [show occupied B S=1 from ite_eq_left hb,mul_one,mul_div_assoc] using
    power_bounds (walk N h Q) (kernel_stoch hQ cap)
    (occupied B) hg hg' (row_occupancy Q hQ B) t S
#print axioms marked_survival
end
end HubMarks
