import FiberTV
import Mathlib.Data.Nat.Choose.Sum
import Mathlib.Data.Matrix.Mul

open scoped BigOperators Matrix
noncomputable section
namespace HubTransfer
variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq X] [DecidableEq C]

def Stochastic (R : Matrix X X ℝ) : Prop := (∀ x y, 0≤R x y) ∧ ∀ x, ∑ y,R x y=1

theorem stochastic_mul {A B : Matrix X X ℝ} (ha : Stochastic A) (hb : Stochastic B) :
    Stochastic (A*B) := by
  constructor
  · intro x y; exact Finset.sum_nonneg fun z _ => mul_nonneg (ha.1 x z) (hb.1 z y)
  · intro x
    simp only [Matrix.mul_apply,Finset.sum_comm (s:=Finset.univ) (t:=Finset.univ)
      (f:=fun y z => A x z*B z y),← Finset.mul_sum,hb.2,mul_one,ha.2]

theorem stochastic_pow {R : Matrix X X ℝ} (h : Stochastic R) (m : ℕ) :
    Stochastic (R^m) := by
  induction m with
  | zero =>
    rw [pow_zero]
    constructor
    · intro x y; simp [Matrix.one_apply]; split <;> norm_num
    · intro x; simp [Matrix.one_apply]
  | succ k ih => rw [pow_succ]; exact stochastic_mul ih h

theorem tv_contract (R : Matrix X X ℝ) (hr : Stochastic R) (a b : X → ℝ) :
    tv (a ᵥ* R) (b ᵥ* R) ≤ tv a b := by
  have h (y : X) : (a ᵥ* R) y - (b ᵥ* R) y = ∑ z, (a z-b z)*R z y := by
    simp [Matrix.vecMul,dotProduct,sub_mul,Finset.sum_sub_distrib]
  unfold tv
  apply div_le_div_of_nonneg_right _ (by norm_num)
  calc
    _ ≤ ∑ y,∑ z, |a z-b z| * R z y := by
      apply Finset.sum_le_sum
      intro y _
      rw [h]
      apply (Finset.abs_sum_le_sum_abs _ _).trans_eq
      apply Finset.sum_congr rfl
      intro z _
      rw [abs_mul,abs_of_nonneg (hr.1 z y)]
    _ = _ := by rw [Finset.sum_comm]; simp_rw [← Finset.mul_sum,hr.2,mul_one]

theorem tv_mix {I : Type*} (s : Finset I) (w : I → ℝ) (hw : ∀ i ∈ s, 0≤w i)
    (a b : I → X → ℝ) :
    tv (fun x => ∑ i ∈ s, w i*a i x) (fun x => ∑ i ∈ s, w i*b i x) ≤
      ∑ i ∈ s, w i*tv (a i) (b i) := by
  have hh (x : X) : |(∑ i ∈ s,w i*a i x) - ∑ i ∈ s,w i*b i x| ≤
      ∑ i ∈ s, w i*|a i x-b i x| := by
    rw [← Finset.sum_sub_distrib]
    simp_rw [← mul_sub]
    apply (Finset.abs_sum_le_sum_abs _ _).trans_eq
    exact Finset.sum_congr rfl fun i hi => by rw [abs_mul,abs_of_nonneg (hw i hi)]
  unfold tv
  calc
    _ ≤ (∑ x,∑ i ∈ s,w i*|a i x-b i x|)/2 :=
      div_le_div_of_nonneg_right (Finset.sum_le_sum (fun x _ => hh x)) (by norm_num)
    _ = _ := by rw [Finset.sum_comm,Finset.sum_div]; simp_rw [← Finset.mul_sum,mul_div_assoc]

/-- Probability of k selected T steps in t independent clock ticks. -/
def weight (t k : ℕ) (p : ℝ) : ℝ := (t.choose k : ℝ)*p^k*(1-p)^(t-k)

theorem weight_nonneg {p : ℝ} (hp : 0≤p) (hp' : p≤1) (t k : ℕ) :
    0≤weight t k p := by unfold weight; positivity

theorem mixture_pow (T R : Matrix X X ℝ) (h : Commute T R) (p : ℝ) (t : ℕ) :
    (p • T + (1-p) • R)^t = ∑ k ∈ Finset.range (t+1),
      weight t k p • (T^k * R^(t-k)) := by
  rw [((h.smul_left p).smul_right (1-p)).add_pow]
  apply Finset.sum_congr rfl
  intro k _
  rw [smul_pow,smul_pow,smul_mul_smul_comm,
    ← Nat.cast_comm,← nsmul_eq_mul,← Nat.cast_smul_eq_nsmul ℝ,
    smul_smul,weight]
  congr 1
  ring

/-- The averaging projection is fixed by every number of pure T steps. -/
theorem avg_pow {E T : Matrix X X ℝ} (h : E*T=E) (k : ℕ) : E*T^k=E := by
  induction k with
  | zero => simp
  | succ k ih => rw [pow_succ,← mul_assoc,ih,h]

#print axioms tv_contract
#print axioms tv_mix
#print axioms mixture_pow
end HubTransfer
