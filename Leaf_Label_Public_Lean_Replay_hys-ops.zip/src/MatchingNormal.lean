import OAI.Probability.SwitchChain.FourVertexSwitch
import OAI.Probability.SwitchChain.ProposalUniqueness
import OAI.Probability.SwitchChain.KernelNormalization

namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ}

lemma partner_unique {S : FourSet n} (M : PerfectMatching S) {u v w : Fin n}
    (hv : M.val.Adj u v) (hw : M.val.Adj u w) : v=w := by
  have hu := (M.property.mem_iff_exists_adj u).2 ⟨v,hv⟩
  obtain ⟨_,_,h⟩ := (M.property u).1 hu
  exact (h _ hv).trans (h _ hw).symm

lemma support_four {S : FourSet n} (M : PerfectMatching S) (a b c d : Fin n)
    (h : FourDistinct a b c d) (hab : M.val.Adj a b) (hcd : M.val.Adj c d) :
    S.val={a,b,c,d} := by
  have hm {u v} (e : M.val.Adj u v) := (M.property.mem_iff_exists_adj u).2 ⟨v,e⟩
  apply Eq.symm; refine eq_of_subset_of_card_le ?_ ?_
  · intro z hz; simp only [mem_insert,mem_singleton] at hz
    rcases hz with rfl|rfl|rfl|rfl <;> first | exact hm hab | exact hm hab.symm | exact hm hcd | exact hm hcd.symm
  · obtain ⟨h1,h2,h3,h4,h5,h6⟩ := h; simp [S.property,h1,h2,h3,h4,h5,h6]

lemma matching_four {S : FourSet n} (M : PerfectMatching S) (a b c d : Fin n)
    (h : FourDistinct a b c d) (hab : M.val.Adj a b) (hcd : M.val.Adj c d) (u v : Fin n) :
    M.val.Adj u v ↔ (u=a ∧ v=b) ∨ (u=b ∧ v=a) ∨ (u=c ∧ v=d) ∨ (u=d ∧ v=c) := by
  constructor
  · intro he
    have hu := (M.property.mem_iff_exists_adj u).2 ⟨v,he⟩
    rw [support_four M _ _ _ _ h hab hcd] at hu
    simp only [mem_insert,mem_singleton] at hu
    rcases hu with rfl|rfl|rfl|rfl
    · exact Or.inl ⟨rfl,partner_unique M he hab⟩
    · exact Or.inr (Or.inl ⟨rfl,partner_unique M he hab.symm⟩)
    · exact Or.inr (Or.inr (Or.inl ⟨rfl,partner_unique M he hcd⟩))
    · exact Or.inr (Or.inr (Or.inr ⟨rfl,partner_unique M he hcd.symm⟩))
  · rintro (⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩|⟨rfl,rfl⟩) <;> first | exact hab | exact hab.symm | exact hcd | exact hcd.symm

/-- A valid proposal gaining an edge a-c has a unique normal form (a,b,c,d),
where b,d are the former partners of a,c. -/
lemma gains_normal {G : SimpleGraph (Fin n)} {p : SwitchProposal n} (hp : validSwitch G p)
    {a c : Fin n} (hac : (addedMatching p).Adj a c) : ∃ b d, ∃ h : FourDistinct a b c d,
       G.Adj a b ∧ G.Adj c d ∧ ¬G.Adj b d ∧ p=fourVertexProposal a b c d h := by
  let R := p.2.val.1; let T := p.2.val.2
  have t : T.val.Adj a c := hac
  have ha := (T.property.mem_iff_exists_adj a).2 ⟨c,t⟩
  have hc := (T.property.mem_iff_exists_adj c).2 ⟨a,t.symm⟩
  obtain ⟨b,hab,_⟩ := (R.property a).1 ha
  obtain ⟨d,hcd,_⟩ := (R.property c).1 hc
  have h₁ := hab.ne; have h₂ := t.ne; have h₆ := hcd.ne
  have h₃ : a≠d := by intro he; subst d; exact hp.2 hac (hp.1 hcd.symm)
  have h₄ : b≠c := by intro he; subst b; exact hp.2 hac (hp.1 hab)
  have h₅ : b≠d := by intro he; subst d; exact h₂ (partner_unique R hab.symm hcd.symm)
  have h : FourDistinct a b c d := ⟨h₁,h₂,h₃,h₄,h₅,h₆⟩
  have hs := support_four R _ _ _ _ h hab hcd
  have hb := (R.property.mem_iff_exists_adj b).2 ⟨a,hab.symm⟩
  obtain ⟨w,hbw,_⟩ := (T.property b).1 hb
  have hw := (T.property.mem_iff_exists_adj w).2 ⟨b,hbw.symm⟩
  rw [hs] at hw; simp only [mem_insert,mem_singleton] at hw
  have hbd : T.val.Adj b d := by
    rcases hw with rfl|rfl|rfl|rfl
    · exact (h₄ (partner_unique T hbw.symm t)).elim
    · exact (hbw.ne rfl).elim
    · exact (h₁ (partner_unique T t.symm hbw.symm)).elim
    · exact hbw
  refine ⟨b,d,h,hp.1 hab,hp.1 hcd,hp.2 hbd,?_⟩
  apply SwitchProposal.ext_matchings
  · ext u v; rw [removedMatching_fourVertexProposal]; exact matching_four R _ _ _ _ h hab hcd u v
  · ext u v; rw [addedMatching_fourVertexProposal]
    exact matching_four T _ _ _ _ ⟨h₂,h₁,h₃,h₄.symm,h₆,h₅⟩ t hbd u v

end
end TwoHub
