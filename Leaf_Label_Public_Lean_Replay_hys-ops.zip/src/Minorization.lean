import QuotientTransfer

open scoped BigOperators Matrix
noncomputable section
namespace HubTransfer
variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq X] [DecidableEq C]

/-- Residual proposal matrix after reserving p of the T clock. -/
def residual (P T : Matrix X X ℝ) (p : ℝ) : Matrix X X ℝ := (1-p)⁻¹ • (P-p • T)

theorem stochastic_residual (P T : Matrix X X ℝ) (p : ℝ) (hp : p<1)
    (hP : Stochastic P) (hT : Stochastic T) (hminor : ∀ x y,p*T x y ≤ P x y) :
    Stochastic (residual P T p) := by
  constructor
  · intro x y
    exact mul_nonneg (inv_nonneg.mpr (by linarith)) (sub_nonneg.mpr (hminor x y))
  · intro x
    change (∑ y,(1-p)⁻¹ * (P x y-p*T x y))=1
    rw [← Finset.mul_sum,Finset.sum_sub_distrib,← Finset.mul_sum,hP.2,hT.2,mul_one]
    exact inv_mul_cancel₀ (by linarith)

theorem mixture_residual (P T : Matrix X X ℝ) (p : ℝ) (hp : p<1) :
    P = p • T + (1-p) • residual P T p := by
  ext x y
  change P x y = p*T x y+(1-p)*((1-p)⁻¹*(P x y-p*T x y))
  have hz : (1-p) ≠ 0 := by linarith
  rw [← mul_assoc,mul_inv_cancel₀ hz,one_mul]
  ring

theorem quotient_transfer_minorized (π : X → C) (hs : Function.Surjective π)
    (P T : Matrix X X ℝ) (p : ℝ) (h0 : 0≤p) (h1 : p<1)
    (hP : Stochastic P) (hT : Stochastic T) (hminor : ∀ x y,p*T x y≤P x y)
    (hTP : Commute T P) (hET : avg π*T=avg π) (hEP : Commute (avg π) P)
    (t : ℕ) (x : X) :
    tv ((P^t) x) (unif X) ≤ tv (push π ((P^t) x)) (push π (unif X)) +
      ∑ k ∈ Finset.range (t+1), weight t k p * tv ((T^k) x) (avg π x) := by
  apply quotient_transfer π hs P T (residual P T p) p h0 h1.le (mixture_residual _ _ _ h1)
    _ (stochastic_residual _ _ _ h1 hP hT hminor) hET hEP
  exact (hTP.sub_right ((Commute.refl T).smul_right p)).smul_right _

theorem weight_moment (t : ℕ) (p β : ℝ) :
    (∑ k ∈ Finset.range (t+1), weight t k p*β^k) = (1-p+p*β)^t := by
  rw [add_comm (1-p),add_pow]
  apply Finset.sum_congr rfl
  intro k _
  simp only [weight,mul_pow]
  ring

/-- A geometric fiber bound costs only the binomially thinned clock. -/
theorem geometric_transfer (π : X → C) (hs : Function.Surjective π)
    (P T : Matrix X X ℝ) (p : ℝ) (h0 : 0≤p) (h1 : p<1)
    (hP : Stochastic P) (hT : Stochastic T) (hminor : ∀ x y,p*T x y≤P x y)
    (hTP : Commute T P) (hET : avg π*T=avg π) (hEP : Commute (avg π) P)
    (t : ℕ) (x : X) (a β : ℝ)
    (hf : ∀ k, tv ((T^k) x) (avg π x) ≤ a*β^k) :
    tv ((P^t) x) (unif X) ≤ tv (push π ((P^t) x)) (push π (unif X)) +
      a*(1-p+p*β)^t := by
  apply (quotient_transfer_minorized π hs P T p h0 h1 hP hT hminor hTP hET hEP t x).trans
  apply add_le_add_right
  calc
    _ ≤ ∑ k ∈ Finset.range (t+1), weight t k p * (a*β^k) :=
      Finset.sum_le_sum (fun k _ => mul_le_mul_of_nonneg_left (hf k) (weight_nonneg h0 h1.le t k))
    _ = _ := by
      rw [← weight_moment,Finset.mul_sum]
      exact Finset.sum_congr rfl (fun _ _ => by ring)

#print axioms quotient_transfer_minorized
#print axioms geometric_transfer
end HubTransfer
