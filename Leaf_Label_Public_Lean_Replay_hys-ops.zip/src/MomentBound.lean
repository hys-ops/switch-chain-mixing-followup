import HarmonicDrift
open Finset HubTransfer LeafDrift
open scoped Matrix
noncomputable section
namespace LeafMoment
variable {X : Type*} [Fintype X] [DecidableEq X]

theorem eigen_iter (P : Matrix X X ℝ) (Z : X → ℝ) (a : ℝ)
    (he : ∀ x, obs (P x) Z = a*Z x) (t : ℕ) (x : X) :
    obs ((P^t) x) Z=a^t*Z x := by
  induction t with
  | zero => simp [obs,Matrix.one_apply]
  | succ t ih =>
    rw [pow_succ,row_mul,show (fun j => obs (P j) Z)=fun j => a*Z j from funext he,obs_scale,ih,pow_succ];ring

theorem variance_iter (P : Matrix X X ℝ) (hp : Stochastic P) (Z : X → ℝ) (a V : ℝ)
    (hV : 0≤V) (hs : ∀ x, obs (P x) (fun y => Z y^2) ≤ a^2*(Z x)^2+(1-a^2)*V)
    (t : ℕ) (x : X) :
    obs ((P^t) x) (fun y => Z y^2) ≤ (a^t*Z x)^2+V := by
  induction t with
  | zero => simpa [obs,Matrix.one_apply] using hV
  | succ t ih =>
    rw [pow_succ,row_mul]
    have pt := stochastic_pow hp t
    calc
      _ ≤ obs ((P^t) x) (fun j => a^2*(Z j)^2+(1-a^2)*V) := obs_mono (pt.1 x) hs
      _ = a^2*obs ((P^t) x) (fun y => Z y^2)+(1-a^2)*V := by rw [obs_add,obs_scale,obs_const _ (pt.2 x)]
      _ ≤ a^2*((a^t*Z x)^2+V)+(1-a^2)*V := by gcongr
      _ = _ := by rw [pow_succ];ring

theorem stationary_square (P : Matrix X X ℝ) (hp : Stochastic P) (w Z : X → ℝ)
    (hw : ∑ x,w x=1) (hw0 : ∀ x,0≤w x) (hst : ∀ f : X → ℝ, obs w (fun y => obs (P y) f)=obs w f)
    (a V : ℝ) (ha : a^2<1)
    (hs : ∀ x,obs (P x) (fun y => Z y^2) ≤ a^2*(Z x)^2+(1-a^2)*V) :
    obs w (fun y => Z y^2) ≤ V := by
  have h := obs_mono hw0 hs
  rw [hst,obs_add,obs_scale,obs_const _ hw] at h
  nlinarith [h]

theorem half_tv (P : Matrix X X ℝ) (hp : Stochastic P) (w Z : X → ℝ)
    (hw : ∑ x,w x=1) (hw0 : ∀ x,0≤w x) (a V : ℝ) (hV : 0≤V)
    (he : ∀ x,obs (P x) Z=a*Z x)
    (hs : ∀ x,obs (P x) (fun y => Z y^2) ≤ a^2*(Z x)^2+(1-a^2)*V)
    (hwz : obs w (fun y => Z y^2) ≤ V) (x : X) (t : ℕ) {m : ℝ}
    (hm : m=a^t*Z x) (hm0 : 0<m) (hbig : 16*V≤m^2) :
    (1:ℝ)/2 ≤ tv ((P^t) x) w := by
  classical
  let p := (P^t) x
  let E := univ.filter (fun y => m≤2*Z y)
  have pt := stochastic_pow hp t
  have hmean : obs p Z = m := (eigen_iter P Z a he t x).trans hm.symm
  have hv := variance_iter P hp Z a V hV hs t x
  rw [←hm] at hv
  have hz : obs p (fun y => (Z y-m)^2)≤V := by
    have hh : (fun y => (Z y-m)^2)=(fun y => (Z y^2+(-2*m)*Z y)+m^2) := by funext y;ring
    rw [hh,obs_add,obs_add,obs_scale,obs_const _ (pt.2 x),hmean]
    change obs p (fun y => Z y^2)≤_ at hv
    linarith
  have pa (y) : m^2 ≤ m^2*ind E y + 4*(Z y-m)^2 := by
    by_cases hy : m≤2*Z y
    · simp [ind,E,hy]; nlinarith [sq_nonneg (Z y-m)]
    · simp [ind,E,hy]
      nlinarith [mul_self_le_mul_self hm0.le (show m≤2*(m-Z y) by linarith)]
  have pb (y) : m^2*ind E y ≤ 4*Z y^2 := by
    by_cases hy : m≤2*Z y
    · simp [ind,E,hy]; nlinarith [mul_self_le_mul_self hm0.le hy]
    · simp [ind,E,hy,sq_nonneg]
  have h1 := obs_mono (pt.1 x) pa
  rw [obs_const _ (pt.2 x),obs_add,obs_scale,obs_scale] at h1
  have h2 := obs_mono hw0 pb
  rw [obs_scale,obs_scale] at h2
  have hd : m^2*(1/2) ≤ m^2*(obs p (ind E)-obs w (ind E)) := by
    change m^2 ≤ m^2*obs p (ind E)+4*obs p (fun y => (Z y-m)^2) at h1
    linarith
  exact ((mul_le_mul_iff_right₀ (sq_pos_of_pos hm0)).mp hd).trans (event_gap (pt.2 x) hw E)

#print axioms half_tv
end LeafMoment
