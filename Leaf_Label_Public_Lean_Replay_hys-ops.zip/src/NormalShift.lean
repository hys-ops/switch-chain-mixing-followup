import CdfUniform
import GraphWindows
import Mathlib.MeasureTheory.Integral.IntervalIntegral.FundThmCalculus
import Mathlib.Analysis.Calculus.Deriv.MeanValue
open MeasureTheory ProbabilityTheory Filter Set Topology
noncomputable section
namespace NormalShift

def F (m x:ℝ) := cdf (gaussianReal m 1) x
lemma integral_cdf (m x:ℝ) : F m x = ∫ y in Iic x,gaussianPDFReal m 1 y := by
  rw [F,cdf_eq_real,measureReal_def,gaussianReal_apply_eq_integral m one_ne_zero,
      ENNReal.toReal_ofReal (integral_nonneg fun y => gaussianPDFReal_nonneg _ _ y)]

lemma deriv_cdf (m x:ℝ) : HasDerivAt (F m) (gaussianPDFReal m 1 x) x := by
  have cint := integrable_gaussianPDFReal m 1
  have hC : Continuous (gaussianPDFReal m 1) := by rw [gaussianPDFReal_def];fun_prop
  have eq : F m = fun z => F m 0 + ∫ y in (0:ℝ)..z,gaussianPDFReal m 1 y := by
    funext z
    rw [integral_cdf,integral_cdf,←intervalIntegral.integral_Iic_sub_Iic cint.integrableOn cint.integrableOn]
    ring
  rw [eq]
  exact (intervalIntegral.integral_hasDerivAt_right cint.intervalIntegrable
    (hC.stronglyMeasurable.stronglyMeasurableAtFilter) hC.continuousAt).const_add _

lemma translate (m x:ℝ) : F m x=F 0 (x-m) := by
  have hm : (gaussianReal 0 1).map (fun z:ℝ=>z+m)=gaussianReal m 1 := by simpa using (gaussianReal_map_add_const (μ:=0) (v:=1) m)
  simp only [F,cdf_eq_real,←hm,map_measureReal_apply (by fun_prop : Measurable (fun z:ℝ=>z+m)) measurableSet_Iic]
  congr 1
  ext z
  change z+m≤x ↔ z≤x-m
  constructor <;> intro h <;> linarith

lemma reflection (x:ℝ) : F 0 (-x)=1-F 0 x := by
  let μ := gaussianReal 0 1
  haveI : NullSingletonClass μ := nullSingletonClass_gaussianReal (by norm_num : (1:NNReal)≠0)
  have hm : μ.map (fun x:ℝ => -x)=μ := by simpa [μ] using (gaussianReal_map_neg (μ:=0) (v:=1))
  change cdf μ (-x)=1-cdf μ x
  simp only [cdf_eq_real]
  calc μ.real (Iic (-x)) = μ.real ((fun z:ℝ=> -z) ⁻¹' Iic (-x)) := by
                             conv_lhs => rw [←hm,map_measureReal_apply measurable_neg measurableSet_Iic]
       _ = μ.real (Ici x) := by congr 1;ext z;change -z≤-x ↔ x≤z;exact neg_le_neg_iff
       _ = μ.real (Ioi x) := measureReal_congr Ioi_ae_eq_Ici.symm
       _ = 1-μ.real (Iic x) := by rw [←compl_Iic,measureReal_compl measurableSet_Iic,probReal_univ]

def gap (m x:ℝ) := F 0 x-F m x

lemma normal_peak {m:ℝ} (hm : 0≤m) :
    gap m (m/2) = 2*F 0 (m/2)-1 ∧ ∀ x, gap m x ≤ 2*F 0 (m/2)-1 := by
  have peak : gap m (m/2) = 2*F 0 (m/2)-1 := by
    rw [gap,translate m,show m/2-m = -(m/2) by ring,reflection];ring
  have hD (x:ℝ) : HasDerivAt (gap m) (gaussianPDFReal 0 1 x-gaussianPDFReal m 1 x) x :=
    (deriv_cdf 0 x).sub (deriv_cdf m x)
  have cmp (x:ℝ) (hx:x≤m/2) : gaussianPDFReal m 1 x ≤ gaussianPDFReal 0 1 x := by
    simp only [gaussianPDFReal,NNReal.coe_one,sub_zero,mul_one]
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply Real.exp_le_exp.mpr
    nlinarith [mul_nonneg hm (show 0≤m-2*x by linarith)]
  have cmp' (x:ℝ) (hx:m/2≤x) : gaussianPDFReal 0 1 x ≤ gaussianPDFReal m 1 x := by
    simp only [gaussianPDFReal,NNReal.coe_one,sub_zero,mul_one]
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply Real.exp_le_exp.mpr
    nlinarith [mul_nonneg hm (show 0≤2*x-m by linarith)]
  have mono : MonotoneOn (gap m) (Iic (m/2)) :=
    monotoneOn_of_deriv_nonneg (convex_Iic _) (fun x _ => (hD x).continuousAt.continuousWithinAt)
      (fun x _ => (hD x).differentiableAt.differentiableWithinAt) (fun x hx => by rw [(hD x).deriv];exact sub_nonneg.mpr (cmp x (show x∈Iic (m/2) from interior_subset hx)))
  have anti : AntitoneOn (gap m) (Ici (m/2)) :=
    antitoneOn_of_deriv_nonpos (convex_Ici _) (fun x _ => (hD x).continuousAt.continuousWithinAt)
      (fun x _ => (hD x).differentiableAt.differentiableWithinAt) (fun x hx => by rw [(hD x).deriv];exact sub_nonpos.mpr (cmp' x (show x∈Ici (m/2) from interior_subset hx)))
  refine ⟨peak,fun x => ?_⟩
  rw [←peak]
  rcases le_total x (m/2) with hx|hx
  · exact mono hx (Set.mem_Iic.mpr le_rfl) hx
  · exact anti (Set.mem_Ici.mpr le_rfl) hx hx

#print axioms normal_peak
end NormalShift
