import MarkovTV

open scoped BigOperators Matrix
noncomputable section
namespace HubTransfer
variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq X] [DecidableEq C]

theorem avg_symm (π : X → C) (x y : X) : avg π x y = avg π y x := by
  by_cases h : π x=π y
  · simp [avg,h]
  · simp [avg,h,Ne.symm h]

theorem avg_row (π : X → C) (x : X) : ∑ y,avg π x y=1 := by
  have h (y : X) : avg π x y = if π y=π x then 1/(fiberSize π (π x):ℝ) else 0 := by
    rw [avg_symm]
    rfl
  simp_rw [h]
  change push π (fun _ => 1/(fiberSize π (π x):ℝ)) (π x)=1
  rw [push_const]
  have hz : (fiberSize π (π x):ℝ)≠0 := by exact_mod_cast (fiberSize_pos π x).ne'
  field_simp

theorem avg_column (π : X → C) (y : X) : ∑ x,avg π x y=1 := by
  simp_rw [avg_symm π _ y]
  exact avg_row π y

theorem avg_absorbs (π : X → C) (T : Matrix X X ℝ)
    (hs : ∀ x y, π x ≠ π y → T x y=0) (hc : ∀ y, ∑ x, T x y=1) :
    avg π*T = avg π := by
  ext x y
  rw [Matrix.mul_apply]
  have h (z : X) : avg π x z*T z y=avg π x y*T z y := by
    by_cases hz : π z=π y
    · simp [avg,hz]
    · rw [hs z y hz,mul_zero,mul_zero]
  simp_rw [h]
  rw [← Finset.mul_sum,hc,mul_one]

/-- Within-fiber transitivity by automorphisms preserving the full partition and M. -/
def OrbitInvariant (π : X → C) (M : Matrix X X ℝ) : Prop :=
  ∀ x y, π x=π y → ∃ e : Equiv.Perm X, e x=y ∧ (∀ z,π (e z)=π z) ∧
    (∀ z w,M (e z) (e w)=M z w)

theorem invariant_mul (A B : Matrix X X ℝ) (e : Equiv.Perm X)
    (ha : ∀ u v,A (e u) (e v)=A u v) (hb : ∀ u v,B (e u) (e v)=B u v)
    (x y : X) : (A*B) (e x) (e y)=(A*B) x y := by
  simp only [Matrix.mul_apply]
  rw [← Equiv.sum_comp e (fun z => A (e x) z*B z (e y))]
  simp_rw [ha,hb]

theorem orbit_commute (π : X → C) (M : Matrix X X ℝ) (hm : OrbitInvariant π M) :
    Commute (avg π) M := by
  let E := avg π
  have he (e : Equiv.Perm X) (hp : ∀ z,π (e z)=π z) (x y : X) :
      E (e x) (e y)=E x y := by simp [E,avg,hp]
  have hc (x u v : X) (h : π u=π v) : (M*E) x u=(M*E) x v := by
    simp [E,row_avg,lift,h]
  have hr (u v x : X) (h : π u=π v) : (E*M) u x=(E*M) v x := by
    simp [E,Matrix.mul_apply,avg,h]
  have hr' (u v x : X) (h : π u=π v) : (M*E) u x=(M*E) v x := by
    obtain ⟨e,hu,hp,hM⟩ := hm u v h
    rw [←hu,← invariant_mul M E e hM (he e hp) u x]
    exact hc _ _ _ (hp _)
  have hc' (x u v : X) (h : π u=π v) : (E*M) x u=(E*M) x v := by
    obtain ⟨e,hu,hp,hM⟩ := hm u v h
    rw [←hu,← invariant_mul E M e (he e hp) hM x u]
    exact hr _ _ _ (hp _)
  have left : E*(M*E)=M*E := by
    ext x y
    rw [Matrix.mul_apply]
    have hh (z : X) : E x z*(M*E) z y=E x z*(M*E) x y := by
      by_cases hz : π x=π z
      · rw [hr' _ _ _ hz.symm]
      · simp [E,avg,hz]
    simp_rw [hh]
    rw [← Finset.sum_mul,avg_row,one_mul]
  have right : (E*M)*E=E*M := by
    ext x y
    rw [Matrix.mul_apply]
    have hh (z : X) : (E*M) x z*E z y=(E*M) x y*E z y := by
      by_cases hz : π z=π y
      · rw [hc' _ _ _ hz]
      · simp [E,avg,hz]
    simp_rw [hh]
    rw [← Finset.mul_sum,avg_column,mul_one]
  exact right.symm.trans ((mul_assoc E M E).trans left)

#print axioms avg_absorbs
#print axioms orbit_commute
end HubTransfer
