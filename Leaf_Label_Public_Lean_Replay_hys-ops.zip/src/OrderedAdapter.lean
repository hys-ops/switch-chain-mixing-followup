import TridiagonalUrn
import OrderedKernel
open Finset HubTransfer JohnsonLower BinaryOverlap HubMarks OrderedUrn
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
variable {N k : ℕ}

def clamp (k n : ℕ) : Fin (k+1) := ⟨min k n,by omega⟩
theorem clamped (z : Fin (k+1)) : clamp k z.val=z := Fin.ext (min_eq_right (by have:=z.isLt;omega))
theorem clamped_dn (z : Fin (k+1)) : clamp k (z.val-1)=down z := Fin.ext (min_eq_right (by have:=z.isLt;omega))

theorem ordered_action (K S : JohnsonLower.Slice N k) {Q:ℝ} (hn : 0<N) (hq : Q≠0) (f : Z k→ℝ) :
    (walk N k Q *ᵥ (fun T=>f (level K T))) S = (B N k Q *ᵥ f) (level K S) := by
  let z:=level K S
  let g:=fun n:ℕ=>f (clamp k n)
  have hf (T:JohnsonLower.Slice N k) : f (level K T)=g (overlap K T) := by
    change f (level K T)=f (clamp k (level K T).val)
    rw [clamped]
  simp_rw [hf]
  rw [overlap_row K S Q hn hq,B_apply]
  change g z.val+(N:ℝ)/Q*SparseUrn.generator N k g z.val=
    f z+birth k Q z*(f (up z)-f z)+death N k Q z*(f (down z)-f z)
  have hn' : (N:ℝ) ≠0 := by exact_mod_cast hn.ne'
  unfold SparseUrn.generator SparseUrn.birth SparseUrn.death birth death g
  rw [clamped,clamped_dn]
  change f z+ _ * (_*(f (up z)-f z) + _*(f (down z)-f z))=_
  field_simp;ring

theorem ordered_matrix (K : JohnsonLower.Slice N k) {Q:ℝ} (hn : 0<N) (hq : Q≠0) (t : ℕ) :
    (walk N k Q)^t * marginal (level K)=marginal (level K)*(B N k Q)^t := by
  have hw : walk N k Q*marginal (level K)=marginal (level K)*B N k Q := by
    ext x j;rw [projected]
    let f:=fun i:Fin (k+1) => (1:Matrix _ _ ℝ) i j
    have he:=ordered_action K x hn hq f
    have hR : (B N k Q *ᵥ f) (level K x)=B N k Q (level K x) j := by
      change (B N k Q*(1:Matrix (Fin (k+1)) (Fin (k+1)) ℝ)) (level K x) j=_
      rw [Matrix.mul_one]
    rw [hR] at he;exact he
  induction t with
  | zero => simp
  | succ t ih => rw [pow_succ,pow_succ,Matrix.mul_assoc,hw,←Matrix.mul_assoc,ih,Matrix.mul_assoc]

theorem ordered_push (K S : JohnsonLower.Slice N k) {Q : ℝ} (hN : 0<N) (hQ : Q≠0) (t : ℕ) :
    push (level K) (((walk N k Q)^t) S) = ((B N k Q)^t) (level K S) := by
  funext j;rw [←pushed_column,ordered_matrix K hN hQ t,projected]

theorem push_marginal {X Y : Type*} [Fintype X] [DecidableEq Y] (π : X→Y) (u : X→ℝ) :
    u ᵥ* marginal π=push π u := by
  funext j;simp [Matrix.vecMul,dotProduct,marginal,push,mul_ite]

theorem ordered_equilibrium (K : JohnsonLower.Slice N k) {Q:ℝ} (hn : 0<N) (hq : Q≠0) (t : ℕ) :
    (hyperProb N k) ᵥ* ((B N k Q)^t)=hyperProb N k := by
  let W := walk N k Q
  have hu : push (level K) (unif _)=hyperProb N k := funext (hypergeometric K)
  have hw (x : JohnsonLower.Slice N k) : ∑ y,W x y=1 := by
    have h:=swap_row Q hq x (fun _=>1)
    simpa [Matrix.mulVec,dotProduct,W] using h
  have huW : (unif _) ᵥ* W=unif _ := by
    funext j; change (∑ i, (1/(Fintype.card (JohnsonLower.Slice N k):ℝ))*W i j)=_
    simp_rw [show ∀i,W i j=W j i from fun i=>kernel_symm Q i j,←mul_sum,hw,mul_one];rfl
  have huWt : (unif _) ᵥ* (W^t)=unif _ := by
    induction t with
    | zero=>simp
    | succ t ih=> rw [pow_succ,←Matrix.vecMul_vecMul,ih,huW]
  rw [←hu,←push_marginal,Matrix.vecMul_vecMul,←ordered_matrix K hn hq t,←Matrix.vecMul_vecMul,huWt]

theorem ordered_distance (K : JohnsonLower.Slice N k) {Q : ℝ} (hn : 0<N) (hq : Q≠0) (t : ℕ) :
    tv (((walk N k Q)^t) K) (unif _) = tv (((B N k Q)^t) (Fin.last k)) (hyperProb N k) := by
  rw [exact_binary_tv K Q hn hq t,ordered_push K K hn hq t,
    show level K K=Fin.last k from Fin.ext (BinaryOverlap.full.mpr rfl),
    show push (level K) (unif _)=hyperProb N k from funext (hypergeometric K)]

#print axioms ordered_push
#print axioms ordered_equilibrium
#print axioms ordered_distance
end PhysicalReduction
