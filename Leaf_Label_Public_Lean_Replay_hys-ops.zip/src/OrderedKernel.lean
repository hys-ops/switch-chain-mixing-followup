import MarkovTV
open Finset HubTransfer
open scoped Matrix
namespace OrderedUrn
noncomputable section
attribute [local instance] Classical.propDecidable

abbrev Z (k : ℕ):=Fin (k+1)
abbrev Pair (k : ℕ):={p : Z k × Z k // p.2≤p.1}
variable {k : ℕ}
def high (x : Pair k) : Z k:=x.1.1
def low (x : Pair k) : Z k:=x.1.2
def diff (x : Pair k):ℝ := (high x:ℝ)-(low x:ℝ)
def up (z : Z k) : Z k := ⟨min k (z.val+1),by omega⟩
def down (z : Z k) : Z k := ⟨z.val-1,by have:=z.isLt;omega⟩
def birth (k : ℕ) (Q : ℝ) (z : Z k) : ℝ := ((k:ℝ)-(z.val:ℝ))^2/Q
def death (N k : ℕ) (Q : ℝ) (z : Z k) : ℝ := (z.val:ℝ)*((N:ℝ)-2*k+(z.val:ℝ))/Q
def pt {X : Type*} [DecidableEq X] (w : ℝ) (x y : X) :ℝ:=if y=x then w else 0

def B (N k : ℕ) (Q : ℝ) : Matrix (Z k) (Z k) ℝ := fun z y=>
  pt (1-birth k Q z-death N k Q z) z y + pt (birth k Q z) (up z) y + pt (death N k Q z) (down z) y

theorem eval_pt {X : Type*} [Fintype X] [DecidableEq X] (w : ℝ) (x : X) (f : X→ℝ) :
    (∑ y,pt w x y*f y)=w*f x := by
  rw [sum_eq_single x]
  · simp [pt]
  · intro b _ hb;simp [pt,hb]
  · simp

theorem B_apply (N k : ℕ) (Q : ℝ) (f : Z k→ℝ) (z : Z k) :
    (B N k Q *ᵥ f) z = f z+birth k Q z*(f (up z)-f z)+death N k Q z*(f (down z)-f z) := by
  simp only [B,Matrix.mulVec,dotProduct,add_mul,sum_add_distrib,eval_pt];ring
end
end OrderedUrn
