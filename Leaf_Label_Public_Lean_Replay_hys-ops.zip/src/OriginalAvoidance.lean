import StationaryMarks
import GoodTV
import ShapeProfile
namespace Avoid
open OAI.Problem315 Finset TwoHub TwoHubUnequal Filter Topology
open scoped BigOperators
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def goodMass (a c : Fin n) (K : Finset (Fin n)) (t : ℕ) (G : GraphState n d) : ℝ :=
  ∑ F∈goodSet a c K d,kernelPow n d t G F

theorem graph_tv_avoid (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (hN : 0<r+s)
    (G : GraphState n d) (K : Finset (Fin n)) (hK : K⊆leaves a c) (h0 : marked a c G⊆K) (t : ℕ) :
    |tvDistanceFrom n d t G - (1-goodMass a c K t G)| ≤
       stationary r s+(K.card:ℝ)*(r+1)/(r+s) := by
  let u : ℝ := 1/(stateCount n d:ℝ)
  have hcard : Fintype.card (GraphState n d)≠0 := (Fintype.card_pos_iff.mpr ⟨G⟩).ne'
  have hu : ∑ _F : GraphState n d,u = 1 := by simp [u,stateCount,allGraphStates,hcard]
  apply le_trans _ (failure_mass sp K hK hN hn G)
  apply tv_mass (goodSet a c K d) (kernelPow n d t G) (fun _ => u)
    (fun F => ManyCore.pow_nonneg t G F) (fun F => by dsimp [u];positivity) (row_mass hn t G) hu
  intro X hX Y hY
  rw [flat_good sp G K h0 t (mem_filter.mp hX).2 (mem_filter.mp hY).2]

/-- The finite graph statement with the canonical initial protected set, including both shapes. -/
theorem graph_tv_initial (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (hN : 0<r+s)
    (G : GraphState n d) (t : ℕ) :
    |tvDistanceFrom n d t G-(1-goodMass a c (marked a c G) t G)| ≤
      stationary r s+((r:ℝ)+1)^2/(r+s) := by
  have h := graph_tv_avoid sp hn hN G (marked a c G) (fun _ hx => (mem_leaves _ _ _).2 (marked_leaf G hx))
    (by rfl) t
  apply h.trans
  have hm : (marked a c G).card ≤ r+1 := by rw [marked_card sp G];split <;> omega
  have hm' : ((marked a c G).card:ℝ) ≤ (r:ℝ)+1 := by exact_mod_cast hm
  gcongr <;> first | exact hm' | positivity | rw [sq];gcongr

/-- Along any fixed-r family and any times, convergence of the *single* good-event
mass implies convergence of full original point-start total variation. -/
theorem fixed_tv_of_good {r : ℕ} (hr : 0<r) (F : TwoHubUnequal.Family r)
    (G : (k:ℕ) → GraphState (r+k+4) (F.d k)) (t : ℕ→ℕ) {b : ℝ}
    (hg : Tendsto (fun k => goodMass (F.a k) (F.c k) (marked (F.a k) (F.c k) (G k)) (t k) (G k)) atTop (𝓝 b)) :
    Tendsto (fun k => tvDistanceFrom _ (F.d k) (t k) (G k)) atTop (𝓝 (1-b)) := by
  let p (k : ℕ) := goodMass (F.a k) (F.c k) (marked (F.a k) (F.c k) (G k)) (t k) (G k)
  let v (k : ℕ) := tvDistanceFrom _ (F.d k) (t k) (G k)
  have hN : Tendsto (fun k:ℕ => (r:ℝ)+(k+2)) atTop atTop := by
    have z := (tendsto_natCast_atTop_atTop (R:=ℝ)).atTop_add (tendsto_const_nhds (x:=(r:ℝ)+2))
    exact z.congr (fun k => by ring)
  have he := (stationary_zero r hr).add ((tendsto_const_nhds (x:=((r:ℝ)+1)^2)).div_atTop hN)
  simp only [add_zero] at he
  have hd : Tendsto (fun k => v k -(1-p k)) atTop (𝓝 0) := by
    rw [tendsto_zero_iff_norm_tendsto_zero]
    apply squeeze_zero (fun _ => norm_nonneg _) _ he
    intro k;simpa [Real.norm_eq_abs,p,v] using graph_tv_initial (F.spec k) (by omega) (by omega) (G k) (t k)
  have H := hd.add ((tendsto_const_nhds (x:=(1:ℝ))).sub hg)
  simp only [zero_add] at H
  apply H.congr;intro k;change v k-(1-p k)+(1-p k)=v k;ring
#print axioms graph_tv_avoid
#print axioms fixed_tv_of_good
end
end Avoid
