import ScalarEndpoint
open Finset HubTransfer JohnsonLower BinaryOverlap
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
variable {N k : ℕ}
abbrev fset (K : JohnsonLower.Slice N k) (j : Fin (k+1)) :=
  univ.filter (fun x : JohnsonLower.Slice N k=>level K x=j)

def parts (K : JohnsonLower.Slice N k) (j : Fin (k+1)) :
    ↥(fset K j) ≃ (↥(K.val.powersetCard j.val) × ↥(K.valᶜ.powersetCard (k-j.val))) where
  toFun x := by
    let T:=x.val.val
    have hj : (T∩K.val).card=j.val := congrArg Fin.val ((mem_filter.mp x.property).2)
    have hk:T.card=k:=x.val.property
    have hd:=card_sdiff_add_card_inter T K.val
    exact (⟨T∩K.val,mem_powersetCard.mpr ⟨inter_subset_right,hj⟩⟩,
      ⟨T\K.val,mem_powersetCard.mpr ⟨fun i hi=>mem_compl.mpr (mem_sdiff.mp hi).2,by omega⟩⟩)
  invFun p := by
    obtain ⟨L,R⟩:=p
    have hs:=(mem_powersetCard.mp L.property).1
    have hL:=(mem_powersetCard.mp L.property).2
    have ht:=(mem_powersetCard.mp R.property).1
    have hR:=(mem_powersetCard.mp R.property).2
    have dis:Disjoint L.val R.val := disjoint_left.mpr fun a ha h=>mem_compl.mp (ht h) (hs ha)
    let T : JohnsonLower.Slice N k := ⟨L.val∪R.val,by rw [card_union_of_disjoint dis,hL,hR];have :=j.isLt;omega⟩
    refine ⟨T,mem_filter.mpr ⟨mem_univ _,Fin.ext ?_⟩⟩
    change ((L.val∪R.val)∩K.val).card=j.val
    have he:(L.val∪R.val)∩K.val=L.val := by
      ext i;simp only [mem_inter,mem_union];constructor
      · rintro ⟨hi,hk⟩;exact hi.elim id (fun h=>False.elim (mem_compl.mp (ht h) hk))
      · exact fun hi=>⟨Or.inl hi,hs hi⟩
    rwa [he]
  left_inv x := by
    apply Subtype.ext;apply Subtype.ext
    change (x.val.val∩K.val)∪(x.val.val\K.val)=x.val.val
    ext i;simp only [mem_union,mem_inter,mem_sdiff];tauto
  right_inv p := by
    obtain ⟨L,R⟩:=p
    obtain ⟨hs,_⟩:=mem_powersetCard.mp L.property
    obtain ⟨ht,_⟩:=mem_powersetCard.mp R.property
    apply Prod.ext
    · apply Subtype.ext;change (L.val∪R.val)∩K.val=L.val
      ext i;simp only [mem_union,mem_inter];constructor
      · rintro ⟨hi,hk⟩;exact hi.elim id (fun h=>False.elim (mem_compl.mp (ht h) hk))
      · exact fun hi=>⟨Or.inl hi,hs hi⟩
    · apply Subtype.ext;change (L.val∪R.val)\K.val=R.val
      ext i;simp only [mem_union,mem_sdiff];constructor
      · rintro ⟨hi,hk⟩;exact hi.elim (fun h=>False.elim (hk (hs h))) id
      · exact fun hi=>⟨Or.inr hi,mem_compl.mp (ht hi)⟩

theorem slice_cardinality (N k : ℕ) : Fintype.card (JohnsonLower.Slice N k)=N.choose k := by
  let A := (univ : Finset (Fin N)).powersetCard k
  let e : JohnsonLower.Slice N k ≃ ↥A := Equiv.subtypeEquivRight (fun S => by simp [A])
  rw [Fintype.card_congr e,Fintype.card_coe]
  simp [A,card_powersetCard]

/-- The exact stationary scalar law, including impossible overlap levels (weight zero). -/
theorem hypergeometric {N k : ℕ} (K : JohnsonLower.Slice N k) (j : Fin (k+1)) :
    push (level K) (unif _) j =
      ((k.choose j.val:ℕ):ℝ)*(((N-k).choose (k-j.val):ℕ):ℝ)/((N.choose k:ℕ):ℝ) := by
  have e:=Fintype.card_congr (parts K j)
  rw [Fintype.card_prod,Fintype.card_coe,Fintype.card_coe,Fintype.card_coe,
      card_powersetCard,card_powersetCard,card_compl,K.property,Fintype.card_fin] at e
  change push (level K) (fun _=>1/(Fintype.card (JohnsonLower.Slice N k):ℝ)) j=_
  rw [push_const,slice_cardinality]
  change (↑(fset K j).card:ℝ)*(1/↑(N.choose k))=_
  rw [e,Nat.cast_mul];ring
#print axioms hypergeometric
end PhysicalReduction
