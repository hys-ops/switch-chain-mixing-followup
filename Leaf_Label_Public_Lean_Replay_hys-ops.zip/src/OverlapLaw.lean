import CountTV
import OverlapStep
import OverlapTV
open Finset HubTransfer JohnsonLower HubMarks
open scoped Matrix Classical
noncomputable section
namespace CountLimit
variable {X : Type*} [Fintype X]
def group (b : X→ℕ) (v : X→ℝ) (j : ℕ) := ∑ x, if j=b x then v x else 0
lemma grouped (b : X→ℕ) (v : X→ℝ) :
    HasSum (group b v) (∑ x,v x) := by
  exact hasSum_sum (fun x (_ : x∈(univ:Finset X)) => hasSum_ite_eq (b x) (v x))
def imageLaw (b : X→ℕ) (v : X→ℝ) (hn : ∀ x, 0≤v x) (ht : ∑ x,v x=1) : Law :=
  ⟨group b v,fun j => sum_nonneg (fun x _ => by split <;> simp_all), ht ▸ grouped b v⟩
lemma image_gen (b : X→ℕ) (v : X→ℝ) (hn : ∀ x,0≤v x) (ht : ∑ x,v x=1) (z : ℝ) :
    pgf (imageLaw b v hn ht) z = ∑ x,v x*z^(b x) := by
  refine ((grouped b (fun x=>v x*z^(b x))).congr_fun ?_).tsum_eq
  intro j;change (∑ x,if j=b x then v x else 0)*z^j= _
  rw [sum_mul];apply sum_congr rfl;intro x _
  by_cases h : j=b x <;> simp [h]

lemma group_tv (b : X → ℕ) (v w : X→ℝ)
    (hv : ∀ x,0≤v x) (hw : ∀ x,0≤w x) (sv : ∑ x,v x=1) (sw : ∑ x,w x=1)
    (hf : ∀ x y, b x=b y → v x-w x=v y-w y) :
    TV (imageLaw b v hv sv) (imageLaw b w hw sw) = tv v w := by
  classical
  unfold TV tv
  congr 1
  refine ((grouped b (fun x=>|v x-w x|)).congr_fun ?_).tsum_eq
  intro j
  change |group b v j-group b w j| = group b (fun x=>|v x-w x|) j
  simp only [group,←sum_filter]
  let V := univ.filter (fun x => j=b x)
  change |(∑ x∈V,v x)-(∑ x∈V,w x)|= ∑ x∈V,|v x-w x|
  rw [←sum_sub_distrib]
  by_cases h : V.Nonempty
  · obtain ⟨a,ha⟩ := h
    have hconst (x : X) (hx:x∈V) : v x-w x=v a-w a :=
      hf _ _ ((mem_filter.mp hx).2.symm.trans (mem_filter.mp ha).2)
    rw [sum_congr rfl hconst,sum_congr rfl (fun x hx => congrArg abs (hconst x hx))]
    simp only [sum_const,nsmul_eq_mul,abs_mul,abs_of_nonneg (Nat.cast_nonneg V.card : (0:ℝ)≤V.card)]
  · simp [not_nonempty_iff_eq_empty.mp h]

variable {N k:ℕ}

def lawAt (K : JohnsonLower.Slice N k) (Q : ℝ) (hq : 0<Q) (hb : (k:ℝ)*(N-k)≤Q) (t : ℕ) : Law :=
  imageLaw (overlap K) (((walk N k Q)^t) K)
    ((stochastic_pow (kernel_stoch hq hb) t).1 K) ((stochastic_pow (kernel_stoch hq hb) t).2 K)

lemma unif_mass (K : JohnsonLower.Slice N k) :
    ∑ x : JohnsonLower.Slice N k,unif (JohnsonLower.Slice N k) x=1 := by
  let : Nonempty (JohnsonLower.Slice N k) := ⟨K⟩
  simp only [unif,sum_const,card_univ,nsmul_eq_mul,one_div]
  exact mul_inv_cancel₀ (by exact_mod_cast (Fintype.card_ne_zero : Fintype.card (JohnsonLower.Slice N k)≠0))
def lawEquilibrium (K : JohnsonLower.Slice N k) : Law :=
  imageLaw (overlap K) (unif _) (fun _ => by unfold unif;positivity) (unif_mass K)

theorem original_binary_TV (K : JohnsonLower.Slice N k) (Q : ℝ) (hq : 0<Q) (hN : 0<N)
    (hb : (k:ℝ)*(N-k)≤Q) (t : ℕ) :
    TV (lawAt K Q hq hb t) (lawEquilibrium K) = tv (((walk N k Q)^t) K) (unif _) :=
  by
    obtain ⟨f,hf⟩ := BinaryOverlap.radial K Q hN hq.ne' t
    exact group_tv _ _ _ _ _ _ _ (fun S T h => by rw [hf,hf,h];rfl)

#print axioms original_binary_TV
#print axioms image_gen
end CountLimit
