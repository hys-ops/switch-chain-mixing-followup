import ExchangeOrder
open Finset HubTransfer JohnsonLower HubMarks
namespace JohnsonProfile
noncomputable section
attribute [local instance] Classical.propDecidable
variable {N k : ℕ}
def overlap (A : Finset (Fin N)) (S : Slice N k) : ℕ := (S.val∩A).card

private lemma unpaired {α : Type*} [DecidableEq α] {S T : Finset α} (hc : S.card≤T.card)
  {i : α} (hi : i∈S) (ho : i∉T) : ∃ j∈T,j∉S := by
  by_contra! hn
  have e := eq_of_subset_of_card_le hn hc
  exact ho (e ▸ hi)

private lemma replace (U : Slice N k) {i j : Fin N} (hi : i∈U.val) (hj : j∉U.val) :
    (swapSet U i j).val=insert j (U.val.erase i) :=
  congrArg Subtype.val (opposite_side U ⟨i,hi⟩ ⟨j,mem_compl.mpr hj⟩)

private lemma remaining_drops (U V : Slice N k) {i j : Fin N} (hi : i∈U.val) (hiv : i∉V.val)
    (hj : j∈V.val) (hju : j∉U.val) : ((swapSet U i j).val \ V.val).card < (U.val \ V.val).card := by
  rw [replace U hi hju]
  have hsd : insert j (U.val.erase i) \ V.val = (U.val \ V.val).erase i := by
    ext x;simp only [mem_sdiff,mem_insert,mem_erase]
    by_cases he : x=j
    · subst x;simp [hj]
    · simp [he];tauto
  rw [hsd];exact card_erase_lt_of_mem (mem_sdiff.mpr ⟨hi,hiv⟩)

/-- The exchange inequalities imply full ordering by overlap, including constancy on each level. -/
theorem sorted_global {A : Finset (Fin N)} {f : Slice N k→ℝ} (hf : Sorted A f)
    (U V : Slice N k) (h : overlap A U≤overlap A V) : f U≤f V := by
  generalize hm : (U.val \ V.val).card=m
  induction m using Nat.strong_induction_on generalizing U with
  | h m ih =>
    by_cases he : U=V
    · rw [he]
    have hmiss : ∃ i∈U.val, i∉V.val := by
      by_contra! hx;apply he;apply Subtype.ext;exact eq_of_subset_of_card_le hx (V.2.trans U.2.symm).le
    have select : ∃ i∈U.val,∃j∈V.val,i∉V.val ∧ j∉U.val ∧ (i∈A → j∈A) ∧ overlap A (swapSet U i j)≤overlap A V := by
      by_cases marked : ∃ i∈U.val,i∉V.val ∧ i∈A
      · obtain ⟨i,hi,hiv,hia⟩:=marked
        obtain ⟨j,hj,hju⟩:=unpaired (S:=U.val∩A) (T:=V.val∩A) h (mem_inter.mpr ⟨hi,hia⟩)
          (fun he' =>hiv (mem_inter.mp he').1)
        obtain ⟨hjv,hja⟩:=mem_inter.mp hj
        have hji : j∉U.val := fun e=>hju (mem_inter.mpr ⟨e,hja⟩)
        refine ⟨i,hi,j,hjv,hiv,hji,fun _ => hja,?_⟩
        apply le_trans _ h
        unfold overlap;rw [replace U hi hji]
        have st : insert j (U.val.erase i)∩A= insert j ((U.val∩A).erase i) := by
          ext v;by_cases ej : v=j
          · subst v;simp [hja]
          · simp [mem_inter,mem_erase,mem_insert,ej];tauto
        rw [st,card_insert_of_notMem (fun hm=>hji (mem_inter.mp (mem_of_mem_erase hm)).1)]
        exact (card_erase_add_one (mem_inter.mpr ⟨hi,hia⟩)).le
      · obtain ⟨i,hi,hiv⟩:=hmiss
        obtain ⟨j,hjv,hju⟩:=unpaired (V.2.symm ▸ U.2.le) hi hiv
        have hia : i∉A := fun v=> marked ⟨i,hi,hiv,v⟩
        refine ⟨i,hi,j,hjv,hiv,hju,fun q=>(hia q).elim,?_⟩
        apply card_le_card
        rw [replace U hi hju]
        intro z hz;obtain ⟨hz,hA⟩:=mem_inter.mp hz
        rcases mem_insert.mp hz with rfl|hzu
        · exact mem_inter.mpr ⟨hjv,hA⟩
        · exact mem_inter.mpr ⟨by by_contra hn;exact marked ⟨z,mem_of_mem_erase hzu,hn,hA⟩,hA⟩
    obtain ⟨i,hi,j,hj,hiv,hju,ord,hz⟩:=select
    apply (hf U i j hi hju ord).trans
    have desc := remaining_drops U V hi hiv hj hju
    rw [hm] at desc
    exact ih _ desc _ hz rfl

theorem ordered_row (A U V : Slice N k) {Q : ℝ} (hQ : 0<Q) (hN : (N:ℝ)^2≤Q) (t : ℕ)
    (hov : overlap A.val U≤overlap A.val V) : ((walk N k Q)^t) A U≤((walk N k Q)^t) A V := by
  have hs : (walk N k Q).IsSymm := by ext S T;exact kernel_symm Q T S
  have hp := hs.pow t
  rw [←hp.apply A U,←hp.apply A V]
  exact sorted_global (sorted_hit A hQ hN t) U V hov

#print axioms sorted_global
#print axioms ordered_row
end
end JohnsonProfile
