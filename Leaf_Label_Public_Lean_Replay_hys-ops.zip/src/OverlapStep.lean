import MarkSurvival
import SparseSemigroup
open Finset JohnsonLower SparseUrn
open scoped Matrix
namespace HubMarks
noncomputable section
variable {N k : ℕ}

def overlap (K S : Slice N k) := (S.val ∩ K.val).card

lemma overlap_step (K S : Slice N k) (i : ↥S.val) (j : ↥S.valᶜ) :
    overlap K (change S i j) =
    if i.val∈K.val then (if j.val∈K.val then overlap K S else overlap K S-1)
    else (if j.val∈K.val then overlap K S+1 else overlap K S) := by
  classical
  have hj : j.val∉S.val := mem_compl.mp j.property
  let A := S.val ∩ K.val
  have hn : j.val∉A.erase i.val := fun h => hj (mem_inter.mp (mem_of_mem_erase h)).1
  have hg : overlap K (change S i j) = if j.val∈K.val then ((A.erase i.val).card+1) else (A.erase i.val).card := by
    unfold overlap change
    by_cases he : j.val∈K.val
    · have h : insert j.val (S.val.erase i.val) ∩ K.val = insert j.val (A.erase i.val) := by
        ext v;by_cases z:v=j.val <;> simp [z,he,A]
      rw [h,card_insert_of_notMem hn,ite_eq_left he]
    · have h : insert j.val (S.val.erase i.val) ∩ K.val = A.erase i.val := by
        ext v;by_cases z:v=j.val <;> simp [z,he,A]
      rw [h,ite_eq_right he]
  rw [hg]
  by_cases hi : i.val∈K.val
  · have hA : i.val∈A := mem_inter.mpr ⟨i.property,hi⟩
    have ht := card_erase_add_one hA
    change (A.erase i.val).card+1=overlap K S at ht
    split_ifs <;> omega
  · have hA : i.val∉A := fun H=>hi (mem_inter.mp H).2
    simp [hi,A,overlap]

/-- Sum a function constant on the two parts of a finite population. -/
lemma census {α : Type*} [DecidableEq α] (S K : Finset α) (a b : ℝ) :
    (∑ i : ↥S, if i.val∈K then a else b) = ((S∩K).card:ℝ)*a+(S.card-(S∩K).card:ℝ)*b := by
  classical
  rw [sum_coe_sort S (fun i => if i∈K then a else b),sum_ite,filter_mem_eq_inter,filter_notMem_eq_sdiff,sum_const,sum_const,nsmul_eq_mul,nsmul_eq_mul]
  have he : S \ K = S \ (S∩K) := by ext x;simp
  rw [he,card_sdiff_of_subset inter_subset_left,Nat.cast_sub (card_le_card inter_subset_left)]

/-- The exact birth/death rates of the overlap of two k-subsets from the concrete
exchange kernel, valid for every test function and at both boundaries. -/
theorem overlap_row (K S : Slice N k) (Q : ℝ) (hN : 0<N) (hQ : Q≠0) (f : ℕ→ℝ) :
    (walk N k Q *ᵥ (fun T => f (overlap K T))) S =
        f (overlap K S)+(N:ℝ)/Q*generator N k f (overlap K S) := by
  classical
  let z := overlap K S
  have c1 : (S.val∩K.val).card=z := rfl
  have c2 : S.valᶜ∩K.val=K.val \ (S.val∩K.val) := by ext x;simp [and_comm]
  have c3 : ((S.valᶜ∩K.val).card:ℝ)=k-(z:ℝ) := by
    rw [c2,card_sdiff_of_subset inter_subset_right,Nat.cast_sub (card_le_card inter_subset_right),K.property,c1]
  have hm (i : ↥S.val) : (∑ j : ↥S.valᶜ,f (overlap K (change S i j))) =
      if i.val∈K.val then ((k:ℝ)-z)*f z+((N:ℝ)-2*k+z)*f (z-1)
      else ((k:ℝ)-z)*f (z+1)+((N:ℝ)-2*k+z)*f z := by
    have hcom : (S.valᶜ.card:ℝ)=(N:ℝ)-k := by
      have hh := cardout S; rw [Fintype.card_coe] at hh;exact hh
    simp_rw [overlap_step]
    by_cases hi : i.val∈K.val
    · simp only [ite_eq_left hi,apply_ite f]
      rw [census,c3,hcom];dsimp [z];ring
    · simp only [ite_eq_right hi,apply_ite f]
      rw [census,c3,hcom];dsimp [z];ring
  change (∑ T,kernel Q S T*f (overlap K T))=_
  rw [row_apply]
  simp_rw [hm]
  rw [census,c1,S.property]
  unfold generator birth death
  change _ = f z + _ * (_*(f (z+1)-f z)+_*(f (z-1)-f z))
  have hn : (N:ℝ) ≠0 := by exact_mod_cast hN.ne'
  field_simp;ring

#print axioms overlap_row
end
end HubMarks
