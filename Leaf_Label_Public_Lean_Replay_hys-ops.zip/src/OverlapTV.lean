import SparseSlice
import FiberTV
open Finset JohnsonLower HubMarks
open scoped Matrix
noncomputable section
namespace BinaryOverlap
variable {N k : ℕ}

def level (K S : Slice N k) : Fin (k+1) :=
  ⟨overlap K S, Nat.lt_succ_of_le ((Finset.card_le_card (Finset.inter_subset_left (s₂:=K.val))).trans_eq S.property)⟩

lemma full {K S : Slice N k} : overlap K S=k ↔ K=S := by
  constructor
  · intro h
    have he : S.val∩K.val=S.val := eq_of_subset_of_card_le inter_subset_left (by rw [S.property]; exact h.ge)
    have hf : S.val∩K.val=K.val := eq_of_subset_of_card_le inter_subset_right (by rw [K.property];exact h.ge)
    exact Subtype.ext (hf.symm.trans he)
  · rintro rfl;simp [overlap,K.property]

lemma binary_sym_pow (Q : ℝ) (t : ℕ) (K S : Slice N k) :
    ((walk N k Q)^t) K S = ((walk N k Q)^t) S K := by
  have h : (walk N k Q)ᵀ=walk N k Q := Matrix.ext fun x y => kernel_symm Q y x
  have hh : ((walk N k Q)^t)ᵀ=(walk N k Q)^t := by rw [Matrix.transpose_pow,h]
  exact (congrFun (congrFun hh K) S).symm

/-- All point-start rows are radial around the originally occupied k-set. -/
theorem radial (K : Slice N k) (Q:ℝ) (hN:0<N) (hQ:Q≠0) (t : ℕ) :
    ∃ f:ℕ→ℝ, ∀ S : Slice N k, ((walk N k Q)^t) K S = f (overlap K S) := by
  classical
  let P := walk N k Q
  induction t with
  | zero =>
    refine ⟨fun z => if z=k then 1 else 0,?_⟩
    intro S;simp [Matrix.one_apply,full]
  | succ t ih =>
    obtain ⟨f,hf⟩ := ih
    refine ⟨fun z => f z+(N:ℝ)/Q*SparseUrn.generator N k f z,?_⟩
    intro S
    rw [binary_sym_pow Q (t+1) K S,pow_succ',Matrix.mul_apply]
    calc _ = (P *ᵥ (fun j=>f (overlap K j))) S := by
               apply sum_congr rfl
               intro j _
               rw [binary_sym_pow Q t j K,hf j]
         _ = _ := overlap_row K S Q hN hQ f

theorem row_level (K : Slice N k) (Q:ℝ) (hN:0<N) (hQ:Q≠0) (t : ℕ)
    {S T: Slice N k} (h : level K S = level K T) :
    ((walk N k Q)^t) K S = ((walk N k Q)^t) K T := by
  obtain ⟨f,hf⟩ := radial K Q hN hQ t
  rw [hf S,hf T,show overlap K S=overlap K T from congrArg Fin.val h]

/-- Lumping TV is exactly lossless if the density difference is constant on fibers.
Empty levels are admitted. Use this also for Poisson mixtures of the above rows. -/
theorem exact_push {X Y:Type*} [Fintype X] [Fintype Y] [DecidableEq Y]
    (π:X→Y) (p u:X→ℝ) (flat:∀ i j,π i=π j→p i-u i=p j-u j) :
    HubTransfer.tv p u = HubTransfer.tv (HubTransfer.push π p) (HubTransfer.push π u) := by
  classical
  have e (y:Y) :
      |HubTransfer.push π p y-HubTransfer.push π u y| =
        ∑ i, if π i=y then |p i-u i| else 0 := by
    unfold HubTransfer.push
    simp only [←sum_filter,←sum_sub_distrib]
    let A := univ.filter (fun i => π i=y)
    by_cases ha : A.Nonempty
    · obtain ⟨v,hv⟩ := ha
      have he (i:X) (hi:i∈A) : p i-u i=p v-u v :=
        flat i v ((mem_filter.mp hi).2.trans (mem_filter.mp hv).2.symm)
      change |∑ i ∈ A, (p i-u i)| = ∑ i ∈ A, |p i-u i|
      rw [sum_congr rfl he,sum_congr rfl (fun i hi => congrArg abs (he i hi))]
      simp only [sum_const,nsmul_eq_mul,abs_mul,abs_of_nonneg (Nat.cast_nonneg (α:=ℝ) A.card)]
    · change |∑ i ∈ A, (p i-u i)| = ∑ i ∈ A, |p i-u i|
      simp [not_nonempty_iff_eq_empty.mp ha]
  unfold HubTransfer.tv
  simp_rw [e]
  rw [sum_comm];simp

theorem exact_binary_tv (K : Slice N k) (Q:ℝ) (hN:0<N) (hQ:Q≠0) (t : ℕ) :
    HubTransfer.tv (((walk N k Q)^t) K) (HubTransfer.unif _) =
    HubTransfer.tv (HubTransfer.push (level K) (((walk N k Q)^t) K))
       (HubTransfer.push (level K) (HubTransfer.unif _)) := by
  apply exact_push
  intro i j h
  rw [row_level K Q hN hQ t h];rfl

#print axioms exact_binary_tv
end BinaryOverlap
