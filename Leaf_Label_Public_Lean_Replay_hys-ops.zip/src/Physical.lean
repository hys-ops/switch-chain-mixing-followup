import Star
import Potential
import Equilibrium
import Tolerance

namespace LeafLower.Star
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable

/-- All star sizes work in the original quartet-normalized switch kernel.
The initial graph is the labeled forest of h disjoint r-stars. -/
theorem physical_tv_lower_tolerance {h r : ℕ} (hh : 4≤h) (hr : h≤r) {δ : ℝ}
    (hδ : 0<δ) (hlarge : (2/δ+1)^2≤(h:ℝ)) (t : ℕ)
    (ht : (t:ℝ)≤δ*(Q (n h r)*Real.log (h:ℝ)/(8*((h*r:ℕ):ℝ)))) :
    1-δ ≤ tvDistanceFrom (n h r) (deg h r) t (start h r) := by
  have hp : 0<h := by omega
  have rp : 0<r := by omega
  have hn : 4≤n h r := by unfold n;omega
  have hQ : 0<Q (n h r) := by unfold Q; exact mul_pos (by norm_num) (by exact_mod_cast Nat.choose_pos hn)
  have hN : (0:ℝ)<(h*r:ℕ) := by exact_mod_cast Nat.mul_pos hp rp
  let a : Fin h := ⟨0,hp⟩
  let w := W r a
  let v : Fin (n h r) := hub a
  let Z := fun G : State (n h r) (deg h r) => (z w v G:ℝ)
  have hW : w.card=r := card_W _ _
  have hd : ∀ g, (∑ y,switchKernel (n h r) (deg h r) g y*Real.log (((r:ℝ)+1)/(Z y+1))) ≤
       Real.log (((r:ℝ)+1)/(Z g+1))+(mass (deg h r):ℝ)/Q (n h r) := by
    have he (g : State (n h r) (deg h r)) : Real.log (((r:ℝ)+1)/(Z g+1))=pot w v g := by
      rw [Real.log_div (by positivity) (by dsimp [Z];positivity)];simp only [pot,hW,Z]
    intro g;simp only [he];exact graph_drift hn w v g
  have hmean : uniformAverage (n h r) (deg h r) Z ≤ (r:ℝ)/h := by
    have hs := stationary_overlap (d:=deg h r) (L h r) w v (hub_not_mem a)
       (card_pos.mp (show 0<(L h r).card by simpa using Nat.mul_pos hp rp))
       (W_sub a) (fun u hu v hv => (leaf_degree hu).trans (leaf_degree hv).symm) ⟨start h r⟩
    have eq : (r:ℝ)*r/((h:ℝ)*r)=r/h := by
      field_simp [show (r:ℝ)≠0 by exact_mod_cast rp.ne',show (h:ℝ)≠0 by exact_mod_cast hp.ne']
    simpa only [uniformAverage,allGraphStates,stateCount,card_univ,Z,hW,v,hub_degree,card_L,Nat.cast_mul,eq] using hs
  apply LeafDrift.marked_lower_tolerance (h:=(h:ℝ)) (r:=(r:ℝ)) (Q:=Q (n h r)) (N:=((h*r:ℕ):ℝ)) (c:=(mass (deg h r):ℝ)/Q (n h r))
    hn Z (start h r) hδ hlarge (by exact_mod_cast hr) hQ hN
  · simp [total_mass]
  · intro g;dsimp [Z];positivity
  · intro g;dsimp [Z];exact_mod_cast (show z w v g≤r by exact (card_le_card (filter_subset _ _)).trans_eq hW)
  · dsimp [Z,w,v];rw [start_z]
  · exact hd
  · exact hmean
  · exact ht

theorem physical_tv_lower {h r : ℕ} (hh : 25≤h) (hr : h≤r) (t : ℕ)
    (ht : (t:ℝ)≤Q (n h r)*Real.log (h:ℝ)/(16*((h*r:ℕ):ℝ))) :
    (1:ℝ)/2 ≤ tvDistanceFrom (n h r) (deg h r) t (start h r) := by
  have hh' : (25:ℝ)≤h := by exact_mod_cast hh
  have hl : (2/(1/2:ℝ)+1)^2≤(h:ℝ) := by norm_num;exact hh
  have ht' : (t:ℝ) ≤ (1/2:ℝ)*(Q (n h r)*Real.log (h:ℝ)/(8*((h*r:ℕ):ℝ))) := by
    exact ht.trans_eq (by ring)
  convert physical_tv_lower_tolerance (by omega : 4≤h) hr (by norm_num : 0<(1/2:ℝ)) hl t ht' using 1 <;> norm_num

theorem polynomial_tv_lower_tolerance {h : ℕ} (hh : 25≤h) {δ : ℝ} (hδ : 0<δ)
    (hlarge : (2/δ+1)^2≤(h:ℝ)) (t : ℕ)
    (ht : (t:ℝ)≤δ*(((n h (h^4):ℕ):ℝ)^3*Real.log (n h (h^4):ℝ)/1536)) :
    1-δ ≤ tvDistanceFrom (n h (h^4)) (deg h (h^4)) t (start h (h^4)) := by
  apply physical_tv_lower_tolerance (by omega) (Nat.le_self_pow (by decide) _) hδ hlarge t
  apply ht.trans
  simpa only [n,Q,show h*h^4=h^5 by ring] using LeafDrift.tolerance_polynomial_clock hh hδ.le

/-- Polynomially growing hubs, measured in the total number of graph vertices. -/
theorem polynomial_tv_lower {h : ℕ} (hh : 25≤h) (t : ℕ)
    (ht : (t:ℝ)≤((n h (h^4):ℕ):ℝ)^3*Real.log (n h (h^4):ℝ)/3072) :
    (1:ℝ)/2 ≤ tvDistanceFrom (n h (h^4)) (deg h (h^4)) t (start h (h^4)) := by
  apply physical_tv_lower hh (Nat.le_self_pow (by decide) _) t
  apply ht.trans
  simpa only [n,Q,show h*h^4=h^5 by ring] using LeafDrift.polynomial_clock hh

theorem polynomial_not_mixed {h : ℕ} (hh : 25≤h) (t : ℕ)
    (ht : (t:ℝ)≤((n h (h^4):ℕ):ℝ)^3*Real.log (n h (h^4):ℝ)/3072) :
    ¬ MixedAt (n h (h^4)) (deg h (h^4)) t := by
  intro hm;linarith [hm (start h (h^4)),polynomial_tv_lower hh t ht]

theorem polynomial_mixingTime {h : ℕ} (hh : 25≤h)
    (hex : ∃t,MixedAt (n h (h^4)) (deg h (h^4)) t) :
    ((n h (h^4):ℕ):ℝ)^3*Real.log (n h (h^4):ℝ)/3072 <
    (mixingTime (n h (h^4)) (deg h (h^4)) hex:ℝ) := by
  exact lt_of_not_ge (fun he => polynomial_not_mixed hh _ he (Nat.find_spec hex))

#print axioms physical_tv_lower_tolerance
#print axioms polynomial_tv_lower_tolerance
#print axioms physical_tv_lower
#print axioms polynomial_tv_lower
#print axioms polynomial_not_mixed
#print axioms polynomial_mixingTime
end
end LeafLower.Star
