import ShapeLaw
import Mathlib.Analysis.SpecialFunctions.Log.Basic
open Filter Topology
namespace TwoHubUnequal
noncomputable section

/-- A moving-exponent binomial limit, including bounded times and zero rate. -/
theorem moving_decay {p : ℕ → ℝ} {t : ℕ → ℕ} {b : ℝ}
    (hp : Tendsto p atTop (𝓝 0)) (ht : Tendsto (fun i => (t i:ℝ)*p i) atTop (𝓝 b)) :
    Tendsto (fun i => (1-p i)^t i) atTop (𝓝 (Real.exp (-b))) := by
  have hev := (tendsto_order.mp hp).2 1 (by norm_num)
  have hl : Tendsto (fun i => -((t i:ℝ)*p i)/(1-p i)) atTop (𝓝 (-b)) := by
    have H := ht.neg.div (tendsto_const_nhds.sub hp) (show (1:ℝ)-0≠0 by norm_num)
    change Tendsto (fun i => -((t i:ℝ)*p i)/(1-p i)) atTop (𝓝 (-b / (1-0))) at H
    rwa [sub_zero,div_one] at H
  have hg : Tendsto (fun i => (t i:ℝ)*Real.log (1-p i)) atTop (𝓝 (-b)) := by
    apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hl ht.neg
    · filter_upwards [hev] with i hi
      have ha : 0<1-p i := sub_pos.mpr hi
      have hb := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos ha)
        (show 0≤(t i:ℝ) by positivity)
      apply le_trans _ hb
      rw [inv_eq_one_div];field_simp [ha.ne'];ring_nf;exact le_rfl
    · filter_upwards [hev] with i hi
      have hb := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos (sub_pos.mpr hi))
        (show 0≤(t i:ℝ) by positivity)
      linarith
  apply (Real.continuous_exp.continuousAt.tendsto.comp hg).congr'
  filter_upwards [hev] with i hi
  simp [Real.exp_nat_mul,Real.exp_log (sub_pos.mpr hi)]

/-- k parametrizes the second degree s=k+2, so all nondegenerate s occur. -/
def N (r k : ℕ) : ℝ := (r:ℝ)+k+2
def Q (r k : ℕ) : ℝ := clock (r+k+4)
def intensity (r k : ℕ) : ℝ := ((r:ℝ)*(k+2)+2)/Q r k
def localTime (r : ℕ) (c : ℝ) (k : ℕ) := ⌊c * Q r k / N r k⌋₊

lemma Qexact (r k : ℕ) : Q r k = (N r k+2)*(N r k+1)*N r k*(N r k-1)/2 := by
  let v:=r+k
  have h := Nat.ascFactorial_eq_factorial_mul_choose v 4
  norm_num [Nat.ascFactorial_succ,Nat.factorial] at h
  have h' : (((v+1+3)*(v+1+2)*(v+1+1)*(v+1):ℕ):ℝ) =
     ((24:ℝ)*((v+4).choose 4:ℝ)) := by
    exact_mod_cast (by simpa [Nat.mul_assoc] using h :
      (v+1+3)*(v+1+2)*(v+1+1)*(v+1)=24*(v+4).choose 4)
  push_cast at h'
  unfold Q clock N
  change 12*((v+4).choose 4:ℝ) = _
  simp only [v,Nat.cast_add] at h' ⊢
  linarith

lemma Npos (r k : ℕ) : 0<N r k := by unfold N; positivity
lemma Qpos (r k : ℕ) : 0<Q r k := clock_pos (by omega)
lemma scale_zero (r : ℕ) : Tendsto (fun k => N r k / Q r k) atTop (𝓝 0) := by
  have hk : Tendsto (fun k:ℕ => (k:ℝ)+1) atTop atTop :=
    tendsto_natCast_atTop_atTop.atTop_add tendsto_const_nhds
  apply squeeze_zero (fun k => div_nonneg (Npos r k).le (Qpos r k).le) _
    (show Tendsto (fun k:ℕ => 1/((k:ℝ)+1)) atTop (𝓝 0) from tendsto_const_nhds.div_atTop hk)
  intro k
  rw [div_le_div_iff₀ (Qpos r k) (by positivity),one_mul,Qexact]
  unfold N
  have h1 : 1 ≤ (r:ℝ)+k+2 := by linarith [Nat.cast_nonneg (α:=ℝ) r,Nat.cast_nonneg (α:=ℝ) k]
  have h2 : (k:ℝ)+1 ≤ (r:ℝ)+k+2-1 := by linarith [Nat.cast_nonneg (α:=ℝ) r]
  rw [le_div_iff₀ (by norm_num : (0:ℝ)<2)]
  calc
    _ ≤ (((r:ℝ)+k+2)*((r:ℝ)+k+2-1))*2 := by gcongr
    _ ≤ (((r:ℝ)+k+2)*((r:ℝ)+k+2-1))*(((r:ℝ)+k+2+2)*((r:ℝ)+k+2+1)) := by
      apply mul_le_mul_of_nonneg_left _ (mul_nonneg (by linarith) (by linarith))
      nlinarith [sq_nonneg ((r:ℝ)+k+2)]
    _ = _ := by ring

lemma Ntop (r : ℕ) : Tendsto (N r) atTop atTop := by
  have h : Tendsto (fun k:ℕ => (k:ℝ)+((r:ℝ)+2)) atTop atTop :=
    tendsto_natCast_atTop_atTop.atTop_add tendsto_const_nhds
  apply h.congr; intro k; unfold N; ring

lemma scaled_time (r : ℕ) (c : ℝ) (hc : 0≤c) :
    Tendsto (fun k => (localTime r c k:ℝ)*(N r k/Q r k)) atTop (𝓝 c) := by
  have hsub : Tendsto (fun k => c-N r k/Q r k) atTop (𝓝 c) := by
    simpa using (tendsto_const_nhds (x:=c)).sub (scale_zero r)
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le hsub tendsto_const_nhds
  · intro k
    have hh := (Nat.lt_floor_add_one (c*Q r k/N r k)).le
    change _ ≤ (⌊c*Q r k/N r k⌋₊:ℝ)*(N r k/Q r k)
    have hb := (div_le_iff₀ (Npos r k)).mp hh
    rw [←mul_div_assoc,sub_le_iff_le_add,←add_div,le_div_iff₀ (Qpos r k)]
    linarith
  · intro k
    have hh := Nat.floor_le (div_nonneg (mul_nonneg hc (Qpos r k).le) (Npos r k).le)
    change (⌊c*Q r k/N r k⌋₊:ℝ)*(N r k/Q r k) ≤ _
    rw [←mul_div_assoc,div_le_iff₀ (Qpos r k)]
    exact (le_div_iff₀ (Npos r k)).mp hh

lemma attenuation (r : ℕ) (c : ℝ) (hc : 0≤c) :
    Tendsto (fun k => (decay (r+k+4) r (k+2))^(localTime r c k)) atTop
      (𝓝 (Real.exp (-(c*r)))) := by
  let load := fun k : ℕ => ((r:ℝ)*(k+2)+2)/N r k
  have hN := Ntop r
  have hload : Tendsto load atTop (𝓝 (r:ℝ)) := by
    have hs : Tendsto (fun k => (r:ℝ)+(2-(r:ℝ)^2)/N r k) atTop (𝓝 ((r:ℝ)+0)) :=
      tendsto_const_nhds.add (tendsto_const_nhds.div_atTop hN)
    rw [add_zero] at hs
    apply hs.congr; intro k
    dsimp [load];field_simp [(Npos r k).ne'];unfold N;ring
  have hi (k : ℕ) : load k*(N r k / Q r k)=intensity r k := by
    dsimp [load,intensity];field_simp [(Npos r k).ne']
  have hp : Tendsto (intensity r) atTop (𝓝 0) := by
    simpa only [hi,mul_zero] using hload.mul (scale_zero r)
  have ht := scaled_time r c hc
  have htp : Tendsto (fun k => (localTime r c k:ℝ)*intensity r k) atTop (𝓝 (c*r)) := by
    apply (ht.mul hload).congr
    intro k;rw [←hi];ring
  simpa [decay,intensity,Q] using moving_decay hp htp

#print axioms attenuation
end
end TwoHubUnequal
