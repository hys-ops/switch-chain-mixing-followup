import Family
import Mathlib.Analysis.SpecialFunctions.Log.Basic
noncomputable section
open OAI.Problem315 Finset
open scoped BigOperators
namespace ManyCore
variable {n : ℕ} {d : Fin n → ℕ} {H : Finset (Fin n)}

theorem family_rate_n (sp : Spec H (H.card^4) d) (hh : 2≤H.card) :
    1 ≤ rate H (H.card^4)*(12*(n:ℝ)^3) := by
  obtain ⟨hn,hr,hrn⟩ := family_sizes sp hh
  have hQ := qpos (n:=n) (by omega)
  have hsz := H.card_compl_add_card
  rw [sp.count,Fintype.card_fin] at hsz
  have hR : n ≤ (H.card^4+1-H.card)^2 := by
    obtain ⟨j,hj⟩ := Nat.exists_eq_add_of_le hh
    have hrep : H.card^4+1-H.card = j^4+8*j^3+24*j^2+31*j+15 := by
      rw [hj];apply Nat.sub_eq_of_eq_add;ring
    rw [hrep]
    rw [hj] at hsz
    nlinarith [Nat.zero_le (j^2),Nat.zero_le (j^3),Nat.zero_le (j^4),Nat.zero_le (j^5),
      Nat.zero_le (j^6),Nat.zero_le (j^7),Nat.zero_le (j^8)]
  have hR' : (n:ℝ) ≤ ((H.card^4+1-H.card:ℕ):ℝ)^2 := by exact_mod_cast hR
  have hch : Q n ≤ 12*(n:ℝ)^4 := by
    have k : (n.choose 4:ℝ) ≤ (n:ℝ)^4 := by exact_mod_cast Nat.choose_le_pow n 4
    unfold Q;linarith
  unfold rate
  rw [div_mul_eq_mul_div,le_div_iff₀ hQ,one_mul]
  calc
    Q n ≤ _ := hch
    _ = (n:ℝ)*(12*(n:ℝ)^3) := by ring
    _ ≤ _ := mul_le_mul_of_nonneg_right hR' (by positivity)

def coreClock (n : ℕ) : ℕ := ⌈1024*(n:ℝ)^3*(1+Real.log n)⌉₊

theorem core_decay_bound (sp : Spec H (H.card^4) d) (hh : 1024≤H.card) {t : ℕ}
    (ht : coreClock n ≤ t) :
    (H.card:ℝ)^2*Real.exp (-rate H (H.card^4)*(t:ℝ)) ≤ 1/32 := by
  have hh' : 2≤H.card := by omega
  obtain ⟨hn,_,_⟩ := family_sizes sp hh'
  have hm := family_rate_n sp hh'
  have hnon := (family_rate sp hh').1.le
  have hl : 0 < (H.card:ℝ) := by exact_mod_cast (show 0<H.card by omega)
  have hle : (H.card:ℝ)≤n := by exact_mod_cast (show H.card≤n by simpa using H.card_le_univ)
  have hnlog : 0≤Real.log n := Real.log_nonneg (by exact_mod_cast (show 1≤n by omega))
  have hlog := Real.log_le_log hl hle
  have ht' : 1024*(n:ℝ)^3*(1+Real.log n) ≤ t := (Nat.le_ceil _).trans (Nat.cast_le.mpr ht)
  have h4 : (12*(n:ℝ)^3)*(4*Real.log n) ≤ (t:ℝ) := by
    apply le_trans _ ht'
    nlinarith [show 0≤(n:ℝ)^3 by positivity,show 0≤(n:ℝ)^3*Real.log n by positivity]
  have hdec : 4*Real.log H.card ≤ rate H (H.card^4)*(t:ℝ) := by
    calc
      _ ≤ 1*(4*Real.log n) := by linarith
      _ ≤ (rate H (H.card^4)*(12*(n:ℝ)^3))*(4*Real.log n) := mul_le_mul_of_nonneg_right hm (by positivity)
      _ = rate H (H.card^4)*((12*(n:ℝ)^3)*(4*Real.log n)) := by ring
      _ ≤ _ := mul_le_mul_of_nonneg_left h4 hnon
  have he : Real.exp (-rate H (H.card^4)*(t:ℝ)) ≤ Real.exp (-(4*Real.log H.card)) :=
    Real.exp_le_exp.mpr (by linarith)
  have hi : Real.exp (-(4*Real.log H.card)) = ((H.card:ℝ)^4)⁻¹ := by
    rw [Real.exp_neg,show (4:ℝ)*Real.log H.card = (4:ℕ)*Real.log H.card by norm_num,
       Real.exp_nat_mul,Real.exp_log hl]
  rw [hi] at he
  apply (mul_le_mul_of_nonneg_left he (sq_nonneg (H.card:ℝ))).trans
  rw [←div_eq_mul_inv,div_le_div_iff₀ (by positivity) (by norm_num : (0:ℝ)<32)]
  have hl' : 1024≤(H.card:ℝ) := by exact_mod_cast hh
  have hz : 32≤(H.card:ℝ)^2 := by nlinarith [sq_nonneg ((H.card:ℝ)-1)]
  nlinarith [mul_nonneg (sq_nonneg (H.card:ℝ)) (sub_nonneg.mpr hz)]

theorem core_error_bound (sp : Spec H (H.card^4) d) (hh : 1024≤H.card) {t : ℕ}
    (ht : coreClock n≤t) (G : GraphState n d) :
    row t G (bad H) + uniformAverage n d (bad H) ≤ 1/16 := by
  have hh' : 2≤H.card := by omega
  have a := family_bad_row sp hh' t G
  have b := family_bad_uniform sp hh'
  have e := core_decay_bound sp hh ht
  have hm : 16/(H.card:ℝ)≤1/32 := by
    have h1 : 1024≤(H.card:ℝ) := by exact_mod_cast hh
    rw [div_le_div_iff₀ (by linarith) (by norm_num : (0:ℝ)<32)];linarith
  have hs : 8/(H.card:ℝ)+8/(H.card:ℝ)=16/(H.card:ℝ) := by ring
  linarith
#print axioms core_error_bound
end ManyCore
