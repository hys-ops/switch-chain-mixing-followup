import DiameterTransfer
import GraphComparison
import GraphEvents
import RedUniform
import GraphGray
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open RestrictedTV TwoHubUnequal TwoHubHorizontal GraphSplit
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

abbrev Slice (r s : ℕ) := JohnsonLower.Slice (r+s) (r-1)
abbrev bin (n r s t : ℕ) := (HubMarks.walk (r+s) (r-1) (clock n))^t
abbrev reference (d : Fin n →ℕ) (a c : Fin n) := uniformOn (joinedSet d a c)
abbrev gray (n s t : ℕ) : ℝ := 2*(1-((s-1:ℕ):ℝ)/clock n)^t
def density (sp : Spec n r s d a c) (b : Slice r s→ℝ) (G : GraphState n d) : ℝ :=
  reference d a c G * (b (redProjection sp G)/(1/(Fintype.card (Slice r s):ℝ)))
def Bdist (n r s t : ℕ) (x : Slice r s) : ℝ := tv (bin n r s t x) (unif _)

theorem joined_iff (G : GraphState n d) : G∈joinedSet d a c ↔ G.val.Adj a c := by simp [joinedSet]
theorem ref_nz (G : GraphState n d) : reference d a c G≠0 ↔ G.val.Adj a c := by
  by_cases h:G.val.Adj a c
  · have hm : G∈joinedSet d a c := (joined_iff _).mpr h
    have hs : (0:ℝ)<(joinedSet d a c).card := by exact_mod_cast (card_pos.mpr ⟨G,hm⟩)
    simp [reference,uniformOn,hm,hs.ne',h]
  · simp [reference,uniformOn,h]

theorem ref_cost (sp : Spec n r s d a c) (hn : 4≤n) (G : GraphState n d) (he : G.val.Adj a c) :
    tv (unif _) (reference d a c)=stationary r s := by
  classical
  let S := joinedSet d a c
  have hS : S.Nonempty := ⟨G,(joined_iff _).mpr he⟩
  rw [show reference d a c=uniformOn S from rfl,conditioning S hS,←graph_shape_stationary sp hn G]
  unfold uniformAverage
  simp only [allGraphStates,stateCount,card_univ,unif]
  rw [sum_div]
  rw [show Sᶜ=univ.filter (fun x:GraphState n d=>¬x.val.Adj a c) by ext x;simp [S,joinedSet]]
  rw [sum_filter];apply sum_congr rfl;intro x _
  by_cases h:x.val.Adj a c <;> simp [vertex,h]

theorem h_symmetric (x y : GraphState n d) : H d a c x y=H d a c y x := by
  by_cases h : x=y
  · subst y;rfl
  · unfold H LeafSplit.horizontal LeafSplit.cross
    simp only [h,Ne.symm h,ite_false,add_zero,chain,Matrix.of_apply]
    rw [switchKernel_symm x y]
    by_cases hi:isEdge a c x↔isEdge a c y
    · rw [ite_eq_left hi,ite_eq_left hi.symm]
    · rw [ite_eq_right hi,ite_eq_right (show ¬(isEdge a c y↔isEdge a c x) by exact fun hh => hi hh.symm)]

theorem ref_balance (t : ℕ) (x y : GraphState n d) :
    reference d a c x*((H d a c)^t) x y=reference d a c y*((H d a c)^t) y x := by
  have sym:=stoch_sym_pow (h_symmetric (d:=d) (a:=a) (c:=c)) t x y
  by_cases h : x.val.Adj a c↔y.val.Adj a c
  · have heq : reference d a c x=reference d a c y := by simp only [reference,uniformOn,joined_iff,h]
    rw [heq,sym]
  · rw [HubMarks.horizontal_stays t x y h,HubMarks.horizontal_stays t y x (fun hi=>h hi.symm)]
    simp

theorem mass_positive (x : Slice r s) : (0:ℝ)<1/(Fintype.card (Slice r s):ℝ) := by
  have h : (0:ℝ)<Fintype.card (Slice r s) := by exact_mod_cast (Fintype.card_pos_iff.mpr ⟨x⟩)
  positivity

/-- Horizontal heat from an actual joined graph is close in TV to the uniform
    conditional lift of *its own* binary heat row. -/
theorem heat_density (sp : Spec n r s d a c) (hn : 4≤n)
    (G : GraphState n d) (he : G.val.Adj a c) (t : ℕ) :
    tv (((H d a c)^t) G) (density sp (bin n r s t (redProjection sp G)))≤gray n s t := by
  let π := redProjection sp
  let K := (H d a c)^t
  let B := bin n r s t
  have hu:=red_uniform sp G he
  refine diameter_density π (reference d a c) (uniformOn_nonneg _) K B _
    (mass_positive (π G)) (congrFun hu) (ref_balance t) ?_ ?_ ((ref_nz _).mpr he) ?_
  · exact stoch_sym_pow (fun i j=>JohnsonLower.kernel_symm (clock n) i j) t
  · intro y hy;exact red_push sp hn y ((ref_nz _).mp hy) t
  · intro i hi hip
    exact GraphGray.graph_gray_diameter sp hn i G ((ref_nz _).mp hi) he
      ((red_eq_iff sp i G ((ref_nz _).mp hi) he).mp hip) t

theorem density_distance (sp : Spec n r s d a c)
    (G : GraphState n d) (he : G.val.Adj a c) (b : Slice r s→ℝ) :
    tv (density sp b) (reference d a c)=tv b (unif _) :=
  density_tv (redProjection sp) _ (uniformOn_nonneg _) _ (mass_positive (redProjection sp G))
    (congrFun (red_uniform sp G he)) b

theorem density_distance_pair (sp : Spec n r s d a c)
    (G : GraphState n d) (he : G.val.Adj a c) (b c' : Slice r s→ℝ) :
    tv (density sp b) (density sp c')=tv b c' :=
  density_pair (redProjection sp) _ (uniformOn_nonneg _) _ (mass_positive (redProjection sp G))
    (congrFun (red_uniform sp G he)) b c'

theorem four_tv {X : Type*} [Fintype X] (p q u v : X→ℝ) :
    |tv p u -tv q v| ≤ tv p q+tv u v := by
  have h1:=between p q u
  have h2:=between u v q
  rw [reverse u q,reverse v q] at h2
  exact (abs_sub_le _ (tv q u) _).trans (add_le_add h1 h2)

theorem edge_binary (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G : GraphState n d) (he : G.val.Adj a c) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t (redProjection sp G)| ≤
      3*t/clock n+gray n s t+stationary r s := by
  let b := bin n r s t (redProjection sp G)
  have H:=four_tv (kernelPow n d t G) (density sp b) (unif _) (reference d a c)
  rw [density_distance sp G he b,ref_cost sp hn G he] at H
  have ha:=tv_triangle (kernelPow n d t G) (((GraphSplit.H d a c)^t) G) (density sp b)
  have hb:=edge_start sp hn hs hrs G he t
  have hd:=heat_density sp hn G he t
  rw [LeafDrift.actual_tv,←LeafDrift.actual_kernel_pow]
  unfold Bdist;change |tv (kernelPow n d t G) (unif _)-tv b (unif _)|≤_
  change tv (((GraphSplit.H d a c)^t) G) (density sp b)≤_ at hd
  linarith
#print axioms edge_binary
end PhysicalReduction
