import Mathlib.Probability.Distributions.Poisson.Basic
import Mathlib.Tactic
noncomputable section
namespace LeafClock
def mass (u : ℝ) (k : ℕ) := Real.exp (-u)*u^k/(k.factorial:ℝ)
lemma mass_ge {u : ℝ} (hu : 0≤u) (k : ℕ) : 0≤mass u k := by unfold mass; positivity
lemma total {u : ℝ} (hu : 0≤u) : HasSum (mass u) 1 :=
  ProbabilityTheory.hasSum_one_poissonMeasure ⟨u,hu⟩
lemma shift (u : ℝ) (k : ℕ) : (k+1:ℝ)*mass u (k+1)=u*mass u k := by
  simp only [mass,Nat.factorial_succ,Nat.cast_mul,Nat.cast_add,Nat.cast_one,pow_succ]
  have h : (k:ℝ)+1≠0 := by positivity
  have hf : (k.factorial:ℝ)≠0 := by positivity
  field_simp
lemma first {u : ℝ} (hu : 0≤u) : HasSum (fun k : ℕ => (k:ℝ)*mass u k) u := by
  apply (hasSum_nat_add_iff' 1).mp
  simpa [shift] using (total hu).mul_left u
lemma factorial2 {u : ℝ} (hu : 0≤u) :
    HasSum (fun k : ℕ => ((k:ℝ)-1)*((k:ℝ)*mass u k)) (u^2) := by
  apply (hasSum_nat_add_iff' 1).mp
  have h := (first hu).mul_left u
  simp only [Finset.sum_range_one,Nat.cast_zero,zero_mul,mul_zero,sub_zero,Nat.cast_add,Nat.cast_one,add_sub_cancel_right,shift]
  convert h using 1 <;> first | funext k;ring | ring
lemma variance {u : ℝ} (hu : 0≤u) :
    HasSum (fun k : ℕ => mass u k*((k:ℝ)-u)^2) u := by
  have h := ((factorial2 hu).add ((first hu).mul_left (1-2*u))).add ((total hu).mul_left (u^2))
  convert h using 1 <;> first | funext k; ring | ring
/-- Young's inequality bounds the absolute deviation of the Poisson clock in L1. -/
lemma clock_deviation {u : ℝ} (hu : 0<u) :
    Summable (fun k : ℕ => mass u k*|(k:ℝ)-u|) ∧
      ∑' k : ℕ, mass u k*|(k:ℝ)-u| ≤ Real.sqrt u := by
  let a := Real.sqrt u
  have ha : 0<a := Real.sqrt_pos.mpr hu
  have hsq : a^2=u := Real.sq_sqrt hu.le
  let b := fun k : ℕ => mass u k*((k:ℝ)-u)^2/(2*a)+mass u k*(a/2)
  have hh : HasSum b a := by
    have q := ((variance hu.le).mul_left (1/(2*a))).add ((total hu.le).mul_left (a/2))
    convert q using 1
    · funext k;dsimp [b];ring
    · field_simp; nlinarith
  have hnon (k : ℕ) : 0≤mass u k*|(k:ℝ)-u| := mul_nonneg (mass_ge hu.le _) (abs_nonneg _)
  have hle (k : ℕ) : mass u k*|(k:ℝ)-u|≤b k := by
    have h : |(k:ℝ)-u|≤ ((k:ℝ)-u)^2/(2*a)+a/2 := by
      field_simp
      nlinarith [sq_nonneg (|(k:ℝ)-u|-a),sq_abs ((k:ℝ)-u)]
    convert mul_le_mul_of_nonneg_left h (mass_ge hu.le k) using 1 <;> dsimp [b] <;> ring
  have hsum := Summable.of_nonneg_of_le hnon hle hh.summable
  exact ⟨hsum,(hsum.tsum_le_tsum hle hh.summable).trans_eq hh.tsum_eq⟩
#print axioms clock_deviation
end LeafClock
