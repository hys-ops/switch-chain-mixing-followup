import PoissonThreshold
import SmoothCrossings
import Mathlib.Analysis.Normed.Group.FunctionSeries
open Filter Topology CountLimit UrnWindow.Degrees
namespace GrowingInverse
noncomputable section

def shifted (α c:ℝ) := α+Real.sqrt α*Real.exp (-c)
theorem shift_pos {α:ℝ} (ha:0<α) (c:ℝ) : 0<shifted α c := by unfold shifted;positivity
theorem mass_cont (j:ℕ) : Continuous (fun u => LeafClock.mass u j) := by unfold LeafClock.mass;fun_prop
theorem shift_cont (α : ℝ) : Continuous (shifted α) := by unfold shifted;fun_prop

theorem critical_form {α:ℝ} (ha : 0<α) :
    critical α=(fun c=>1-∑'j,min (LeafClock.mass α j) (LeafClock.mass (shifted α c) j)) := by
  funext c;change poissonTV (shifted α c) α=_
  rw [tv_poisson ha.le (shift_pos ha _).le,TV_eq];rfl

private lemma dom {α:ℝ} (ha:0<α) (j:ℕ) (c:ℝ) :
    ‖min (LeafClock.mass α j) (LeafClock.mass (shifted α c) j)‖≤LeafClock.mass α j := by
  rw [Real.norm_eq_abs,abs_of_nonneg (le_min (LeafClock.mass_ge ha.le j) (LeafClock.mass_ge (shift_pos ha c).le j))]
  exact min_le_left _ _

theorem critical_cont {α:ℝ} (ha:0<α) : Continuous (critical α) := by
  rw [critical_form ha]
  exact continuous_const.sub (continuous_tsum (fun j=>continuous_const.min ((mass_cont j).comp (shift_cont α)))
    (LeafClock.total ha.le).summable (dom ha))

theorem critical_endpoints {α:ℝ} (ha:0<α) :
    Tendsto (critical α) atBot (𝓝 1) ∧ Tendsto (critical α) atTop (𝓝 0) := by
  rw [critical_form ha]
  have hi : Tendsto (shifted α) atBot atTop := by
    have hx := (Real.tendsto_exp_atTop.comp tendsto_neg_atBot_atTop).const_mul_atTop (Real.sqrt_pos.mpr ha)
    exact tendsto_const_nhds.add_atTop hx
  have lo : Tendsto (shifted α) atTop (𝓝 α) := by
    unfold shifted
    simpa only [shifted,Function.comp_def,mul_zero,add_zero] using (tendsto_const_nhds (x:=α)).add
      ((tendsto_const_nhds (x:=Real.sqrt α)).mul (Real.tendsto_exp_atBot.comp tendsto_neg_atTop_atBot))
  have zero (j:ℕ) : Tendsto (fun c=>LeafClock.mass (shifted α c) j) atBot (𝓝 0) := by
    have T := ((Real.tendsto_pow_mul_exp_neg_atTop_nhds_zero j).comp hi).div_const (j.factorial:ℝ)
    simpa only [Function.comp_def,zero_div,LeafClock.mass,mul_comm] using T
  have l j : Tendsto (fun c=>min (LeafClock.mass α j) (LeafClock.mass (shifted α c) j)) atBot (𝓝 0) := by
    simpa only [min_eq_right (LeafClock.mass_ge ha.le j)] using (tendsto_const_nhds (x:=LeafClock.mass α j)).min (zero j)
  have h j : Tendsto (fun c=>min (LeafClock.mass α j) (LeafClock.mass (shifted α c) j)) atTop (𝓝 (LeafClock.mass α j)) := by
    simpa only [Function.comp_def,min_self] using (tendsto_const_nhds (x:=LeafClock.mass α j)).min ((mass_cont j).continuousAt.tendsto.comp lo)
  have A := tendsto_tsum_of_dominated_convergence (LeafClock.total ha.le).summable l (Filter.Eventually.of_forall fun c j => dom ha j c)
  have B := tendsto_tsum_of_dominated_convergence (LeafClock.total ha.le).summable h (Filter.Eventually.of_forall fun c j => dom ha j c)
  constructor
  · simpa only [tsum_zero,sub_zero] using (tendsto_const_nhds (x:=(1:ℝ))).sub A
  · simpa only [(LeafClock.total ha.le).tsum_eq,sub_self] using (tendsto_const_nhds (x:=(1:ℝ))).sub B

theorem critical_crossing {α ε:ℝ} (ha:0<α) (he:0<ε) (he':ε<1) : ∃!w : ℝ,critical α w=ε :=
  inverse_exists _ (critical_anti ha) (critical_cont ha) (critical_endpoints ha).1 (critical_endpoints ha).2 he he'
#print axioms critical_crossing
end
end GrowingInverse
