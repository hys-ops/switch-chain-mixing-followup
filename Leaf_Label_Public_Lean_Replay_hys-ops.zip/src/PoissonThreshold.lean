import CountTV
import GraphWindows
import Mathlib.Analysis.Calculus.Deriv.MeanValue
open Finset Filter Topology Set CountLimit UrnWindow.Degrees
namespace GrowingInverse
noncomputable section

def lowerMass (l : ℕ) (u : ℝ) := ∑j∈range l, LeafClock.mass u j
private lemma mass_diff (u : ℝ) (j : ℕ) : HasDerivAt (fun v=>LeafClock.mass v (j+1))
    (LeafClock.mass u j-LeafClock.mass u (j+1)) u := by
  have a := ((hasDerivAt_id u).neg.exp.mul ((hasDerivAt_id u).pow (j+1))).div_const ((j+1).factorial:ℝ)
  convert a using 1
  · rfl
  · simp only [LeafClock.mass,Nat.succ_sub_one,Nat.cast_succ,Nat.factorial_succ,Nat.cast_mul,Pi.neg_apply,Pi.pow_apply,id_eq]
    field_simp;ring
theorem prefix_derivative (l : ℕ) (u : ℝ) :
    HasDerivAt (lowerMass (l+1)) (-LeafClock.mass u l) u := by
  induction l with
  | zero =>
    have hh : lowerMass 1 = fun v => Real.exp (-v) := by funext v;simp [lowerMass,LeafClock.mass]
    rw [hh];simpa [LeafClock.mass] using ((hasDerivAt_id u).neg.exp)
  | succ l ih =>
    have he : lowerMass (l+1+1)=fun t=>lowerMass (l+1) t+LeafClock.mass t (l+1) := by funext t;simp [lowerMass,sum_range_succ]
    rw [he];convert ih.add (mass_diff u l) using 1;ring
theorem prefix_strict (l : ℕ) : StrictAntiOn (lowerMass (l+1)) (Ioi 0) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioi 0)
  · exact fun x _ => (prefix_derivative l x).continuousAt.continuousWithinAt
  · intro x hx;rw [(prefix_derivative l x).deriv]
    have h : 0<x := interior_subset hx
    unfold LeafClock.mass;exact neg_neg_of_pos (by positivity)

def posDiff (A B : Law) (j:ℕ) := A.p j-min (A.p j) (B.p j)

theorem posDiff_sum (A B : Law) : HasSum (posDiff A B) (TV A B) := by
  have hm := Summable.of_nonneg_of_le (fun j=>le_min (A.nonneg j) (B.nonneg j))
    (fun j=>min_le_left (A.p j) (B.p j)) A.total.summable
  rw [TV_eq];exact A.total.sub hm.hasSum

theorem prefix_le (α m : ℝ) (ha : 0≤α) (hm : 0≤m) (l : ℕ) :
    lowerMass l α-lowerMass l m≤TV (poisson α ha) (poisson m hm) := by
  let A := poisson α ha;let B := poisson m hm
  have h := (posDiff_sum A B).summable.sum_le_tsum (range l) (fun j _=> sub_nonneg.mpr (min_le_left _ _))
  rw [(posDiff_sum A B).tsum_eq] at h
  apply le_trans _ h
  unfold lowerMass; rw [←sum_sub_distrib]
  exact sum_le_sum fun j _ => sub_le_sub_left (min_le_right (A.p j) (B.p j)) _

theorem ratio_rule {a m : ℝ} (ha : 0<a) (hm : a<m) (j : ℕ) :
    LeafClock.mass a j≤LeafClock.mass m j ↔ Real.exp (m-a)≤(m/a)^j := by
  unfold LeafClock.mass
  rw [div_le_div_iff_of_pos_right (by positivity : (0:ℝ)<j.factorial),div_pow,
      le_div_iff₀ (pow_pos ha j),Real.exp_sub,div_mul_eq_mul_div,div_le_iff₀ (Real.exp_pos a)]
  rw [Real.exp_neg,Real.exp_neg,inv_mul_eq_div,inv_mul_eq_div,
      div_le_div_iff₀ (Real.exp_pos a) (Real.exp_pos m)]
  ring_nf

theorem cut_exists {a m : ℝ} (ha : 0<a) (hm : a<m) :
    ∃ l : ℕ, TV (poisson a ha.le) (poisson m (ha.trans hm).le)=lowerMass (l+1) a-lowerMass (l+1) m := by
  let U := Real.exp (m-a)
  let b := m/a
  have hb : 1<b := (one_lt_div ha).mpr hm
  have hex : ∃ j:ℕ,U≤b^j := (tendsto_pow_atTop_atTop_of_one_lt hb).eventually_ge_atTop U |>.exists
  let l := Nat.find hex
  have hpos : 0<l := by
    by_contra! h
    have he := Nat.find_spec hex
    change U≤b^l at he
    rw [show l=0 by omega,pow_zero] at he
    exact (not_lt_of_ge he) (Real.one_lt_exp_iff.mpr (by linarith : 0<m-a))
  have low j (hj : j<l) : LeafClock.mass m j<LeafClock.mass a j := lt_of_not_ge (fun h =>
    Nat.find_min hex hj ((ratio_rule ha hm j).mp h))
  have hi j (hj : l≤j) : LeafClock.mass a j≤LeafClock.mass m j :=
    (ratio_rule ha hm j).mpr ((Nat.find_spec hex).trans (pow_le_pow_right₀ hb.le hj))
  obtain ⟨v,hv⟩ := Nat.exists_eq_succ_of_ne_zero hpos.ne'
  refine ⟨v,?_⟩
  let A := poisson a ha.le
  let B := poisson m (ha.trans hm).le
  have hv' : v+1=l := hv.symm
  rw [←(posDiff_sum A B).tsum_eq,tsum_eq_sum (s:=range l),lowerMass,lowerMass,←sum_sub_distrib,hv']
  · apply sum_congr rfl;intro j hj
    change LeafClock.mass a j-min (LeafClock.mass a j) (LeafClock.mass m j)=_
    rw [min_eq_right (low j (mem_range.mp hj)).le]
  · intro j hj
    change LeafClock.mass a j-min (LeafClock.mass a j) (LeafClock.mass m j)=0
    rw [min_eq_left (hi j (by simpa using hj)),sub_self]

lemma tv_poisson {a m:ℝ} (ha:0≤a) (hm:0≤m) : poissonTV m a = TV (poisson a ha) (poisson m hm) := by
  rw [TV_comm];unfold poissonTV TV
  simp [CountLimit.poisson,LeafClock.mass,ProbabilityTheory.poissonPMFReal,Real.coe_toNNReal _ hm,Real.coe_toNNReal _ ha]

theorem poisson_strict {α m m' : ℝ} (hα : 0<α) (hm : α<m) (hm' : m<m') : poissonTV m α<poissonTV m' α := by
  obtain ⟨l,hl⟩ := cut_exists hα hm
  rw [tv_poisson hα.le (hα.trans hm).le,tv_poisson hα.le ((hα.trans hm).trans hm').le,hl]
  exact (sub_lt_sub_left (prefix_strict l (hα.trans hm) ((hα.trans hm).trans hm') hm') _).trans_le
    (prefix_le α m' hα.le ((hα.trans hm).trans hm').le (l+1))

theorem critical_anti {α : ℝ} (ha : 0<α) : StrictAnti (critical α) := by
  intro u v huv
  unfold critical
  have hx := Real.exp_lt_exp.mpr (neg_lt_neg huv)
  apply poisson_strict ha (lt_add_of_pos_right _ (mul_pos (Real.sqrt_pos.mpr ha) (Real.exp_pos _)))
  linarith [mul_lt_mul_of_pos_left hx (Real.sqrt_pos.mpr ha)]

#print axioms critical_anti
end
end GrowingInverse
