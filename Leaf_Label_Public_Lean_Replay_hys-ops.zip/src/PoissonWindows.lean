import CriticalWindow
namespace CriticalUrn
open Filter Topology UrnWindow UrnWindow.Degrees HubMarks JohnsonLower HubTransfer Finset
open scoped Matrix
noncomputable section

lemma physical (g : Degrees) (i k : ℕ) :
    0<g.population i ∧ g.N i≤g.Q i ∧ (k:ℝ)*(g.N i-k)≤g.Q i := by
  have hn := (sizes g i).2.2.1
  have hn0 : 0<g.N i := by linarith
  have clk := clock_square g i
  exact ⟨by exact_mod_cast hn0,by nlinarith [sq_nonneg (g.N i-1)],
    by nlinarith [sq_nonneg (g.N i-(k:ℝ)),sq_nonneg (k:ℝ)]⟩

theorem point_window (g : Degrees) {α : ℝ} (hα : 0≤α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ)
    (K : (i : ℕ)→Slice (g.population i) (g.ballCount i)) {z : ℝ} (hz : 0≤z) (hz' : z≤1) :
    Tendsto (fun i => ((walk _ _ (g.Q i))^(g.time .halfLogN c i) *ᵥ
      fun T => z^(HubMarks.overlap (K i) T)) (K i)) atTop
        (𝓝 (Real.exp ((z-1)*(α+Real.sqrt α*Real.exp (-c))))) := by
  have he := allowance_zero g hα h
  have hm := pgf_center g hα h c z
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' (by simpa only [sub_zero] using hm.sub he)
    (by simpa only [add_zero] using hm.add he)
  all_goals apply Filter.Eventually.of_forall;intro i
  all_goals obtain ⟨hn,hscale,cap⟩ := physical g i (g.ballCount i)
  all_goals have hp := slice_pgf (K i) (K i) hn (clk_pos g i) hscale cap hz hz' (g.time .halfLogN c i)
  all_goals rw [show HubMarks.overlap (K i) (K i)=g.ballCount i by simp [HubMarks.overlap,(K i).property]] at hp
  all_goals try dsimp only [Pi.sub_apply,Pi.add_apply]
  all_goals unfold step at *;linarith [(abs_le.mp hp).1,(abs_le.mp hp).2]

theorem uniform_window (g : Degrees) {α : ℝ} (hα : 0≤α)
    (h : Tendsto g.ratio atTop (𝓝 (Real.sqrt α)))
    (K : (i : ℕ)→Slice (g.population i) (g.ballCount i)) {z : ℝ} (hz : 0≤z) (hz' : z≤1) :
    Tendsto (fun i => ∑ T,(unif _ T)*z^(HubMarks.overlap (K i) T)) atTop
        (𝓝 (Real.exp ((z-1)*α))) := by
  have he := allowance_zero g hα h
  have hm := Real.continuous_exp.continuousAt.tendsto.comp ((tendsto_const_nhds (x:=z-1)).mul (load_limit g hα h))
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' (by simpa only [sub_zero] using hm.sub he)
    (by simpa only [add_zero] using hm.add he)
  all_goals apply Filter.Eventually.of_forall;intro i
  all_goals obtain ⟨hn,hscale,cap⟩ := physical g i (g.ballCount i)
  all_goals have hp := stationary_pgf (K i) hn (clk_pos g i) hscale cap hz hz'
  all_goals dsimp only [Function.comp_apply,Pi.sub_apply,Pi.add_apply];unfold step at *;linarith [(abs_le.mp hp).1,(abs_le.mp hp).2]

#print axioms point_window
#print axioms uniform_window
end
end CriticalUrn
