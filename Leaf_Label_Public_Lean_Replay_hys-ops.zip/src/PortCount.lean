import MatchingNormal
namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ}

abbrev Ports (G : SimpleGraph (Fin n)) (a c : Fin n) :=
  {w : Fin n × Fin n // FourDistinct a w.1 c w.2 ∧ G.Adj a w.1 ∧ G.Adj c w.2 ∧ ¬G.Adj w.1 w.2}
abbrev Gains (G : SimpleGraph (Fin n)) (a c : Fin n) :=
  {p : SwitchProposal n // (proposalResult G p).Adj a c}

def makePort {G : SimpleGraph (Fin n)} {a c : Fin n} (h : ¬G.Adj a c) (w : Ports G a c) : Gains G a c := by
  let p := fourVertexProposal a w.1.1 c w.1.2 w.2.1
  have hv : validSwitch G p := (validSwitch_fourVertexProposal_iff _ _ _ _ _ _).2 ⟨w.2.2.1,w.2.2.2.1,h,w.2.2.2.2⟩
  have ha : (addedMatching p).Adj a c := (addedMatching_fourVertexProposal _ _ _ _ _ _ _).2 (Or.inl ⟨rfl,rfl⟩)
  exact ⟨p,((addedMatching_adj_iff hv _ _).mp ha).1⟩

/-- Exact count of all proposals which create an absent oriented edge a-c.
The original sampling convention counts each ordered matching replacement once. -/
def gainEquiv {G : SimpleGraph (Fin n)} {a c : Fin n} (h : ¬G.Adj a c) : Ports G a c ≃ Gains G a c := by
  apply Equiv.ofBijective (makePort h); constructor
  · intro x y he
    have hp : fourVertexProposal a x.1.1 c x.1.2 x.2.1 = fourVertexProposal a y.1.1 c y.1.2 y.2.1 := congrArg Subtype.val he
    let p := fourVertexProposal a y.1.1 c y.1.2 y.2.1
    have e₁ : (removedMatching p).Adj a x.1.1 := by rw [show p=_ from hp.symm]; simp
    have e₂ : (removedMatching p).Adj a y.1.1 := by simp [p]
    have f₁ : (removedMatching p).Adj c x.1.2 := by rw [show p=_ from hp.symm]; simp
    have f₂ : (removedMatching p).Adj c y.1.2 := by simp [p]
    exact Subtype.ext (Prod.ext (partner_unique p.2.val.1 e₁ e₂) (partner_unique p.2.val.1 f₁ f₂))
  · rintro ⟨p,hh⟩
    have hp : validSwitch G p := validSwitch_of_proposalResult_ne (by intro he; rw [he] at hh;exact h hh)
    have ha := (addedMatching_adj_iff hp a c).2 ⟨hh,h⟩
    obtain ⟨b,d,hd,hab,hcd,hbd,rfl⟩ := gains_normal hp ha
    exact ⟨⟨(b,d),hd,hab,hcd,hbd⟩,rfl⟩

/-- Summing the published kernel over an event excluding the current state
amounts exactly to counting the proposals whose actual result hits the event. -/
theorem mass_of_event {d : Fin n → ℕ} (G : GraphState n d) (P : GraphState n d → Prop) (h : ¬P G) :
    ∑ H ∈ (allGraphStates n d).filter P, switchKernel n d G H =
      (((allProposals n).filter (fun p => P (proposalState G p))).card : ℝ)/(12*(n.choose 4 : ℝ)) := by
  classical
  let E := (allGraphStates n d).filter P
  have hp : ∀ H∈E,G≠H := by intro H hH h';subst H;exact h ((mem_filter.mp hH).2)
  have hi (H : GraphState n d) : ((allProposals n).filter (fun p => proposalResult G.val p=H.val))=
    (allProposals n).filter (fun p => proposalState G p=H) := by
    ext p;simp only [mem_filter]; exact and_congr_right fun _ => ⟨fun hv => Subtype.ext hv,fun hv => congrArg Subtype.val hv⟩
  have hc := sum_card_fiberwise_eq_card_filter (allProposals n) E (proposalState G)
  have hf : (allProposals n).filter (fun p => proposalState G p∈E) = (allProposals n).filter (fun p => P (proposalState G p)) := by ext p;simp [E,allGraphStates]
  change (∑ H ∈ E,switchKernel n d G H) = _
  calc
    _ = ∑ H∈E, (((allProposals n).filter (fun p => proposalState G p=H)).card:ℝ)/(12*(n.choose 4:ℝ)) := by
      apply sum_congr rfl;intro H hH;simp [switchKernel,hp H hH,hi]
    _ = _ := by rw [←sum_div];congr 1; exact_mod_cast (hc.trans (congrArg card hf))

lemma mass_gain {d : Fin n → ℕ} (G : GraphState n d) {a c : Fin n} (h : ¬G.val.Adj a c) :
  ∑ H∈(allGraphStates n d).filter (fun H => H.val.Adj a c),switchKernel n d G H =
    (Fintype.card (Ports G.val a c):ℝ)/(12*(n.choose 4:ℝ)) := by
  rw [mass_of_event G _ h]; congr 1
  have hc := Fintype.card_congr (gainEquiv h)
  have hh : Fintype.card (Gains G.val a c) = ((allProposals n).filter (fun p => (proposalResult G.val p).Adj a c)).card := by simp [Gains,Fintype.card_subtype,allProposals]
  exact_mod_cast (hc.trans hh).symm

#print axioms gainEquiv
#print axioms mass_gain
end
end TwoHub
