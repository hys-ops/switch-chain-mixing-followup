import EdgeHazard
namespace LeafLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

def pot (W : Finset (Fin n)) (a : Fin n) (G : State n d) : ℝ :=
  Real.log ((W.card:ℝ)+1)-Real.log ((z W a G:ℝ)+1)

lemma pot_nonneg (W : Finset (Fin n)) (a : Fin n) (G : State n d) : 0≤pot W a G := by
  have hz : z W a G ≤ W.card := card_le_card (filter_subset _ _)
  exact sub_nonneg.mpr (Real.log_le_log (by positivity) (by exact_mod_cast Nat.add_le_add_right hz 1))

lemma point_drift (W : Finset (Fin n)) (a : Fin n) (G H : State n d) (hk : K n d G H ≠ 0) :
    pot W a H ≤ pot W a G + ((lost W a G H).card:ℝ)/(z W a G:ℝ) := by
  by_cases h : z W a G≤z W a H
  · have hl := Real.log_le_log (by positivity : 0<(z W a G:ℝ)+1) (show (z W a G:ℝ)+1≤(z W a H:ℝ)+1 by exact_mod_cast Nat.add_le_add_right h 1)
    unfold pot; linarith [div_nonneg (Nat.cast_nonneg (α:=ℝ) (lost W a G H).card) (Nat.cast_nonneg (α:=ℝ) (z W a G))]
  · have hx := z_lower (W:=W) (a:=a) hk
    have he : z W a H+1=z W a G := by omega
    have hz : 0<(z W a G:ℝ) := by exact_mod_cast (show 0<z W a G by omega)
    have hlpos : 0<(lost W a G H).card := by
      by_contra! hn
      have hs : marks W a G ⊆ marks W a H := by
        apply Finset.sdiff_eq_empty_iff_subset.mp
        apply card_eq_zero.mp; exact Nat.eq_zero_of_le_zero hn
      exact h (card_le_card hs)
    have hc : (lost W a G H).card=1 := by have := lost_le_one (W:=W) (a:=a) hk;omega
    have he' : (z W a H:ℝ)+1=(z W a G:ℝ) := by exact_mod_cast he
    have hl := Real.log_le_sub_one_of_pos (show 0<((z W a G:ℝ)+1)/(z W a G:ℝ) by positivity)
    rw [Real.log_div (by positivity) hz.ne'] at hl
    have hd : ((z W a G:ℝ)+1)/(z W a G:ℝ)-1=1/(z W a G:ℝ) := by field_simp;ring
    rw [hd,one_div] at hl;unfold pot;rw [hc,he'];simp only [Nat.cast_one,one_div];linarith

/-- One-step drift in every state of every original switch chain, measured
against arbitrary marked labels at any chosen center. -/
theorem graph_drift (hn : 4≤n) (W : Finset (Fin n)) (a : Fin n) (G : State n d) :
    ∑ H : State n d,K n d G H*pot W a H ≤ pot W a G + (mass d:ℝ)/Q n := by
  classical
  have hrow : ∑ H : State n d,K n d G H=1 := switchKernel_row_sum hn G
  calc
    _ ≤ ∑ H : State n d,K n d G H*(pot W a G+((lost W a G H).card:ℝ)/(z W a G:ℝ)) := by
      apply sum_le_sum;intro H _;by_cases hh : K n d G H=0
      · simp [hh]
      · exact mul_le_mul_of_nonneg_left (point_drift W a G H hh) (switchKernel_nonneg _ _)
    _ = pot W a G + (∑ H : State n d,K n d G H*((lost W a G H).card:ℝ))/(z W a G:ℝ) := by
      simp only [mul_add,sum_add_distrib,←sum_mul,←mul_div_assoc,←sum_div,hrow,one_mul]
    _ ≤ _ := by
      apply add_le_add_right
      by_cases hh : z W a G=0
      · rw [hh];simp only [Nat.cast_zero,div_zero];unfold Q;positivity
      · apply (div_le_iff₀ (by exact_mod_cast Nat.pos_of_ne_zero hh : 0<(z W a G:ℝ))).mpr
        simpa [mul_comm] using lost_expectation W a G

#print axioms graph_drift
end
end LeafLower
