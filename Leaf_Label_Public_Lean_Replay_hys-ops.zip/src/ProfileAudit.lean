import ProofAudit
import FixedMixing
import ThreeRegimeWorst
import GraphToOrdered
import Lean.Util.FoldConsts
open Lean
namespace LeafTerminalAudit
private def externalMod (env : Environment) (n : Name) : Bool := Id.run do
  let some i := env.getModuleIdxFor? n | return true
  let root := env.allImportedModuleNames[i.toNat]!.getRoot.toString
  return ["Mathlib","Lean","Std","Init","Batteries","Aesop","Qq","Plausible","ProofWidgets","ImportGraph","LeanSearchClient"].contains root
private partial def closure (env : Environment) (queue : List Name) (seen : NameSet) : NameSet :=
  match queue with
  | [] => seen
  | n::rest =>
    if seen.contains n || externalMod env n then closure env rest seen
    else closure env (((env.find? n).map fun decl => decl.getUsedConstantsAsSet.toList).getD [] ++ rest) (seen.insert n)
run_cmd
  let env ← getEnv
  let verify (root : Name) (expected : List Name) := do
    let used := closure env [root] {}
    for k in expected do
      unless used.contains k do throwError "Missing dependency of {root} : {k}"
      logInfo m!"{root} uses {k}"
    for k in [`UrnWindow.Degrees.UrnProfileInput,`UrnWindow.Degrees.full_graph_profiles,`PhysicalReduction.scalar_profiles,`PhysicalReduction.tridiagonal_profiles,`OAI.Problem315.switch_chain_main] do
      if used.contains k then throwError "Unexpected external or conditional endpoint {k} in {root}"
    logInfo m!"{root} independent of conditional urn interfaces and published general graph endpoint"
  verify `TwoHubWorst.limit [`HubMarks.sparse_graph_uniform,`CriticalResult.critical_graph_uniform,`UrnWindow.Degrees.dense_graph_uniform,`CriticalUrn.point_window,`StationaryUrn.dense_cdf,`HubDense.dense_dynamic_cdf,`OAI.Problem315.switchKernel,`OAI.Problem315.tvDistanceFrom,`Avoid.worstTV]
  verify `Avoid.fixed_worst [`HubMarks.fixed_edge,`HubMarks.fixed_vertex,`OAI.Problem315.switchKernel,`Avoid.worstTV]
  verify `PhysicalReduction.graph_to_ordered [`OAI.Problem315.switchKernel,`OAI.Problem315.tvDistanceFrom]
#print axioms TwoHubWorst.limit
#print axioms UrnWindow.Degrees.dense_graph_uniform
#print axioms CriticalResult.critical_graph_uniform
#print axioms HubMarks.sparse_graph_uniform
#print axioms HubMarks.fixed_edge_uniform
#print axioms HubMarks.fixed_vertex_uniform
#print axioms Avoid.fixed_worst
#print axioms Avoid.fixed_no_cutoff
#print axioms PhysicalReduction.graph_to_ordered
end LeafTerminalAudit
