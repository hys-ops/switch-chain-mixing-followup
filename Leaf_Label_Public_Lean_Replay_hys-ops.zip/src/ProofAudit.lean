import ManyHubTheta
import Lean.Util.FoldConsts
open Lean
namespace LeafProofAudit
private def belongs (env : Environment) (n : Name) : Bool := Id.run do
  let some i := env.getModuleIdxFor? n | return false
  let s := env.allImportedModuleNames[i.toNat]!.getRoot.toString
  return !(["Mathlib","Lean","Std","Init","Batteries","Aesop","Qq","Plausible","ProofWidgets","ImportGraph","LeanSearchClient"].contains s)
private partial def visit (env : Environment) (todo : List Name) (seen : NameSet) : NameSet :=
  match todo with
  | [] => seen
  | h::t =>
    if !belongs env h || seen.contains h then visit env t seen
    else visit env (((env.find? h).map (fun v => v.getUsedConstantsAsSet.toList)).getD [] ++ t) (seen.insert h)
run_cmd
  let env ← getEnv
  let used := visit env [`LeafResult.many_hub_theta] {}
  for k in [`LeafResult.actual_upper, `LeafLower.Star.polynomial_tv_lower,
    `LeafMark.inserted_marked, `LeafMark.thinned_shuffle, `ManyCore.core_error_bound,
    `OAI.Problem315.LeafTransfer.iid_leaf_minorization,
    `OAI.Problem315.LeafOrbit.graph_orbit_transfer, `OAI.Problem315.switchKernel,
    `OAI.Problem315.tvDistanceFrom,`OAI.Problem315.MixedAt,`OAI.Problem315.mixingTime] do
    unless used.contains k do throwError "Missing required dependency: {k}"
    logInfo m!"checked dependency {k}"
  for k in [`OAI.Problem315.switch_chain_main,`OAI.Problem315.VerifiedSwitch.switch_mixing,`UnigraphWorst.worst_theta] do
    if used.contains k then throwError "Unexpected earlier endpoint: {k}"
    logInfo m!"bypasses earlier theorem {k}"
#print LeafResult.many_hub_theta
#print axioms LeafResult.many_hub_theta
end LeafProofAudit
