import CouponCoupling
open Finset HubTransfer
open scoped Matrix
namespace OrderedUrn
noncomputable section
variable {N k : ℕ} {Q : ℝ}
lemma cast_up (z : Z k) (h : z.val<k) : ((up z).val:ℝ)=(z.val:ℝ)+1 := by
  exact_mod_cast (show (up z).val=z.val+1 by simp only [up,min_eq_right (Nat.succ_le_of_lt h)])
lemma cast_down (z : Z k) (h : 0<z.val) : ((down z).val:ℝ)=(z.val:ℝ)-1 := by
  have e : (down z).val+1=z.val := by change z.val-1+1=z.val;omega
  have hr : ((down z).val:ℝ)+1=z.val := by exact_mod_cast e
  linarith

/-- Under the common-move coupling the entire overlap discrepancy is a death
chain. A single discrepancy label is removed at rate N/Q per discrete step. -/
theorem coupon_step (g : ℝ→ℝ) (x : Pair k) :
    (P N k Q *ᵥ (g ∘ diff)) x =
      g (diff x)+(N:ℝ)/Q*diff x*(g (diff x-1)-g (diff x)) := by
  let b:=birth k Q;let d:=death N k Q
  let u:=high x;let v:=low x
  have vu : v.val≤u.val:=low_le x
  have Hup : b u * g (diff (bothUp x))=b u * g (diff x) := by
    by_cases h : u.val<k
    · have hv : v.val<k:=lt_of_le_of_lt vu h
      have eq : diff (bothUp x)=diff x := by
        unfold diff;rw [hi_up,lo_up,cast_up _ h,cast_up _ hv];ring
      rw [eq]
    · have hu : u.val=k := by have m:=u.isLt;omega
      have e : b u=0 := by simp [b,birth,hu]
      rw [e];ring
  have Hdn : d v * g (diff (bothDown x))=d v * g (diff x) := by
    by_cases h : 0<v.val
    · have hu : 0<u.val := lt_of_lt_of_le h vu
      have eq : diff (bothDown x)=diff x := by
        unfold diff;rw [hi_down,lo_down,cast_down _ hu,cast_down _ h];ring
      rw [eq]
    · have hv : v.val=0:=Nat.eq_zero_of_not_pos h
      have e : d v=0 := by simp [d,death,hv]
      rw [e];ring
  have other : (d u-d v)*g (diff (downHigh x))+(b v-b u)*g (diff (upLow x))=
      ((d u-d v)+(b v-b u))*g (diff x-1) := by
    by_cases h : low x < high x
    · have h1 : 0<u.val := by have e : v.val<u.val:=h;omega
      have h2 : v.val<k := by have e : v.val<u.val:=h;have m:=u.isLt;omega
      have eq₁ : diff (downHigh x)=diff x-1 := by
        unfold diff;rw [(other_hi x h).1,(other_hi x h).2,cast_down _ h1];ring
      have eq₂ : diff (upLow x)=diff x-1 := by
        unfold diff;rw [(other_lo x h).1,(other_lo x h).2,cast_up _ h2];ring
      rw [eq₁,eq₂];ring
    · have e : v=u:=le_antisymm (low_le x) (le_of_not_gt h)
      rw [e];ring
  have rate : ((d u-d v)+(b v-b u))=(N:ℝ)/Q*diff x := by
    dsimp [d,b,death,birth,diff,u,v];ring
  simp only [P_apply,Function.comp_apply]
  change (1-b v-d u)*g (diff x)+b u*g (diff (bothUp x))+d v*g (diff (bothDown x))+
      (d u-d v)*g (diff (downHigh x))+(b v-b u)*g (diff (upLow x))=_
  rw [Hup,Hdn,add_assoc _ ((d u-d v)*_),other,←rate];ring

theorem diff_eigen : P N k Q *ᵥ (diff (k:=k)) = (1-(N:ℝ)/Q) • diff := by
  funext x
  have h:=coupon_step (N:=N) (Q:=Q) (fun z=>z) x
  change (P N k Q *ᵥ diff) x = _ at h
  simp only [Pi.smul_apply,smul_eq_mul]
  rw [h];ring

theorem diff_factorial_eigen : P N k Q *ᵥ (fun x=>diff x*(diff x-1)) =
    (1-2*((N:ℝ)/Q)) • (fun x=>diff x*(diff x-1)) := by
  funext x
  have h:=coupon_step (N:=N) (Q:=Q) (fun z=>z*(z-1)) x
  change (P N k Q *ᵥ (fun x=>diff x*(diff x-1))) x = _ at h
  simp only [Pi.smul_apply,smul_eq_mul]
  rw [h];ring

#print axioms coupon_step
#print axioms diff_eigen
#print axioms diff_factorial_eigen
end
end OrderedUrn
