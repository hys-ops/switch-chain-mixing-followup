import WorstLimit
namespace Avoid
open OAI.Problem315 TwoHubUnequal Finset Filter Topology
noncomputable section
variable {r : ℕ}

def inverseCurve (r : ℕ) (ε : ℝ) : ℝ :=
  -Real.log (1-(1-ε)^(((r+1:ℕ):ℝ)⁻¹))

theorem inverse_pos {ε : ℝ} (hε : 0<ε) (hε' : ε<1) : 0 < inverseCurve r ε := by
  have hz : 0<1-ε := by linarith
  have hb : 1-ε<1 := by linarith
  have he : 0<(((r+1:ℕ):ℝ)⁻¹) := by positivity
  have a := Real.rpow_pos_of_pos hz (((r+1:ℕ):ℝ)⁻¹)
  have b := Real.rpow_lt_one hz.le hb he
  unfold inverseCurve
  exact neg_pos.mpr (Real.log_neg (by linarith) (by linarith))

theorem inverse_exact {ε : ℝ} (hε : 0<ε) (hε' : ε<1) : edgeCurve r (inverseCurve r ε)=ε := by
  have hz : 0<1-ε := by linarith
  have ha : 0<1-(1-ε)^(((r+1:ℕ):ℝ)⁻¹) :=
    sub_pos.mpr (Real.rpow_lt_one hz.le (by linarith) (by positivity))
  unfold edgeCurve inverseCurve
  rw [neg_neg,Real.exp_log ha,sub_sub_cancel,Real.rpow_inv_natCast_pow hz.le (by omega)]
  ring

theorem curve_anti {u v : ℝ} (hu : 0≤u) (huv : u<v) : edgeCurve r v<edgeCurve r u := by
  unfold edgeCurve
  apply sub_lt_sub_left
  apply pow_lt_pow_left₀ _ _ (Nat.succ_ne_zero r)
  · exact sub_lt_sub_left (Real.exp_lt_exp.mpr (neg_lt_neg huv)) _
  · exact sub_nonneg.mpr (Real.exp_le_one_iff.mpr (neg_nonpos.mpr hu))

theorem threshold_limit_of_worst (F : Family r) (ε : ℝ) (hε : 0<ε) (hε' : ε<1)
    (hLaw : ∀u:ℝ,0≤u → Tendsto (fun k => worstTV (F.spec k) (localTime r u k)) atTop (𝓝 (edgeCurve r u))) :
    Tendsto (fun k => (threshold (F.spec k) ε:ℝ)*(N r k/Q r k)) atTop (𝓝 (inverseCurve r ε)) := by
  have hp := inverse_pos (r:=r) hε hε'
  have he := inverse_exact (r:=r) hε hε'
  let c := inverseCurve r ε
  have usable (u : ℝ) (hu : c<u) :
      ∀ᶠ k in atTop, worstTV (F.spec k) (localTime r u k)≤ε := by
    have h := (curve_anti (r:=r) hp.le hu)
    rw [he] at h
    exact ((tendsto_order.mp (hLaw u (hp.le.trans hu.le))).2 ε h).mono (fun _ hh => hh.le)
  apply tendsto_order.mpr
  constructor
  · intro z hz
    obtain ⟨v,hzv,hvc⟩ := exists_between (max_lt hz hp)
    have hv : 0<v := (le_max_right _ _).trans_lt hzv
    have hz' : z<v := (le_max_left _ _).trans_lt hzv
    have hlo := curve_anti (r:=r) hv.le hvc
    rw [he] at hlo
    have hcross := (tendsto_order.mp (hLaw v hv.le)).1 ε hlo
    have hbelow := (tendsto_order.mp (scaled_time r v hv.le)).1 z hz'
    filter_upwards [usable (c+1) (by linarith),hcross,hbelow] with k ht hk hy
    have hh : {t : ℕ | worstTV (F.spec k) t≤ε}.Nonempty := ⟨_,ht⟩
    have hd : localTime r v k < threshold (F.spec k) ε := by
      by_contra! H
      have b := worst_antitone (F.spec k) (by omega) H
      exact (not_lt_of_ge (b.trans (Nat.sInf_mem hh))) hk
    exact hy.trans_le (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr hd.le) (div_nonneg (Npos r k).le (Qpos r k).le))
  · intro z hz
    obtain ⟨v,hv,hzv⟩ := exists_between hz
    have habove := (tendsto_order.mp (scaled_time r v (hp.le.trans hv.le))).2 z hzv
    filter_upwards [usable v hv,habove] with k hk ht
    have he : threshold (F.spec k) ε≤localTime r v k := Nat.sInf_le hk
    exact (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr he) (div_nonneg (Npos r k).le (Qpos r k).le)).trans_lt ht

/-- Different accuracy thresholds have different first-order constants on the original clock. -/
theorem inverse_separated {ε δ : ℝ} (he : 0<ε) (hed : ε<δ) (hd : δ<1) :
    inverseCurve r δ < inverseCurve r ε := by
  have he' : ε<1 := hed.trans hd
  have hδ : 0<δ := he.trans hed
  by_contra! h
  rcases h.eq_or_lt with e|e
  · exact hed.ne ((inverse_exact he he').symm.trans ((congrArg (edgeCurve r) e).trans (inverse_exact hδ hd)))
  · have h' := curve_anti (r:=r) (inverse_pos he he').le e
    rw [inverse_exact he he', inverse_exact hδ hd] at h'
    linarith
#print axioms threshold_limit_of_worst
#print axioms inverse_separated
end
end Avoid
