import MarkovTV
open scoped BigOperators Matrix
noncomputable section
namespace HubTransfer
variable {X C : Type*} [Fintype X] [Fintype C] [DecidableEq X] [DecidableEq C]

/-- Discrete-time conditional mixing on a partition. A binomial number of T
steps controls precisely the residual after lifting the quotient distribution
back to uniform conditional laws on the fibers. -/
theorem quotient_transfer (π : X → C) (hs : Function.Surjective π)
    (P T R : Matrix X X ℝ) (p : ℝ) (h0 : 0 ≤ p) (h1 : p ≤ 1)
    (hP : P = p • T + (1-p) • R) (hTR : Commute T R) (hR : Stochastic R)
    (hET : avg π*T = avg π) (hEP : Commute (avg π) P) (t : ℕ) (x : X) :
    tv ((P^t) x) (unif X) ≤ tv (push π ((P^t) x)) (push π (unif X)) +
      ∑ k ∈ Finset.range (t+1), weight t k p * tv ((T^k) x) (avg π x) := by
  let s := Finset.range (t+1)
  let w := fun k => weight t k p
  let A := fun k => T^k * R^(t-k)
  let B := fun k => avg π * R^(t-k)
  have hp : P^t = ∑ k ∈ s, w k • A k := by rw [hP]; exact mixture_pow T R hTR p t
  have he : P^t*avg π = ∑ k ∈ s,w k • B k := by
    rw [← (hEP.pow_right t).eq, hp, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro k _
    rw [mul_smul_comm]
    congr 1
    exact (mul_assoc _ _ _).symm.trans (congrArg (fun M => M * R^(t-k)) (avg_pow hET k))
  have rows (M : Matrix X X ℝ) (D : ℕ → Matrix X X ℝ) (h : M=∑ k ∈ s,w k • D k) :
      M x = fun y => ∑ k ∈ s,w k * D k x y := by
    funext y
    rw [h]
    simp [Matrix.sum_apply]
  have herr : tv ((P^t) x) ((P^t*avg π) x) ≤ ∑ k ∈ s,w k * tv ((T^k) x) (avg π x) := by
    rw [rows _ _ hp,rows _ _ he]
    apply (tv_mix s w (fun k _ => weight_nonneg h0 h1 t k) (fun k => A k x) (fun k => B k x)).trans
    apply Finset.sum_le_sum
    intro k _
    apply mul_le_mul_of_nonneg_left _ (weight_nonneg h0 h1 t k)
    exact tv_contract _ (stochastic_pow hR (t-k)) ((T^k) x) (avg π x)
  have htotal := tv_triangle ((P^t) x) ((P^t*avg π) x) (unif X)
  rw [averaged_tv π hs] at htotal
  linarith

#print axioms quotient_transfer
end HubTransfer
