import ThresholdTV
import CdfUniform
open Finset
noncomputable section
namespace RealThreshold
variable {X:Type*} [Fintype X]

def cdf (r:X→ℕ) (μ σ x:ℝ) (p:X→ℝ) : ℝ :=
  ∑ i,if ((r i:ℝ)-μ)/σ ≤ x then p i else 0

lemma tail_cdf (r:X→ℕ) (p q:X→ℝ) (h:∑i,p i=∑i,q i) (μ σ x:ℝ) (m:ℕ)
    (cut : ∀i, ((r i:ℝ)-μ)/σ≤x ↔ ¬m≤r i) :
    JohnsonProfile.tailDiff r p q m = cdf r μ σ x q-cdf r μ σ x p := by
  classical
  have sc : ∑ i,((if m≤r i then p i-q i else 0) +
        ((if ((r i:ℝ)-μ)/σ≤x then p i else 0)-(if ((r i:ℝ)-μ)/σ≤x then q i else 0)))=0 := by
    calc _ = ∑ i, (p i-q i) := by
               apply sum_congr rfl;intro i _
               by_cases hh:m≤r i <;> simp [cut,hh]
         _=0 := by simp [sum_sub_distrib,h]
  rw [sum_add_distrib,sum_sub_distrib] at sc
  unfold JohnsonProfile.tailDiff cdf
  linarith

lemma cdf_max (r:X→ℕ) (p q:X→ℝ) (h:∑i,p i=∑i,q i) (μ σ A:ℝ) (hs:0<σ)
    (hit : ∃ m, A=JohnsonProfile.tailDiff r p q m) (bound : ∀m,JohnsonProfile.tailDiff r p q m ≤A) :
    (∃ x:ℝ,A=cdf r μ σ x q-cdf r μ σ x p) ∧ (∀x:ℝ,cdf r μ σ x q-cdf r μ σ x p ≤ A) := by
  constructor
  · obtain ⟨m,hm⟩:=hit
    let x : ℝ := ((m:ℝ)-1/2-μ)/σ
    refine ⟨x,hm.trans (tail_cdf r p q h μ σ x m ?_)⟩
    intro i
    unfold x
    rw [div_le_div_iff_of_pos_right hs]
    constructor
    · intro hv hj
      have hx : (m:ℝ)≤r i := by exact_mod_cast hj
      linarith
    · intro hv
      have hj : ((r i:ℝ)+1)≤m := by exact_mod_cast (show r i+1≤m by omega)
      linarith
  · intro x
    let y:= μ+σ*x
    by_cases hy:0≤y
    · rw [←tail_cdf r p q h μ σ x (⌊y⌋₊+1)];exact bound _
      intro i
      rw [div_le_iff₀ hs,not_le,Nat.lt_succ_iff,Nat.le_floor_iff hy]
      dsimp [y];constructor <;> intro h <;> nlinarith
    · rw [←tail_cdf r p q h μ σ x 0];exact bound _
      intro i
      rw [div_le_iff₀ hs]
      have hneg : ¬(r i:ℝ)-μ≤x*σ := by dsimp [y] at hy;nlinarith [Nat.cast_nonneg (α:=ℝ) (r i)]
      simp [hneg]

#print axioms cdf_max
end RealThreshold
