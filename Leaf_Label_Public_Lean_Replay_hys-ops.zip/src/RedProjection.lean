import GraphMarkCode
import GraphMarkedPower
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset JohnsonLower HubMarks HubTransfer
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def redProjection (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) : Slice (r+s) (r-1) :=
  if he : G.val.Adj a c then ⟨markLabels sp (star G.val a c),by
    rw [card_markLabels sp (star G.val a c) (by exact filter_subset _ _)]
    have hc := (star_size G.val a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
    rw [ite_eq_left he] at hc;omega⟩
  else by
    have hh : r-1≤(univ:Finset (Fin (r+s))).card := by rw [card_univ,Fintype.card_fin];omega
    exact ⟨(exists_subset_card_eq hh).choose,(exists_subset_card_eq hh).choose_spec.2⟩

theorem red_mem (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (he : G.val.Adj a c) (x : Label a c) :
    markCode sp x∈(redProjection sp G).val ↔ G.val.Adj a x.val := by
  simp only [redProjection,dite_eq_left he,mem_markLabels,mem_star]
  exact and_iff_right ((mem_leaves _ _ _).mp x.2)

theorem red_eq_iff (sp : TwoHubUnequal.Spec n r s d a c) (G J : GraphState n d)
    (hG : G.val.Adj a c) (hJ : J.val.Adj a c) :
    redProjection sp G=redProjection sp J ↔ star G.val a c=star J.val a c := by
  constructor
  · intro he;ext v;by_cases hv : v∈leaves a c
    · let x : Label a c := ⟨v,hv⟩
      have hh : G.val.Adj a v ↔ J.val.Adj a v := by rw [← red_mem sp G hG x,he,red_mem sp J hJ]
      simp only [mem_star,hh]
    · have hx := (mem_leaves _ _ _).not.mp hv;simp [mem_star,hx]
  · intro he;apply Subtype.ext;simp only [redProjection,dite_eq_left hG,dite_eq_left hJ,he]

theorem red_swap (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) (he : G.val.Adj a c) (i j : Label a c) :
    redProjection sp (permute sp G i j)=swapSet (redProjection sp G) (markCode sp i) (markCode sp j) := by
  have he' := (shape_permute sp G i j).mpr he
  apply Subtype.ext;ext z;obtain ⟨x,rfl⟩:=(markCode sp).surjective z
  change _ ↔ markCode sp x∈Finset.map (Equiv.swap (markCode sp i) (markCode sp j)).toEmbedding _
  rw [mem_map_equiv,Equiv.symm_swap]
  have hfix : Equiv.swap i.val j.val a=a := Equiv.swap_apply_of_ne_of_ne ((mem_leaves _ _ _).mp i.2).1.symm ((mem_leaves _ _ _).mp j.2).1.symm
  by_cases h : x=i
  · subst x;rw [Equiv.swap_apply_left,red_mem sp G he,red_mem sp _ he'];change G.val.Adj _ _ ↔ _;rw [hfix,Equiv.swap_apply_left]
  by_cases h' : x=j
  · subst x;rw [Equiv.swap_apply_right,red_mem sp G he,red_mem sp _ he'];change G.val.Adj _ _ ↔ _;rw [hfix,Equiv.swap_apply_right]
  rw [Equiv.swap_apply_of_ne_of_ne (mt (markCode sp).injective.eq_iff.mp h) (mt (markCode sp).injective.eq_iff.mp h'),red_mem sp G he,red_mem sp _ he']
  change G.val.Adj _ _ ↔ _
  rw [hfix,Equiv.swap_apply_of_ne_of_ne (fun e=> h (Subtype.ext e)) (fun e=> h' (Subtype.ext e))]

theorem red_push (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (G : GraphState n d) (he : G.val.Adj a c) (t : ℕ) :
    push (redProjection sp) (((GraphSplit.H d a c)^t) G)=((walk (r+s) (r-1) (TwoHubUnequal.clock n))^t) (redProjection sp G) := by
  funext T
  let f : Slice (r+s) (r-1) → ℝ := fun S=>if S=T then 1 else 0
  have h := graph_marked_power sp hn (markCode sp) (redProjection sp) (red_swap sp) t f G he
  simpa [push,Matrix.mulVec,dotProduct,f,Function.comp_apply,mul_ite] using h

#print axioms red_push
end
end TwoHubHorizontal
