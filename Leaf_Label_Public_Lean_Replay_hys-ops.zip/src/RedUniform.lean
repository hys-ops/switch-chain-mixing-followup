import RedProjection
import RestrictedTV
import OAI.Probability.SwitchChain.SlicePermutationAction
import Mathlib.GroupTheory.Perm.Support
namespace TwoHubHorizontal
open OAI.Problem315 TwoHub Finset JohnsonLower HubMarks HubTransfer LeafLower.Labels
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def joinedSet (d : Fin n → ℕ) (a c : Fin n) : Finset (GraphState n d) := univ.filter (fun G => G.val.Adj a c)

@[simp] theorem in_joined (G : GraphState n d) : G∈joinedSet d a c ↔ G.val.Adj a c := by simp [joinedSet]

/-- Finite label permutations are enough to transport any red-set fiber to any other. -/
theorem red_fiber_transport (sp : TwoHubUnequal.Spec n r s d a c) (S T : Slice (r+s) (r-1)) :
    ∃ A : Equiv.Perm (GraphState n d), (∀ G,(A G).val.Adj a c ↔ G.val.Adj a c) ∧
      ∀ G, G.val.Adj a c → (redProjection sp (A G)=S ↔ redProjection sp G=T) := by
  obtain ⟨σ,hσ⟩:=SlicePermutationAction.exists_perm_map_eq S.val T.val (S.2.trans T.2.symm)
  let z:=markCode sp
  let q : Equiv.Perm (Label a c):=z.trans (σ.trans z.symm)
  let p : Equiv.Perm (Fin n):=Equiv.Perm.ofSubtype q
  have hp (x : Label a c) : p x.val=(q x).val := Equiv.Perm.ofSubtype_apply_of_mem q x.2
  have pfix {v : Fin n} (hv : v∉leaves a c) : p v=v := Equiv.Perm.ofSubtype_apply_of_not_mem q hv
  have pa : p a=a := pfix (by simp)
  have pc : p c=c := pfix (by simp)
  have hd (v : Fin n) : d (p v)=d v := by
    by_cases hv : v∈leaves a c
    · let x : Label a c := ⟨v,hv⟩
      change d (p x.val)=d x.val;rw [hp]
      have hi:=(mem_leaves _ _ _).mp (q x).2;have hj:=(mem_leaves _ _ _).mp x.2
      exact (sp.leaf _ hi.1 hi.2).trans (sp.leaf _ hj.1 hj.2).symm
    · rw [pfix hv]
  let A:=labelEquiv p hd
  have hA (G : GraphState n d) : (A G).val.Adj a c ↔ G.val.Adj a c := by
    change G.val.Adj (p a) (p c) ↔ _;rw [pa,pc]
  refine ⟨A,hA,?_⟩
  intro G hg
  have key (x : Label a c) : z x ∈ (redProjection sp (A G)).val ↔ σ (z x)∈(redProjection sp G).val := by
    have he : z (q x)=σ (z x) := by simp [q,z]
    rw [←he,red_mem sp G hg,red_mem sp (A G) ((hA G).mpr hg)]
    change G.val.Adj (p a) (p x.val) ↔ G.val.Adj a (q x).val
    rw [pa,hp]
  have dst (v : Fin (r+s)) : v∈S.val ↔ σ v∈T.val := by rw [←hσ];simp
  constructor
  · intro he;apply Subtype.ext;ext y
    obtain ⟨v,rfl⟩:=σ.surjective y;obtain ⟨x,rfl⟩:=z.surjective v
    rw [←key,he,dst]
  · intro he;apply Subtype.ext;ext y
    obtain ⟨x,rfl⟩:=z.surjective y;rw [key,he,←dst]

theorem red_uniform (sp : TwoHubUnequal.Spec n r s d a c) (G₀ : GraphState n d) (h₀ : G₀.val.Adj a c) :
  push (redProjection sp) (RestrictedTV.uniformOn (joinedSet d a c))=unif (Slice (r+s) (r-1)) := by
  let E:=joinedSet d a c
  let m:=RestrictedTV.uniformOn E
  let p:=push (redProjection sp) m
  have hi : E.Nonempty := ⟨G₀,(in_joined G₀).mpr h₀⟩
  have hs : ∑ S,p S=1 := by
    unfold p push;rw [sum_comm];simpa [m] using RestrictedTV.uniformOn_sum E hi
  have inv (S T : Slice (r+s) (r-1)) : p S=p T := by
    obtain ⟨A,hA,hfiber⟩ := red_fiber_transport sp S T
    have eq (G : GraphState n d) : (if redProjection sp (A G)=S then m (A G) else 0)=
        (if redProjection sp G=T then m G else 0) := by
      by_cases hh : G.val.Adj a c
      · have hi' := (hA G).mpr hh
        simp only [m,E,RestrictedTV.uniformOn,in_joined,ite_eq_left hi',ite_eq_left hh,hfiber G hh]
      · have hi' := (hA G).not.mpr hh
        simp [m,E,RestrictedTV.uniformOn,hi',hh]
    have hsum:=Equiv.sum_comp A (fun G : GraphState n d => if redProjection sp G=S then m G else 0)
    simp only [eq] at hsum
    exact hsum.symm
  funext T
  have hm : (Fintype.card (Slice (r+s) (r-1)):ℝ) * p T=1 := by
    calc
      _ = ∑ _S : Slice (r+s) (r-1), p T := by simp
      _ = ∑ S : Slice (r+s) (r-1), p S := sum_congr rfl (fun S _ => inv T S)
      _ = 1 := hs
  have hcard : (Fintype.card (Slice (r+s) (r-1)):ℝ) ≠ 0 := by intro e;rw [e,zero_mul] at hm;norm_num at hm
  change p T=1/(Fintype.card (Slice (r+s) (r-1)):ℝ)
  exact (eq_div_iff hcard).mpr (by linarith [mul_comm (Fintype.card (Slice (r+s) (r-1)):ℝ) (p T)])

#print axioms red_uniform
end
end TwoHubHorizontal
