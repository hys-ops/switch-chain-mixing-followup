import MarkovTV
open Finset HubTransfer
open scoped Matrix Classical
noncomputable section
namespace RestrictedTV
variable {X Y : Type*} [Fintype X] [DecidableEq X] [Fintype Y] [DecidableEq Y]

def uniformOn (S : Finset X) (x : X) : ℝ := if x∈S then 1/(S.card:ℝ) else 0

omit [Fintype X] in
theorem uniformOn_nonneg (S : Finset X) (x : X) : 0≤ uniformOn S x := by
  unfold uniformOn;split <;> positivity

theorem uniformOn_sum (S : Finset X) (hs : S.Nonempty) : ∑ x,uniformOn S x=1 := by
  simp only [uniformOn,←sum_filter,filter_mem_eq_inter,univ_inter,sum_const,nsmul_eq_mul]
  field_simp [show (S.card:ℝ)≠0 by exact_mod_cast hs.card_pos.ne']

omit [DecidableEq X] in
theorem reverse (p q : X → ℝ) : tv p q=tv q p := by simp only [tv,abs_sub_comm]

omit [DecidableEq X] in
theorem push_le (π : X→Y) (p q : X→ℝ) : tv (push π p) (push π q) ≤ tv p q := by
  unfold tv
  apply div_le_div_of_nonneg_right _ (by norm_num)
  calc
    _ ≤ ∑ y:Y, ∑ x:X, if π x=y then |p x-q x| else 0 := by
      apply sum_le_sum;intro y _
      unfold push
      rw [←sum_sub_distrib]
      apply (abs_sum_le_sum_abs _ _).trans_eq
      apply sum_congr rfl;intro x _;split <;> simp_all
    _ = _ := by rw [sum_comm];simp

omit [DecidableEq X] in
theorem prob_tv_le {p q : X→ℝ} (hp : ∀x,0≤p x) (hq : ∀x,0≤q x)
    (hp1 : ∑ x,p x=1) (hq1 : ∑ x,q x=1) : tv p q ≤ 1 := by
  unfold tv; apply (div_le_iff₀ (by norm_num : (0:ℝ)<2)).mpr
  calc
    _ ≤ ∑ x,(p x + q x) := sum_le_sum fun x _ => (abs_sub (p x) (q x)).trans_eq (by rw [abs_of_nonneg (hp _),abs_of_nonneg (hq _)])
    _ = _ := by rw [sum_add_distrib,hp1,hq1];norm_num

theorem to_mixture {I : Type*} [Fintype I] (w : I→ℝ) (hw : ∀i,0≤w i) (h1 : ∑ i,w i=1)
    (p : I→X→ℝ) (q : X→ℝ) {e : ℝ} (he : ∀i,w i≠0→tv (p i) q≤e) :
    tv (fun x => ∑ i,w i*p i x) q ≤ e := by
  have hh : (fun x => ∑ i,w i*q x)=q := by funext x;rw [←sum_mul,h1,one_mul]
  have H := tv_mix univ w (fun i _ => hw i) p (fun _ => q)
  rw [hh] at H
  apply H.trans
  calc
    _ ≤ ∑ i,w i*e := by
      apply sum_le_sum;intro i _;by_cases h:w i=0
      · simp [h]
      · exact mul_le_mul_of_nonneg_left (he i h) (hw i)
    _ = _ := by rw [←sum_mul,h1,one_mul]

omit [DecidableEq X] in
theorem between (p q z : X→ℝ) : |tv p z-tv q z| ≤ tv p q := by
  have a:=tv_triangle p q z
  have b:=tv_triangle q p z
  rw [reverse q p] at b;exact abs_le.mpr ⟨by linarith,by linarith⟩

theorem stoch_sym_pow {K : Matrix X X ℝ} (hk : ∀x y,K x y=K y x) (t : ℕ) (x y : X) :
    (K^t) x y=(K^t) y x := by
  have h : K.transpose=K := by ext i j;exact hk j i
  change ((K^t).transpose) y x=_
  rw [Matrix.transpose_pow,h]

/-- Exact cost of replacing equilibrium on a finite space by equilibrium on a stratum. -/
theorem conditioning (S : Finset X) (hs : S.Nonempty) :
    tv (unif X) (uniformOn S) = ∑ x ∈ Sᶜ,unif X x := by
  have hn : (0:ℝ)<Fintype.card X := by exact_mod_cast (Fintype.card_pos_iff.mpr ⟨hs.choose⟩)
  have hc : (0:ℝ)<S.card := by exact_mod_cast hs.card_pos
  have hdis : ∀x∈S, unif X x ≤ uniformOn S x := by
    intro x hx;unfold unif uniformOn;rw [if_pos hx];exact one_div_le_one_div_of_le hc (by exact_mod_cast card_le_univ S)
  have hsum : ∑ x∈S,uniformOn S x=1 := by
    calc
      _ = ∑ _x∈S,1/(S.card:ℝ) := sum_congr rfl (fun x hx=>if_pos hx)
      _ = _ := by simp [hc.ne']
  have ht : (∑ x∈S,unif X x)+(∑ x∈Sᶜ,unif X x)=1 := by
    rw [sum_add_sum_compl];simp [unif,hn.ne']
  unfold tv
  rw [←sum_add_sum_compl S]
  have hS : (∑ x∈S,|unif X x-uniformOn S x|)=1-∑ x∈S,unif X x := by
    rw [←hsum,←sum_sub_distrib]
    apply sum_congr rfl;intro x hx;rw [abs_of_nonpos (sub_nonpos.mpr (hdis x hx))];ring
  have hcS : (∑ x∈Sᶜ,|unif X x-uniformOn S x|)=∑ x∈Sᶜ,unif X x := by
    apply sum_congr rfl;intro x hx;simp [uniformOn,mem_compl.mp hx,unif]
  rw [hS,hcS];linarith
end RestrictedTV
