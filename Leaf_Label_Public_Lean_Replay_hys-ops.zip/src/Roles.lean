import FixedColors
import ShapeLaw
import LeafEquivariance
namespace Avoid
open OAI.Problem315 Finset TwoHub TwoHubUnequal
open scoped BigOperators
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def marked (a c : Fin n) (G : GraphState n d) := star G.1 a c ∪ loose G.1 a c
def good (a c : Fin n) (K : Finset (Fin n)) (G : GraphState n d) :=
  G.1.Adj a c ∧ Disjoint K (marked a c G)

theorem marked_of_leaf (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) {x : Fin n}
    (hx : x≠a) (hc : x≠c) : x∈marked a c G ↔ ¬G.1.Adj c x := by
  simp only [marked,mem_union,mem_star,mem_loose,hx,hc,true_and]
  have hbad : G.1.Adj a x → ¬G.1.Adj c x :=
    fun h k => sp.distinct (TwoHubUnequal.leaf_unique sp G hx hc h.symm k.symm)
  tauto

theorem marked_leaf (G : GraphState n d) {x : Fin n} (h : x∈marked a c G) : x≠a ∧ x≠c := by
  rcases mem_union.mp h with e|e
  · exact (mem_star _ _ _ _).mp e |>.1
  · exact ⟨((mem_loose _ _ _ _).mp e).1,((mem_loose _ _ _ _).mp e).2.1⟩

theorem marked_card (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) :
    (marked a c G).card = if G.1.Adj a c then r+1 else r := by
  have hd : Disjoint (star G.1 a c) (loose G.1 a c) := by
    apply disjoint_left.mpr;intro x hx hy
    exact ((mem_loose _ _ _ _).mp hy).2.2.1 ((mem_star _ _ _ _).mp hx).2
  unfold marked
  rw [card_union_of_disjoint hd, TwoHubUnequal.loose_size sp G]
  have ht := star_size G.1 a c sp.distinct
  rw [G.2,sp.first] at ht
  split_ifs at * <;> omega

theorem leaf_leaf (sp : TwoHubUnequal.Spec n r s d a c) (G : GraphState n d) {x y : Fin n}
    (hxa : x≠a) (hxc : x≠c) (hya : y≠a) (hyc : y≠c) :
    G.1.Adj x y ↔ x≠y ∧ x∈loose G.1 a c ∧ y∈loose G.1 a c := by
  constructor
  · intro h
    have hx : x∈loose G.1 a c := (mem_loose _ _ _ _).mpr ⟨hxa,hxc,
      fun e => hya (TwoHubUnequal.leaf_unique sp G hxa hxc h e.symm),
      fun e => hyc (TwoHubUnequal.leaf_unique sp G hxa hxc h e.symm)⟩
    exact ⟨h.ne,hx,TwoHubUnequal.loose_partner sp G hx h⟩
  · rintro ⟨hne,hx,hy⟩
    have hj : G.1.Adj a c := by
      by_contra he
      have hsize := TwoHubUnequal.loose_size sp G
      have hzero : (loose G.1 a c).card=0 := by simpa [he] using hsize
      exact (card_pos.mpr ⟨x,hx⟩).ne' hzero
    obtain ⟨u,v,_,he,e⟩ := TwoHubUnequal.loose_edge sp G hj
    rw [he] at hx hy
    simp only [mem_insert,mem_singleton] at hx hy
    rcases hx with h|h <;> rcases hy with k|k <;> subst x <;> subst y <;> first | exact e | exact e.symm | exact (hne rfl).elim

theorem transport (sp : TwoHubUnequal.Spec n r s d a c) (G F : GraphState n d)
    (σ : Equiv.Perm (Fin n)) (ha : σ a=a) (hc : σ c=c)
    (hjoin : F.1.Adj a c ↔ G.1.Adj a c)
    (hstar : ∀x,σ x∈star F.1 a c ↔ x∈star G.1 a c)
    (hloose : ∀x,σ x∈loose F.1 a c ↔ x∈loose G.1 a c) :
    ∀x y,F.1.Adj (σ x) (σ y) ↔ G.1.Adj x y := by
  have hna (x) (h : x≠a) : σ x ≠ a := fun e => h (σ.injective (e.trans ha.symm))
  have hnc (x) (h : x≠c) : σ x ≠ c := fun e => h (σ.injective (e.trans hc.symm))
  have hhA x (h : x≠a) (j : x≠c) : F.1.Adj a (σ x) ↔ G.1.Adj a x := by
    simpa [mem_star,h,j,hna _ h,hnc _ j] using hstar x
  have hhC x (h : x≠a) (j : x≠c) : F.1.Adj c (σ x) ↔ G.1.Adj c x := by
    have he : σ x∈marked a c F ↔ x∈marked a c G := by simp only [marked,mem_union,hstar,hloose]
    rw [marked_of_leaf sp F (hna _ h) (hnc _ j),marked_of_leaf sp G h j] at he
    tauto
  intro x y
  by_cases xa : x=a <;> by_cases xc : x=c <;> by_cases ya : y=a <;> by_cases yc : y=c
  all_goals first | subst x;subst y;simp [ha,hc,hjoin,F.1.adj_comm c a,G.1.adj_comm c a]
                  | subst x;simpa only [ha] using hhA y ya yc
                  | subst x;simpa only [hc] using hhC y ya yc
                  | subst y;simpa only [ha,F.1.adj_comm (σ x),G.1.adj_comm x] using hhA x xa xc
                  | subst y;simpa only [hc,F.1.adj_comm (σ x),G.1.adj_comm x] using hhC x xa xc
                  | rw [leaf_leaf sp F (hna _ xa) (hnc _ xc) (hna _ ya) (hnc _ yc),leaf_leaf sp G xa xc ya yc,
                    σ.injective.ne_iff,hloose,hloose]
#print axioms transport
end
end Avoid
