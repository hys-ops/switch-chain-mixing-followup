import GrowingContinuous
import OverlapTV
open Finset HubTransfer OAI.Problem315 Filter Topology UrnWindow UrnWindow.Degrees
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open TwoHubUnequal HubMarks BinaryOverlap

/-- The scalar chain observes the number of labels still in the original marked
    set. Its equilibrium is the overlap law of a uniform k-subset. -/
def scalarDistance {N k : ℕ} (K : JohnsonLower.Slice N k) (u : ℝ) : ℝ :=
  tv (push (level K) (LeafClock.continuous (LeafClock.published N k) u K))
    (push (level K) (unif _))

theorem urn_to_scalar {N k : ℕ} (K : JohnsonLower.Slice N k) (hN : 0<N) (u : ℝ) :
    urnDistance K u=scalarDistance K u := by
  have hn : (0:ℝ)<N := by exact_mod_cast hN
  apply BinaryOverlap.exact_push
  intro i j h
  have he : LeafClock.continuous (LeafClock.published N k) u K i =
      LeafClock.continuous (LeafClock.published N k) u K j := by
    apply tsum_congr;intro t;congr 1
    exact row_level K ((N:ℝ)^2/2) hN (by positivity) t h
  rw [he];rfl

/-- In external time, the generator on the scalar coordinate is 2/N times
    SparseUrn.generator. This pins down both the birth/death rates and the clock. -/
theorem scalar_generator {N k : ℕ} (K S:JohnsonLower.Slice N k) (hN : 0<N) (f : ℕ→ℝ) :
    ((LeafClock.published N k-1) *ᵥ (fun T=>f (overlap K T))) S =
      2/(N:ℝ)*SparseUrn.generator N k f (overlap K S) := by
  have hn : (0:ℝ)<N := by exact_mod_cast hN
  rw [Matrix.sub_mulVec,Pi.sub_apply,Matrix.one_mulVec]
  rw [show LeafClock.published N k=HubMarks.walk N k ((N:ℝ)^2/2) from rfl,
    overlap_row K S _ hN (by positivity)]
  field_simp;ring

theorem scalar_bound (g : Degrees) (z : Center) (c : ℝ) (i : ℕ)
    {d : Fin (g.population i+2) → ℕ} {a b : Fin (g.population i+2)}
    (sp : Spec (g.population i+2) (g.r i) (g.s i) d a b)
    (G : GraphState _ d) (K : Slice (g.r i) (g.s i)) :
    |tvDistanceFrom _ d (g.time z c i) G - scalarDistance K (g.external i (g.tau z c i))|≤
      envelope g z c i := by
  rw [←urn_to_scalar K (by have:=g.two i;omega)];exact continuous_bound g z c i sp G K

/-- The only outside mathematical input is the specific one-dimensional urn's
    continuous profile, including continuity of that curve. -/
theorem scalar_profiles (g : Degrees)
    (d : (i:ℕ)→Fin (g.population i+2)→ℕ) (a b : (i:ℕ)→Fin (g.population i+2))
    (sp : ∀i,Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (S : (i:ℕ)→Slice (g.r i) (g.s i))
    (paper : g.UrnProfileInput (fun i=>scalarDistance (S i)))
    (z : Regime) (hz : z.holds g) (c : ℝ) {ε : ℝ} (hε : 0<ε) :
    ∀ᶠ i in atTop, ∀ G : GraphState _ (d i),
      |tvDistanceFrom _ (d i) (g.time z.window c i) G-z.curve c|<ε := by
  have he (i : ℕ) : urnDistance (S i)=scalarDistance (S i) :=
    funext (urn_to_scalar (S i) (by have:=g.two i;omega))
  apply named_profiles g d a b sp S _ z hz c hε
  simpa only [he] using paper
#print axioms urn_to_scalar
#print axioms scalar_generator
#print axioms scalar_bound
#print axioms scalar_profiles
end PhysicalReduction
