import PortCount
namespace TwoHub
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r : ℕ} {d : Fin n → ℕ} {a c : Fin n}

/-- The two named hubs and 2r designated leaves. -/
structure Spec (n r : ℕ) (d : Fin n → ℕ) (a c : Fin n) : Prop where
  size : n=2*r+2
  distinct : a≠c
  first : d a=r
  second : d c=r
  leaf : ∀v,v≠a → v≠c → d v=1

def leaves (a c : Fin n) : Finset (Fin n) := univ \ {a,c}
def star (G : SimpleGraph (Fin n)) (a c : Fin n) : Finset (Fin n) := (leaves a c).filter (G.Adj a)
def loose (G : SimpleGraph (Fin n)) (a c : Fin n) : Finset (Fin n) := leaves a c \ (star G a c ∪ star G c a)
@[simp] lemma mem_leaves (v a c : Fin n) : v∈leaves a c ↔ v≠a ∧ v≠c := by simp [leaves,not_or]
@[simp] lemma mem_star (G : SimpleGraph (Fin n)) (a c v : Fin n) :
    v∈star G a c ↔ (v≠a ∧ v≠c) ∧ G.Adj a v := by simp [star]
@[simp] lemma mem_loose (G : SimpleGraph (Fin n)) (a c v : Fin n) :
    v∈loose G a c ↔ v≠a ∧ v≠c ∧ ¬G.Adj a v ∧ ¬G.Adj c v := by
  simp [loose]; tauto

lemma one_neighbor (G : GraphState n d) {z : Fin n} (h : d z=1) : ∃!w,G.val.Adj z w := by
  have hr := (G.2 z).trans h
  obtain ⟨w,hw⟩ := Finset.card_eq_one.mp hr
  have he y : G.val.Adj z y ↔ y=w := by simpa using (Finset.ext_iff.mp hw y)
  exact ⟨w,(he w).2 rfl,fun _ hy => (he _).mp hy⟩

lemma leaf_unique (sp : Spec n r d a c) (G : GraphState n d) {z u v : Fin n}
    (hza : z≠a) (hzc : z≠c) (hu : G.val.Adj z u) (hv : G.val.Adj z v) : u=v := by
  obtain ⟨w,_,hw⟩ := one_neighbor G (sp.leaf z hza hzc)
  exact (hw _ hu).trans (hw _ hv).symm

lemma star_size (G : SimpleGraph (Fin n)) (a c : Fin n) (_h : a≠c) :
    graphDegree G a=(star G a c).card+(if G.Adj a c then 1 else 0) := by
  unfold graphDegree
  by_cases hh : G.Adj a c
  · have he : univ.filter (G.Adj a)=insert c (star G a c) := by
      ext u; simp only [mem_filter,mem_univ,true_and,mem_insert,mem_star]
      by_cases huc : u=c
      · subst u;simp [hh]
      · simp [huc]; exact fun hu => hu.ne.symm
    rw [he,card_insert_of_notMem (by simp),ite_eq_left hh]
  · have he : univ.filter (G.Adj a)=star G a c := by
      ext u; simp only [mem_filter,mem_univ,true_and,mem_star]
      constructor
      · intro hu; exact ⟨⟨hu.ne.symm,fun e => hh (e ▸ hu)⟩,hu⟩
      · exact And.right
    simp [hh,he]

lemma star_disjoint (sp : Spec n r d a c) (G : GraphState n d) : Disjoint (star G.val a c) (star G.val c a) := by
  apply disjoint_left.mpr;intro x hx hy
  obtain ⟨⟨h1,h2⟩,hx'⟩ := (mem_star _ _ _ _).1 hx
  exact sp.distinct (leaf_unique sp G h1 h2 hx'.symm ((mem_star _ _ _ _).1 hy).2.symm)

lemma loose_size (sp : Spec n r d a c) (G : GraphState n d) :
    (loose G.val a c).card=if G.val.Adj a c then 2 else 0 := by
  have ha := (star_size G.val a c sp.distinct).symm.trans ((G.2 a).trans sp.first)
  have hc := (star_size G.val c a sp.distinct.symm).symm.trans ((G.2 c).trans sp.second)
  rw [G.val.adj_comm c a] at hc
  have hL : (leaves a c).card=2*r := by
    unfold leaves;rw [card_sdiff_of_subset (subset_univ _)];simp [sp.distinct,sp.size]
  have hsub : star G.val a c ∪ star G.val c a ⊆ leaves a c := by
    intro x hx;rcases mem_union.mp hx with h|h
    · exact (mem_leaves _ _ _).mpr ((mem_star _ _ _ _).mp h).1
    · exact (mem_leaves _ _ _).mpr ((mem_star _ _ _ _).mp h).1.symm
  unfold loose;rw [card_sdiff_of_subset hsub,card_union_of_disjoint (star_disjoint sp G),hL]
  split_ifs at * <;> omega

lemma loose_partner (sp : Spec n r d a c) (G : GraphState n d) {u v : Fin n}
    (hu : u∈loose G.val a c) (hv : G.val.Adj u v) : v∈loose G.val a c := by
  obtain ⟨ha,hc,hna,hnc⟩ := (mem_loose _ _ _ _).mp hu
  have hva : v≠a := by intro h;subst v;exact hna hv.symm
  have hvc : v≠c := by intro h;subst v;exact hnc hv.symm
  exact (mem_loose _ _ _ _).mpr ⟨hva,hvc,fun h => ha (leaf_unique sp G hva hvc hv.symm h.symm),fun h => hc (leaf_unique sp G hva hvc hv.symm h.symm)⟩

/-- If the hubs are joined, the two unattached leaves form an isolated edge. -/
lemma loose_edge (sp : Spec n r d a c) (G : GraphState n d) (h : G.val.Adj a c) : ∃ u v,
    u≠v ∧ loose G.val a c={u,v} ∧ G.val.Adj u v := by
  obtain ⟨u,v,huv,he⟩ := card_eq_two.mp ((loose_size sp G).trans (ite_eq_left h))
  have hu : u∈loose G.val a c := he ▸ (by simp)
  have hL := (mem_loose _ _ _ _).mp hu
  obtain ⟨z,hz,_⟩ := one_neighbor G (sp.leaf _ hL.1 hL.2.1)
  have hm := loose_partner sp G hu hz;rw [he] at hm
  have hzv : z=v := by simpa [hz.ne.symm] using hm
  exact ⟨u,v,huv,he,hzv ▸ hz⟩
end
end TwoHub
