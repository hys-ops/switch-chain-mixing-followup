import UnequalCrossing
import OAI.Probability.SwitchChain.KernelNormalization
namespace TwoHubUnequal
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def clock (n : ℕ) : ℝ := 12 * n.choose 4
def vertex (a c : Fin n) (G : GraphState n d) : ℝ := if G.val.Adj a c then 0 else 1
def stationary (r s : ℕ) : ℝ := 2 / ((r:ℝ)*s + 2)
def decay (n r s : ℕ) : ℝ := 1 - ((r:ℝ)*s + 2)/clock n

lemma clock_pos (hn : 4≤n) : 0 < clock n := by
  unfold clock
  exact mul_pos (by norm_num) (by exact_mod_cast Nat.choose_pos hn)

lemma shape_step (sp : Spec n r s d a c) (hn : 4≤n) (G : GraphState n d) :
    (∑ H ∈ allGraphStates n d, switchKernel n d G H * vertex a c H)
      = 2 / clock n + decay n r s * vertex a c G := by
  classical
  have hQ := (clock_pos hn).ne'
  have he :
      (∑ H ∈ allGraphStates n d, switchKernel n d G H * vertex a c H) =
      ∑ H ∈ (allGraphStates n d).filter (fun H => ¬H.val.Adj a c), switchKernel n d G H := by
    rw [Finset.sum_filter]
    apply Finset.sum_congr rfl
    intro H _
    by_cases h : H.val.Adj a c <;> simp [h,vertex]
  rw [he]
  by_cases h : G.val.Adj a c
  · simpa [vertex,h,clock] using B_to_A sp G h
  · have hsum := Finset.sum_filter_add_sum_filter_not (allGraphStates n d)
          (fun H : GraphState n d => H.val.Adj a c) (switchKernel n d G)
    rw [A_to_B sp G h, switchKernel_row_sum hn] at hsum
    change (r:ℝ)*s/clock n + _ = 1 at hsum
    simp only [vertex, h, if_false, mul_one, decay]
    field_simp [hQ] at hsum ⊢
    linarith

lemma row_mass (hn : 4≤n) (t : ℕ) (G : GraphState n d) :
    ∑ H ∈ allGraphStates n d, kernelPow n d t G H = 1 := by
  classical
  induction t with
  | zero => simp [kernelPow,allGraphStates]
  | succ t ih =>
    change (∑ H ∈ _, ∑ K ∈ _, kernelPow n d t G K * switchKernel n d K H) = 1
    rw [Finset.sum_comm]
    simp_rw [← Finset.mul_sum,switchKernel_row_sum hn,mul_one]
    exact ih

/-- Exact probability of the absent-hub-edge event for the source chain after t proposals. -/
theorem graph_shape_law (sp : Spec n r s d a c) (hn : 4≤n)
    (t : ℕ) (G : GraphState n d) :
    (∑ H ∈ allGraphStates n d, kernelPow n d t G H * vertex a c H) =
      stationary r s + (decay n r s)^t * (vertex a c G - stationary r s) := by
  classical
  have hQ := (clock_pos hn).ne'
  have hgs : (r:ℝ)*s + 2 ≠ 0 := by positivity
  induction t with
  | zero =>
    simp [kernelPow,allGraphStates,ite_mul]
  | succ t ih =>
    change (∑ H ∈ _, (∑ K ∈ _, kernelPow n d t G K * switchKernel n d K H) * vertex a c H) = _
    simp_rw [Finset.sum_mul,mul_assoc]
    rw [Finset.sum_comm]
    simp_rw [← Finset.mul_sum,shape_step sp hn,mul_add,Finset.sum_add_distrib]
    rw [← Finset.sum_mul,row_mass hn,one_mul]
    simp_rw [← mul_left_comm (decay n r s) (kernelPow n d t G _), ← Finset.mul_sum]
    rw [ih,pow_succ]
    have he : 2 / clock n + decay n r s * stationary r s = stationary r s := by
      unfold decay stationary
      field_simp
      ring
    linear_combination he

/-- Under the uniform law the same event has mass 2/(rs+2). -/
theorem graph_shape_stationary (sp : Spec n r s d a c) (hn : 4≤n) (G₀ : GraphState n d) :
    uniformAverage n d (vertex a c) = stationary r s := by
  classical
  let L := allGraphStates n d
  let u := ∑ H ∈ L, vertex a c H
  have h : (∑ G ∈ L, ∑ H ∈ L, switchKernel n d G H * vertex a c H) = u := by
    rw [Finset.sum_comm]
    simp_rw [← Finset.sum_mul]
    simp [L,switchKernel_column_sum hn,u]
  change (∑ G ∈ allGraphStates n d, ∑ H ∈ allGraphStates n d, _) = u at h
  simp_rw [shape_step sp hn, Finset.sum_add_distrib, ← Finset.mul_sum] at h
  simp only [Finset.sum_const,nsmul_eq_mul] at h
  change (stateCount n d : ℝ) * (2/clock n) + decay n r s * u = u at h
  have hQ := (clock_pos hn).ne'
  have hgs : (r:ℝ)*s + 2 ≠ 0 := by positivity
  have hcard : (stateCount n d:ℝ) ≠ 0 := by
    have hc : 0 < stateCount n d := Finset.card_pos.mpr ⟨G₀,by simp [allGraphStates]⟩
    exact_mod_cast hc.ne'
  change u / (stateCount n d : ℝ) = 2/((r:ℝ)*s+2)
  unfold decay at h
  field_simp [hQ] at h
  field_simp
  linarith

#print axioms graph_shape_law
#print axioms graph_shape_stationary
end
end TwoHubUnequal
