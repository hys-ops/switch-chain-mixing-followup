import PhysicalClock
import ShapeTV
open Filter Topology
open OAI.Problem315
namespace TwoHubUnequal
noncomputable section

/-- Concrete labeled graph families at s=k+2.  The two hub labels may depend on k. -/
structure Family (r : ℕ) where
  d : (k : ℕ) → Fin (r+k+4) → ℕ
  a : (k : ℕ) → Fin (r+k+4)
  c : (k : ℕ) → Fin (r+k+4)
  spec : ∀ k, Spec (r+k+4) r (k+2) (d k) (a k) (c k)

def rowEvent {r} (F : Family r) (u : ℝ) (k : ℕ) (G : GraphState (r+k+4) (F.d k)) : ℝ :=
  ∑ H ∈ allGraphStates _ (F.d k),kernelPow _ (F.d k) (localTime r u k) G H * vertex (F.a k) (F.c k) H

lemma stationary_zero (r : ℕ) (hr : 0<r) :
    Tendsto (fun k : ℕ => stationary r (k+2)) atTop (𝓝 0) := by
  have hk : Tendsto (fun k:ℕ => (k:ℝ)+2) atTop atTop :=
    tendsto_natCast_atTop_atTop.atTop_add tendsto_const_nhds
  have he := (hk.const_mul_atTop (show 0<(r:ℝ) by exact_mod_cast hr)).atTop_add
    (tendsto_const_nhds (x:=(2:ℝ)))
  simpa [stationary] using (tendsto_const_nhds (x:=(2:ℝ))).div_atTop he

/-- The original switch-chain shape at the physical, floored clock.  Initial values
one and zero give exp(-u*r) and zero for vertex- and edge-start respectively. -/
theorem fixed_shape_limit {r : ℕ} (hr : 0<r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (G : (k : ℕ) → GraphState (r+k+4) (F.d k)) (v : ℝ)
    (hv : ∀ k, vertex (F.a k) (F.c k) (G k)=v) :
    Tendsto (fun k => rowEvent F u k (G k)) atTop (𝓝 (Real.exp (-(u*r))*v)) := by
  have hs := stationary_zero r hr
  have ht := hs.add ((attenuation r u hu).mul ((tendsto_const_nhds (x:=v)).sub hs))
  simp only [zero_add,sub_zero] at ht
  apply ht.congr; intro k
  exact (graph_shape_law (F.spec k) (by omega) (localTime r u k) (G k) |>.trans (by rw [hv])).symm

/-- A full-graph TV lower bound valid in the physical time window, with the
limiting function of the observed shape given by fixed_shape_limit. -/
theorem fixed_vertex_lower {r : ℕ} (hr : 0<r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (G : (k : ℕ) → GraphState (r+k+4) (F.d k))
    (hv : ∀ k, ¬(G k).val.Adj (F.a k) (F.c k)) (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ k in atTop, Real.exp (-(u*r))-ε ≤ tvDistanceFrom _ (F.d k) (localTime r u k) (G k) := by
  have hs := stationary_zero r hr
  have ht := (attenuation r u hu).mul ((tendsto_const_nhds (x:=(1:ℝ))).sub hs)
  simp only [sub_zero,mul_one] at ht
  have hh := (tendsto_order.mp ht).1 (Real.exp (-(u*r))-ε) (by linarith)
  filter_upwards [hh] with k hk
  have he := shape_tv_lower (F.spec k) (by omega) (localTime r u k) (G k)
  simp only [vertex,hv,ite_false] at he
  exact hk.le.trans ((le_abs_self _).trans he)
#print axioms fixed_shape_limit
#print axioms fixed_vertex_lower
end
end TwoHubUnequal
