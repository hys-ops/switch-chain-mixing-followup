import ShapeLaw
namespace TwoHubUnequal
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

/-- Exact total variation after observing just the shape is a lower bound on source total variation. -/
theorem shape_tv_lower (sp : Spec n r s d a c) (hn : 4≤n) (t : ℕ) (G : GraphState n d) :
    |(decay n r s)^t * (vertex a c G - stationary r s)| ≤ tvDistanceFrom n d t G := by
  classical
  let L := allGraphStates n d
  let p := kernelPow n d t G
  let u := (1:ℝ)/(stateCount n d:ℝ)
  let f := vertex (d:=d) a c
  have hcard : (stateCount n d:ℝ) ≠ 0 := by
    have hc : 0 < stateCount n d := Finset.card_pos.mpr ⟨G,by simp [allGraphStates]⟩
    exact_mod_cast hc.ne'
  have h0 : (∑ H ∈ L, (p H-u)) = 0 := by
    rw [sum_sub_distrib,row_mass hn]
    simp only [sum_const,nsmul_eq_mul]
    change 1 - (stateCount n d:ℝ)*(1/(stateCount n d:ℝ)) = 0
    field_simp
    ring
  have hau := graph_shape_stationary sp hn G
  have hu : (∑ H ∈ L, u*f H) = stationary r s := by
    rw [← Finset.mul_sum]
    simp only [uniformAverage] at hau
    simpa [u,f,L,div_eq_mul_inv,mul_comm] using hau
  have hf : (∑ H ∈ L, (p H-u)*f H) = (decay n r s)^t*(f G - stationary r s) := by
    simp_rw [sub_mul,sum_sub_distrib,hu]
    rw [graph_shape_law sp hn]
    ring
  have hid : (∑ H ∈ L, (p H-u)*(2*f H-1)) =
        2*((decay n r s)^t*(f G-stationary r s)) := by
    simp_rw [mul_sub,mul_one,mul_left_comm (p _ - u) 2]
    rw [sum_sub_distrib,←mul_sum,h0,hf,sub_zero]
    ring
  have ha := Finset.abs_sum_le_sum_abs (fun H => (p H-u)*(2*f H-1)) L
  rw [hid,abs_mul,abs_of_nonneg (by norm_num : (0:ℝ)≤2)] at ha
  have hab (H : GraphState n d) : |(p H-u)*(2*f H-1)|=|p H-u| := by
    rw [abs_mul]
    by_cases hh : H.val.Adj a c <;> norm_num [f,vertex,hh]
  simp_rw [hab] at ha
  change _ ≤ (1/2:ℝ) * ∑ H∈L,|p H-u|
  change |(decay n r s)^t*(f G-stationary r s)| ≤ _
  linarith
#print axioms shape_tv_lower
end
end TwoHubUnequal
