import HorizontalCensus
import GraphToOrdered
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace SharpClock
open TwoHubUnequal TwoHubHorizontal GraphSplit LeafSplit PhysicalReduction RestrictedTV
variable {n r s : ℕ} {d : Fin n→ℕ} {a c : Fin n}

def splitCost (n r s t : ℕ) : ℝ := (t:ℝ)*(3*((r:ℝ)*s/clock n)^2+2/clock n)
theorem frozen_error_bound (sp : Spec n r s d a c) (hn : 4≤n) (hr:2≤r) (hs:2≤s)
    (hrs : 2≤(r:ℝ)*s) (t:ℕ) (G : GraphState n d) :
    tv (kernelPow n d t G) ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G) ≤
      splitCost n r s t := by
  have e:=graph_error sp hn hrs (physical_commute sp hn)
    (u:=3*((r:ℝ)*s)/(2*clock n)) (by have:=clock_pos hn;positivity)
    (horizontal_sharp sp hn hr hs) t G
  apply e.trans_eq;unfold splitCost;ring
theorem sharp_edge_start (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (hrs : 2≤(r:ℝ)*s) (G : GraphState n d) (hg : isEdge a c G) (t : ℕ) :
    tv (kernelPow n d t G) (((H d a c)^t) G) ≤ splitCost n r s t := by
  have h := frozen_error_bound sp hn hr hs hrs t G
  have he : ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G) = ((H d a c)^t) G := by
    funext y
    rw [Matrix.mul_apply,frozen_edge (isEdge a c) (V d a c) G hg t]
    change ((1 : Matrix (GraphState n d) (GraphState n d) ℝ)*(H d a c)^t) G y=_
    rw [Matrix.one_mul]
  rwa [he] at h

/-- Original row from a hub-disconnected graph versus its complete first-exit mixture. -/
theorem sharp_vertex_start (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (hrs : 2≤(r:ℝ)*s) (G : GraphState n d) (hg : ¬isEdge a c G) (t : ℕ) :
    tv (kernelPow n d t G) (fun y =>
      (1-(r:ℝ)*s/clock n)^t*((H d a c)^t) G y+
      (1-(1-(r:ℝ)*s/clock n)^t)*((U a c G) ᵥ* (H d a c)^t) y) ≤ splitCost n r s t := by
  have h := frozen_error_bound sp hn hr hs hrs t G
  have e := vertex_row sp hn (by linarith : 0<(r:ℝ)*s) G hg t
  have he : ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G) =
      fun y => (1-(r:ℝ)*s/clock n)^t*((H d a c)^t) G y+
      (1-(1-(r:ℝ)*s/clock n)^t)*((U a c G) ᵥ* (H d a c)^t) y := by
    funext y
    rw [Matrix.mul_apply,e]
    simp only [add_mul,sum_add_distrib,mul_assoc,←Finset.mul_sum]
    congr 2
    change ((1 : Matrix (GraphState n d) (GraphState n d) ℝ)*(H d a c)^t) G y=_
    rw [Matrix.one_mul]
  rwa [he] at h

theorem sharp_edge_binary (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G : GraphState n d) (he : G.val.Adj a c) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t (redProjection sp G)| ≤
      splitCost n r s t+gray n s t+stationary r s := by
  let b := bin n r s t (redProjection sp G)
  have H:=four_tv (kernelPow n d t G) (density sp b) (unif _) (reference d a c)
  rw [density_distance sp G he b,ref_cost sp hn G he] at H
  have ha:=tv_triangle (kernelPow n d t G) (((GraphSplit.H d a c)^t) G) (density sp b)
  have hb:=sharp_edge_start sp hn hr hs hrs G he t
  have hd:=heat_density sp hn G he t
  rw [LeafDrift.actual_tv,←LeafDrift.actual_kernel_pow]
  unfold Bdist;change |tv (kernelPow n d t G) (unif _)-tv b (unif _)|≤_
  change tv (((GraphSplit.H d a c)^t) G) (density sp b)≤_ at hd
  linarith
theorem sharp_nonedge (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G : GraphState n d) (he : ¬G.val.Adj a c) (t : ℕ) :
    tv (kernelPow n d t G) ((U a c G) ᵥ* (H d a c)^t) ≤ splitCost n r s t + noexit n r s t := by
  let U₀ := U a c G
  let T := (H d a c)^t
  let w := noexit n r s t
  have hT := stochastic_pow (LeafSplit.h_stoch (isEdge a c) (chain d) (physical_stochastic hn)) t
  have hu1 := incident_mass sp hn (by linarith) G he
  have hu (x) : 0≤U₀ x := div_nonneg
    (LeafSplit.cross_bounds _ _ (physical_stochastic hn) G x).1
    (LeafSplit.ex_bounds _ _ (physical_stochastic hn) G).1
  have hv (x) : 0≤(U₀ ᵥ* T) x := sum_nonneg fun y _=>mul_nonneg (hu y) (hT.1 y x)
  have hv1 : ∑ x,(U₀ ᵥ* T) x=1 := by
    simp only [Matrix.vecMul,dotProduct]
    rw [sum_comm];simp_rw [←mul_sum];change (∑ x,U₀ x*(∑ y,T x y))=1
    simp_rw [show ∀x,∑ y,T x y=1 from hT.2,mul_one];exact hu1
  have hw : 0≤w := by
    have h:=(LeafSplit.ex_bounds (isEdge a c) (chain d) (physical_stochastic hn) G).2
    rw [exit_vertex sp G he] at h;exact pow_nonneg (sub_nonneg.mpr h) t
  let F := fun y=>w*T G y+(1-w)*(U₀ ᵥ* T) y
  have h1 : tv (kernelPow n d t G) F≤splitCost n r s t := sharp_vertex_start sp hn hr hs hrs G he t
  have h2 : tv F (U₀ ᵥ* T) ≤ w := by
    rw [show F=fun y=>w*T G y+(1-w)*(U₀ ᵥ* T) y from rfl,mix_tv _ _ _ hw]
    exact mul_le_of_le_one_right hw (prob_tv_le (hT.1 G) hv (hT.2 G) hv1)
  exact (tv_triangle _ F _).trans (add_le_add h1 h2)

theorem sharp_vertex_binary (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G J : GraphState n d) (he : ¬G.val.Adj a c) (hJ : U a c G J≠0) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t (redProjection sp J)| ≤
      splitCost n r s t+noexit n r s t+gray n s t+adjerr n r s t+stationary r s := by
  let U₀ := U a c G
  let T := (H d a c)^t
  let B := bin n r s t
  let b := B (redProjection sp J)
  have uj := (HubMarks.incidence_marked sp G J he hJ).1
  have Tclose : tv (U₀ ᵥ* T) (density sp b)≤gray n s t + adjerr n r s t := by
    apply to_mixture U₀ _ (incident_mass sp hn (by linarith) G he) T
    · intro L hL
      have hL' := (HubMarks.incidence_marked sp G L he hL).1
      have hl:=heat_density sp hn L hL' t
      obtain ⟨i,j,heq⟩:=incident_red_swap sp G J L he hJ hL
      have hc:=GraphGray.clock_big sp hn
      rw [GraphGray.label_card sp] at hc
      have ha := BinaryGray.binary_adjacent (redProjection sp J) i j (clock_pos hn) hc t
      rw [←heq] at ha
      have hd : tv (density sp (B (redProjection sp L))) (density sp b)≤adjerr n r s t := by
        rw [density_distance_pair sp J uj,reverse];exact ha
      exact (tv_triangle _ (density sp (B (redProjection sp L))) _).trans (add_le_add hl hd)
    · intro x;exact div_nonneg (LeafSplit.cross_bounds _ _ (physical_stochastic hn) G x).1
        (LeafSplit.ex_bounds _ _ (physical_stochastic hn) G).1
  have hh:=four_tv (kernelPow n d t G) (density sp b) (unif _) (reference d a c)
  rw [density_distance sp J uj b,ref_cost sp hn J uj] at hh
  have h1:=sharp_nonedge sp hn hr hs hrs G he t
  have h2:=tv_triangle (kernelPow n d t G) (U₀ ᵥ* T) (density sp b)
  rw [LeafDrift.actual_tv,←LeafDrift.actual_kernel_pow];unfold Bdist
  change |tv (kernelPow n d t G) (unif _)-tv b (unif _)|≤_
  change tv (kernelPow n d t G) (U₀ ᵥ* T)≤_ at h1
  linarith
theorem sharp_choice (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) (t : ℕ) : ∃ S : Slice r s,
      |tvDistanceFrom n d t G-Bdist n r s t S| ≤ (splitCost n r s t+noexit n r s t+gray n s t+adjerr n r s t+stationary r s) := by
  have hrs : 2≤(r:ℝ)*s := by
    have hr' : (2:ℝ)≤r := by exact_mod_cast hr
    have hs' : (2:ℝ)≤s := by exact_mod_cast hs
    nlinarith [mul_le_mul hr' hs' (by norm_num) (by positivity : (0:ℝ)≤r)]
  by_cases he:G.val.Adj a c
  · refine ⟨redProjection sp G,(sharp_edge_binary sp hn hr hs hrs G he t).trans ?_⟩
    obtain ⟨ha,_,hb⟩:=rates sp hn hr hs
    have h1:=pow_nonneg (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr ha)) t
    have h2:=pow_nonneg (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr hb)) t
    linarith
  · obtain ⟨J,hJ⟩:=support_some sp hn (by linarith) G he
    exact ⟨redProjection sp J,sharp_vertex_binary sp hn hr hs hrs G J he hJ t⟩

/-- Every labeled graph start can be compared with the same, arbitrarily
    prescribed point of the red binary slice. -/
theorem sharp_all_starts (sp : Spec n r s d a c) (hn : 4≤n) (hr : 2≤r) (hs : 2≤s)
    (G : GraphState n d) (S : Slice r s) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t S|≤(splitCost n r s t+noexit n r s t+gray n s t+adjerr n r s t+stationary r s) := by
  obtain ⟨T,h⟩:=sharp_choice sp hn hr hs G t
  unfold Bdist at h ⊢
  rw [←JohnsonProfile.tv_start_independent (clock_pos hn).ne' T S t];exact h

#print axioms sharp_all_starts
end SharpClock
