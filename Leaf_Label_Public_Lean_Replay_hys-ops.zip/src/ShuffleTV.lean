import MarkMix
import Minorization
open scoped BigOperators Matrix
noncomputable section
namespace LeafMark
open HubTransfer
variable {A : Type*} [Fintype A] [DecidableEq A] [Nonempty A]
theorem shuffle_minor (t : ℕ) (x y : G A) : (1-tail (Fintype.card A) t 0)*unif (G A) y ≤
    ((shuffle A)^t) x y := by
  let f : G A → ℝ := fun z => if z=y then 1 else 0
  have h := mark_mix t ∅ f (marked_empty _) (fun z => by simp only [f]; split <;> norm_num) x
  simpa [f,mean,unif,Matrix.mulVec,dotProduct,mul_ite] using h

theorem shuffle_tv (t : ℕ) (x : G A) :
    tv (((shuffle A)^t) x) (unif (G A)) ≤
      (2*(Fintype.card A:ℝ)*(1+Real.log (Fintype.card A)))/((t:ℝ)+1) := by
  let n := Fintype.card A
  let e := tail n t 0
  let u := unif (G A)
  let v := ((shuffle A)^t) x
  have su : ∑ y,u y=1 := by simp [u,unif,nsmul_eq_mul,Fintype.card_ne_zero]
  have sv : ∑ y,v y=1 := by simpa [v,Matrix.mulVec,dotProduct] using shuffle_const (A:=A) 1 x t
  have h1 (y:G A) : |v y-u y| ≤ v y+u y-2*((1-e)*u y) := by
    have h := shuffle_minor t x y
    change (1-e)*u y≤v y at h
    have he := tail_nonneg n t 0
    have hu : 0≤u y := by dsimp [u,unif]; positivity
    apply abs_le.mpr; constructor <;> nlinarith [mul_nonneg he hu]
  have herr : tv v u ≤ e := by
    unfold tv
    apply (div_le_iff₀ (by norm_num : (0:ℝ)<2)).2
    apply (Finset.sum_le_sum (s:=Finset.univ) (fun y _ => h1 y)).trans
    simp only [Finset.sum_sub_distrib,Finset.sum_add_distrib,← Finset.mul_sum,su,sv]
    ring_nf; rfl
  exact herr.trans ((tail_bound n t).trans (div_le_div_of_nonneg_right (budget_log Fintype.card_pos) (by positivity)))

theorem binom_recip (t : ℕ) {p : ℝ} (hp : 0<p) (hp' : p≤1) :
    (∑ k ∈ Finset.range (t+1),weight t k p/((k:ℝ)+1))≤1/(((t:ℝ)+1)*p) := by
  have eq (k:ℕ) : ((t:ℝ)+1)*p*(weight t k p/((k:ℝ)+1)) = weight (t+1) (k+1) p := by
    unfold weight
    simp only [Nat.cast_add_one,Nat.add_sub_add_right,pow_succ]
    have hh : ((t:ℝ)+1)*(t.choose k:ℝ)=((t+1).choose (k+1):ℝ)*((k:ℝ)+1) := by
      exact_mod_cast Nat.add_one_mul_choose_eq t k
    field_simp
    linear_combination ((1-p)^(t-k))*hh
  apply (le_div_iff₀ (by positivity)).2
  rw [mul_comm,Finset.mul_sum]
  simp_rw [eq]
  have all : ∑ k ∈ Finset.range ((t+1)+1),weight (t+1) k p =1 := by
    simpa using weight_moment (t+1) p 1
  rw [Finset.sum_range_succ'] at all
  linarith [weight_nonneg hp.le hp' (t+1) 0]

theorem thinned_shuffle (t:ℕ) (x:G A) {p:ℝ} (hp:0<p) (hp':p≤1) :
    (∑ k∈Finset.range (t+1),weight t k p*tv (((shuffle A)^k) x) (unif (G A))) ≤
    (2*(Fintype.card A:ℝ)*(1+Real.log (Fintype.card A)))/(((t:ℝ)+1)*p) := by
  let B := 2*(Fintype.card A:ℝ)*(1+Real.log (Fintype.card A))
  have hB : 0≤B := by
    dsimp [B]
    have h1 : (1:ℝ)≤Fintype.card A := by exact_mod_cast Fintype.card_pos (α:=A)
    positivity [Real.log_nonneg h1]
  calc
    _ ≤ ∑ k∈Finset.range (t+1),weight t k p*(B/((k:ℝ)+1)) :=
      Finset.sum_le_sum fun k _ => mul_le_mul_of_nonneg_left (shuffle_tv k x) (weight_nonneg hp.le hp' _ _)
    _ = B*(∑ k∈Finset.range (t+1),weight t k p/((k:ℝ)+1)) := by
      rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intros; ring
    _ ≤ B*(1/(((t:ℝ)+1)*p)) := mul_le_mul_of_nonneg_left (binom_recip t hp hp') hB
    _ = _ := by dsimp [B]; ring

#print axioms shuffle_tv
#print axioms thinned_shuffle
end LeafMark
