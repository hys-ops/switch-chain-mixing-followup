import DiscretePGF
import OverlapStep
open Finset HubTransfer JohnsonLower HubMarks Filter Topology
open scoped Matrix
namespace CriticalUrn
noncomputable section
variable {N k : ℕ}

theorem slice_pgf (K S : Slice N k) {Q z : ℝ} (hN : 0<N) (hQ : 0<Q)
    (hscale : (N:ℝ)≤Q) (cap : (k:ℝ)*((N:ℝ)-k)≤Q) (hz : 0≤z) (hz' : z≤1) (t : ℕ) :
    |((walk N k Q)^t *ᵥ (fun V => z^(HubMarks.overlap K V))) S-
       comp (load N k) (pbase (N/Q) z t) z (HubMarks.overlap K S)| ≤ allowance N (N/Q) k := by
  have hx (V:Slice N k) : HubMarks.overlap K V≤k := (card_le_card (inter_subset_left (s₂:=K.val))).trans_eq V.property
  have hN' : 0<(N:ℝ) := by exact_mod_cast hN
  have ha := (div_pos hN' hQ).le
  have ha' := (div_le_one hQ).mpr hscale
  have h := discrete_pgf (walk N k Q) (kernel_stoch hQ cap) _ hx
    (fun S f => overlap_row K S Q hN hQ.ne' f) hN' ha ha' hz hz' t S
  apply h.trans
  have hh := (pbase_bounds hz hz' ha ha' t).2
  apply mul_le_of_le_one_right _ (by linarith)
  unfold allowance load;positivity

/-- A uniform state is invariant at every finite N. Average the pointwise finite-clock
bound, then let that auxiliary clock tend to infinity. -/
theorem stationary_pgf (K : Slice N k) {Q z : ℝ} (hN : 0<N) (hQ : 0<Q)
    (hscale : (N:ℝ)≤Q) (cap : (k:ℝ)*((N:ℝ)-k)≤Q) (hz : 0≤z) (hz' : z≤1) :
    |(∑ V : Slice N k,unif _ V*z^(HubMarks.overlap K V))-Real.exp ((z-1)*load N k)| ≤ allowance N (N/Q) k := by
  classical
  have : Nonempty (Slice N k) := ⟨K⟩
  let P := walk N k Q
  let w := unif (Slice N k)
  let a : ℝ := N/Q
  let m := load N k
  let g := fun V : Slice N k => z^(HubMarks.overlap K V)
  let f := fun (t : ℕ) (V : Slice N k) => comp m (pbase a z t) z (HubMarks.overlap K V)
  have ha : 0<a := div_pos (by exact_mod_cast hN) hQ
  have ha' : a≤1 := (div_le_one hQ).mpr hscale
  have hw : ∑ V,w V=1 := by
    have hc : (Fintype.card (Slice N k):ℝ)≠0 := by exact_mod_cast Fintype.card_ne_zero
    simp only [w,unif,sum_const,card_univ,nsmul_eq_mul,one_div,mul_inv_cancel₀ hc]
  have hw0 V : 0≤w V := by unfold w unif;positivity
  have hst : w ᵥ* P=w := by
    funext y;change (∑i,unif _ y * kernel Q i y)=_
    simp_rw [kernel_symm Q _ y];rw [←mul_sum,(kernel_stoch hQ cap).2 y,mul_one]
  have hpow (t : ℕ) : w ᵥ* P^t=w := by
    induction t with
    | zero => simp
    | succ t ih => rw [pow_succ,←Matrix.vecMul_vecMul,ih,hst]
  have mean (t : ℕ) : (∑V,w V*((P^t)*ᵥ g) V) = ∑ V,w V*g V := by
    change w ⬝ᵥ ((P^t)*ᵥ g)=w ⬝ᵥ g
    rw [Matrix.dotProduct_mulVec,hpow]
  have hu (t:ℕ) : |(∑V,w V*g V)-(∑V,w V*f t V)|≤allowance N a k := by
    rw [←mean t,←sum_sub_distrib]
    simp_rw [←mul_sub]
    apply (abs_sum_le_sum_abs _ _).trans
    calc
      _ ≤ ∑ V,w V*allowance N a k := by
        apply sum_le_sum;intro V _;rw [abs_mul,abs_of_nonneg (hw0 V)]
        exact mul_le_mul_of_nonneg_left (slice_pgf K V hN hQ hscale cap hz hz' t) (hw0 V)
      _ = _ := by rw [←sum_mul,hw,one_mul]
  have hb : Tendsto (pbase a z) atTop (𝓝 1) := by
    have hh := (tendsto_pow_atTop_nhds_zero_of_lt_one (sub_nonneg.mpr ha') (by linarith : 1-a<1))
    unfold pbase;simpa using (tendsto_const_nhds (x:=(1:ℝ))).sub ((tendsto_const_nhds (x:=1-z)).mul hh)
  have htail : Tendsto (fun t => ∑V,w V*f t V) atTop (𝓝 (Real.exp ((z-1)*m))) := by
    have hh := tendsto_finsetSum (s:=(univ : Finset (Slice N k))) (fun V _ => (tendsto_const_nhds (x:=w V)).mul
      (((Real.continuous_exp.continuousAt.tendsto.comp ((tendsto_const_nhds (x:=-m)).mul (hb.sub_const z)))).mul (hb.pow (HubMarks.overlap K V))))
    simp only [one_pow,mul_one] at hh
    rw [←sum_mul,hw,one_mul,show -m*(1-z)=(z-1)*m by ring] at hh
    exact hh
  exact le_of_tendsto (tendsto_const_nhds.sub htail).abs (Filter.Eventually.of_forall hu)

#print axioms stationary_pgf
end
end CriticalUrn
