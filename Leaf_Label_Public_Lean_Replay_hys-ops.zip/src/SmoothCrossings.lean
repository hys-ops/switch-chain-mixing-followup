import WindowInverse
import NormalShift
import SparseHubProfile
open Filter Topology OAI.Problem315 UrnWindow UrnWindow.Degrees ProbabilityTheory
namespace GrowingInverse
noncomputable section

theorem inverse_exists (F : ℝ→ℝ) (ha : StrictAnti F) (hc : Continuous F)
    (hL : Tendsto F atBot (𝓝 1)) (hR : Tendsto F atTop (𝓝 0)) {ε : ℝ}
    (hε : 0<ε) (hε' : ε<1) : ∃!w : ℝ,F w=ε := by
  obtain ⟨x,hx⟩ := ((tendsto_order.mp hL).1 ε hε').exists
  obtain ⟨y,hy,hxy⟩ := (((tendsto_order.mp hR).2 ε hε).and (eventually_ge_atTop x)).exists
  obtain ⟨w,_,hw⟩ := intermediate_value_Icc' hxy hc.continuousOn (show ε∈Set.Icc (F y) (F x) from ⟨hy.le,hx.le⟩)
  exact ⟨w,hw,fun v hv=>ha.injective (hv.trans hw.symm)⟩

theorem gumbel_anti : StrictAnti gumbel := by
  intro x y h
  exact sub_lt_sub_left (Real.exp_lt_exp.mpr (neg_lt_neg (Real.exp_lt_exp.mpr (neg_lt_neg h)))) _

def gumbelInverse (ε : ℝ) := -Real.log (-Real.log (1-ε))
theorem gumbel_inverse_exact {ε : ℝ} (he : 0<ε) (he' : ε<1) : gumbel (gumbelInverse ε)=ε := by
  have hp : 0<1-ε := by linarith
  have hn : 0 < -Real.log (1-ε) := neg_pos.mpr (Real.log_neg hp (by linarith))
  unfold gumbel gumbelInverse;rw [neg_neg,Real.exp_log hn,neg_neg,Real.exp_log hp];ring

theorem gaussian_anti : StrictAnti gaussian := by
  have hc : StrictMono (NormalShift.F 0) := strictMono_of_deriv_pos fun x=>by
    rw [(NormalShift.deriv_cdf 0 x).deriv];exact gaussianPDFReal_pos _ _ _ one_ne_zero
  intro u v hv
  have hp := hc (show Real.exp (-v)/2 < Real.exp (-u)/2 by linarith [Real.exp_lt_exp.mpr (neg_lt_neg hv)])
  change 2*NormalShift.F 0 (Real.exp (-v)/2)-1<2*NormalShift.F 0 (Real.exp (-u)/2)-1;linarith

theorem gaussian_crossing {ε : ℝ} (he : 0<ε) (he' : ε<1) : ∃!w : ℝ,gaussian w=ε := by
  have hcont : Continuous (NormalShift.F 0) := continuous_iff_continuousAt.mpr (fun x=>(NormalShift.deriv_cdf 0 x).continuousAt)
  have hc : Continuous gaussian := by change Continuous (fun w : ℝ=>2*NormalShift.F 0 (Real.exp (-w)/2)-1);fun_prop
  have h0 := NormalShift.reflection 0
  simp only [neg_zero] at h0
  apply inverse_exists gaussian gaussian_anti hc _ _ he he'
  · have h := ((Real.tendsto_exp_atTop.comp tendsto_neg_atBot_atTop).atTop_div_const (show (0:ℝ)<2 by norm_num))
    have hx := (tendsto_cdf_atTop (gaussianReal 0 1)).comp h
    unfold gaussian;convert ((tendsto_const_nhds (x:=(2:ℝ))).mul hx).sub_const 1 using 2 <;> norm_num
  · have hx := hcont.continuousAt.tendsto.comp ((Real.tendsto_exp_atBot.comp tendsto_neg_atTop_atBot).div_const 2)
    have h : 2*NormalShift.F 0 0-1=0 := by linarith
    unfold gaussian;have HH := ((tendsto_const_nhds (x:=(2:ℝ))).mul hx).sub_const 1
    simp only [zero_div,h] at HH;exact HH

theorem sparse_time (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0))
    {d : (i:ℕ)→Fin (g.population i+2)→ℕ} {a b : (i:ℕ)→Fin (g.population i+2)}
    (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    {ε : ℝ} (he : 0<ε) (he' : ε<1) :
    Tendsto (fun i=>(Avoid.threshold (sp i) ε:ℝ)*g.step i-g.center .logK i) atTop
      (𝓝 (gumbelInverse ε)) :=
  inverse_of_anti g sp .logK gumbel (HubMarks.sparse_graph_uniform g sparse d a b sp)
    gumbel_anti (gumbel_inverse_exact he he')
#print axioms sparse_time
#print axioms gaussian_crossing
end
end GrowingInverse
