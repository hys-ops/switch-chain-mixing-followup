import SparseSemigroup
open Filter Topology Set Finset
namespace SparseUrn
noncomputable section

theorem zero_probability {N k} (X : Flow N k) {u : ℝ} (hN : 0<N) (hu : 0≤u) :
    (1-Real.exp (-u))^k - ((k:ℝ)^2/N)*(1-Real.exp (-u)) ≤ X.p u 0 ∧
    X.p u 0 ≤ (1-Real.exp (-u))^k := by
  let load := (k:ℝ)^2/N
  let H := value X u
  let B : ℝ → ℝ := fun t => H t + load*Real.exp (t-u)
  have hD (t:ℝ) (ht:0≤t) := value_deriv X u t ht
  have hB (t:ℝ) (ht:0≤t) : HasDerivAt B (residual X u t+load*Real.exp (t-u)) t := by
    have he := (((hasDerivAt_id t).sub_const u).exp).const_mul load
    simpa [B,H,Pi.add_def] using (hD t ht).add he
  have ha : AntitoneOn H (Icc 0 u) := by
    apply antitoneOn_of_deriv_nonpos (convex_Icc _ _)
    · intro t ht; exact (hD t ht.1).continuousAt.continuousWithinAt
    · intro t ht; exact (hD t (interior_subset ht).1).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [(hD t (interior_subset ht).1).deriv]
      exact (residual_bound X hN (interior_subset ht).1 (interior_subset ht).2).2
  have hm : MonotoneOn B (Icc 0 u) := by
    apply monotoneOn_of_deriv_nonneg (convex_Icc _ _)
    · intro t ht; exact (hB t ht.1).continuousAt.continuousWithinAt
    · intro t ht; exact (hB t (interior_subset ht).1).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [(hB t (interior_subset ht).1).deriv]
      dsimp only [load]
      linarith [(residual_bound X hN (interior_subset ht).1 (interior_subset ht).2).1]
  have h0 : H 0 = (1-Real.exp (-u))^k := by
    change ∑ j ∈ range (k+1), X.p 0 j*test u 0 j = _
    rw [sum_eq_single k]
    · simp [X.initial k le_rfl,test,q]
    · intro i hi hik; rw [X.initial i (by simpa using mem_range.mp hi)];simp [hik]
    · simp
  have hu' : H u = X.p u 0 := by
    change ∑ j ∈ range (k+1), X.p u j*test u u j = _
    rw [sum_eq_single 0]
    · simp [test,q]
    · intro i hi hik; simp [test,q,zero_pow hik]
    · simp
  have ax := ha (left_mem_Icc.mpr hu) (right_mem_Icc.mpr hu) hu
  have bx := hm (left_mem_Icc.mpr hu) (right_mem_Icc.mpr hu) hu
  change H 0 + load*Real.exp (0-u) ≤ H u + load*Real.exp (u-u) at bx
  simp only [h0,hu',zero_sub,sub_self,Real.exp_zero,mul_one,load] at bx ax
  constructor <;> linarith

/-- A stationary probability vector for the same explicitly specified overlap generator. -/
structure Invariant (N:ℝ) (k:ℕ) where
  p : ℕ → ℝ
  nonneg : ∀ x ≤ k, 0≤p x
  mass : ∑ x ∈ range (k+1), p x=1
  eqn : ∀ f : ℕ → ℝ, ∑ x ∈ range (k+1), p x*generator N k f x=0

lemma first_mode {N : ℝ} {k : ℕ} (hN : 0<N) (x : ℕ) :
    generator N k (fun j => (j:ℝ)) x = (k:ℝ)^2/N-x := by
  cases x with
  | zero => simp [generator,birth,death]
  | succ x =>
    simp [generator,birth,death]
    field_simp
    ring

lemma invariant_nonzero {N k} (S : Invariant N k) (hN : 0<N) :
    1-S.p 0 ≤ (k:ℝ)^2/N := by
  have hm := S.eqn (fun x => (x:ℝ))
  simp only [first_mode hN,mul_sub,sum_sub_distrib,←sum_mul,S.mass,one_mul] at hm
  have he : ∑ x ∈ range (k+1), S.p x*(if x=0 then 0 else 1 : ℝ) = 1-S.p 0 := by
    calc _ = ∑ x ∈ range (k+1), (S.p x-(if x=0 then S.p 0 else 0)) := by
                apply sum_congr rfl; intro x _;split_ifs with hx <;> simp_all
         _ = _ := by simp [sum_sub_distrib,S.mass]
  rw [←he]
  calc _ ≤ ∑ x ∈ range (k+1), S.p x*(x:ℝ) := by
             apply sum_le_sum
             intro x hx
             apply mul_le_mul_of_nonneg_left _ (S.nonneg x (by simpa using mem_range.mp hx))
             split_ifs with hx <;> first | positivity | (exact_mod_cast (show 1≤x by omega))
       _ = _ := by linarith

end
end SparseUrn
