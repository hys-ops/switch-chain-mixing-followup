import SparseSemigroup
import MarkovTV
open Finset HubTransfer
open scoped Matrix
namespace SparseUrn
noncomputable section

def remainder (q d : ℝ) (n : ℕ) := (q+d)^n-q^n-(n:ℝ)*d*q^(n-1)

lemma second_order {q d : ℝ} (hq : 0≤q) (hd : 0≤d) (h : q+d≤1) (x : ℕ) :
    0≤remainder q d x ∧ remainder q d x ≤ (x:ℝ)^2*d^2 := by
  induction x with
  | zero => simp [remainder]
  | succ x ih =>
    have recId : remainder q d (x+1) = (q+d)*remainder q d x+(x:ℝ)*d^2*q^(x-1) := by
      cases x with
      | zero => simp [remainder]
      | succ x => simp only [remainder,Nat.cast_succ,
                  Nat.succ_sub_one,pow_succ];ring
    rw [recId,Nat.cast_succ]
    have hxq := pow_le_one₀ hq (by linarith : q≤1) (n:=x-1)
    have hh := mul_le_mul_of_nonneg_right h ih.1
    have hb := mul_le_mul_of_nonneg_left hxq (show 0≤(x:ℝ)*d^2 by positivity)
    constructor
    · exact add_nonneg (mul_nonneg (add_nonneg hq hd) ih.1) (by positivity)
    · nlinarith [ih.2,mul_nonneg (Nat.cast_nonneg (α:=ℝ) x) (sq_nonneg d),sq_nonneg d]

def coupon (a : ℝ) (t : ℕ) := 1-(1-a)^t
lemma coupon_le {a : ℝ} (ha : 0≤a) (ha1 : a≤1) (t : ℕ) :
    0≤coupon a t ∧ coupon a t≤1 := by
  exact ⟨sub_nonneg.mpr (pow_le_one₀ (by linarith) (by linarith) (n:=t)),
    by unfold coupon;linarith [pow_nonneg (by linarith : 0≤1-a) t]⟩
lemma coupon_step (a : ℝ) (t : ℕ) : coupon a (t+1) = coupon a t + a*(1-coupon a t) := by
  simp only [coupon,pow_succ];ring

/-- One-step discrete analogue of the backward generating function estimate. -/
lemma single_step {k x : ℕ} {a q N : ℝ} (hx : x≤k) (hN : 0<N) (ha : 0≤a) (ha1 : a≤1)
    (hq : 0≤q) (hq1 : q≤1) :
    0≤(q+a*(1-q))^x-(q^x+a*generator N k (fun j=>q^j) x) ∧
    (q+a*(1-q))^x-(q^x+a*generator N k (fun j=>q^j) x) ≤
      ((k:ℝ)^2/N+(k:ℝ)^2*a)*a*(1-q) := by
  let d := a*(1-q)
  have hd : 0≤d := mul_nonneg ha (by linarith)
  have hd1 : q+d≤1 := by dsimp [d];nlinarith [mul_nonneg (sub_nonneg.mpr ha1) (sub_nonneg.mpr hq1)]
  obtain ⟨hl,hu⟩ := second_order hq hd hd1 x
  obtain ⟨dl,du⟩ := discrepancy hN hx hq hq1
  have hsq : (x:ℝ)^2*d^2 ≤ (k:ℝ)^2*a*d := by
    have hxn := Nat.cast_nonneg (α:=ℝ) x
    have hkn := Nat.cast_nonneg (α:=ℝ) k
    have hxk : (x:ℝ)≤k := by exact_mod_cast hx
    have hda : d≤a := by dsimp [d];nlinarith [mul_nonneg ha hq]
    calc _ ≤ (k:ℝ)^2*d^2 := by gcongr
         _ ≤ _ := by nlinarith [mul_nonneg (sq_nonneg (k:ℝ)) (mul_nonneg hd (sub_nonneg.mpr hda))]
  dsimp only [remainder,d] at hl hu hsq
  constructor <;> nlinarith [mul_nonneg ha (sub_nonneg.mpr du),mul_nonneg ha (sub_nonneg.mpr dl)]

/-- A discrete stochastic row with the exact overlap generator needs no continuous-time
embedding. The factor 1−(1−a)^t sums the exponentially weighted per-step errors. -/
theorem discrete_avoid {X : Type*} [Fintype X] [DecidableEq X] {N a : ℝ} {k : ℕ}
    (P : Matrix X X ℝ) (hp : Stochastic P) (z : X → ℕ) (hz : ∀ i, z i≤k)
    (hN : 0<N) (ha : 0≤a) (ha1 : a≤1)
    (row : ∀ (i:X) (f:ℕ→ℝ),
      (P *ᵥ (fun j => f (z j))) i = f (z i)+a*generator N k f (z i))
    (t : ℕ) (i:X) :
    0 ≤ (coupon a t)^(z i) - ((P^t) *ᵥ fun j => (0:ℝ)^(z j)) i ∧
    (coupon a t)^(z i) - ((P^t) *ᵥ fun j => (0:ℝ)^(z j)) i ≤
      ((k:ℝ)^2/N+(k:ℝ)^2*a)*coupon a t := by
  let B := (k:ℝ)^2/N+(k:ℝ)^2*a
  let H (t:ℕ) := ((P^t) *ᵥ fun j => (0:ℝ)^(z j))
  change 0 ≤ (coupon a t)^(z i) - H t i ∧ (coupon a t)^(z i) - H t i ≤ B*coupon a t
  induction t generalizing i with
  | zero => simp [coupon,H]
  | succ t ih =>
    let q := coupon a t
    obtain ⟨hq,hq1⟩ := coupon_le ha ha1 t
    have lo (j:X) : H t j ≤ q^(z j) := by linarith [(ih j).1]
    have hi (j:X) : q^(z j) ≤ H t j+B*q := by linarith [(ih j).2]
    have ph : H (t+1) i = (P *ᵥ H t) i := by
      dsimp [H];rw [pow_succ',Matrix.mulVec_mulVec]
    have lo' : (P *ᵥ H t) i ≤ (P *ᵥ (fun j => q^(z j))) i :=
      sum_le_sum fun j _ => mul_le_mul_of_nonneg_left (lo j) (hp.1 i j)
    have hi' : (P *ᵥ (fun j => q^(z j))) i ≤ (P *ᵥ H t) i+B*q := by
      calc _ ≤ ∑ j, P i j*(H t j+B*q) :=
                 sum_le_sum fun j _ => mul_le_mul_of_nonneg_left (hi j) (hp.1 i j)
           _ = _ := by simp only [mul_add,sum_add_distrib,←sum_mul,hp.2 i,one_mul];rfl
    have g := single_step (a:=a) (q:=q) (hx:=hz i) hN ha ha1 hq hq1
    have eq := row i (fun j => q^j)
    change (P *ᵥ fun j => q^(z j)) i = q^(z i)+a*generator _ _ _ _ at eq
    change 0≤(q+a*(1-q))^(z i)-(q^(z i)+a*generator _ _ _ _) ∧
        (q+a*(1-q))^(z i)-(q^(z i)+a*generator _ _ _ _) ≤ B*a*(1-q) at g
    rw [ph,coupon_step]
    change 0≤(q+a*(1-q))^(z i)-(P *ᵥ H t) i ∧ (q+a*(1-q))^(z i)-(P *ᵥ H t) i ≤ B*(q+a*(1-q))
    constructor <;> nlinarith [g.1,g.2]

#print axioms discrete_avoid
end
end SparseUrn
