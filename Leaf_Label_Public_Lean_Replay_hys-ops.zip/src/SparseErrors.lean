import SparseScalars

open Filter Topology
noncomputable section
namespace UrnWindow.Degrees.SparseScalars
open UrnWindow
abbrev marks (g : Degrees) (i:ℕ) : ℝ := (g.r i:ℝ)+1

theorem mark_mass (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0)) :
    Tendsto (fun i => (marks g i)^2/g.N i) atTop (𝓝 0) := by
  have h := (tendsto_const_nhds (x:=(9:ℝ))).mul (sparse.pow 2)
  simp only [zero_pow (by decide:2≠0),mul_zero] at h
  apply squeeze_zero (fun i => by
    have hn := (sizes g i).2.2.1;exact div_nonneg (sq_nonneg _) (by linarith)) _ h
  intro i
  obtain ⟨hr,hs,hn,he⟩ := sizes g i
  have hg : 0<g.N i := by linarith
  change (marks g i)^2/g.N i ≤ 9*(g.k i/Real.sqrt (g.N i))^2
  rw [div_pow,Real.sq_sqrt hg.le,←mul_div_assoc]
  apply div_le_div_of_nonneg_right _ hg.le
  have hmk : 0≤marks g i := by dsimp [marks]; positivity
  have hk : marks g i ≤ 3*g.k i := by dsimp [marks,k];linarith
  nlinarith [mul_nonneg (sub_nonneg.mpr hk) (show 0≤3*g.k i+marks g i by linarith)]

theorem mark_step_mass (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0)) :
    Tendsto (fun i => (marks g i)^2*g.N i/g.Q i) atTop (𝓝 0) := by
  apply squeeze_zero (fun i => by have hq := clk_pos g i;positivity) _ (mark_mass g sparse)
  intro i
  have hn : 0<g.N i := by linarith [(sizes g i).2.2.1]
  rw [div_le_div_iff₀ (clk_pos g i) hn]
  nlinarith [mul_nonneg (sq_nonneg (marks g i)) (sub_nonneg.mpr (q_square g i))]

theorem mark_clock (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0)) (c:ℝ) :
    Tendsto (fun i => (g.time .logK c i:ℝ)*marks g i/g.Q i) atTop (𝓝 0) := by
  have hh := (tendsto_const_nhds (x:=1+|c|)).mul (mark_mass g sparse)
  simp only [mul_zero] at hh
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hh
  · filter_upwards with i
    have hq := clk_pos g i; dsimp [marks];positivity
  · filter_upwards [rounding g .logK c] with i hi
    obtain ⟨hr,hs,hn,he⟩ := sizes g i
    have hk : 0<g.k i := by dsimp [k];linarith
    have hlog := Real.log_le_sub_one_of_pos hk
    have ht : g.N i * g.tau .logK c i ≤ Real.log (g.k i)+c := sub_nonpos.mp hi.2
    have hm : 1≤marks g i := by dsimp [marks];linarith
    have hlin : g.N i*g.tau .logK c i ≤ (1+|c|)*marks g i := by
      dsimp [k] at hlog
      dsimp [marks] at hm ⊢
      nlinarith [le_abs_self c,mul_nonneg (abs_nonneg c) (Nat.cast_nonneg (α:=ℝ) (g.r i))]
    have hmul := mul_le_mul_of_nonneg_right hlin (by linarith : 0≤marks g i)
    rw [←mul_div_assoc,le_div_iff₀ (by linarith : 0<g.N i)]
    change (g.time .logK c i:ℝ)*marks g i/g.Q i*g.N i ≤ _
    rw [show (g.time .logK c i:ℝ)*marks g i/g.Q i*g.N i =
      (g.N i*g.tau .logK c i)*marks g i by unfold tau; ring]
    linarith

theorem loss_decay (g : Degrees) (c : ℝ) (a : ℕ→ℝ)
    (hlo : ∀i,g.N i/4≤a i) (hhi : ∀i,a i≤g.Q i) :
    Tendsto (fun i => (1-a i/g.Q i)^(g.time .logK c i)) atTop (𝓝 0) := by
  have ht := Real.tendsto_exp_atBot.comp
    (tendsto_neg_atTop_atBot.comp ((normalized_time_grows g .logK c).atTop_div_const (by norm_num : (0:ℝ)<4)))
  apply squeeze_zero (fun i => pow_nonneg (sub_nonneg.mpr ((div_le_one (clk_pos g i)).mpr (hhi i))) _) _ ht
  intro i
  apply (ManyCore.exp_decay ((div_le_one (clk_pos g i)).mpr (hhi i)) (g.time .logK c i)).trans
  apply Real.exp_le_exp.mpr
  change -(a i / g.Q i) * (g.time .logK c i:ℝ) ≤ -(g.N i*g.tau .logK c i/4)
  have hw : 0≤g.tau .logK c i := div_nonneg (Nat.cast_nonneg _) (clk_pos g i).le
  have he : a i/g.Q i*(g.time .logK c i:ℝ) = a i*g.tau .logK c i := by unfold tau;ring
  rw [neg_mul,he]
  nlinarith [mul_nonneg (sub_nonneg.mpr (hlo i)) hw]

theorem extra_decay (g : Degrees) (c : ℝ) :
    Tendsto (fun i => (1-(g.N i-marks g i)/g.Q i)^(g.time .logK c i)) atTop (𝓝 0) := by
  apply loss_decay
  · intro i;obtain ⟨hr,hs,hn,he⟩:=sizes g i;dsimp [marks];linarith
  · intro i;obtain ⟨hr,hs,hn,he⟩:=sizes g i;dsimp [marks];nlinarith [q_square g i,sq_nonneg (g.N i-1)]

theorem no_exit_decay (g : Degrees) (c:ℝ) :
    Tendsto (fun i => (1-(g.r i:ℝ)*g.s i/g.Q i)^(g.time .logK c i)) atTop (𝓝 0) := by
  apply loss_decay
  · intro i;obtain ⟨hr,hs,hn,he⟩:=sizes g i
    nlinarith [mul_nonneg (by linarith : 0≤(g.r i:ℝ)-2) (Nat.cast_nonneg (α:=ℝ) (g.s i))]
  · intro i;apply le_trans _ (q_square g i);rw [(sizes g i).2.2.2]
    nlinarith [sq_nonneg ((g.r i:ℝ)),sq_nonneg ((g.s i:ℝ)),mul_nonneg (Nat.cast_nonneg (α:=ℝ) (g.r i)) (Nat.cast_nonneg (α:=ℝ) (g.s i))]

theorem stationary_zero (g : Degrees) : Tendsto (fun i => TwoHubUnequal.stationary (g.r i) (g.s i)) atTop (𝓝 0) := by
  apply squeeze_zero (fun i => by unfold TwoHubUnequal.stationary;positivity) _
    ((tendsto_const_nhds (x:=(2:ℝ))).div_atTop (N_infty g))
  intro i;obtain ⟨hr,hs,hn,he⟩ := sizes g i
  apply div_le_div_of_nonneg_left (by norm_num) (by linarith:0<g.N i)
  nlinarith [mul_nonneg (by linarith : 0≤(g.r i:ℝ)-2) (Nat.cast_nonneg (α:=ℝ) (g.s i))]

theorem triple_clock (g : Degrees) (c:ℝ) :
    Tendsto (fun i => 3*(g.time .logK c i:ℝ)/g.Q i) atTop (𝓝 0) := by
  simpa [mul_div_assoc,tau] using (tendsto_const_nhds (x:=(3:ℝ))).mul (tau_zero g .logK c)

theorem total_errors (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0)) (c:ℝ) :
    Tendsto (fun i => TwoHubUnequal.stationary (g.r i) (g.s i)+(marks g i)^2/g.N i+
      2*(3*(g.time .logK c i:ℝ)/g.Q i)+
      ((marks g i)^2/g.N i+(marks g i)^2*g.N i/g.Q i)+
      ((1-(g.N i-marks g i)/g.Q i)^(g.time .logK c i)+(g.time .logK c i:ℝ)*marks g i/g.Q i)+
      (1-(g.r i:ℝ)*g.s i/g.Q i)^(g.time .logK c i)) atTop (𝓝 0) := by
  have hm:=mark_mass g sparse
  have hr:=mark_step_mass g sparse
  have ht:=(tendsto_const_nhds (x:=(2:ℝ))).mul (triple_clock g c)
  simpa only [mul_zero,add_zero] using
    (((((stationary_zero g).add hm).add ht).add (hm.add hr)).add ((extra_decay g c).add (mark_clock g sparse c))).add (no_exit_decay g c)

#print axioms total_errors
end UrnWindow.Degrees.SparseScalars
