import SparseLimit
open Filter Topology OAI.Problem315 SparseUrn
namespace UrnWindow.Degrees
noncomputable section

def ballCount (g : Degrees) (i : ℕ) := g.r i-1
lemma ball_cast (g : Degrees) (i : ℕ) : (g.ballCount i:ℝ)=g.k i := by
  rw [ballCount,Nat.cast_sub (by have := g.two i; omega)];simp [k]
lemma balls_grow (g : Degrees) : Tendsto g.ballCount atTop atTop := by
  apply tendsto_atTop.2
  intro n
  filter_upwards [g.grows.eventually_ge_atTop (n+1)] with i hi
  unfold ballCount;omega

lemma load_vanishes (g : Degrees) (hs : Tendsto g.ratio atTop (𝓝 0)) :
    Tendsto (fun i => (g.ballCount i:ℝ)^2/g.N i) atTop (𝓝 0) := by
  have h : Tendsto (fun i => (g.ratio i)^2) atTop (𝓝 0) := by simpa using hs.pow 2
  apply h.congr;intro i
  rw [ratio,div_pow,Real.sq_sqrt (by linarith [(sizes g i).2.2.1]),ball_cast]

theorem moving_coupon (g : Degrees) (c : ℝ) :
    Tendsto (fun i => (1-Real.exp (-(g.N i*g.tau .logK c i)))^(g.ballCount i))
      atTop (𝓝 (Real.exp (-Real.exp (-c)))) := by
  let w := fun i => g.N i*g.tau .logK c i - Real.log (g.k i)
  have hw : Tendsto w atTop (𝓝 c) := by
    have hh := (rounding_limit g .logK c).add (tendsto_const_nhds (x:=c))
    rw [zero_add] at hh
    apply hh.congr;intro i;dsimp [w,center];ring
  have hkpos (i:ℕ) : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
  have he (i : ℕ) : Real.exp (-(g.N i*g.tau .logK c i)) = Real.exp (-(w i))/g.k i := by
    rw [show -(g.N i*g.tau .logK c i) = -(w i) + -(Real.log (g.k i)) by dsimp [w];ring,
      Real.exp_add,Real.exp_neg (Real.log _),Real.exp_log (hkpos i),div_eq_mul_inv]
  have hcont := Real.continuous_exp.continuousAt.tendsto.comp hw.neg
  have hP : Tendsto (fun i => Real.exp (-(g.N i*g.tau .logK c i))) atTop (𝓝 0) := by
    simpa only [he,Function.comp_def] using hcont.div_atTop (k_infty g)
  have hm : Tendsto (fun i => (g.ballCount i:ℝ)*Real.exp (-(g.N i*g.tau .logK c i)))
      atTop (𝓝 (Real.exp (-c))) := by
    apply hcont.congr;intro i
    rw [he,ball_cast];dsimp;field_simp [(hkpos i).ne']
  exact TwoHubUnequal.moving_decay hP hm

/-- Sparse graph profile directly from the explicit finite generator, with no
external urn-profile assumption. The graph-to-overlap finite comparison remains
an explicit input until a graph coupling proves it. -/
theorem sparse_graph_profile (g : Degrees) (c : ℝ) (hs : Tendsto g.ratio atTop (𝓝 0))
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (X : ∀ i, Flow (g.N i) (g.ballCount i)) (S : ∀ i, Invariant (g.N i) (g.ballCount i))
    (compare : ∀ i (x : GraphState (g.population i+2) (d i)),
      |tvDistanceFrom _ (d i) (g.time .logK c i) x -
        tv (g.ballCount i) ((X i).p (g.N i*g.tau .logK c i)) (S i).p| ≤ g.error .logK c i)
    {ε : ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ x : GraphState (g.population i+2) (d i),
      |tvDistanceFrom _ (d i) (g.time .logK c i) x-gumbel c|<ε := by
  have he := (tendsto_order.mp (error_zero g .logK c)).2 (ε/3) (by linarith)
  have hl := (tendsto_order.mp (load_vanishes g hs)).2 (ε/6) (by linarith)
  have hc := Metric.tendsto_nhds.mp ((tendsto_const_nhds (x:=(1:ℝ))).sub (moving_coupon g c)) (ε/3) (by linarith)
  filter_upwards [he,hl,hc] with i hi hj hu
  rw [Real.dist_eq] at hu
  intro x
  have hn : 0<g.N i := by linarith [(sizes g i).2.2.1]
  have hτ : 0≤g.N i*g.tau .logK c i := mul_nonneg hn.le (div_nonneg (Nat.cast_nonneg _) (clk_pos g i).le)
  let p := tv (g.ballCount i) ((X i).p (g.N i*g.tau .logK c i)) (S i).p
  let v := tvDistanceFrom _ (d i) (g.time .logK c i) x
  let b := 1-(1-Real.exp (-(g.N i*g.tau .logK c i)))^(g.ballCount i)
  change |v-gumbel c|<ε
  have h1 : |v-p|≤g.error .logK c i := compare i x
  have h2 : |p-b| ≤ 2*((g.ballCount i:ℝ)^2/g.N i) := finite_sparse _ _ hn hτ
  have h3 : |b-gumbel c| < ε/3 := hu
  linarith [abs_sub_le v p (gumbel c),abs_sub_le p b (gumbel c)]

#print axioms sparse_graph_profile
end
end UrnWindow.Degrees
