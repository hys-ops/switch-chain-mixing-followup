import SparseProjection
import SparseSlice
import DiscreteWindow
open OAI.Problem315 JohnsonLower Finset Filter Topology
open scoped Matrix
namespace HubMarks
noncomputable section
open TwoHubUnequal UrnWindow
/-- Every term is an explicit number in the original degree and quartet clock. -/
def sparseError (g : Degrees) (c : ℝ) (i : ℕ) : ℝ :=
    (stationary (g.r i) (g.s i) + ((g.r i:ℝ)+1)^2/g.N i) +
       2*(3*(g.time .logK c i:ℝ)/g.Q i) +
       (((g.r i:ℝ)+1)^2/g.N i+((g.r i:ℝ)+1)^2*(g.N i/g.Q i)) +
       ((1-(g.N i-((g.r i:ℝ)+1))/g.Q i)^(g.time .logK c i) +
         (g.time .logK c i:ℝ)*((g.r i:ℝ)+1)/g.Q i) +
       (1-(g.r i:ℝ)*(g.s i:ℝ)/g.Q i)^(g.time .logK c i)

theorem sparse_physical_bound (g : Degrees) (i : ℕ)
    {d : Fin (g.population i+2) → ℕ} {a b : Fin (g.population i+2)}
    (sp : Spec (g.population i+2) (g.r i) (g.s i) d a b) (c : ℝ)
    (G : GraphState (g.population i+2) d) :
    |tvDistanceFrom _ d (g.time .logK c i) G -
        (1-(1-(1-g.N i/g.Q i)^(g.time .logK c i))^(g.r i+1))|≤sparseError g c i := by
  let Nn := g.population i
  let m := g.r i+1
  let q := g.Q i
  let t := g.time .logK c i
  have hr := g.two i
  have hs := g.small i
  have hNn : 4≤Nn := by dsimp [Nn,Degrees.population];omega
  have hN := (g.sizes i).2.2.1
  have hNpos : 0<g.N i := by linarith
  have hs2 : 2≤g.s i := by omega
  have hq := g.clk_pos i
  have qs : (g.N i)^2≤q := Degrees.clock_square g i
  have hscale : g.N i ≤ q := by nlinarith only [hN,qs,sq_nonneg (g.N i-1)]
  have h0 : (0:ℝ)≤g.N i := hNpos.le
  have hR : (g.r i:ℝ)≤g.N i := by exact_mod_cast (show g.r i≤Nn by dsimp [Nn,Degrees.population];omega)
  have hS : (g.s i:ℝ)≤g.N i := by exact_mod_cast (show g.s i≤Nn by dsimp [Nn,Degrees.population];omega)
  have hM : (m:ℝ)≤g.N i := by exact_mod_cast (show m≤Nn by dsimp [m,Nn,Degrees.population];omega)
  have hrq : (g.r i:ℝ)*(g.s i:ℝ)≤q := by
    rw [sq] at qs;exact (mul_le_mul hR hS (by positivity) h0).trans qs
  have cap : (m:ℝ)*(g.N i-(m:ℝ))≤q := by
    rw [sq] at qs
    exact (mul_le_mul hM (sub_le_self _ (by positivity)) (sub_nonneg.mpr hM) h0).trans qs
  let B := SparseUrn.coupon (g.N i/q) t^m
  have ht := SparseUrn.coupon_le (div_nonneg h0 hq.le) ((div_le_one hq).mpr hscale) t
  have hB : |B|≤1 := (abs_of_nonneg (pow_nonneg ht.1 m)).le.trans (pow_le_one₀ ht.1 ht.2)
  have hf := sparse_projection sp (by omega) hs2 hr hrq cap t B
    ((m:ℝ)^2/g.N i+(m:ℝ)^2*(g.N i/q)) hB (by dsimp [q];positivity) (fun M =>
      SparseUrn.actual_slice_avoid M q t (by omega) hq hscale cap) G
  have nadd : ((g.r i:ℝ)+g.s i)=g.N i := (g.sizes i).2.2.2.symm
  simpa only [sparseError,extraError,noExit,eigen,windowError,B,SparseUrn.coupon,Nat.cast_one,one_mul,m,t,q,
    Nat.cast_add,Degrees.Q,Degrees.N,Degrees.population] using hf

#print axioms sparse_physical_bound
end
end HubMarks
