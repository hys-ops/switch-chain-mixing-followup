import SparseGraphKernel
import SparseErrors
open OAI.Problem315 Filter Topology UrnWindow
namespace HubMarks
noncomputable section
/-- Sparse Gumbel window of the ORIGINAL labeled degree-realization switch chain.
All shapes are simultaneous. Only the numerical regime and the supplied degrees are inputs. -/
theorem sparse_graph_uniform (g : Degrees)
    (sparse : Tendsto g.ratio atTop (𝓝 0))
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (sp : ∀ i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (c : ℝ) (ε : ℝ) (hε : 0<ε) :
    ∀ᶠ i in atTop, ∀ G : GraphState (g.population i+2) (d i),
      |tvDistanceFrom _ (d i) (g.time .logK c i) G - Degrees.gumbel c|<ε := by
  have e : Tendsto (sparseError g c) atTop (𝓝 0) := by
    apply (Degrees.SparseScalars.total_errors g sparse c).congr
    intro i;unfold sparseError;dsimp only [Degrees.SparseScalars.marks];ring
  have v := Degrees.SparseScalars.discrete_coupon g c
  have vd : Tendsto (fun i=>|(1-(1-(1-g.N i/g.Q i)^(g.time .logK c i))^(g.r i+1))-Degrees.gumbel c|) atTop (𝓝 0) := by
    have hs := (((tendsto_const_nhds (x:=(1:ℝ))).sub v).sub_const (Degrees.gumbel c)).abs
    simpa [Degrees.gumbel] using hs
  have err := e.add vd
  simp only [add_zero] at err
  filter_upwards [(tendsto_order.mp err).2 ε hε] with i hi
  intro G
  have bound := sparse_physical_bound g i (sp i) c G
  exact (abs_sub_le _ _ _).trans_lt ((add_le_add bound le_rfl).trans_lt hi)

theorem sparse_graph_limit (g : Degrees) (sparse : Tendsto g.ratio atTop (𝓝 0))
    (d : (i:ℕ) → Fin (g.population i+2) → ℕ)
    (a b : (i:ℕ) → Fin (g.population i+2))
    (sp : ∀ i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
    (G : (i:ℕ) → GraphState (g.population i+2) (d i)) (c : ℝ) :
    Tendsto (fun i=>tvDistanceFrom _ (d i) (g.time .logK c i) (G i)) atTop (𝓝 (Degrees.gumbel c)) := by
  apply Metric.tendsto_nhds.mpr;intro ε hε
  filter_upwards [sparse_graph_uniform g sparse d a b sp c ε hε] with i hi
  exact hi (G i)

#print axioms sparse_graph_uniform
#print axioms sparse_graph_limit
end
end HubMarks
