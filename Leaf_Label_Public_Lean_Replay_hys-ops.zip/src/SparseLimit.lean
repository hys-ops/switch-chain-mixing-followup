import SparseCoupon
import GraphWindows
open Filter Topology Set Finset
namespace SparseUrn
noncomputable section

def tv (k : ℕ) (p s : ℕ → ℝ) : ℝ := (∑ i ∈ range (k+1), |p i-s i|)/2
def point (j:ℕ) : ℝ := if j=0 then 1 else 0

lemma tv_triangle (k : ℕ) (p s z : ℕ → ℝ) : tv k p z ≤ tv k p s + tv k s z := by
  unfold tv
  rw [←add_div,←sum_add_distrib]
  exact div_le_div_of_nonneg_right (sum_le_sum fun i _ => abs_sub_le _ _ _) (by norm_num)
lemma tv_comm (k : ℕ) (p s : ℕ → ℝ) : tv k p s=tv k s p := by
  unfold tv; simp only [abs_sub_comm (p _) (s _)]
lemma tv_zero (k : ℕ) (p : ℕ → ℝ) (hp : ∀ i ≤ k,0 ≤ p i)
    (hm : ∑ i ∈ range (k+1),p i=1) : tv k p point=1-p 0 := by
  have hp0 : p 0 ≤ 1 := hm ▸ single_le_sum (f:=p) (fun i hi => hp i (by simpa using mem_range.mp hi))
      (by simp : 0 ∈ range (k+1))
  have hsum : ∑ i ∈ range (k+1), |p i-point i| =
      ∑ i ∈ range (k+1), (p i + if i=0 then 1-2*p 0 else 0) := by
    apply sum_congr rfl
    intro i hi
    by_cases he : i=0
    · subst i
      simp [point,abs_of_nonpos (by linarith : p 0-1 ≤ 0)]
      ring
    · simp [point,he,abs_of_nonneg (hp i (by simpa using mem_range.mp hi))]
  unfold tv
  rw [hsum,sum_add_distrib,hm]
  simp
  ring

/-- Direct finite comparison for the real continuous-time overlap TV, derived from
the exact birth/death generator and stationarity alone. The estimate is uniform
in time and requires no OTS profile or coupling assumption. -/
theorem finite_sparse {N k} (X : Flow N k) (S : Invariant N k) {u:ℝ}
    (hN:0<N) (hu:0≤u) :
    |tv k (X.p u) S.p - (1-(1-Real.exp (-u))^k)| ≤ 2*((k:ℝ)^2/N) := by
  have hSX := tv_zero k (X.p u) (X.nonneg u hu) (X.mass u hu)
  have hS := tv_zero k S.p S.nonneg S.mass
  have h1 := tv_triangle k (X.p u) S.p point
  have h2 := tv_triangle k (X.p u) point S.p
  rw [tv_comm k point S.p] at h2
  have ht := zero_probability X hN hu
  have hh := invariant_nonzero S hN
  have hsmall : 0≤(k:ℝ)^2/N := div_nonneg (sq_nonneg _) hN.le
  have hex : ((k:ℝ)^2/N)*(1-Real.exp (-u)) ≤ (k:ℝ)^2/N := by nlinarith [mul_nonneg hsmall (Real.exp_pos (-u)).le]
  rw [abs_le];constructor <;> linarith [ht.1,ht.2]

lemma finite_coupons_limit {k : ℕ → ℕ} (hg : Tendsto k atTop atTop) (c:ℝ) :
    Tendsto (fun i => (1-Real.exp (-(Real.log (k i:ℝ)+c)))^k i) atTop
      (𝓝 (Real.exp (-Real.exp (-c)))) := by
  have hk : Tendsto (fun i => (k i:ℝ)) atTop atTop := tendsto_natCast_atTop_atTop.comp hg
  have hkp := hk.eventually_gt_atTop 0
  have e : ∀ᶠ i in atTop, Real.exp (-(Real.log (k i:ℝ)+c)) = Real.exp (-c)/(k i:ℝ) := by
    filter_upwards [hkp] with i hi
    rw [neg_add,Real.exp_add,Real.exp_neg,Real.exp_log hi];ring
  have hp : Tendsto (fun i => Real.exp (-(Real.log (k i:ℝ)+c))) atTop (𝓝 0) :=
    (tendsto_const_nhds.div_atTop hk).congr' (e.mono fun _ hi => hi.symm)
  have hm : Tendsto (fun i => (k i:ℝ)*Real.exp (-(Real.log (k i:ℝ)+c))) atTop (𝓝 (Real.exp (-c))) := by
    apply tendsto_const_nhds.congr'
    filter_upwards [e,hkp] with i hi hpos
    rw [hi];field_simp
  exact TwoHubUnequal.moving_decay hp hm

/-- Full sparse limit for any probability solution to the explicit finite overlap
equations, compared to a stationary solution. -/
theorem gumbel_limit {N : ℕ → ℝ} {k : ℕ → ℕ}
    (hn : ∀ i, 0<N i) (hk : Tendsto k atTop atTop)
    (sparse : Tendsto (fun i => (k i:ℝ)^2/N i) atTop (𝓝 0))
    (X : ∀ i, Flow (N i) (k i)) (S : ∀ i, Invariant (N i) (k i)) (c:ℝ) :
    Tendsto (fun i => tv (k i) ((X i).p (Real.log (k i:ℝ)+c)) (S i).p)
      atTop (𝓝 (UrnWindow.Degrees.gumbel c)) := by
  have hu := ((Real.tendsto_log_atTop.comp (tendsto_natCast_atTop_atTop.comp hk)).atTop_add
    (tendsto_const_nhds (x:=c))).eventually_ge_atTop 0
  have h0 : Tendsto (fun i => 2*((k i:ℝ)^2/N i)) atTop (𝓝 0) := by
    simpa using (tendsto_const_nhds (x:=(2:ℝ))).mul sparse
  have hF := (tendsto_const_nhds (x:=(1:ℝ))).sub (finite_coupons_limit hk c)
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' (by simpa only [UrnWindow.Degrees.gumbel,sub_zero] using hF.sub h0)
    (by simpa only [UrnWindow.Degrees.gumbel,add_zero] using hF.add h0)
  · filter_upwards [hu] with i hi
    change 0 ≤ Real.log (k i:ℝ)+c at hi
    linarith [(abs_le.mp (finite_sparse (X i) (S i) (hn i) hi)).1]
  · filter_upwards [hu] with i hi
    change 0 ≤ Real.log (k i:ℝ)+c at hi
    linarith [(abs_le.mp (finite_sparse (X i) (S i) (hn i) hi)).2]

#print axioms finite_sparse
#print axioms gumbel_limit
end
end SparseUrn
