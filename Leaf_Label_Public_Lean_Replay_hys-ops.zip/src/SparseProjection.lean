import GraphGoodMass
import ExtraLabel
open OAI.Problem315 Finset HubTransfer JohnsonLower
open scoped Matrix Classical
namespace HubMarks
noncomputable section
open TwoHubUnequal TwoHubHorizontal
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def extraError (r s n t : ℕ) : ℝ :=
  (eigen (r+s) (r+1) 1 (clock n))^t + (t:ℝ)*(r+1)/clock n

/-- A finite inequality for the actual full graph, based only on the probability
of zero overlap when *all* h=r+1 original marks are protected in the ordinary
h-subset chain. The single extra mark accounts for vertex starts. -/
theorem sparse_projection (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hr : 2≤r)
    (rsQ : (r:ℝ)*s≤clock n) (cap : ((r+1:ℕ):ℝ)*((r+s:ℕ)-(r+1:ℕ):ℝ) ≤ clock n)
    (t : ℕ) (b err : ℝ) (hb : |b|≤1) (he : 0≤err)
    (slice : ∀ M : Slice (r+s) (r+1), |((walk (r+s) (r+1) (clock n))^t *ᵥ avoid M.val) M-b|≤err)
    (G : GraphState n d) :
    |tvDistanceFrom n d t G-(1-b)| ≤
      (stationary r s+((r:ℝ)+1)^2/(r+s)) + 2*(3*t/clock n) + err + extraError r s n t + noExit r s n t := by
  let K := Avoid.marked a c G
  let A := goodStates a c K d
  let T := (GraphSplit.H d a c)^t
  let w := noExit r s n t
  let M := graphMarked sp (show 1≤s by omega)
  have rs : 2≤(r:ℝ)*s := by exact_mod_cast (show 2≤r*s by nlinarith)
  have hk : K⊆TwoHub.leaves a c := fun _ h => (TwoHub.mem_leaves _ _ _).mpr (Avoid.marked_leaf G h)
  have hN : (0:ℝ) ≤ ((r+s:ℕ):ℝ)-(r+1:ℕ) := by apply sub_nonneg.mpr; exact_mod_cast (show r+1≤r+s by omega)
  have h1 : 0≤eigen (r+s) (r+1) 1 (clock n) := by
    unfold eigen;rw [Nat.cast_one,one_mul]
    refine sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr (le_trans ?_ cap))
    simpa only [one_mul] using mul_le_mul_of_nonneg_right (show (1:ℝ)≤(r+1:ℕ) by exact_mod_cast (show 1≤r+1 by omega)) hN
  have hD : 0≤extraError r s n t := by
    unfold extraError;apply add_nonneg (pow_nonneg h1 _);exact div_nonneg (by positivity) (clock_pos hn).le
  have hw0 : 0≤w := pow_nonneg (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr rsQ)) _
  have hw1 : w≤1 := pow_le_one₀ (sub_nonneg.mpr ((div_le_one (clock_pos hn)).mpr rsQ)) (sub_le_self _ (div_nonneg (by positivity) (clock_pos hn).le))
  have Hst := Avoid.graph_tv_initial sp hn (by omega) G t
  have hpr : |mass A (kernelPow n d t G)-b| ≤ 2*(3*t/clock n)+err+extraError r s n t+w := by
    by_cases hG : G.val.Adj a c
    · have ha := (mass_tv A (kernelPow n d t G) (T G)).trans
        (mul_le_mul_of_nonneg_left (GraphSplit.edge_start sp hn hs rs G hG t) (by norm_num))
      have hm : markLabels sp K = (M G).val := by
        ext z;obtain ⟨x,rfl⟩ := (markCode sp).surjective z
        exact (mem_markLabels sp K x).trans (graphMarked_mem sp _ G hG x).symm
      have h : |mass A (T G)-b|≤err := by
        change |mass (goodStates a c K d) (((GraphSplit.H d a c)^t) G)-b|≤err
        rw [joined_event_projection sp hn (by omega) K hk t G hG,hm]
        exact slice (M G)
      linarith only [abs_sub_le (mass A (kernelPow n d t G)) (mass A (T G)) b,ha,h,hD,hw0]
    · let U := GraphSplit.U a c G
      let F := fun y => w*T G y+(1-w)*(U ᵥ* T) y
      have h1' : |mass A (kernelPow n d t G)-mass A F|≤2*(3*t/clock n) :=
        (mass_tv A _ _).trans (mul_le_mul_of_nonneg_left (GraphSplit.vertex_start sp hn hs rs G hG t) (by norm_num))
      have hu : ∀J,0≤U J := fun J => div_nonneg
        (LeafSplit.cross_bounds _ _ (GraphSplit.physical_stochastic hn) G J).1
        (LeafSplit.ex_bounds _ _ (GraphSplit.physical_stochastic hn) G).1
      have hm := weighted_error U (fun J=>mass A (T J)) b (err+extraError r s n t) hu
        (GraphSplit.incident_mass sp hn (by linarith) G hG) (by
          intro J hJ
          obtain ⟨hj,hh⟩ := incidence_marked sp G J hG hJ
          change |mass (goodStates a c K d) (((GraphSplit.H d a c)^t) J)-b|≤_
          rw [joined_event_projection sp hn (by omega) K hk t J hj]
          have hsz : (markLabels sp K).card+1=r+1 := by
            rw [card_markLabels sp K hk];change (Avoid.marked a c G).card+1=r+1
            rw [Avoid.marked_card sp G,ite_eq_right hG]
          have ho := one_missing (clock_pos hn) cap (markLabels sp K) (M J)
             (graphMarked_subset sp _ J hj K hh) hsz t
          simp only [Nat.cast_add,Nat.cast_one] at ho
          exact (abs_sub_le _ _ _).trans ((add_le_add ho (slice (M J))).trans_eq (add_comm _ _)))
      have hev : mass A F=(1-w)*(∑ J,U J*mass A (T J)) := by
        change mass A (fun y=>w*T G y+(1-w)*(U ᵥ* T) y)=_
        rw [weighted_mass,vertex_horizontal_mass K t G hG,mul_zero,zero_add]
      have h3 : |mass A F-b|≤err+extraError r s n t+w := by
        rw [hev]
        let v := ∑ J,U J*mass A (T J)
        have hA : |(1-w)*(v-b)|≤err+extraError r s n t := by
          rw [abs_mul,abs_of_nonneg (sub_nonneg.mpr hw1)]
          exact (mul_le_mul_of_nonneg_left hm (sub_nonneg.mpr hw1)).trans
            (mul_le_of_le_one_left (add_nonneg he hD) (by linarith))
        have hw : |w*b|≤w := by rw [abs_mul,abs_of_nonneg hw0];exact mul_le_of_le_one_right hw0 hb
        change |(1-w)*v-b|≤_
        rw [show (1-w)*v-b=(1-w)*(v-b)-w*b by ring]
        exact (abs_sub _ _).trans (add_le_add hA hw)
      linarith only [abs_sub_le (mass A (kernelPow n d t G)) (mass A F) b,h1',h3]
  change |tvDistanceFrom n d t G-(1-mass A (kernelPow n d t G))|≤_ at Hst
  have HT := abs_sub_le (tvDistanceFrom n d t G) (1-mass A (kernelPow n d t G)) (1-b)
  rw [show (1-mass A (kernelPow n d t G))-(1-b)= -(mass A (kernelPow n d t G)-b) by ring,abs_neg] at HT
  linarith only [HT,Hst,hpr]

#print axioms sparse_projection
end
end HubMarks
