import GraphWindows
import Family

open Filter Topology
noncomputable section
namespace UrnWindow.Degrees
namespace SparseScalars

theorem q_square (g : Degrees) (i : ℕ) : (g.N i)^2≤g.Q i := by
  have hn := (sizes g i).2.2.1
  have h := clock_lower g i
  have hN : 4 ≤ (g.N i)^2 := by nlinarith [sq_nonneg (g.N i-2)]
  nlinarith [mul_nonneg (sq_nonneg (g.N i)) (sub_nonneg.mpr hN)]

theorem squared_step (g : Degrees) (c : ℝ) :
    Tendsto (fun i => (g.time .logK c i:ℝ)*(g.N i/g.Q i)^2) atTop (𝓝 0) := by
  apply squeeze_zero (fun i => mul_nonneg (Nat.cast_nonneg _) (sq_nonneg _)) _ (tau_zero g .logK c)
  intro i
  rw [tau,div_pow,←mul_div_assoc,div_le_div_iff₀ (sq_pos_of_pos (clk_pos g i)) (clk_pos g i)]
  nlinarith [mul_le_mul_of_nonneg_left (q_square g i) (mul_nonneg (Nat.cast_nonneg (α:=ℝ) (g.time .logK c i)) (clk_pos g i).le)]

theorem log_correction {p : ℕ→ℝ} {t : ℕ→ℕ} (hp : Tendsto p atTop (𝓝 0))
    (h2 : Tendsto (fun i => (t i:ℝ)*(p i)^2) atTop (𝓝 0)) :
    Tendsto (fun i => (t i:ℝ)*Real.log (1-p i)+(t i:ℝ)*p i) atTop (𝓝 0) := by
  have hev := (tendsto_order.mp hp).2 1 (by norm_num)
  have hlo := h2.neg.div (tendsto_const_nhds.sub hp) (show (1:ℝ)-0≠0 by norm_num)
  simp only [neg_zero,sub_zero,zero_div] at hlo
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' hlo tendsto_const_nhds
  · filter_upwards [hev] with i hi
    have hpos : 0<1-p i := sub_pos.mpr hi
    have h := mul_le_mul_of_nonneg_left (Real.one_sub_inv_le_log_of_pos hpos) (Nat.cast_nonneg (α:=ℝ) (t i))
    apply le_trans _ (add_le_add_left h ((t i:ℝ)*p i))
    apply le_of_eq
    change -((t i:ℝ)*p i^2)/(1-p i) = _
    field_simp [hpos.ne']; ring
  · filter_upwards [hev] with i hi
    have h := mul_le_mul_of_nonneg_left (Real.log_le_sub_one_of_pos (sub_pos.mpr hi)) (Nat.cast_nonneg (α:=ℝ) (t i))
    linarith

theorem scaled_survival (g : Degrees) (c : ℝ) :
    Tendsto (fun i => g.k i * (1-g.N i/g.Q i)^(g.time .logK c i)) atTop (𝓝 (Real.exp (-c))) := by
  have hround := rounding_limit g .logK c
  have hcorr := log_correction (step_size g) (squared_step g c)
  have ht := ((tendsto_const_nhds (x:= -c)).sub hround).add hcorr
  simp only [sub_zero,add_zero] at ht
  have hlog : Tendsto (fun i => Real.log (g.k i)+(g.time .logK c i:ℝ)*Real.log (1-g.N i/g.Q i)) atTop (𝓝 (-c)) := by
    apply ht.congr; intro i; dsimp only [center,tau]; ring
  apply (Real.continuous_exp.continuousAt.tendsto.comp hlog).congr'
  filter_upwards [(tendsto_order.mp (step_size g)).2 1 (by norm_num)] with i hi
  have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
  simp [Function.comp_def,Real.exp_add,Real.exp_nat_mul,Real.exp_log hk,Real.exp_log (sub_pos.mpr hi)]

theorem discrete_coupon (g : Degrees) (c : ℝ) :
    Tendsto (fun i => (1-(1-g.N i/g.Q i)^(g.time .logK c i))^(g.r i+1)) atTop
      (𝓝 (Real.exp (-Real.exp (-c)))) := by
  let p := fun i => (1-g.N i/g.Q i)^(g.time .logK c i)
  have hprod := scaled_survival g c
  have hp : Tendsto p atTop (𝓝 0) := by
    apply (hprod.div_atTop (k_infty g)).congr
    intro i; dsimp [p]
    have hk : 0<g.k i := by dsimp [k];linarith [(sizes g i).1]
    field_simp [hk.ne']
  have ht : Tendsto (fun i => ((g.r i+1:ℕ):ℝ)*p i) atTop (𝓝 (Real.exp (-c))) := by
    have H := hprod.add ((tendsto_const_nhds (x:=(2:ℝ))).mul hp)
    simp only [mul_zero,add_zero] at H
    apply H.congr
    intro i; change g.k i*p i+2*p i=_
    simp only [k,Nat.cast_add_one];ring
  exact TwoHubUnequal.moving_decay hp ht

#print axioms discrete_coupon
end SparseScalars
end UrnWindow.Degrees
