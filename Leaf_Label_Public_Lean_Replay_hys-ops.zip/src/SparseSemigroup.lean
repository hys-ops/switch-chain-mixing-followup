import UrnTransfer
import Mathlib.Analysis.Calculus.Deriv.MeanValue
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

open Finset Set Filter Topology
namespace SparseUrn
noncomputable section

/-- u=Nτ scale, k red labels and k sites, overlap x and total N labels. -/
def birth (N:ℝ) (k x:ℕ) : ℝ := ((k:ℝ)-x)^2/N
def death (N:ℝ) (k x:ℕ) : ℝ := (x:ℝ)*(N-2*k+x)/N
def generator (N:ℝ) (k:ℕ) (f:ℕ → ℝ) (x:ℕ) : ℝ :=
  birth N k x*(f (x+1)-f x)+death N k x*(f (x-1)-f x)

/-- A probability solution of the finite forward equations. The weak equation is
the row-vector master equation tested against *arbitrary* functions. No mixing
estimate, transition-distance comparison or limiting distribution is assumed. -/
structure Flow (N:ℝ) (k:ℕ) where
  p : ℝ → ℕ → ℝ
  dp : ℝ → ℕ → ℝ
  nonneg : ∀ t ≥ 0, ∀ x ≤ k, 0 ≤ p t x
  mass : ∀ t ≥ 0, ∑ x ∈ range (k+1), p t x = 1
  initial : ∀ x ≤ k, p 0 x = if x=k then 1 else 0
  differentiable : ∀ t ≥ 0, ∀ x ≤ k, HasDerivAt (fun s => p s x) (dp t x) t
  eqn : ∀ t ≥ 0, ∀ f : ℕ → ℝ, ∑ x ∈ range (k+1), dp t x*f x =
        ∑ x ∈ range (k+1), p t x*generator N k f x

lemma discrepancy {N q : ℝ} {k x : ℕ} (hN : 0<N) (hx : x≤k) (hq : 0≤q) (h1 : q≤1) :
    -((k:ℝ)^2/N)*(1-q) ≤ generator N k (fun j=>q^j) x - (x:ℝ)*(1-q)*q^(x-1)
      ∧ generator N k (fun j=>q^j) x - (x:ℝ)*(1-q)*q^(x-1) ≤ 0 := by
  let δ := (x:ℝ)*(2*k-x)/N
  have hx' : (x:ℝ)≤k := by exact_mod_cast hx
  have hδ : 0≤δ := div_nonneg (mul_nonneg (Nat.cast_nonneg _) (by linarith [Nat.cast_nonneg (α:=ℝ) k])) hN.le
  have hb : 0≤birth N k x := div_nonneg (sq_nonneg _) hN.le
  have sum : birth N k x + δ = (k:ℝ)^2/N := by dsimp [birth,δ];ring
  have de : death N k x = (x:ℝ)-δ := by dsimp [death,δ];field_simp;ring
  have equ : generator N k (fun j=>q^j) x - (x:ℝ)*(1-q)*q^(x-1) =
      -(1-q)*(birth N k x*q^x + δ*q^(x-1)) := by
    unfold generator
    simp only [de,pow_succ]
    cases x with
    | zero => simp [δ];ring
    | succ z => simp only [Nat.succ_sub_one, Nat.cast_succ,pow_succ];ring
  have v1 := pow_nonneg hq x
  have v2 := pow_nonneg hq (x-1)
  have hi1 := pow_le_one₀ hq h1 (n:=x)
  have hi2 := pow_le_one₀ hq h1 (n:=x-1)
  rw [equ]
  have hsmall : birth N k x*q^x+δ*q^(x-1) ≤ (k:ℝ)^2/N :=
    calc _ ≤ birth N k x*1+δ*1 := add_le_add (mul_le_mul_of_nonneg_left hi1 hb) (mul_le_mul_of_nonneg_left hi2 hδ)
         _ = _ := by simpa using sum
  constructor
  · nlinarith [mul_nonneg (sub_nonneg.mpr h1) (sub_nonneg.mpr hsmall)]
  · exact mul_nonpos_of_nonpos_of_nonneg (by linarith) (add_nonneg (mul_nonneg hb v1) (mul_nonneg hδ v2))

def q (u t : ℝ) := 1-Real.exp (t-u)
def test (u t : ℝ) (x : ℕ) := (q u t)^x
def value {N k} (X : Flow N k) (u t : ℝ) : ℝ := ∑ x ∈ range (k+1), X.p t x*test u t x
def residual {N k} (X : Flow N k) (u t : ℝ) : ℝ := ∑ x ∈ range (k+1),
    X.p t x*(generator N k (test u t) x - (x:ℝ)*(1-q u t)*(q u t)^(x-1))

lemma test_deriv (u t : ℝ) (x : ℕ) : HasDerivAt (fun v => test u v x)
    (-((x:ℝ)*(1-q u t)*(q u t)^(x-1))) t := by
  have h := ((hasDerivAt_id t).sub_const u).exp
  have hh := ((hasDerivAt_const t (1:ℝ)).sub h).pow x
  convert hh using 1
  · rfl
  · simp [q];ring

lemma value_deriv {N k} (X : Flow N k) (u t : ℝ) (ht : 0≤t) :
    HasDerivAt (value X u) (residual X u t) t := by
  have dh := HasDerivAt.fun_sum (u:=range (k+1))
    (fun x hx => (X.differentiable t ht x (by simpa using mem_range.mp hx)).mul (test_deriv u t x))
  convert dh using 1
  · rfl
  unfold residual
  rw [sum_add_distrib,X.eqn t ht (test u t), ←sum_add_distrib]
  apply sum_congr rfl
  intro x _
  ring

lemma residual_bound {N k} (X : Flow N k) (hN : 0<N) {u t : ℝ} (ht : 0≤t) (htu : t≤u) :
    -((k:ℝ)^2/N)*Real.exp (t-u) ≤ residual X u t ∧ residual X u t ≤ 0 := by
  have hq : 0≤q u t := by unfold q;rw [sub_nonneg,Real.exp_le_one_iff];linarith
  have hq1 : q u t≤1 := by unfold q;linarith [Real.exp_pos (t-u)]
  have hdown (x) (hx:x ∈ range (k+1)) := discrepancy (N:=N) (x:=x) (k:=k) hN
    (by simpa using mem_range.mp hx) hq hq1
  have he : Real.exp (t-u) = 1-q u t := by simp [q]
  constructor
  · calc _ = ∑ x ∈ range (k+1), X.p t x*(-((k:ℝ)^2/N)*(1-q u t)) := by
                rw [←sum_mul,X.mass t ht,one_mul,he]
         _ ≤ _ := sum_le_sum fun x hx => mul_le_mul_of_nonneg_left (hdown x hx).1
           (X.nonneg t ht x (by simpa using mem_range.mp hx))
  · apply sum_nonpos
    intro x hx
    exact mul_nonpos_of_nonneg_of_nonpos (X.nonneg t ht x (by simpa using mem_range.mp hx)) (hdown x hx).2

end
end SparseUrn
