import SparseDiscrete
import OverlapStep
import Avoidance
open Filter Topology Finset SparseUrn JohnsonLower HubMarks
open scoped Matrix
namespace SparseUrn
noncomputable section

lemma point_event_avoid {N k:ℕ} (K:Slice N k) :
    (fun S : Slice N k => (0:ℝ)^(overlap K S))=avoid K.val := by
  funext S
  by_cases h : overlap K S = 0
  · have h0 : S.val∩K.val=∅ := card_eq_zero.mp h
    have hdis : Disjoint K.val S.val := Finset.disjoint_iff_inter_eq_empty.mpr (by rwa [Finset.inter_comm])
    simp [h,avoid,hdis]
  · have hdis : ¬Disjoint K.val S.val := by
      intro he
      apply h
      unfold overlap
      rw [Finset.disjoint_iff_inter_eq_empty.mp he.symm,Finset.card_empty]
    simp [h,avoid,hdis]

theorem actual_slice_bounds {N k:ℕ} (K S:Slice N k) (Q:ℝ) (t:ℕ)
    (hN:0<N) (hQ:0<Q) (hscale:(N:ℝ)≤Q) (cap:(k:ℝ)*((N:ℝ)-k)≤Q) :
    0 ≤ coupon ((N:ℝ)/Q) t ^ (overlap K S) - (((walk N k Q)^t) *ᵥ avoid K.val) S ∧
    coupon ((N:ℝ)/Q) t ^ (overlap K S) - (((walk N k Q)^t) *ᵥ avoid K.val) S ≤
      ((k:ℝ)^2/N+(k:ℝ)^2*((N:ℝ)/Q))*coupon ((N:ℝ)/Q) t := by
  have hx (s:Slice N k) : overlap K s ≤ k := (Finset.card_le_card (Finset.inter_subset_left (s₂:=K.val))).trans_eq s.property
  have h := discrete_avoid (walk N k Q) (kernel_stoch hQ cap) (overlap K) hx
    (by exact_mod_cast hN : 0<(N:ℝ)) (div_nonneg (Nat.cast_nonneg _) hQ.le)
    ((div_le_one hQ).mpr hscale) (fun i f => overlap_row K i Q hN hQ.ne' f) t S
  rwa [point_event_avoid] at h

theorem actual_slice_avoid {N k:ℕ} (K:Slice N k) (Q:ℝ) (t:ℕ)
    (hN:0<N) (hQ:0<Q) (hscale:(N:ℝ)≤Q) (cap:(k:ℝ)*((N:ℝ)-k)≤Q) :
    |(((walk N k Q)^t) *ᵥ avoid K.val) K - coupon ((N:ℝ)/Q) t ^ k| ≤
      (k:ℝ)^2/N+(k:ℝ)^2*((N:ℝ)/Q) := by
  obtain ⟨h0,h1⟩ := actual_slice_bounds K K Q t hN hQ hscale cap
  have hk : overlap K K=k := by simp [overlap,K.property]
  rw [hk] at h0 h1
  have hq := (coupon_le (div_nonneg (Nat.cast_nonneg _) hQ.le) ((div_le_one hQ).mpr hscale) t).2
  have hb : 0≤(k:ℝ)^2/N+(k:ℝ)^2*((N:ℝ)/Q) := by positivity
  rw [abs_of_nonpos (by linarith)]
  nlinarith [mul_nonneg hb (sub_nonneg.mpr hq)]

#print axioms actual_slice_avoid
end
end SparseUrn
