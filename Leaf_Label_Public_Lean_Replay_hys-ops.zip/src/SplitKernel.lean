import MarkovTV
open Finset HubTransfer
open scoped Matrix
noncomputable section
namespace LeafSplit
variable {X : Type*} [Fintype X] [DecidableEq X]

theorem rows_mix (A B C : Matrix X X ℝ) (ha : Stochastic A) {e : ℝ}
    (hr : ∀ y,tv (B y) (C y)≤e) (x : X) : tv ((A*B) x) ((A*C) x)≤e := by
  have h := tv_mix univ (A x) (fun y _ => ha.1 x y) B C
  change tv ((A*B) x) ((A*C) x) ≤ ∑ y,A x y*tv (B y) (C y) at h
  calc
    _ ≤ _ := h
    _ ≤ ∑ y,A x y*e := sum_le_sum (fun y _ => mul_le_mul_of_nonneg_left (hr y) (ha.1 x y))
    _ = e := by rw [←sum_mul,ha.2 x,one_mul]

theorem power_error (P R : Matrix X X ℝ) (hp : Stochastic P) (hr : Stochastic R)
    {e : ℝ} (hd : ∀ x,tv (P x) (R x)≤e) (t : ℕ) (x : X) :
    tv ((P^t) x) ((R^t) x) ≤ (t:ℝ)*e := by
  induction t with
  | zero => simp [tv]
  | succ t ih =>
    rw [pow_succ,pow_succ]
    have h := tv_triangle ((P^t*P) x) ((P^t*R) x) ((R^t*R) x)
    have ha := rows_mix (P^t) P R (stochastic_pow hp t) hd x
    have hb := tv_contract R hr ((P^t) x) ((R^t) x)
    change tv ((P^t*R) x) ((R^t*R) x) ≤ _ at hb
    push_cast;linarith

/-- Exact row ℓ¹ distance from the identity, including its diagonal contribution. -/
theorem row_abs_sub_id (P : Matrix X X ℝ) (hp : Stochastic P) (x : X) :
    (∑ y,|(P-1) x y|)=2*(1-P x x) := by
  classical
  have hi := Finset.single_le_sum (fun y (_ : y∈(univ:Finset X)) => hp.1 x y) (mem_univ x)
  rw [hp.2] at hi
  have hx : x∈(univ:Finset X) := mem_univ x
  have hs := sum_erase_add univ (fun y => P x y) hx
  rw [hp.2 x] at hs
  rw [←sum_erase_add univ (fun y => |(P-1) x y|) hx]
  have he : (∑ y ∈ univ.erase x,|(P-1) x y|)=∑ y ∈ univ.erase x,P x y := by
    apply sum_congr rfl;intro y hy
    have hn : x≠y := ((mem_erase.mp hy).1).symm
    simp [Matrix.sub_apply,hn,abs_of_nonneg (hp.1 x y)]
  rw [he]
  simp only [Matrix.sub_apply,Matrix.one_apply,ite_true]
  rw [abs_of_nonpos (by linarith : P x x-1≤0)];linarith

theorem one_step (P H V : Matrix X X ℝ) (hh : Stochastic H) (hv : Stochastic V)
    (hform : P=H+V-1) {a b : ℝ} (hb : 0≤b)
    (hk : ∀ x,1-H x x≤a) (hl : ∀ x,1-V x x≤b) (x : X) :
    tv (P x) ((H*V) x) ≤ 2*a*b := by
  have he : H*V -P=(H-1)*(V-1) := by rw [hform];noncomm_ring
  have hpt (y) : |P x y-(H*V) x y| = |((H-1)*(V-1)) x y| := by
    rw [←he,Matrix.sub_apply,abs_sub_comm]
  unfold tv
  simp_rw [hpt]
  apply (div_le_iff₀ (by norm_num : (0:ℝ)<2)).mpr
  calc
    _ ≤ ∑ y, ∑ z, |(H-1) x z| *|(V-1) z y| := by
      apply sum_le_sum;intro y _
      rw [Matrix.mul_apply]
      exact (Finset.abs_sum_le_sum_abs _ _).trans_eq (by simp [abs_mul])
    _ = ∑ z, |(H-1) x z| *(2*(1-V z z)) := by
      rw [sum_comm];simp_rw [←mul_sum,row_abs_sub_id V hv]
    _ ≤ ∑ z, |(H-1) x z| *(2*b) := by
      apply sum_le_sum;intro z _;gcongr;exact hl z
    _ = (2*(1-H x x))*(2*b) := by rw [←sum_mul,row_abs_sub_id H hh]
    _ ≤ _ := by nlinarith [mul_le_mul_of_nonneg_right (hk x) hb]

/-- The result is vertical-first then horizontal. Only the final equality requires commutation. -/
theorem separated_powers (P H V : Matrix X X ℝ) (hp : Stochastic P)
    (hh : Stochastic H) (hv : Stochastic V) (hform : P=H+V-1) (comm : Commute V H)
    {a b : ℝ} (ha : 0≤a) (hvdiag : ∀ x,1-V x x≤b) (hhdiag : ∀ x,1-H x x≤a)
    (t : ℕ) (x : X) : tv ((P^t) x) ((V^t*H^t) x)≤(t:ℝ)*(2*a*b) := by
  have hf : P=V+H-1 := by rw [hform,add_comm H V]
  have h := power_error P (V*H) hp (stochastic_mul hv hh)
    (fun y => one_step P V H hv hh hf ha hvdiag hhdiag y) t x
  rw [comm.mul_pow] at h
  linarith

#print axioms power_error
#print axioms separated_powers
end LeafSplit
