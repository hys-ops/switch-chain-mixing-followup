import Roles
namespace Avoid
open OAI.Problem315 Finset TwoHub TwoHubUnequal
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

theorem perm_degree (sp : TwoHubUnequal.Spec n r s d a c) (σ : Equiv.Perm (Fin n))
    (ha : σ a=a) (hc : σ c=c) : ∀x,d (σ x)=d x := by
  intro x
  by_cases p : x=a
  · subst x;rw [ha]
  by_cases q : x=c
  · subst x;rw [hc]
  rw [sp.leaf x p q,sp.leaf (σ x) (fun e => p (σ.injective (e.trans ha.symm))) (fun e => q (σ.injective (e.trans hc.symm)))]

theorem good_perm (sp : TwoHubUnequal.Spec n r s d a c) (G₀ F G : GraphState n d) (K : Finset (Fin n))
    (h0 : marked a c G₀⊆K) (hf : good a c K F) (hg : good a c K G) :
    ∃ e : Equiv.Perm (GraphState n d), e G₀=G₀ ∧ e F=G ∧
      ∀X Y,switchKernel n d (e X) (e Y)=switchKernel n d X Y := by
  let T := insert a (insert c K)
  have ds (V : GraphState n d) (hv : good a c K V) :
      Disjoint T (star V.1 a c) ∧ Disjoint T (loose V.1 a c) ∧ Disjoint (star V.1 a c) (loose V.1 a c) := by
    have z : Disjoint T (marked a c V) := by
      apply disjoint_left.mpr;intro x hx hy
      have hn := marked_leaf V hy
      simp only [T,mem_insert] at hx
      rcases hx with h|h|h
      · exact hn.1 h
      · exact hn.2 h
      · exact disjoint_left.mp hv.2 h hy
    refine ⟨z.mono_right (subset_union_left),z.mono_right (subset_union_right),?_⟩
    apply disjoint_left.mpr;intro x h j
    exact ((mem_loose _ _ _ _).1 j).2.2.1 ((mem_star _ _ _ _).1 h).2
  have cardA (V : GraphState n d) (hv : good a c K V) : (star V.1 a c).card+1=r := by
    have h := star_size V.1 a c sp.distinct
    simpa [V.2 a,sp.first,hv.1] using h.symm
  obtain ⟨ga,gb,gab⟩ := ds G hg
  obtain ⟨fa,fb,fab⟩ := ds F hf
  obtain ⟨σ,hfix,hA,hB⟩ := three_sets ga gb gab fa fb fab
    (by have h:=cardA G hg;have j:=cardA F hf;omega)
    (by rw [TwoHubUnequal.loose_size sp G,TwoHubUnequal.loose_size sp F,ite_eq_left hg.1,ite_eq_left hf.1])
  have ha : σ a=a := hfix _ (by simp [T])
  have hc : σ c=c := hfix _ (by simp [T])
  let slow := perm_degree sp σ ha hc
  let e := LeafOrbit.labelEquiv σ slow
  have preserve (S : Finset (Fin n)) (hs : S⊆marked a c G₀) : ∀x, σ x∈S ↔ x∈S := by
    have hiden j (hj : j∈S) : σ j=j := hfix j (by exact mem_insert_of_mem (mem_insert_of_mem (h0 (hs hj))))
    intro x
    constructor
    · intro hx
      have he := σ.injective (hiden (σ x) hx)
      rwa [he] at hx
    · intro hx;rwa [hiden x hx]
  refine ⟨e,?_,?_,LeafOrbit.switchKernel_labelEquiv σ slow⟩
  · apply Subtype.ext
    ext x y
    exact transport sp G₀ G₀ σ ha hc Iff.rfl (preserve _ subset_union_left) (preserve _ subset_union_right) x y
  · apply Subtype.ext
    ext x y
    exact transport sp G F σ ha hc (iff_of_true hf.1 hg.1) hA hB x y

theorem pow_invariant (e : Equiv.Perm (GraphState n d))
    (hs : ∀G F,switchKernel n d (e G) (e F)=switchKernel n d G F) (t : ℕ) (G F : GraphState n d) :
    kernelPow n d t (e G) (e F)=kernelPow n d t G F := by
  induction t generalizing G F with
  | zero => simp [kernelPow]
  | succ t ih =>
    change (∑ K,kernelPow n d t (e G) K * switchKernel n d K (e F)) = ∑ K,kernelPow n d t G K * switchKernel n d K F
    rw [←Equiv.sum_comp e (fun K => kernelPow n d t (e G) K * switchKernel n d K (e F))]
    simp only [ih,hs]

theorem flat_good (sp : TwoHubUnequal.Spec n r s d a c) (G₀ : GraphState n d) (K : Finset (Fin n))
    (h0 : marked a c G₀⊆K) (t : ℕ) {F G : GraphState n d}
    (hf : good a c K F) (hg : good a c K G) : kernelPow n d t G₀ F=kernelPow n d t G₀ G := by
  obtain ⟨e,h,j,k⟩ := good_perm sp G₀ F G K h0 hf hg
  simpa only [h,j] using (pow_invariant e k t G₀ F).symm

#print axioms flat_good
end
end Avoid
