import FiniteLevy
import DenseModes
open Filter Topology MeasureTheory ProbabilityTheory Finset
namespace FiniteLevy
open HubDense HubTransfer JohnsonLower
noncomputable section

theorem gaussian_shift (m z : ℝ) : cdf (gaussianReal m 1) z=cdf (gaussianReal 0 1) (z-m) := by
  have h : (gaussianReal 0 1).map (fun x:ℝ=>x+m)=gaussianReal m 1 := by
    simpa using (gaussianReal_map_add_const (μ:=0) (v:=1) m)
  rw [cdf_eq_real,cdf_eq_real,←h,measureReal_def,Measure.map_apply (by fun_prop) measurableSet_Iic,measureReal_def]
  congr 2
  ext x;change x+m≤z ↔ x≤z-m;constructor <;> intro j <;> linarith

theorem standardized {N k : ℕ→ℕ} (K : ∀ i,Slice (N i) (k i))
    (w : (i:ℕ)→Slice (N i) (k i)→ℝ) (hw : ∀ i j,0≤w i j) (ht : ∀i,∑j,w i j=1)
    (m : ℝ)
    (hc : ∀θ:ℝ,Tendsto (fun i => ∑j,(w i j:ℂ)*
      Complex.exp ((θ*(score (K i) j):ℝ)*Complex.I))
      atTop (𝓝 (Complex.exp (θ*m*Complex.I)*(Real.exp (-(θ^2)/2):ℂ)))) (z : ℝ) :
    Tendsto (fun i => ∑j,if score (K i) j≤z then w i j else 0)
      atTop (𝓝 (cdf (gaussianReal 0 1) (z-m))) := by
  rw [←gaussian_shift m z]
  apply cdf_of_gaussian_char w (fun i => score (K i)) hw ht m _ z
  intro θ
  have h := hc θ
  simp only [sub_zero,Complex.ofReal_mul,Complex.ofReal_exp,Complex.ofReal_div,Complex.ofReal_neg,
    Complex.ofReal_pow,Complex.ofReal_ofNat,←Complex.exp_add] at h
  convert h using 2 <;> first | rfl | congr 2 <;> ring

theorem score_uniform {N k : ℕ→ℕ} (K : ∀i,Slice (N i) (k i))
    (hc : ∀θ:ℝ,Tendsto (fun i => ∑j,(unif _ j:ℂ)*Complex.exp ((θ*(score (K i) j):ℝ)*Complex.I))
       atTop (𝓝 ((Real.exp (-(θ^2)/2)):ℂ))) (z : ℝ) :
    Tendsto (fun i => ∑j,if score (K i) j≤z then unif _ j else 0) atTop (𝓝 (cdf (gaussianReal 0 1) z)) := by
  have hw (i : ℕ) : ∑j : Slice (N i) (k i),unif _ j=1 := by
    let : Nonempty (Slice (N i) (k i)) := ⟨K i⟩
    simp only [unif,sum_const,card_univ,nsmul_eq_mul,one_div]
    exact mul_inv_cancel₀ (by exact_mod_cast (Fintype.card_ne_zero : Fintype.card (Slice (N i) (k i))≠0))
  apply cdf_standard _ (fun i=>score (K i)) (fun i j=>by unfold unif;positivity) hw _ z
  intro θ
  simpa only [Complex.ofReal_mul,Complex.ofReal_exp,Complex.ofReal_div,Complex.ofReal_neg,Complex.ofReal_pow,
    Complex.ofReal_ofNat] using hc θ
#print axioms score_uniform
#print axioms standardized
end
end FiniteLevy
