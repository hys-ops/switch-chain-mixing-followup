import EdgeHazard
namespace LeafLower.Star
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
def n (h r : ℕ) := h+h*r
abbrev Side (h r : ℕ) := Fin h ⊕ (Fin h × Fin r)
def code (h r : ℕ) : Side h r ≃ Fin (n h r) := Fintype.equivOfCardEq (by change Fintype.card (Fin h ⊕ (Fin h × Fin r)) = Fintype.card (Fin (h+h*r)); simp only [Fintype.card_sum,Fintype.card_prod,Fintype.card_fin])
def hub {h r : ℕ} (i : Fin h) : Fin (n h r) := code h r (.inl i)
def embed (h r : ℕ) : (Fin h × Fin r) ↪ Fin (n h r) :=
  ⟨fun l => code h r (.inr l),fun _ _ e => Sum.inr.inj ((code h r).injective e)⟩
def embedAt {h : ℕ} (r : ℕ) (i : Fin h) : Fin r ↪ Fin (n h r) :=
  ⟨fun j => embed h r (i,j),fun _ _ e => congrArg Prod.snd ((embed h r).injective e)⟩
def L (h r : ℕ) := univ.map (embed h r)
def W {h : ℕ} (r : ℕ) (i : Fin h) := univ.map (embedAt r i)
def adj {h r : ℕ} : Side h r → Side h r → Prop
  | .inl i,.inr l => i=l.1
  | .inr l,.inl i => i=l.1
  | _,_ => False
private def weight {h r : ℕ} : Side h r → Side h r → ℕ
 | .inl i,.inr l => if i=l.1 then 1 else 0
 | .inr l,.inl i => if i=l.1 then 1 else 0
 | _,_ => 0
private theorem weight_eq {h r : ℕ} (x y : Side h r) : (if adj x y then 1 else 0)=weight x y := by
  cases x <;> cases y <;> unfold weight <;> split_ifs <;> simp_all [adj]
private theorem indicatorSum {h : ℕ} (i : Fin h) : (∑ x : Fin h, if i=x then 1 else (0:ℕ))=1 := by
  rw [sum_eq_single i]
  · simp
  · intro b _ hbi; exact ite_eq_right (Ne.symm hbi)
  · simp
private theorem indicatorSum' {h : ℕ} (i : Fin h) : (∑ x : Fin h, if x=i then 1 else (0:ℕ))=1 := by
  rw [sum_eq_single i]
  · simp
  · intro b _ hbi; exact ite_eq_right hbi
  · simp
def graph (h r : ℕ) : SimpleGraph (Fin (n h r)) where
  Adj u v := adj ((code h r).symm u) ((code h r).symm v)
  symm := ⟨by intro u v;generalize (code h r).symm u=x;generalize (code h r).symm v=y;cases x <;> cases y <;> simp [adj]⟩
  loopless := ⟨by intro u;generalize (code h r).symm u=x;cases x <;> simp [adj]⟩
def val {h r : ℕ} : Side h r → ℕ
  | .inl _ => r
  | .inr _ => 1
def deg (h r : ℕ) (v : Fin (n h r)) : ℕ := val ((code h r).symm v)
theorem degrees (h r : ℕ) : Realizes (n h r) (deg h r) (graph h r) := by
  intro u
  obtain ⟨x,rfl⟩ := (code h r).surjective u
  have hs := (code h r).sum_comp (fun v => if (graph h r).Adj (code h r x) v then 1 else (0:ℕ))
  change (univ.filter _).card = _
  have hf := (Finset.sum_boole (R:=ℕ) ((graph h r).Adj (code h r x)) univ)
  rw [Nat.cast_id] at hf;rw [←hf,←hs]
  have ew (y : Side h r) : (if (graph h r).Adj ((code h r) x) ((code h r) y) then 1 else 0)=weight x y := by
    by_cases ha : adj x y
    · have hb : (graph h r).Adj ((code h r) x) ((code h r) y) := by simpa [graph] using ha
      simpa only [ite_eq_left ha,ite_eq_left hb] using weight_eq x y
    · have hb : ¬(graph h r).Adj ((code h r) x) ((code h r) y) := by simpa [graph] using ha
      simpa only [ite_eq_right ha,ite_eq_right hb] using weight_eq x y
  simp only [ew,deg,Equiv.symm_apply_apply]
  cases x with
  | inl i =>
    simp only [Fintype.sum_sum_type,Fintype.sum_prod_type,weight,val,sum_const_zero,zero_add]
    rw [sum_comm];simp only [indicatorSum,sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one,Nat.cast_id]
  | inr l => simp [Fintype.sum_sum_type,weight,val]
def start (h r : ℕ) : State (n h r) (deg h r) := ⟨graph h r,degrees h r⟩
theorem total_mass (h r : ℕ) : mass (deg h r)=2*(h*r) := by
  unfold mass;rw [← (code h r).sum_comp]
  simp [deg,val,Fintype.sum_sum_type];ring
@[simp] theorem card_L (h r : ℕ) : (L h r).card=h*r := by simp [L]
@[simp] theorem card_W {h : ℕ} (r : ℕ) (i : Fin h) : (W r i).card=r := by simp [W]
theorem W_sub {h r : ℕ} (i : Fin h) : W r i⊆ L h r := by
  intro v hv;obtain ⟨j,_,rfl⟩:=mem_map.mp hv
  exact mem_map.mpr ⟨(i,j),mem_univ _,rfl⟩
theorem hub_not_mem {h r : ℕ} (i : Fin h) : hub i ∉ L h r := by
  intro he;obtain ⟨j,_,e⟩:=mem_map.mp he
  cases (code h r).injective e
theorem leaf_degree {h r : ℕ} {v} (hv : v ∈ L h r) : deg h r v=1 := by
  obtain ⟨j,_,rfl⟩:=mem_map.mp hv;change val ((code h r).symm (code h r (.inr j)))=1; rw [Equiv.symm_apply_apply];rfl
@[simp] theorem hub_degree {h r : ℕ} (i : Fin h) : deg h r (hub i)=r := by simp [deg,hub,val]
theorem start_z {h r : ℕ} (i : Fin h) : z (W r i) (hub i) (start h r)=r := by
  have he : marks (W r i) (hub i) (start h r)=W r i := by
    apply filter_eq_self.mpr;intro v hv;obtain ⟨j,_,rfl⟩ := mem_map.mp hv
    change adj ((code h r).symm (code h r (.inl i))) ((code h r).symm (code h r (.inr (i,j))))
    rw [Equiv.symm_apply_apply,Equiv.symm_apply_apply];rfl
  simp [z,he]
#print axioms start_z
#print axioms total_mass
end
end LeafLower.Star
