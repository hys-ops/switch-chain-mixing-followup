import OriginalAvoidance
namespace Avoid
open OAI.Problem315 TwoHubUnequal TwoHub Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

theorem separated_exists (sp : TwoHubUnequal.Spec n r s d a c) :
    ∃G : GraphState n d, ¬G.1.Adj a c := by
  let L := leaves a c
  have hL : L.card=r+s := by unfold L leaves;rw [card_sdiff_of_subset (subset_univ _)];simp [sp.distinct,sp.size]
  obtain ⟨A,hAL,hA⟩ := exists_subset_card_eq (s:=L) (n:=r) (by omega)
  let B := L \ A
  have hB : B.card=s := by unfold B;rw [card_sdiff_of_subset hAL,hL,hA];omega
  have h := sp.distinct
  have ar : a∉A := fun e => ((mem_leaves _ _ _).1 (hAL e)).1 rfl
  have cr : c∉A := fun e => ((mem_leaves _ _ _).1 (hAL e)).2 rfl
  have br : a∉B := fun e => ((mem_leaves _ _ _).1 (mem_sdiff.mp e).1).1 rfl
  have dr : c∉B := fun e => ((mem_leaves _ _ _).1 (mem_sdiff.mp e).1).2 rfl
  let S : SimpleGraph (Fin n) := {
    Adj := fun x y => (x=a ∧ y∈A) ∨ (y=a ∧ x∈A) ∨ (x=c ∧ y∈B) ∨ (y=c ∧ x∈B)
    symm := ⟨fun x y h => by tauto⟩
    loopless := ⟨fun x e => by
      rcases e with ⟨j,k⟩|⟨j,k⟩|⟨j,k⟩|⟨j,k⟩ <;> subst x <;> contradiction⟩ }
  have degree : ∀x,graphDegree S x=d x := by
    intro x
    by_cases xa : x=a
    · subst x;rw [sp.first,←hA];apply congrArg Finset.card
      ext y;simp [S,h,ar,br]
    by_cases xc : x=c
    · subst x;rw [sp.second,←hB];apply congrArg Finset.card
      ext y;simp [S,h.symm,cr,dr]
    have hl := (mem_leaves _ _ _).2 ⟨xa,xc⟩
    rw [sp.leaf _ xa xc]
    by_cases xx : x∈A
    · have xb : x∉B := fun e => (mem_sdiff.mp e).2 xx
      apply card_eq_one.mpr;refine ⟨a,?_⟩;ext y;simp [S,xa,xc,xx,xb]
    · have xb : x∈B := mem_sdiff.mpr ⟨hl,xx⟩
      apply card_eq_one.mpr;refine ⟨c,?_⟩;ext y;simp [S,xa,xc,xx,xb]
  refine ⟨⟨S,degree⟩,?_⟩
  change ¬S.Adj a c;simp [S,h,ar,cr,br,dr]

theorem connected_exists (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) (hr : 0<r) (hs : 0<s) :
    ∃G : GraphState n d, G.1.Adj a c := by
  obtain ⟨G,hg⟩ := separated_exists sp
  have h := TwoHubUnequal.A_to_B sp G hg
  by_contra! he
  simp [he] at h
  have hc := clock_pos (n:=n) hn
  unfold clock at hc
  have hh : 0<((r:ℝ)*s)/(12*(n.choose 4:ℝ)) := by positivity
  linarith

theorem same_stratum (sp : TwoHubUnequal.Spec n r s d a c) (G F : GraphState n d)
    (hh : F.1.Adj a c ↔ G.1.Adj a c) (t : ℕ) :
    tvDistanceFrom n d t F=tvDistanceFrom n d t G := by
  let T : Finset (Fin n) := {a,c}
  have ds (V : GraphState n d) :
      Disjoint T (star V.1 a c) ∧ Disjoint T (loose V.1 a c) ∧ Disjoint (star V.1 a c) (loose V.1 a c) := by
    have z : Disjoint T (marked a c V) := by
      apply disjoint_left.mpr;intro x hx hy
      have hn := marked_leaf V hy
      simp [T] at hx;tauto
    refine ⟨z.mono_right subset_union_left,z.mono_right subset_union_right,?_⟩
    apply disjoint_left.mpr;intro x h j
    exact ((mem_loose _ _ _ _).1 j).2.2.1 ((mem_star _ _ _ _).1 h).2
  have hsize (V : GraphState n d) := star_size V.1 a c sp.distinct
  obtain ⟨ga,gb,gab⟩ := ds G
  obtain ⟨fa,fb,fab⟩ := ds F
  obtain ⟨σ,hfix,hA,hB⟩ := three_sets ga gb gab fa fb fab
    (by have h:=hsize G;have j:=hsize F;rw [G.2,sp.first] at h;rw [F.2,sp.first,propext hh] at j;omega)
    (by rw [TwoHubUnequal.loose_size sp G,TwoHubUnequal.loose_size sp F,propext hh])
  have ha : σ a=a := hfix _ (by simp [T])
  have hc : σ c=c := hfix _ (by simp [T])
  let slow := perm_degree sp σ ha hc
  let e := LeafOrbit.labelEquiv σ slow
  have he : e F=G := by apply Subtype.ext;ext x y;exact transport sp G F σ ha hc hh hA hB x y
  have hpow := pow_invariant e (LeafOrbit.switchKernel_labelEquiv σ slow) t F
  rw [←he];unfold tvDistanceFrom allGraphStates
  congr 1
  rw [←Equiv.sum_comp e (fun Y => |kernelPow n d t (e F) Y-1/(stateCount n d:ℝ)|)]
  simp only [hpow]

def worstTV (sp : TwoHubUnequal.Spec n r s d a c) (t : ℕ) : ℝ :=
  univ.sup' (show (univ : Finset (GraphState n d)).Nonempty from
    (separated_exists sp).elim (fun G _ => ⟨G,mem_univ _⟩)) (tvDistanceFrom n d t)

theorem worst_eq (sp : TwoHubUnequal.Spec n r s d a c) (t : ℕ) (E V : GraphState n d)
    (he : E.1.Adj a c) (hv : ¬V.1.Adj a c) :
    worstTV sp t = max (tvDistanceFrom n d t E) (tvDistanceFrom n d t V) := by
  apply le_antisymm
  · apply sup'_le;intro G _
    by_cases h : G.1.Adj a c
    · rw [same_stratum sp E G (iff_of_true h he) t];exact le_max_left _ _
    · rw [same_stratum sp V G (iff_of_false h hv) t];exact le_max_right _ _
  · exact max_le (le_sup' _ (mem_univ E)) (le_sup' _ (mem_univ V))
#print axioms worst_eq
#print axioms connected_exists
end
end Avoid
