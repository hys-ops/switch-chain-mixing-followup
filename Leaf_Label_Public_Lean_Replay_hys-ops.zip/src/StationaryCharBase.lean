import StationaryStein
import DenseGenerator
import Mathlib.Analysis.SpecialFunctions.ExpDeriv

open Finset HubTransfer HubDense JohnsonLower
noncomputable section
namespace StationaryUrn
variable {N k : ℕ}

def cmean (K : Slice N k) (f : ℕ→ℂ) : ℂ :=
  ∑ S:Slice N k,(unif (Slice N k) S:ℂ)*f (HubMarks.overlap K S)
def phase (x θ : ℝ) := Complex.exp ((θ*x:ℝ)*Complex.I)
def char (K : Slice N k) (θ : ℝ) := cmean K (fun x => phase (standard N k x) θ)

@[simp] theorem phase_norm (x θ : ℝ) : ‖phase x θ‖=1 := Complex.norm_exp_ofReal_mul_I _
theorem cmean_mul (K : Slice N k) (a : ℂ) (f : ℕ→ℂ) :
    cmean K (fun x=>a*f x)=a*cmean K f := by
  unfold cmean; rw [mul_sum]; exact sum_congr rfl (fun _ _ => by ring)
theorem cmean_sub (K : Slice N k) (f g : ℕ→ℂ) :
    cmean K (fun i=>f i-g i)=cmean K f-cmean K g := by simp [cmean,mul_sub,sum_sub_distrib]
theorem cmean_norm (K : Slice N k) (f : ℕ→ℂ) : ‖cmean K f‖ ≤ mean K (fun x=>‖f x‖) := by
  apply (norm_sum_le _ _).trans_eq
  unfold mean
  exact sum_congr rfl (fun S _ => by simp [norm_mul,Real.norm_eq_abs,abs_of_nonneg (show 0≤unif (Slice N k) S by unfold unif;positivity)])
theorem cmean_const (K : Slice N k) (a : ℂ) : cmean K (fun _=>a)=a := by
  have h := mean_const K 1
  simp only [mean,mul_one] at h
  simp only [cmean,← sum_mul,← Complex.ofReal_sum,h,Complex.ofReal_one,one_mul]
theorem char_zero (K : Slice N k) : char K 0=1 := by simp [char,phase,cmean_const]
theorem char_deriv (K : Slice N k) (t : ℝ) :
    HasDerivAt (char K) (Complex.I*cmean K (fun x=>(standard N k x:ℂ)*phase (standard N k x) t)) t := by
  let z (S : Slice N k) := standard N k (HubMarks.overlap K S)
  let f (S : Slice N k) (u:ℝ) := (unif (Slice N k) S:ℂ)*phase (z S) u
  have hd (S : Slice N k) : HasDerivAt (f S) ((unif _ S:ℂ)*((Complex.I*(z S:ℂ))*phase (z S) t)) t := by
    have h1 := (Complex.ofRealCLM.hasFDerivAt.hasDerivAt (x:=t)).mul_const ((z S:ℂ)*Complex.I)
    have h2 := h1.cexp
    change HasDerivAt (fun u:ℝ => (unif _ S:ℂ)*Complex.exp ((u*(z S):ℝ)*Complex.I)) _ t
    simpa [phase, mul_assoc, mul_comm, mul_left_comm] using h2.const_mul (unif _ S:ℂ)
  have HH := HasDerivAt.fun_sum (u:=Finset.univ) (fun S _ => hd S)
  convert HH using 1
  · rfl
  unfold cmean; rw [mul_sum]; exact sum_congr rfl (fun _ _ => by dsimp [z];ring)

theorem complex_stein (K : Slice N k) (hN : 0<N) (f : ℕ→ℂ) :
    cmean K (fun x=>(loc N k x:ℂ)*f x) =
      cmean K (fun x=>(SparseUrn.birth N k x:ℂ)*(f (x+1)-f x)) := by
  apply Complex.ext
  · simpa [cmean,Complex.re_sum,Complex.mul_re,mean] using stein K hN (fun x => (f x).re)
  · simpa [cmean,Complex.im_sum,Complex.mul_im,mean] using stein K hN (fun x => (f x).im)

def coeff (N k : ℕ) (x : ℕ) := SparseUrn.birth N k x/(sig N k)^2

theorem scale_relation (hN : 1<N) :
    (k:ℝ)-(k:ℝ)^2/N=Real.sqrt ((N:ℝ)-1)*sig N k := by
  have h1 : (0:ℝ)<N-1 := by exact_mod_cast (show (1:ℝ)<N by exact_mod_cast hN) |> sub_pos.mpr
  have hn : (N:ℝ)≠0 := by linarith
  unfold sig;field_simp [(Real.sqrt_pos.mpr h1).ne',hn]

theorem standardized_moments (K : Slice N k) (hN : 1<N) (hk : 0<k) (hkN : k<N) :
    mean K (fun x=>standard N k x)=0 ∧ mean K (fun x=>(standard N k x)^2)=1 := by
  have hs := sigma_pos (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast hN) (by exact_mod_cast hk) (by exact_mod_cast hkN)
  have hn' : (1:ℝ)<N := by exact_mod_cast hN
  have hv := centered_variance K hN
  rw [scale_relation hN,mul_pow,Real.sq_sqrt (by linarith)] at hv
  have hN1 : (N:ℝ)-1≠0 := by linarith
  field_simp at hv
  constructor
  · change mean K (fun x => loc N k x/sig N k)=0
    simp only [div_eq_inv_mul,mean_mul,mean_center K (by omega),mul_zero]
  · change mean K (fun x=>(loc N k x/sig N k)^2)=1
    simp only [div_eq_inv_mul,mul_pow,mean_mul,hv,inv_pow]
    exact inv_mul_cancel₀ (pow_ne_zero _ hs.ne')

theorem coeff_form (hN : 1<N) (hk : 0<k) (hkN : k<N) (x : ℕ) :
    coeff N k x=(Real.sqrt ((N:ℝ)-1)-standard N k x)^2/N := by
  have hs := sigma_pos (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast hN) (by exact_mod_cast hk) (by exact_mod_cast hkN)
  have h := scale_relation (k:=k) hN
  have H : (k:ℝ)-x = Real.sqrt ((N:ℝ)-1)*sig N k-standard N k x*sig N k := by
    unfold standard mu; rw [div_mul_cancel₀ _ hs.ne'];linarith
  unfold coeff SparseUrn.birth
  rw [H];field_simp

#print axioms char_deriv
#print axioms complex_stein
#print axioms standardized_moments
end StationaryUrn
