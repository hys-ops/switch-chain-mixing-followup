import StationaryCharBase
open Finset HubTransfer HubDense JohnsonLower
noncomputable section
namespace StationaryUrn
variable {N k : ℕ}
def noise (N : ℕ) : ℝ := (2+2*Real.sqrt ((N:ℝ)-1))/N

theorem coeff_nonneg (x : ℕ) : 0≤coeff N k x := by unfold coeff SparseUrn.birth; positivity

theorem coeff_moments (K : Slice N k) (hN : 1<N) (hk : 0<k) (hkN : k<N) :
    mean K (coeff N k)=1 ∧ mean K (fun x => |1-coeff N k x|) ≤ noise N := by
  let z := fun x:ℕ => standard N k x
  let a := Real.sqrt ((N:ℝ)-1)
  have hn : (1:ℝ)<N := by exact_mod_cast hN
  have posN : (0:ℝ)<N := by linarith
  have ha : 0≤a := Real.sqrt_nonneg _
  have ha2 : a^2=(N:ℝ)-1 := Real.sq_sqrt (by linarith)
  obtain ⟨m,v⟩ := standardized_moments K hN hk hkN
  change mean K z=0 at m
  change mean K (fun x=>z x^2)=1 at v
  have form (x:ℕ) : coeff N k x=(1/(N:ℝ))*(a^2+(-2*a)*z x+z x^2) := by
    rw [coeff_form hN hk hkN];dsimp [a,z];ring
  have meanAbs : mean K (fun x=>|z x|) ≤ 1 := calc
    _ ≤ mean K (fun x => (1/2:ℝ)+(1/2:ℝ)*z x^2) := mean_le K (fun x => by nlinarith [sq_nonneg (|z x|-1),sq_abs (z x)])
    _ = 1 := by rw [mean_add,mean_mul,mean_const,v];ring
  constructor
  · simp only [show coeff N k=_ from funext form,mean_mul,mean_add,mean_const,m,v,mul_zero,add_zero,ha2]
    field_simp;ring
  · have hh (x:ℕ) : |1-coeff N k x| ≤ (1/(N:ℝ))*(1+2*a*|z x|+z x^2) := by
      have eqn : 1-coeff N k x=(1/(N:ℝ))*(1+2*a*z x-z x^2) := by
        rw [form,ha2]; field_simp; ring
      rw [eqn,abs_mul,abs_of_pos (by positivity : 0<1/(N:ℝ))]
      apply mul_le_mul_of_nonneg_left _ (by positivity)
      apply abs_le.mpr
      constructor
      · nlinarith [mul_nonneg ha (show 0≤|z x|+z x by linarith [neg_abs_le (z x)])]
      · nlinarith [mul_nonneg ha (sub_nonneg.mpr (le_abs_self (z x))),sq_nonneg (z x)]
    apply (mean_le K hh).trans
    simp only [mean_mul,mean_add,mean_const,v]
    unfold noise
    change 1/(N:ℝ)*(1+(2*a)*mean K (fun x=>|z x|)+1) ≤ (2+2*a)/N
    calc
      _ ≤ 1/(N:ℝ)*(1+(2*a)*1+1) := by gcongr
      _ = _ := by ring

#print axioms coeff_moments
end StationaryUrn
