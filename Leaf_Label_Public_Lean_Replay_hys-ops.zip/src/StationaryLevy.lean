import StandardScore
import StationaryCharBase
open Filter Topology Finset MeasureTheory ProbabilityTheory
namespace FiniteLevy
open HubDense HubTransfer JohnsonLower
noncomputable section

theorem equilibrium_of_char {N k : ℕ→ℕ} (K : ∀ i, Slice (N i) (k i))
    (hc : ∀θ : ℝ,Tendsto (fun i=>StationaryUrn.char (K i) θ) atTop (𝓝 (Real.exp (-(θ^2)/2):ℂ))) (x : ℝ) :
    Tendsto (fun i=>∑ S : Slice (N i) (k i),if standard (N i) (k i) (HubMarks.overlap (K i) S)≤x then unif _ S else 0)
      atTop (𝓝 (cdf (gaussianReal 0 1) x)) :=
  score_uniform K hc x

#print axioms equilibrium_of_char
end
end FiniteLevy
