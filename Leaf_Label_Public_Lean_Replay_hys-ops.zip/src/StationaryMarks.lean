import Stabilizer
namespace Avoid
open OAI.Problem315 Finset TwoHub TwoHubUnequal
open scoped BigOperators
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def markTotal (d : Fin n→ℕ) (a c x : Fin n) : ℕ := ∑ G : GraphState n d, if x∈marked a c G then 1 else 0

theorem mark_exchange (sp : TwoHubUnequal.Spec n r s d a c) {x y : Fin n}
    (hx : x∈leaves a c) (hy : y∈leaves a c) : markTotal d a c x=markTotal d a c y := by
  obtain ⟨xa,xc⟩ := (mem_leaves _ _ _).1 hx
  obtain ⟨ya,yc⟩ := (mem_leaves _ _ _).1 hy
  let σ := Equiv.swap x y
  have hσa : σ a=a := Equiv.swap_apply_of_ne_of_ne xa.symm ya.symm
  have hσc : σ c=c := Equiv.swap_apply_of_ne_of_ne xc.symm yc.symm
  let e := LeafOrbit.labelEquiv σ (perm_degree sp σ hσa hσc)
  have M (G : GraphState n d) : x∈marked a c (e G) ↔ y∈marked a c G := by
    rw [marked_of_leaf sp (e G) xa xc,marked_of_leaf sp G ya yc]
    change (¬G.1.Adj (σ c) (σ x)) ↔ ¬G.1.Adj c y
    rw [hσc,show σ x=y from Equiv.swap_apply_left _ _]
  have h := Equiv.sum_comp e (fun G => if x∈marked a c G then (1:ℕ) else 0)
  simpa only [markTotal,M] using h.symm

theorem expected_hits (sp : TwoHubUnequal.Spec n r s d a c) (K : Finset (Fin n))
    (hK : K⊆leaves a c) (hN : 0<r+s) (G₀ : GraphState n d) :
    uniformAverage n d (fun G => ((K ∩ marked a c G).card:ℝ)) ≤ (K.card:ℝ)*(r+1)/(r+s) := by
  let L := leaves a c
  have hc : L.card = r+s := by
    unfold L leaves;rw [card_sdiff_of_subset (subset_univ _)];simp [sp.distinct,sp.size]
  obtain ⟨v,hv⟩ := card_pos.mp (hc.symm ▸ hN)
  let k := markTotal d a c v
  let z := Fintype.card (GraphState n d)
  have hm (S : Finset (Fin n)) (hs : S⊆L) :
      (∑G : GraphState n d, (S∩marked a c G).card)=S.card*k := by
    have he (G : GraphState n d) : (S∩marked a c G).card = ∑ i∈S,if i∈marked a c G then 1 else 0 := by
      simp [filter_mem_eq_inter]
    simp_rw [he];rw [sum_comm]
    calc
      _ = ∑ _i∈S,k := sum_congr rfl fun i hi => mark_exchange sp (hs hi) hv
      _ = _ := by simp
  have hs : L.card*k≤z*(r+1) := by
    rw [←hm L (by rfl)]
    calc
      _ ≤ ∑ _G : GraphState n d,(r+1) := by
        apply sum_le_sum;intro G _
        apply (card_le_card (inter_subset_right (s₁:=L))).trans
        rw [marked_card sp G];split <;> omega
      _ = _ := by simp [z]
  rw [hc] at hs
  have A : (∑ G : GraphState n d,((K∩marked a c G).card:ℝ)) = (K.card:ℝ)*k := by exact_mod_cast hm K hK
  have B : ((r:ℝ)+s)*k≤(z:ℝ)*(r+1) := by exact_mod_cast hs
  have hz : (0:ℝ)<z := by exact_mod_cast (Fintype.card_pos_iff.mpr ⟨G₀⟩)
  have hN' : (0:ℝ)<r+s := by exact_mod_cast hN
  change (∑ G : GraphState n d,((K∩marked a c G).card:ℝ))/(z:ℝ)≤_
  rw [A,div_le_div_iff₀ hz hN']
  nlinarith only [mul_le_mul_of_nonneg_left B (Nat.cast_nonneg (α:=ℝ) K.card)]

def goodSet (a c : Fin n) (K : Finset (Fin n)) (d : Fin n→ℕ) := univ.filter (good (d:=d) a c K)

theorem failure_mass (sp : TwoHubUnequal.Spec n r s d a c) (K : Finset (Fin n)) (hK : K⊆leaves a c)
    (hN : 0<r+s) (hn : 4≤n) (G₀ : GraphState n d) :
    1-(∑ _G∈goodSet a c K d,(1:ℝ)/(stateCount n d:ℝ)) ≤
      stationary r s+(K.card:ℝ)*(r+1)/(r+s) := by
  let z : ℝ := stateCount n d
  have hz : 0<z := by
    change 0<((univ : Finset (GraphState n d)).card:ℝ)
    exact_mod_cast (card_pos.mpr ⟨G₀,mem_univ _⟩ : 0<(univ : Finset (GraphState n d)).card)
  have hnon (G : GraphState n d) : (if good a c K G then (0:ℝ) else 1) ≤
      vertex a c G + ((K∩marked a c G).card:ℝ) := by
    by_cases he : G.1.Adj a c <;> by_cases hd : Disjoint K (marked a c G)
    all_goals simp only [good,he,hd,true_and,false_and,ite_true,ite_false,vertex,zero_add]
    all_goals try positivity
    all_goals try linarith [Nat.cast_nonneg (α:=ℝ) ((K∩marked a c G).card)]
    have hp : 0<(K∩marked a c G).card := card_pos.mpr (not_disjoint_iff_nonempty_inter.mp hd)
    exact_mod_cast (show 1≤(K∩marked a c G).card by omega)
  have hm := div_le_div_of_nonneg_right (sum_le_sum (s:=univ) fun G _ => hnon G) hz.le
  rw [sum_add_distrib,add_div] at hm
  have hshape := graph_shape_stationary sp hn G₀
  have hhit := expected_hits sp K hK hN G₀
  change (∑G,vertex a c G)/z=stationary r s at hshape
  change (∑G,((K∩marked a c G).card:ℝ))/z≤_ at hhit
  rw [hshape] at hm
  have hsum : (∑ G : GraphState n d,(1:ℝ)) / z = 1 := by
    change _ / (stateCount n d:ℝ)=1
    have he : Fintype.card (GraphState n d)≠0 := (Fintype.card_pos_iff.mpr ⟨G₀⟩).ne'
    simp [stateCount,allGraphStates,he]
  have e : (∑ G : GraphState n d,if good a c K G then (0:ℝ) else 1)/z =
      1-(∑ _G∈goodSet a c K d,(1:ℝ)/(stateCount n d:ℝ)) := by
    conv_rhs => lhs; rw [←hsum]
    unfold goodSet;rw [sum_filter]
    have hf (G : GraphState n d) : (if good a c K G then (1:ℝ)/(stateCount n d:ℝ) else 0) = (if good a c K G then 1 else 0)/z := by split_ifs <;> simp [z]
    simp_rw [hf,←sum_div]
    rw [←sub_div,←sum_sub_distrib]
    apply congrArg (·/z);apply sum_congr rfl;intro G _;split_ifs <;> norm_num
  rw [e] at hm;linarith
#print axioms failure_mass
end
end Avoid
