import StationaryCoefficient
open Finset HubTransfer HubDense JohnsonLower
noncomputable section
namespace StationaryUrn
variable {N k : ℕ}
def derivative (K : Slice N k) (t : ℝ) : ℂ :=
  Complex.I*cmean K (fun x=>(standard N k x:ℂ)*phase (standard N k x) t)

theorem residual (K : Slice N k) (hN : 1<N) (hk : 0<k) (hkN : k<N)
    (t : ℝ) (ht : |t|≤sig N k) :
    ‖derivative K t+(t:ℂ)*char K t‖ ≤ t^2/sig N k+|t| *noise N := by
  let s := sig N k
  have hs : 0<s := sigma_pos (N:=(N:ℝ)) (k:=(k:ℝ)) (by exact_mod_cast hN) (by exact_mod_cast hk) (by exact_mod_cast hkN)
  have hsc : (s:ℂ)≠0 := by exact_mod_cast hs.ne'
  let z := fun x:ℕ => standard N k x
  let f := fun x:ℕ => phase (z x) t
  let u : ℂ := (t:ℂ)/s*Complex.I
  let a := cmean K (fun x => (coeff N k x:ℂ)*f x)
  have hn (x:ℕ) : ‖f x‖=1 := phase_norm _ _
  have h := coeff_moments K hN hk hkN
  have ha : ‖a‖ ≤ 1 := calc
    _ ≤ mean K (fun x=> ‖(coeff N k x:ℂ)*f x‖) := cmean_norm _ _
    _ = 1 := by simpa only [norm_mul,hn,mul_one,Complex.norm_real,Real.norm_eq_abs,abs_of_nonneg (coeff_nonneg _)] using h.1
  have had : ‖char K t-a‖ ≤ noise N := by
    change ‖cmean K f-cmean K (fun x=>(coeff N k x:ℂ)*f x)‖≤_
    rw [←cmean_sub]
    apply (cmean_norm _ _).trans
    simpa only [←one_sub_mul,norm_mul,hn,mul_one,←Complex.ofReal_one,←Complex.ofReal_sub,Complex.norm_real,Real.norm_eq_abs] using h.2
  have fnext (x:ℕ) : f (x+1)= f x * Complex.exp u := by
    simp only [f,phase,←Complex.exp_add]
    congr 1
    simp only [z,standard,Nat.cast_add,Nat.cast_one,Complex.ofReal_mul,Complex.ofReal_div,Complex.ofReal_sub,Complex.ofReal_natCast]
    dsimp [u,s];push_cast; ring
  have hstein := complex_stein K (by omega) f
  have hz (x:ℕ) : (loc N k x:ℂ)*f x=(s:ℂ)*((z x:ℂ)*f x) := by
    dsimp [z,standard,s,mu,loc]; push_cast
    change _= (s:ℂ)*(((x:ℂ)-k^2/N)/s * f x)
    field_simp
  have hb (x:ℕ) : (SparseUrn.birth N k x:ℂ)*(f (x+1)-f x) =
      ((s:ℂ)^2*(Complex.exp u-1))*((coeff N k x:ℂ)*f x) := by
    rw [fnext];unfold coeff;push_cast
    change _=_*((↑(SparseUrn.birth N k x)/(s:ℂ)^2)*f x)
    field_simp
  simp only [hz,hb,cmean_mul] at hstein
  change (s:ℂ)*cmean K (fun x=>(z x:ℂ)*f x)=(s^2*(Complex.exp u-1))*a at hstein
  have hd : derivative K t=Complex.I*s*(Complex.exp u-1)*a := by
    change Complex.I*cmean K (fun x=>(z x:ℂ)*f x)=_
    apply mul_left_cancel₀ hsc
    linear_combination Complex.I * hstein
  have eqn : derivative K t+(t:ℂ)*char K t =
      Complex.I*s*(Complex.exp u-1-u)*a+(t:ℂ)*(char K t-a) := by
    rw [hd];dsimp [u];field_simp;linear_combination t*a*(Complex.I_mul_I)
  have hu : ‖u‖=|t|/s := by simp [u,norm_mul,norm_div,Real.norm_eq_abs,abs_of_pos hs]
  have hut : ‖u‖≤1 := by rw [hu]; exact (div_le_one hs).mpr ht
  rw [eqn]
  apply (norm_add_le _ _).trans
  simp only [norm_mul,Complex.norm_I,one_mul,Complex.norm_real,Real.norm_eq_abs,abs_of_pos hs]
  calc
    _ ≤ s * (|t|/s)^2 * 1 + |t| *noise N := by
      gcongr
      · exact (Complex.norm_exp_sub_one_sub_id_le hut).trans_eq (by rw [hu])
    _ = _ := by change _=t^2/s + |t| *noise N; rw [div_pow,sq_abs];field_simp

#print axioms residual
end StationaryUrn
