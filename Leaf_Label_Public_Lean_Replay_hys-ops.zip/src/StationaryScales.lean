import StationaryResidual
import DenseClock
open Filter Topology UrnWindow HubDense
noncomputable section
namespace StationaryUrn
theorem dense_sizes (g : Degrees) (i : ℕ) :
    1<g.population i ∧ 0<g.r i-1 ∧ g.r i-1<g.population i ∧ ((g.r i-1:ℕ):ℝ)=g.k i := by
  have hr := g.two i
  have hs := g.small i
  simp only [Degrees.population,Degrees.k]
  exact ⟨by omega,by omega,by omega,by rw [Nat.cast_sub (by omega)];norm_num⟩

theorem sd_infty (g : Degrees) (dense : Tendsto g.ratio atTop atTop) :
    Tendsto (fun i=>sig (g.population i) (g.r i-1:ℕ)) atTop atTop := by
  apply tendsto_atTop_mono (f:=fun i=>g.ratio i/2) _ (dense.atTop_div_const (by norm_num : (0:ℝ)<2))
  intro i
  obtain ⟨hr,hs,hn,he⟩ := g.sizes i
  rw [(dense_sizes g i).2.2.2]
  have h := sigma_ge (show 2≤g.N i by linarith) (show 0≤g.k i by dsimp [Degrees.k];linarith)
    (show 2*g.k i≤g.N i by dsimp [Degrees.k];linarith)
  convert h using 1
  unfold Degrees.ratio;ring

theorem noise_zero (g : Degrees) : Tendsto (fun i=>noise (g.population i)) atTop (𝓝 0) := by
  have h := (tendsto_const_nhds (x:=(2:ℝ))).div_atTop g.N_infty
  have h' := (tendsto_const_nhds (x:=(2:ℝ))).div_atTop (sqrt_grows g)
  apply squeeze_zero (fun i => by unfold noise;positivity) _ (by simpa using h.add h')
  intro i
  have hn : 0<g.N i := by linarith [(g.sizes i).2.2.1]
  have hs := Real.sqrt_pos.mpr hn
  have H := Real.sqrt_le_sqrt (show g.N i-1≤g.N i by linarith)
  change (2+2*Real.sqrt (g.N i-1))/(g.N i)≤2/g.N i+2/Real.sqrt (g.N i)
  rw [add_div];apply add_le_add_right
  rw [div_le_div_iff₀ hn hs]
  nlinarith [mul_nonneg hs.le (sub_nonneg.mpr H),Real.sq_sqrt hn.le]

#print axioms sd_infty
#print axioms noise_zero
end StationaryUrn
