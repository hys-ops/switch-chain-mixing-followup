import OverlapStep
import JohnsonTV

open Finset HubTransfer LeafDrift JohnsonLower
open scoped Matrix
noncomputable section
namespace StationaryUrn
variable {N k : ℕ}
def mean (K : Slice N k) (f : ℕ→ℝ) : ℝ :=
  ∑ T : Slice N k,unif (Slice N k) T * f (HubMarks.overlap K T)

theorem mean_const (K : Slice N k) (a : ℝ) : mean K (fun _=>a)=a := by
  letI : Nonempty (Slice N k) := ⟨K⟩
  have hp : (Fintype.card (Slice N k):ℝ)≠0 := by exact_mod_cast Fintype.card_pos.ne'
  simp only [mean,unif,sum_const,card_univ,nsmul_eq_mul,one_div,←mul_assoc,mul_inv_cancel₀ hp,one_mul]
theorem mean_add (K : Slice N k) (f g : ℕ→ℝ) :
    mean K (fun i=>f i+g i)=mean K f+mean K g := by simp [mean,mul_add,sum_add_distrib]
theorem mean_sub (K : Slice N k) (f g : ℕ→ℝ) :
    mean K (fun i=>f i-g i)=mean K f-mean K g := by simp [mean,mul_sub,sum_sub_distrib]
theorem mean_mul (K : Slice N k) (a : ℝ) (f : ℕ→ℝ) :
    mean K (fun i=>a*f i)=a*mean K f := by
  unfold mean;rw [mul_sum];exact sum_congr rfl (fun _ _ => by ring)
theorem mean_nonneg (K : Slice N k) (f : ℕ→ℝ) (hf : ∀i,0≤f i) : 0≤mean K f :=
  sum_nonneg (fun T _ => mul_nonneg (by unfold unif;positivity) (hf _))
theorem mean_le (K : Slice N k) {f g : ℕ→ℝ} (h : ∀i,f i≤g i) : mean K f ≤ mean K g :=
  sum_le_sum (fun T _ => mul_le_mul_of_nonneg_left (h _) (by unfold unif;positivity))

/-- Stationarity of the actual uniform slice law tested at its actual overlap. -/
theorem stationarity (K : Slice N k) (hN : 0<N) (f : ℕ→ℝ) :
    mean K (SparseUrn.generator N k f)=0 := by
  let Q : ℝ := (N:ℝ)^2+1
  have hk : k≤N := by simpa [K.2] using Finset.card_le_univ K.val
  have hq : 0<Q := by dsimp [Q];positivity
  have cap : (k:ℝ)*(N-k)≤Q := by
    dsimp [Q]
    have hkn : (k:ℝ)≤N := by exact_mod_cast hk
    nlinarith [mul_nonneg (Nat.cast_nonneg (α:=ℝ) N) (sub_nonneg.mpr hkn),sq_nonneg (k:ℝ)]
  have h := unif_stationary (N:=N) (s:=k) hq cap (fun S => f (HubMarks.overlap K S))
  change (∑ S:Slice N k,unif _ S * ((HubMarks.walk N k Q *ᵥ fun T => f (HubMarks.overlap K T)) S))=mean K f at h
  simp_rw [HubMarks.overlap_row K _ Q hN hq.ne' f] at h
  change mean K (fun z => f z + (N:ℝ)/Q*SparseUrn.generator N k f z)=_ at h
  rw [mean_add,mean_mul] at h
  have hr : (0:ℝ)< (N:ℝ)/Q := div_pos (by exact_mod_cast hN) hq
  nlinarith

def loc (N k : ℕ) (x : ℕ) : ℝ := x-(k:ℝ)^2/N

/-- Discrete integration by parts. The forward difference is weighted by
the exact squared vacancy count, even at the lower endpoint. -/
theorem stein (K : Slice N k) (hN : 0<N) (f : ℕ→ℝ) :
    mean K (fun x=>loc N k x*f x) =
      mean K (fun x => SparseUrn.birth N k x*(f (x+1)-f x)) := by
  let F := fun x:ℕ => ∑ j∈range x,f (j+1)
  have gen (x:ℕ) : SparseUrn.generator N k F x =
      SparseUrn.birth N k x*(f (x+1)-f x)-loc N k x * f x := by
    have hn : (N:ℝ)≠0 := by exact_mod_cast hN.ne'
    cases x with
    | zero =>
      simp [SparseUrn.generator,SparseUrn.birth,SparseUrn.death,loc,F]
      ring
    | succ x =>
      have hplus : F (x+1+1)-F (x+1)=f (x+1+1) := by simp [F,sum_range_succ]
      have hminus : F ((x+1)-1)-F (x+1)= -f (x+1) := by simp [F,sum_range_succ]
      rw [SparseUrn.generator,hplus,hminus]
      unfold SparseUrn.death SparseUrn.birth loc
      push_cast; field_simp;ring
  have h := stationarity K hN F
  rw [show (SparseUrn.generator N k F)=_ from funext gen,mean_sub] at h
  linarith

theorem mean_center (K : Slice N k) (hN : 0<N) : mean K (loc N k)=0 := by
  have h := stein K hN (fun _ => 1)
  simpa [mean] using h

theorem centered_variance (K : Slice N k) (hN : 1<N) :
    mean K (fun x => (loc N k x)^2)=((k:ℝ)-(k:ℝ)^2/N)^2/(N-1) := by
  have hn : 0<N := by omega
  have hn' : (N:ℝ)≠0 := by exact_mod_cast hn.ne'
  have hN' : (1:ℝ)<N := by exact_mod_cast hN
  let m : ℝ := (k:ℝ)^2/N
  let z := loc N k
  have b (x:ℕ) : SparseUrn.birth N k x =
      (1/(N:ℝ))*(((k:ℝ)-m)^2 + (-2*((k:ℝ)-m))*z x + (z x)^2) := by
    simp only [SparseUrn.birth,m,z,loc];ring
  have hd (x:ℕ) : z (x+1)-z x=1 := by simp [z,loc]
  have h := stein K hn z
  change mean K (fun x=>z x*z x)=mean K (fun x=>SparseUrn.birth N k x*(z (x+1)-z x)) at h
  simp only [hd,mul_one,b,← pow_two,mean_mul,mean_add,mean_const,show mean K z=0 from mean_center K hn,
    mul_zero,add_zero] at h
  change mean K (fun x=>z x^2)=((k:ℝ)-m)^2/((N:ℝ)-1)
  apply (eq_div_iff (by linarith)).mpr
  field_simp at h
  linarith

#print axioms stationarity
#print axioms stein
#print axioms centered_variance
end StationaryUrn
