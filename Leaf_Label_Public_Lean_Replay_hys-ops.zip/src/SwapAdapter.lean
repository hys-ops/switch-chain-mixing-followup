import GraphSplit
import HorizontalRow
import LeafOrbitTransfer
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace GraphSplit
open TwoHubUnequal TwoHubHorizontal LeafSplit
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def pairAction (sp : Spec n r s d a c) (i j : Label a c) :
    Equiv.Perm (GraphState n d) :=
  LeafOrbit.labelEquiv (Equiv.swap i.val j.val) (LeafOrbit.swap_preserves_degree _ _
      ((sp.leaf _ ((TwoHub.mem_leaves _ _ _).mp i.2).1 ((TwoHub.mem_leaves _ _ _).mp i.2).2).trans
      (sp.leaf _ ((TwoHub.mem_leaves _ _ _).mp j.2).1 ((TwoHub.mem_leaves _ _ _).mp j.2).2).symm))

theorem pairAction_apply (sp : Spec n r s d a c) (i j : Label a c) (G : GraphState n d) :
    pairAction sp i j G = permute sp G i j := rfl
theorem label_count (sp : Spec n r s d a c) : Fintype.card (Label a c) = r+s := by
  change Fintype.card (↥(TwoHub.leaves a c))=_
  rw [Fintype.card_coe]
  unfold TwoHub.leaves
  rw [card_sdiff_of_subset (subset_univ _)]
  simp [sp.distinct,sp.size]

def moveSum (sp : Spec n r s d a c) : Matrix (GraphState n d) (GraphState n d) ℝ :=
  ∑ i : Label a c,∑ j : Label a c,LeafOrbit.permStep (pairAction sp i j)

theorem sw_formula (sp : Spec n r s d a c) (hn : 4≤n) :
    H d a c=(1-((r:ℝ)+s)^2/(2*clock n)) • (1 : Matrix _ _ ℝ) +
      (1/(2*clock n)) • moveSum sp := by
  ext G J
  let one : Matrix (GraphState n d) (GraphState n d) ℝ := 1
  let f := fun S => one S J-one G J
  have step := horizontal_row sp G f (sub_self _)
  have hkeep (S) : (if G.val.Adj a c ↔ S.val.Adj a c then switchKernel n d G S*f S else 0)=H d a c G S*f S := by
    by_cases he : G=S
    · subst S;simp [f]
    · by_cases h : G.val.Adj a c ↔ S.val.Adj a c <;> simp [H,horizontal,cross,isEdge,h,he,chain]
  simp_rw [hkeep] at step
  have hhs := (h_stoch (isEdge a c) (chain d) (physical_stochastic hn)).2 G
  have hleft : (∑ S,H d a c G S*f S)=H d a c G J-one G J := by
    simp only [f,mul_sub,sum_sub_distrib,←sum_mul]
    have idprod : (∑ S,H d a c G S*one S J)=H d a c G J := by
      change ((H d a c)*(1 : Matrix (GraphState n d) (GraphState n d) ℝ)) G J=_
      rw [Matrix.mul_one]
    rw [idprod, show (∑ y,H d a c G y)=1 from hhs,one_mul]
  rw [hleft] at step
  have hsum : (∑ i : Label a c,∑ j : Label a c, f (permute sp G i j))=
      moveSum sp G J - ((r:ℝ)+s)^2*one G J := by
    simp only [f,sum_sub_distrib,sum_const,card_univ,nsmul_eq_mul,label_count sp,Nat.cast_add]
    have ha : (∑ i : Label a c,∑ j : Label a c,one (permute sp G i j) J) = moveSum sp G J := by
      simp only [moveSum,Matrix.sum_apply,LeafOrbit.permStep,one,Matrix.one_apply,pairAction_apply]
      rfl
    rw [ha];ring
  rw [hsum] at step
  simp only [Matrix.add_apply,Matrix.smul_apply,smul_eq_mul]
  change H d a c G J=(1-_)*one G J+_*moveSum sp G J
  calc
    _ = (moveSum sp G J-((r:ℝ)+s)^2*one G J)/(2*clock n)+one G J := by linarith only [step]
    _ = _ := by ring

theorem physical_commute (sp : Spec n r s d a c) (hn : 4≤n) : Commute (V d a c) (H d a c) := by
  have hP : Commute (H d a c) (chain d) := by
    rw [sw_formula sp hn]
    apply Commute.add_left ((Commute.one_left _).smul_left _)
    apply Commute.smul_left
    apply Commute.sum_left;intro i _
    apply Commute.sum_left;intro j _
    apply LeafOrbit.step_commutes
    exact LeafOrbit.switchKernel_labelEquiv _ _
  have hf := decompose (isEdge a c) (chain d)
  have hv : V d a c=chain d-H d a c+1 := by
    calc
      _ = (H d a c+V d a c-1)-H d a c+1 := by abel
      _ = _ := by rw [show H d a c+V d a c-1=chain d from hf.symm]
  rw [hv]
  exact (hP.symm.sub_left (Commute.refl _)).add_left (Commute.one_left _)

theorem horizontal_diag (sp : Spec n r s d a c) (hn : 4≤n) (G : GraphState n d) :
    1-H d a c G G ≤ ((r:ℝ)+s)^2/(2*clock n) := by
  rw [sw_formula sp hn]
  simp only [Matrix.add_apply,Matrix.smul_apply,smul_eq_mul,Matrix.one_apply,ite_true,mul_one]
  have hnon : 0≤moveSum sp G G := by
    simp only [moveSum,Matrix.sum_apply,LeafOrbit.permStep]
    positivity
  have hh := mul_nonneg (show 0≤1/(2*clock n) by have := clock_pos hn; positivity) hnon
  linarith

theorem graph_horizontal_first_exit (sp : Spec n r s d a c) (hn : 4≤n) (hrs : 2≤(r:ℝ)*s)
    (t : ℕ) (G : GraphState n d) :
    tv (kernelPow n d t G) ((((frozen (isEdge a c) (V d a c))^t)*(H d a c)^t) G)
    ≤ (t:ℝ)*(2*(((r:ℝ)+s)^2/(2*clock n))*((r:ℝ)*s/clock n)+2/clock n) :=
  graph_error sp hn hrs (physical_commute sp hn)
    (by have := clock_pos hn;positivity) (horizontal_diag sp hn) t G

#print axioms graph_horizontal_first_exit
end GraphSplit
