import MarkSurvival
open Finset JohnsonLower
open scoped Matrix
namespace HubMarks
noncomputable section
variable {N h : ℕ}

def swapSet (S : Slice N h) (i j : Fin N) : Slice N h :=
  ⟨S.val.map (Equiv.swap i j).toEmbedding,by simp [S.property]⟩

lemma same_side (S : Slice N h) {i j : Fin N} (he : i∈S.val ↔ j∈S.val) :
    swapSet S i j = S := by
  apply Subtype.ext; ext x
  change x ∈ Finset.map (Equiv.swap i j).toEmbedding S.val ↔ _
  rw [mem_map_equiv,Equiv.symm_swap]
  by_cases hi : x=i
  · subst x;simp [he]
  by_cases hj : x=j
  · subst x;simp [he]
  rw [Equiv.swap_apply_of_ne_of_ne hi hj]

lemma opposite_side (S : Slice N h) (i : ↥S.val) (j : ↥S.valᶜ) :
    swapSet S i j=change S i j := by
  apply Subtype.ext; ext x
  change x ∈ Finset.map (Equiv.swap i.val j.val).toEmbedding S.val ↔ x ∈ insert j.val (S.val.erase i.val)
  rw [mem_map_equiv, Equiv.symm_swap]
  have hn := mem_compl.mp j.property
  have he : i.val ≠ j.val := by intro e;exact hn (e ▸ i.property)
  by_cases hi : x=i.val
  · subst x; simp [hn,he]
  by_cases hj : x=j.val
  · subst x;simp [i.property]
  simp [Equiv.swap_apply_of_ne_of_ne hi hj,hi,hj]

/-- Apply the subset chain by averaging label transpositions, with the original graph proposal clock. -/
theorem swap_row (Q : ℝ) (hQ : Q≠0) (S : Slice N h) (f : Slice N h → ℝ) :
    ((walk N h Q) *ᵥ f) S = f S +
      (∑ i : Fin N, ∑ j : Fin N, (f (swapSet S i j)-f S))/(2*Q) := by
  classical
  let g := fun i j : Fin N => f (swapSet S i j)-f S
  have part (v : Fin N → ℝ) :
      (∑ i,v i) = (∑ i : ↥S.val,v i)+(∑ j : ↥S.valᶜ,v j) := by
    rw [sum_coe_sort,sum_coe_sort];exact (sum_add_sum_compl _ _).symm
  have asym (i j : Fin N) : g i j=g j i := by
    have he : swapSet S i j=swapSet S j i := by
      apply Subtype.ext;change map (Equiv.swap i j).toEmbedding _=map (Equiv.swap j i).toEmbedding _
      rw [Equiv.swap_comm]
    simp [g,he]
  have oo (i j : ↥S.val) : g i j=0 := by simp [g,same_side S (show i.val∈S.val ↔ j.val∈S.val by simp)]
  have cc (i j : ↥S.valᶜ) : g i j=0 := by
    have hn : i.val∉S.val := mem_compl.mp i.property
    have hm : j.val∉S.val := mem_compl.mp j.property
    simp [g,same_side S (show i.val∈S.val ↔ j.val∈S.val by simp [hn,hm])]
  have sumg : (∑ i,∑ j,g i j)=2*(∑ i : ↥S.val,∑ j : ↥S.valᶜ,g i j) := by
    rw [part (fun i => ∑ j,g i j)]
    simp_rw [part (fun j => g _ j),sum_add_distrib,oo,cc,sum_const_zero,zero_add,add_zero]
    rw [sum_comm (f:=fun (j:↥S.valᶜ) (i:↥S.val) => g j i)]
    simp_rw [asym (_ : ↥S.valᶜ) (_ : ↥S.val)]
    ring
  have he (i : ↥S.val) (j : ↥S.valᶜ) : g i j=f (change S i j)-f S := by simp [g,opposite_side]
  change (∑ T,kernel Q S T * f T) = f S + (∑ i,∑ j,g i j)/(2*Q)
  rw [row_apply,sumg]
  simp_rw [he,sum_sub_distrib,sum_const,card_univ,nsmul_eq_mul,cardout,cardinal]
  field_simp;ring

/-- Row intertwining on a closed stratum is sufficient to transfer all times and
observables. The projection may be defined only for states satisfying D. -/
theorem closed_projection {X Y : Type*} [Fintype X] [Fintype Y] [DecidableEq X] [DecidableEq Y]
    (D : X → Prop) (P : Matrix X X ℝ) (W : Matrix Y Y ℝ) (π : X → Y)
    (closed : ∀ x, D x → ∀ y, ¬D y → P x y=0)
    (row : ∀ f : Y → ℝ, ∀ x, D x → (P *ᵥ (f ∘ π)) x=(W *ᵥ f) (π x))
    (t : ℕ) (f : Y → ℝ) (x : X) (hx : D x) :
    (P^t *ᵥ (f ∘ π)) x=(W^t *ᵥ f) (π x) := by
  induction t generalizing x with
  | zero => simp
  | succ t ih =>
    rw [pow_succ',pow_succ',←Matrix.mulVec_mulVec,←Matrix.mulVec_mulVec]
    rw [← row (W^t *ᵥ f) x hx]
    apply sum_congr rfl;intro y _
    by_cases hy : D y
    · rw [ih y hy];rfl
    · simp [closed x hx y hy]

#print axioms swap_row
#print axioms closed_projection
end
end HubMarks
