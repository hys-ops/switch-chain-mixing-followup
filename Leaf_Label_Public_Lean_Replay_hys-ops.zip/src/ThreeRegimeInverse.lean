import PoissonRange
import CriticalEndpoint
import DenseHubProfile
open Filter Topology UrnWindow UrnWindow.Degrees OAI.Problem315
namespace GrowingInverse
noncomputable section

variable (g : Degrees) {d : (i:ℕ)→Fin (g.population i+2)→ℕ}
  {a b : (i:ℕ)→Fin (g.population i+2)}
  (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))

include sp in
theorem actual_law (R : Regime) (h : R.holds g) : WindowLaw (d:=d) g R.window R.curve := by
  cases R with
  | dense => exact fun c η hη=>dense_graph_uniform g h d a b sp c η hη
  | critical α => exact fun c η hη=>CriticalResult.critical_graph_uniform g h.1 h.2 c d a b sp hη
  | sparse => exact HubMarks.sparse_graph_uniform g h d a b sp

theorem unique_crossing (R : Regime) (h : R.holds g) {ε : ℝ} (he : 0<ε) (he' : ε<1) :
    ∃!w : ℝ,R.curve w=ε := by
  cases R with
  | dense => exact gaussian_crossing he he'
  | critical α => exact critical_crossing h.1 he he'
  | sparse =>
    exact ⟨gumbelInverse ε,gumbel_inverse_exact he he',fun w hw=>gumbel_anti.injective (hw.trans (gumbel_inverse_exact he he').symm)⟩

theorem curve_anti (R : Regime) (h : R.holds g) : StrictAnti R.curve := by
  cases R with
  | dense => exact gaussian_anti
  | critical α => exact critical_anti h.1
  | sparse => exact gumbel_anti

def profileInverse (R : Regime) (h : R.holds g) (ε : ℝ) (he : 0<ε) (he' : ε<1) :=
  (unique_crossing g R h he he').exists.choose

theorem profileInverse_spec (R : Regime) (h : R.holds g) (ε : ℝ) (he : 0<ε) (he' : ε<1) :
    R.curve (profileInverse g R h ε he he')=ε := (unique_crossing g R h he he').exists.choose_spec

/-- For any accuracy and any of the three regimes with its natural hypotheses,
N/Q times the *actual worst-start hitting time* minus the prescribed centering tends
to the unique inverse of its physical profile.  There are no tail or mixing inputs. -/
theorem original_time (R : Regime) (h : R.holds g) (ε : ℝ) (he : 0<ε) (he' : ε<1) :
    Tendsto (fun i=>(Avoid.threshold (sp i) ε:ℝ)*g.step i-g.center R.window i) atTop
       (𝓝 (profileInverse g R h ε he he')) :=
  inverse_of_anti g sp R.window R.curve (actual_law g sp R h) (curve_anti g R h) (profileInverse_spec g R h ε he he')

include sp in
/-- The source defines the accuracy-1/4 mixing time via a proof of existence. This result
simultaneously produces that proof eventually and gives the same original time bound
for any choice of its proof argument. -/
theorem original_quarter (R : Regime) (h : R.holds g) (η : ℝ) (hη : 0<η) :
    ∀ᶠ i in atTop,
      (∃t,MixedAt (g.population i+2) (d i) t) ∧
      ∀ he : ∃t,MixedAt (g.population i+2) (d i) t,
      |(mixingTime (g.population i+2) (d i) he:ℝ)*g.step i - g.center R.window i -
        profileInverse g R h (1/4) (by norm_num) (by norm_num)| < η := by
  let w := profileInverse g R h (1/4) (by norm_num) (by norm_num)
  have hh : R.curve (w+1)<(1/4:ℝ) := by
    have j := curve_anti g R h (show w<w+1 by linarith)
    rwa [show R.curve w=(1/4:ℝ) from profileInverse_spec g R h _ _ _] at j
  have H := eventually_mixes g sp R.window R.curve (actual_law g sp R h) hh
  filter_upwards [H,Metric.tendsto_nhds.mp (original_time g sp R h (1/4) (by norm_num) (by norm_num)) η hη] with i hi hv
  refine ⟨hi,fun e=>?_⟩
  rw [←Avoid.threshold_original (sp i) e];exact hv

#print axioms original_time
#print axioms unique_crossing
#print axioms original_quarter
end
end GrowingInverse
