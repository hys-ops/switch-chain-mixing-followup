import WorstProfiles
import DenseHubProfile
open Filter Topology UrnWindow UrnWindow.Degrees OAI.Problem315
noncomputable section
namespace TwoHubWorst
variable (g : Degrees) {d : (i:ℕ)→Fin (g.population i+2)→ℕ}
  {a b : (i:ℕ)→Fin (g.population i+2)}
  (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))

theorem dense (hd : Tendsto g.ratio atTop atTop) (c : ℝ) :
    Tendsto (fun i=>Avoid.worstTV (sp i) (g.time .halfLogN c i)) atTop (𝓝 (gaussian c)) :=
  GrowingInverse.worst_profile g sp .halfLogN gaussian
    (fun u η hη => dense_graph_uniform g hd d a b sp u η hη) c

theorem limit (z : Regime) (hz : z.holds g) (c : ℝ) :
    Tendsto (fun i=>Avoid.worstTV (sp i) (g.time z.window c i)) atTop (𝓝 (z.curve c)) := by
  cases z with
  | dense => exact dense g sp hz c
  | critical α => exact critical g sp hz.1 hz.2 c
  | sparse => exact sparse g sp hz c

#print axioms dense
#print axioms limit
end TwoHubWorst
