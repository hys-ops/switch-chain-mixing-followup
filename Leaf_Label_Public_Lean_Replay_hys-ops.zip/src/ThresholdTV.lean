import OverlapOrder
open Finset HubTransfer JohnsonLower HubMarks
namespace JohnsonProfile
noncomputable section
attribute [local instance] Classical.propDecidable
variable {X : Type*} [Fintype X]

def tailDiff (rank : X→ℕ) (p q : X→ℝ) (m : ℕ) := ∑x,if m≤rank x then p x-q x else 0

/-- A monotone signed difference of two probabilities changes sign at one
rank. The half-L¹ metric equals the largest excess mass of an upper tail. -/
theorem threshold_max (rank : X→ℕ) (p q : X→ℝ) (k : ℕ)
    (hr : ∀x,rank x≤k) (hm : ∀x y,rank x≤rank y → p x-q x≤p y-q y)
    (sumEq : ∑x,p x=∑x,q x) :
    (∃ m≤k+1, tv p q=tailDiff rank p q m) ∧ (∀m,tailDiff rank p q m≤tv p q) := by
  classical
  let D:=fun x=>p x-q x
  have balanced : (∑x,D x)=0 := by simp [D,sum_sub_distrib,sumEq]
  have total : (∑ x,(|D x|+D x))=2*tv p q := by
    rw [sum_add_distrib,balanced,add_zero];unfold tv;dsimp [D];ring
  have cut : ∃m≤k+1,(∀x,m≤rank x → 0≤D x) ∧ ∀x,rank x<m → D x≤0 := by
    by_cases h : ∃i:ℕ,∃x:X,rank x=i ∧ 0<D x
    · obtain ⟨x,hrank,hpos⟩:=Nat.find_spec h
      refine ⟨Nat.find h,by have :=hr x;omega,?_,?_⟩
      · intro y hy;exact hpos.le.trans (hm x y (hrank ▸ hy))
      · intro y hy;by_contra! hn
        exact (Nat.find_min h hy) ⟨y,rfl,hn⟩
    · refine ⟨k+1,le_refl _,fun x hx=>(by have :=hr x;omega),?_⟩
      intro x _;by_contra! hn;exact h ⟨rank x,x,rfl,hn⟩
  obtain ⟨m,hm₁,pos,neg⟩:=cut
  constructor
  · refine ⟨m,hm₁,?_⟩
    have point (x) : |D x|+D x=2*(if m≤rank x then D x else 0) := by
      by_cases he : m≤rank x
      · simp [he,abs_of_nonneg (pos x he)];ring
      · simp [he,abs_of_nonpos (neg x (Nat.lt_of_not_ge he))]
    simp only [point,←mul_sum] at total
    unfold tailDiff;change tv p q=∑x,if m≤rank x then D x else 0;linarith
  · intro j
    have h : 2*tailDiff rank p q j≤2*tv p q := by
      rw [←total,tailDiff,mul_sum];apply sum_le_sum
      intro x _;change 2*(if j≤rank x then D x else 0)≤_
      split <;> linarith [le_abs_self (D x),neg_abs_le (D x)]
    linarith

/-- The original lazy Johnson chain, from any fixed labeled point, has exact
TV equal to a one-sided overlap tail discrepancy at every discrete time. -/
theorem tv_is_overlap_tail {N k : ℕ} (A : Slice N k) {Q:ℝ} (hQ : 0<Q)
    (hN : (N:ℝ)^2≤Q) (t : ℕ) :
    (∃ m≤k+1, tv (((walk N k Q)^t) A) (unif _)
      =tailDiff (overlap A.val) (((walk N k Q)^t) A) (unif _) m) ∧
    (∀ m,tailDiff (overlap A.val) (((walk N k Q)^t) A) (unif _) m ≤ tv (((walk N k Q)^t) A) (unif _)) := by
  classical
  have hkn : k≤N := by simpa [A.2] using (card_le_univ A.val)
  have hkr : (k:ℝ)≤N := by exact_mod_cast hkn
  have ab : (k:ℝ)*(N-k) ≤ Q := by
    apply le_trans _ hN;calc
      _ ≤ (N:ℝ)*N := mul_le_mul hkr (by linarith [show 0≤(k:ℝ) by positivity]) (sub_nonneg.mpr hkr) (by positivity)
      _ = _ := by ring
  have hs:= (stochastic_pow (kernel_stoch (N:=N) (s:=k) hQ ab) t).2 A
  have : Nonempty (Slice N k) := ⟨A⟩
  have hc : (Fintype.card (Slice N k):ℝ)≠0 := by exact_mod_cast Fintype.card_ne_zero
  apply threshold_max
  · intro x;exact (card_le_card (inter_subset_left)).trans_eq x.2
  · intro x y he;exact sub_le_sub_right (ordered_row A x y hQ hN t he) _
  · calc
      _ = 1 := hs
      _ = _ := by unfold unif;rw [sum_const,card_univ,nsmul_eq_mul];field_simp

#print axioms tv_is_overlap_tail
end
end JohnsonProfile
