import LowerClock
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace LeafDrift

/-- Adjustable threshold. With h growing, any fixed pre-cutoff discrepancy 1-δ
    can be certified on a δ-dependent multiple of the same logarithmic time. -/
theorem marked_lower_tolerance {n : ℕ} {d : Fin n → ℕ} (hn : 4≤n)
    (Z : GraphState n d → ℝ) (G : GraphState n d)
    {Q N h r c δ : ℝ} (hd0 : 0<δ) (hh : (2/δ+1)^2≤h) (hr : h≤r)
    (hQ : 0<Q) (hN : 0<N) (hc : c≤2*N/Q) (hZ : ∀ y,0≤Z y)
    (hle : ∀ y,Z y≤r) (hinit : Z G=r)
    (hstep : ∀ g, (∑ y,switchKernel n d g y*Real.log ((r+1)/(Z y+1))) ≤
         Real.log ((r+1)/(Z g+1))+c)
    (hmean : uniformAverage n d Z ≤r/h)
    (t : ℕ) (ht : (t:ℝ) ≤ δ*(Q*Real.log h/(8*N))) :
    1-δ ≤ tvDistanceFrom n d t G := by
  let A := (2:ℝ)/δ
  have hA : 0<A := by dsimp [A];positivity
  change (A+1)^2≤h at hh
  have h1 : 1<h := by nlinarith [sq_nonneg A]
  have hp : 0<h := by linarith
  have rp : 0<r := by linarith
  have hlg : 0<Real.log h := Real.log_pos h1
  let F := fun y => Real.log ((r+1)/(Z y+1))
  have hF (y) : 0≤F y := by
    apply Real.log_nonneg
    apply (one_le_div (by linarith [hZ y])).mpr
    linarith [hle y]
  have hi : F G=0 := by simp [F,hinit,show r+1≠0 by linarith]
  have hb : 0<A*r/h := by positivity
  have hl : 0<Real.log h/2 := by positivity
  have barrier (y) (hy : Z y≤A*r/h) : Real.log h/2 ≤ F y := by
    have ha1 : 0<A+1 := by linarith
    have hh' := (le_div_iff₀ hp).mp hy
    have hlow : h/(A+1)≤(r+1)/(Z y+1) := by
      rw [div_le_div_iff₀ ha1 (by linarith [hZ y])]
      nlinarith
    have hsq : h≤(h/(A+1))^2 := by
      rw [div_pow]
      apply (le_div_iff₀ (sq_pos_of_pos ha1)).mpr
      nlinarith [mul_le_mul_of_nonneg_left hh hp.le]
    have lh := Real.log_le_log hp hsq
    rw [Real.log_pow] at lh
    have ll := Real.log_le_log (div_pos hp ha1) hlow
    dsimp [F];linarith
  have hg := actual_tv_lower hn F Z hF hZ G hb hl hi hstep barrier hmean t
  have tail : (r/h)/(A*r/h) = δ/2 := by dsimp [A];field_simp
  have tcost : (t:ℝ)*c/(Real.log h/2) ≤ δ/2 := by
    apply (div_le_iff₀ hl).mpr
    calc
      _ ≤ (t:ℝ)*(2*N/Q) := mul_le_mul_of_nonneg_left hc (by positivity)
      _ ≤ (δ*(Q*Real.log h/(8*N)))*(2*N/Q) := mul_le_mul_of_nonneg_right ht (by positivity)
      _ = _ := by field_simp;ring
  rw [tail] at hg
  linarith

theorem tolerance_polynomial_clock {h : ℕ} (hh : 25≤h) {δ : ℝ} (hd : 0≤δ) :
    δ*(((h+h^5:ℕ):ℝ)^3*Real.log ((h+h^5:ℕ):ℝ)/1536) ≤
    δ*((12*((h+h^5).choose 4:ℝ))*Real.log (h:ℝ)/(8*(h^5:ℕ))) := by
  apply mul_le_mul_of_nonneg_left _ hd
  have e := mul_le_mul_of_nonneg_left (polynomial_clock hh) (show (0:ℝ)≤2 by norm_num)
  convert e using 1 <;> ring

#print axioms marked_lower_tolerance
#print axioms tolerance_polynomial_clock
end LeafDrift
