import OverlapEquilibrium
open Finset HubTransfer JohnsonLower BinaryOverlap NormedSpace
open scoped Matrix Matrix.Norms.Operator Classical
noncomputable section
namespace PhysicalReduction
variable {N k : ℕ}

/-- One ordered-pair proposal on the overlap coordinate. Values on
    impossible levels are irrelevant, and reachable levels are closed. -/
def orderedStep (N k : ℕ) : Matrix (Fin (k+1)) (Fin (k+1)) ℝ := fun x j=>
  (if x=j then 1 else 0) + 2/(N:ℝ)*SparseUrn.generator N k
    (fun z=>if z=j.val then 1 else 0) x.val

def marginal {X Y : Type*} [DecidableEq Y] (π : X→Y) : Matrix X Y ℝ :=
  fun x y=> if π x=y then 1 else 0

theorem pushed_column {X Y : Type*} [Fintype X] [DecidableEq Y] (π : X→Y)
    (K : Matrix X X ℝ) (x : X) (j : Y) :
    (K*marginal π) x j=push π (K x) j := by
  simp [Matrix.mul_apply,marginal,push,mul_ite]

theorem projected{C X : Type*} [Fintype C] [DecidableEq C] (π : X→C)
    (B : Matrix C C ℝ) (x : X) (j : C) : (marginal π*B) x j=B (π x) j := by
  simp [Matrix.mul_apply,marginal,ite_mul]

/-- Intertwining the true subset transition and the tridiagonal proposal. -/
theorem ordered_one (K : JohnsonLower.Slice N k) (hn : 0<N) :
    LeafClock.published N k * marginal (level K)=marginal (level K)*orderedStep N k := by
  ext S j
  rw [projected]
  let f := fun z:ℕ => if z=j.val then (1:ℝ) else 0
  have hh:=scalar_generator K S hn f
  rw [Matrix.sub_mulVec,Pi.sub_apply,Matrix.one_mulVec] at hh
  have h (T : JohnsonLower.Slice N k) : marginal (level K) T j=f (HubMarks.overlap K T) := by
    unfold marginal f
    simp only [Fin.ext_iff];rfl
  rw [Matrix.mul_apply];simp_rw [h]
  change (LeafClock.published N k *ᵥ (fun T=>f (HubMarks.overlap K T))) S=_
  change _=marginal (level K) S j+2/(N:ℝ)*SparseUrn.generator N k f (HubMarks.overlap K S)
  rw [h];linarith

theorem power_marginal (K : JohnsonLower.Slice N k) (hn : 0<N) (t : ℕ) :
    (LeafClock.published N k)^t * marginal (level K)=marginal (level K)*(orderedStep N k)^t := by
  induction t with
  | zero => simp
  | succ t ih => rw [pow_succ,pow_succ,Matrix.mul_assoc,ordered_one K hn,←Matrix.mul_assoc,ih,Matrix.mul_assoc]

theorem power_scalar (K S : JohnsonLower.Slice N k) (hn : 0<N) (t : ℕ) (j : Fin (k+1)) :
    push (level K) (((LeafClock.published N k)^t) S) j=((orderedStep N k)^t) (level K S) j := by
  rw [←pushed_column,power_marginal K hn t,projected]

/-- The overlap law produced by the full subset semigroup equals the
    exponential of a (k+1)×(k+1) matrix in physical external time. -/
theorem exp_scalar (K S : JohnsonLower.Slice N k) (hn : 0<N) {u : ℝ} (hu : 0≤u) (j : Fin (k+1)) :
    push (level K) (LeafClock.continuous (LeafClock.published N k) u S) j=
    (exp (𝔸:=Matrix (Fin (k+1)) (Fin (k+1)) ℝ) (u • (orderedStep N k-1))) (level K S) j := by
  let P:=LeafClock.published N k
  have hr : (0:ℝ)<N := by exact_mod_cast hn
  have hp : Stochastic P := kernel_stoch (by positivity) (by nlinarith [sq_nonneg ((N:ℝ)-2*k)])
  rw [←LeafClock.continuous_exp]
  change push (level K) (LeafClock.continuous P u S) j=_
  unfold push
  rw [←sum_filter]
  change (∑ T∈univ.filter (fun T => level K T=j), ∑' t:ℕ,LeafClock.mass u t*(P^t) S T)=_
  rw [←Summable.tsum_finsetSum (fun T _ => LeafClock.entry_summable P hp hu S T)]
  apply tsum_congr;intro t;rw [←mul_sum]
  have he:=power_scalar K S hn t j
  unfold push at he;rw [←sum_filter] at he
  rw [show (∑ T∈univ.filter (fun T=>level K T=j),(P^t) S T)=_ from he]

def hyperProb (N k : ℕ) (j : Fin (k+1)) : ℝ :=
  (k.choose j.val:ℝ)*((N-k).choose (k-j.val):ℝ)/(N.choose k:ℝ)

/-- A directly computable urn distance requiring only the k+1 scalar levels. -/
def tridiagonalDistance (N k : ℕ) (u : ℝ) : ℝ :=
  tv ((exp (𝔸:=Matrix (Fin (k+1)) (Fin (k+1)) ℝ) (u • (orderedStep N k-1))) (Fin.last k))
    (hyperProb N k)

theorem scalar_to_tridiagonal (K : JohnsonLower.Slice N k) (hn : 0<N) {u : ℝ} (hu : 0≤u) :
    scalarDistance K u=tridiagonalDistance N k u := by
  have he : level K K=Fin.last k := Fin.ext (BinaryOverlap.full.mpr rfl)
  unfold scalarDistance tridiagonalDistance
  congr 1
  · funext j;rw [exp_scalar K K hn hu j,he]
  · funext j;exact hypergeometric K j
#print axioms ordered_one
#print axioms exp_scalar
#print axioms scalar_to_tridiagonal
end PhysicalReduction
