import HarmonicDrift
import OAI.Probability.SwitchChain.KernelNormalization
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace LeafDrift
variable {n : ℕ} {d : Fin n → ℕ}

theorem actual_kernel_pow (t : ℕ) : (kernelPow n d t : Matrix (GraphState n d) (GraphState n d) ℝ)
    = (Matrix.of (switchKernel n d))^t := by
  classical
  induction t with
  | zero =>
    funext G H
    change (if G = H then (1:ℝ) else 0) = (1 : Matrix (GraphState n d) (GraphState n d) ℝ) G H
    simp [Matrix.one_apply]
  | succ t ih =>
    funext G H
    change (∑ K ∈ allGraphStates n d, kernelPow n d t G K*switchKernel n d K H) = _
    rw [ih,pow_succ]
    rfl

theorem actual_tv (G : GraphState n d) (t : ℕ) :
    tvDistanceFrom n d t G = tv (((Matrix.of (switchKernel n d))^t) G) (unif _) := by
  unfold tvDistanceFrom tv unif
  rw [← actual_kernel_pow]
  simp only [allGraphStates,stateCount,card_univ]
  ring

theorem actual_tv_lower (hn : 4≤n) (F Z : GraphState n d → ℝ)
    (hF : ∀ y, 0≤F y) (hZ : ∀ y, 0≤Z y)
    (G : GraphState n d) {c B L mu : ℝ} (hB : 0<B) (hL : 0<L)
    (hinit : F G=0)
    (hd : ∀ g, (∑ y,switchKernel n d g y*F y) ≤ F g+c)
    (hbad : ∀ y, Z y ≤ B → L ≤ F y)
    (hmean : uniformAverage n d Z ≤ mu) (t : ℕ) :
    1-(t:ℝ)*c/L-mu/B ≤ tvDistanceFrom n d t G := by
  classical
  have : Nonempty (GraphState n d) := ⟨G⟩
  have hc : (Fintype.card (GraphState n d):ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  have hu : (∑ y : GraphState n d, unif _ y) = 1 := by simp [unif,hc]
  have he : obs (unif _) Z = uniformAverage n d Z := by
    simp [obs,unif,uniformAverage,allGraphStates,stateCount,←sum_mul,div_eq_mul_inv,mul_comm]
  have hP : Stochastic (switchKernel n d) :=
    ⟨switchKernel_nonneg, fun g => by simpa [allGraphStates] using switchKernel_row_sum hn g⟩
  rw [actual_tv]
  exact tv_lower _ hP _ F Z hu (fun y => by unfold unif;positivity) hF hZ G hB hL hinit hd hbad (he.trans_le hmean) t

#print axioms actual_tv_lower
end LeafDrift
