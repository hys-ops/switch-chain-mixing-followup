import ClockRows
import SwapRow
import Mathlib.Analysis.Normed.Algebra.MatrixExponential
open Finset HubTransfer NormedSpace JohnsonLower
open scoped Matrix Matrix.Norms.Operator Classical
noncomputable section
namespace LeafClock
variable {X : Type*} [Fintype X] [DecidableEq X]

set_option backward.isDefEq.respectTransparency false in
theorem continuous_exp (P : Matrix X X ℝ) (u : ℝ) :
    continuous P u = exp (𝔸:=Matrix X X ℝ) (u • (P-1)) := by
  have hmul : u • (P-1) = (-u) • (1:Matrix X X ℝ)+u • P := by rw [smul_sub,neg_smul];abel
  have hc : Commute ((-u) • (1:Matrix X X ℝ)) (u • P) := ((Commute.one_left P).smul_left _).smul_right _
  have hcst := algebraMap_exp_comm (𝕂:=ℝ) (𝔸:=Matrix X X ℝ) (-u)
  simp only [Algebra.algebraMap_eq_smul_one,←Real.exp_eq_exp_ℝ] at hcst
  rw [hmul,Matrix.exp_add_of_commute _ _ hc]
  erw [←hcst,Matrix.smul_mul,one_mul]
  ext x y
  have h := expSeries_hasSum_exp (𝕂:=ℝ) (u • P)
  simp only [expSeries_apply_eq,smul_pow] at h
  have h₁ := Pi.hasSum.mp (Pi.hasSum.mp h x) y
  have h₂ := h₁.mul_left (Real.exp (-u))
  change (∑' k, mass u k*(P^k) x y) = Real.exp (-u)*(exp (u • P)) x y
  exact (h₂.congr_fun (by intro k;simp [mass,Matrix.smul_apply,smul_eq_mul];ring)).tsum_eq

/-- Unit-rate ordered-pair proposals have distinct unordered-pair rate 2/N². -/
def published (N k : ℕ) : Matrix (Slice N k) (Slice N k) ℝ := HubMarks.walk N k ((N:ℝ)^2/2)

theorem clock_identity {N k : ℕ} (hN : 0<N) (Q w : ℝ) (hQ : 0<Q) :
    continuous (HubMarks.walk N k Q) w =
      exp (𝔸:=Matrix (Slice N k) (Slice N k) ℝ) ((w * (N:ℝ)^2/(2*Q)) • (published N k - 1)) := by
  rw [continuous_exp]
  apply congrArg (fun M : Matrix (Slice N k) (Slice N k) ℝ => exp M)
  ext S T
  have hn : 0<(N:ℝ) := by exact_mod_cast hN
  change w*(kernel Q S T-(if S=T then 1 else 0))= (w*(N:ℝ)^2/(2*Q))*(kernel ((N:ℝ)^2/2) S T-(if S=T then 1 else 0))
  unfold kernel
  by_cases h : S=T
  · subst T;simp only [ite_true];field_simp;ring
  · by_cases e : edge S T <;> simp [h,Ne.symm h,e] <;> field_simp <;> ring

theorem binary_clock_bound {N k : ℕ} (S : Slice N k) (hN : 0<N) {Q : ℝ} (hQ : 0<Q)
    (hb : (k:ℝ)*(N-k)≤Q) {t : ℕ} (ht : 0<t) :
    tv ((exp (𝔸:=Matrix (Slice N k) (Slice N k) ℝ) (((t:ℝ)*N^2/(2*Q)) • (published N k-1))) S)
        (((HubMarks.walk N k Q)^t) S) ≤ Real.sqrt t * ((k:ℝ)*(N-k)/Q) := by
  have hk : k≤N := by simpa [S.property] using S.val.card_le_univ
  have hb0 : 0≤(k:ℝ)*((N:ℝ)-k)/Q := by
    have : (k:ℝ)≤N := by exact_mod_cast hk
    positivity
  rw [←clock_identity hN Q t hQ]
  apply discrete_continuous _ (kernel_stoch hQ hb) hb0 _ S t ht
  intro y;simp [HubMarks.walk,kernel]

#print axioms continuous_exp
#print axioms clock_identity
#print axioms binary_clock_bound
end LeafClock
