import UrnWindow
open Filter Topology
namespace UrnWindow.Degrees
noncomputable section

lemma normalized_time_grows (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (fun i => g.N i * g.tau z c i) atTop atTop := by
  have h := ((center_infty g z).atTop_add (tendsto_const_nhds (x:=c))).atTop_add
    (rounding_limit g z c)
  apply h.congr
  intro i
  ring

lemma tau_zero (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (g.tau z c) atTop (𝓝 0) := by
  have hlog : Tendsto (fun i => Real.log (g.N i)/g.N i) atTop (𝓝 0) := by
    simpa [Function.comp_def] using (Real.tendsto_pow_log_div_mul_add_atTop 1 0 1 one_ne_zero).comp (N_infty g)
  have h : Tendsto (fun i => (Real.log (g.N i)+c)/g.N i) atTop (𝓝 0) := by
    simpa [add_div] using hlog.add ((tendsto_const_nhds (x:=c)).div_atTop (N_infty g))
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds h
  · exact Filter.Eventually.of_forall (fun i => div_nonneg (Nat.cast_nonneg _) (clk_pos g i).le)
  · filter_upwards [rounding g z c] with i hi
    rw [le_div_iff₀ (by linarith [(sizes g i).2.2.1])]
    linarith [(center_le g z i).2,hi.2]

def error (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) : ℝ :=
    (g.time z c i : ℝ) * (2*(g.r i:ℝ)*g.s i/g.Q i)^2 +
    2/((g.r i:ℝ)*g.s i+2) + 2*g.tau z c i +
    Real.exp (-((g.r i:ℝ)*g.s i*g.tau z c i)) +
    2*Real.exp (-(((g.s i:ℝ)-1)*g.tau z c i)) +
    Real.exp (-((g.N i-2)*g.tau z c i))

lemma error_envelope (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) :
    0 ≤ g.error z c i ∧
    g.error z c i ≤ 18*g.tau z c i + 2/g.N i +
      4*Real.exp (-(g.N i*g.tau z c i/4)) := by
  obtain ⟨hr,hs,hn,he⟩ := sizes g i
  have hs0 : 0≤(g.s i:ℝ) := by positivity
  have hq := clk_pos g i
  have hn0 : 0<g.N i := by linarith
  have ht : 0≤g.tau z c i := div_nonneg (Nat.cast_nonneg _) hq.le
  have hrs : g.N i ≤ (g.r i:ℝ)*g.s i := by nlinarith [mul_nonneg (by linarith : 0≤(g.r i:ℝ)-2) hs0]
  have hq4 := clock_lower g i
  have hprod : (2*(g.r i:ℝ)*g.s i)^2 ≤ 16*g.Q i := by
    have h1 : 0≤2*(g.r i:ℝ)*g.s i := by positivity
    have h2 : 2*(g.r i:ℝ)*g.s i ≤ 2*(g.N i)^2 := by
      rw [he]
      nlinarith [mul_nonneg (Nat.cast_nonneg (α:=ℝ) (g.r i)) hs0,sq_nonneg ((g.r i:ℝ)),sq_nonneg ((g.s i:ℝ))]
    have h3 := sq_le_sq' (by linarith [sq_nonneg (g.N i)] : -(2*(g.N i)^2) ≤ 2*(g.r i:ℝ)*g.s i) h2
    nlinarith
  have hp : (g.time z c i:ℝ)*(2*(g.r i:ℝ)*g.s i/g.Q i)^2 ≤ 16*g.tau z c i := by
    rw [tau,div_pow,←mul_div_assoc,←mul_div_assoc,div_le_div_iff₀ (sq_pos_of_pos hq) hq]
    nlinarith [mul_nonneg (by positivity : 0≤(g.time z c i:ℝ)*g.Q i) (sub_nonneg.mpr hprod)]
  have hstat : 2/((g.r i:ℝ)*g.s i+2) ≤ 2/g.N i :=
    div_le_div_of_nonneg_left (by norm_num) hn0 (by linarith)
  have hex (x:ℝ) (hx:g.N i/4≤x) :
      Real.exp (-(x*g.tau z c i)) ≤ Real.exp (-(g.N i*g.tau z c i/4)) := by
    apply Real.exp_le_exp.mpr
    nlinarith [mul_nonneg ht (sub_nonneg.mpr hx)]
  constructor
  · unfold error; positivity
  · unfold error
    linarith [hex ((g.r i:ℝ)*g.s i) (by linarith),hex ((g.s i:ℝ)-1) (by linarith),hex (g.N i-2) (by linarith)]

theorem error_zero (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (g.error z c) atTop (𝓝 0) := by
  have h1 := (tendsto_const_nhds (x:=(18:ℝ))).mul (tau_zero g z c)
  have h2 := (tendsto_const_nhds (x:=(2:ℝ))).div_atTop (N_infty g)
  have h3 := Real.tendsto_exp_atBot.comp
    (tendsto_neg_atTop_atBot.comp ((normalized_time_grows g z c).atTop_div_const (by norm_num : (0:ℝ)<4)))
  have h := (h1.add h2).add ((tendsto_const_nhds (x:=(4:ℝ))).mul h3)
  apply squeeze_zero (fun i => (error_envelope g z c i).1) (fun i => (error_envelope g z c i).2)
  simpa [Function.comp_def] using h

#print axioms error_zero
end
end UrnWindow.Degrees
