import ClockWindow
import RestrictedTV
open Finset HubTransfer LeafClock NormedSpace
open scoped Matrix Matrix.Norms.Operator Classical
noncomputable section
namespace PhysicalReduction
variable {X : Type*} [Fintype X] [DecidableEq X]

/-- Time is the published unit-rate ordered-pair proposal clock. -/
def urnDistance {N k : ℕ} (S : JohnsonLower.Slice N k) (u : ℝ) : ℝ :=
  tv (continuous (published N k) u S) (unif _)

theorem urnDistance_exp {N k : ℕ} (S : JohnsonLower.Slice N k) (u : ℝ) :
    urnDistance S u = tv ((exp (𝔸:=Matrix _ _ ℝ) (u • (published N k-1))) S) (unif _) := by
  unfold urnDistance;rw [continuous_exp]

theorem continuous_stoch (P : Matrix X X ℝ) (hp : Stochastic P) {v : ℝ} (hv : 0≤v) :
    Stochastic (continuous P v) := by
  refine ⟨fun x y=>tsum_nonneg (fun k=>mul_nonneg (mass_ge hv k) ((stochastic_pow hp k).1 x y)),?_⟩
  intro x
  unfold continuous
  rw [←Summable.tsum_finsetSum (fun y _=>entry_summable P hp hv x y)]
  simp_rw [←mul_sum,(fun k=> (stochastic_pow hp k).2 x),mul_one]
  exact (total hv).tsum_eq

theorem continuous_plus (P : Matrix X X ℝ) (u v : ℝ) :
    continuous P (u+v) = continuous P u * continuous P v := by
  rw [continuous_exp,continuous_exp,continuous_exp,add_smul]
  apply Matrix.exp_add_of_commute
  exact ((Commute.refl (P-1)).smul_left u).smul_right v

omit [DecidableEq X] in
theorem uniform_fixed (P : Matrix X X ℝ) (hp : Stochastic P) (sym : ∀x y,P x y=P y x) :
    (unif X) ᵥ* P=unif X := by
  funext x;change (∑ y,(1/(Fintype.card X:ℝ))*P y x)=_
  simp_rw [fun y=>sym y x];rw [←mul_sum,hp.2,mul_one];rfl

/-- Only the time increment has to be nonnegative. TV contracts for any
    signed starting row, so the scalar distance is antitone for all real times. -/
theorem urn_antitone {N k : ℕ} (S : JohnsonLower.Slice N k) (hn : 0<N) :
    Antitone (urnDistance S) := by
  let P:=published N k
  have hN : (0:ℝ)<N := by exact_mod_cast hn
  have hk : (k:ℝ)≤N := by exact_mod_cast (show k≤N by simpa [S.property] using S.val.card_le_univ)
  have hp : Stochastic P := JohnsonLower.kernel_stoch (by positivity) (by nlinarith [sq_nonneg ((N:ℝ)-2*k)])
  intro u v huv
  let R:=continuous P (v-u)
  have hR:=continuous_stoch P hp (sub_nonneg.mpr huv)
  have sym (x y) : R x y=R y x := by
    unfold R continuous
    congr 1;funext j
    congr 1;exact RestrictedTV.stoch_sym_pow (K:=P) (fun i l=>JohnsonLower.kernel_symm _ i l) j x y
  have he:=tv_contract R hR (continuous P u S) (unif _)
  rw [uniform_fixed R hR sym] at he
  have ht : continuous P v=continuous P u*R := by rw [show v=u+(v-u) by ring];convert continuous_plus P u (v-u) using 2
  change tv (continuous P v S) (unif _)≤_
  rw [ht];exact he
#print axioms urn_antitone
end PhysicalReduction
