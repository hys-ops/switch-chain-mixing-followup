import UrnError
open Filter Topology
namespace UrnWindow.Degrees
noncomputable section

/-- Sandwich a vanishing movement of the time parameter between two fixed parameters. -/
theorem moving_window {D : ℕ → ℝ → ℝ} {F : ℝ → ℝ} {a : ℕ → ℝ} {c : ℝ}
    (hd : ∀ i, Antitone (D i)) (hF : ContinuousAt F c)
    (hp : ∀ w, Tendsto (fun i => D i w) atTop (𝓝 (F w)))
    (ha : Tendsto a atTop (𝓝 c)) : Tendsto (fun i => D i (a i)) atTop (𝓝 (F c)) := by
  apply tendsto_order.2
  constructor
  · intro v hv
    obtain ⟨δ,hδ,hh⟩ := Metric.continuousAt_iff.mp hF (F c-v) (by linarith)
    have hm := hh (x:=c+δ/2) (by rw [Real.dist_eq,abs_of_nonneg (by linarith)];linarith)
    rw [Real.dist_eq,abs_lt] at hm
    have hx := (tendsto_order.mp (hp (c+δ/2))).1 v (by linarith)
    have hy := (tendsto_order.mp ha).2 (c+δ/2) (by linarith)
    filter_upwards [hx,hy] with i hi hj using hi.trans_le (hd i hj.le)
  · intro v hv
    obtain ⟨δ,hδ,hh⟩ := Metric.continuousAt_iff.mp hF (v-F c) (by linarith)
    have hm := hh (x:=c-δ/2) (by rw [Real.dist_eq,abs_of_nonpos (by linarith)];linarith)
    rw [Real.dist_eq,abs_lt] at hm
    have hx := (tendsto_order.mp (hp (c-δ/2))).2 v (by linarith)
    have hy := (tendsto_order.mp ha).1 (c-δ/2) (by linarith)
    filter_upwards [hx,hy] with i hi hj using (hd i hj.le).trans_lt hi

def external (g : Degrees) (i : ℕ) (τ : ℝ) := (g.N i)^2 * τ / 2

/-- Each ordered-with-replacement pair has external rate 1/N². The two orders give
external rate 2/N² per unordered transposition; the scaled time has unit rate. -/
lemma pair_clock (g : Degrees) (i : ℕ) (τ : ℝ) :
    g.external i τ * (2/(g.N i)^2) = τ := by
  have hn : 0 <g.N i := by linarith [(sizes g i).2.2.1]
  unfold external
  field_simp [hn.ne']

lemma rounded_binary_limit (g : Degrees) (z : Center) (c : ℝ)
    (D : ℕ → ℝ → ℝ) (F : ℝ → ℝ) (hD : ∀ i, Antitone (D i)) (hc : ContinuousAt F c)
    (hOTS : ∀ w, Tendsto (fun i => D i (g.N i*(g.center z i+w)/2)) atTop (𝓝 (F w))) :
    Tendsto (fun i => D i (g.external i (g.tau z c i))) atTop (𝓝 (F c)) := by
  have hw : Tendsto (fun i => g.N i*g.tau z c i-g.center z i) atTop (𝓝 c) := by
    have H := (rounding_limit g z c).add (tendsto_const_nhds (x:=c))
    simp only [zero_add] at H
    apply H.congr
    intro i
    ring
  have hd : ∀ i, Antitone (fun w : ℝ => D i (g.N i*(g.center z i+w)/2)) := by
    intro i x y hxy
    apply hD i
    have hn := (sizes g i).2.2.1
    nlinarith [mul_nonneg (by linarith : 0≤g.N i) (sub_nonneg.mpr hxy)]
  apply (moving_window hd hc hOTS hw).congr
  intro i
  congr 1
  unfold external
  ring

/-- All point starts simultaneously, under exactly the finite comparison in Theorem 5
and the indicated (continuous) binary-urn limit on the source's external clock. -/
theorem uniform_transfer (g : Degrees) (z : Center) (c : ℝ)
    {X : ℕ → Type*} (graph : (i : ℕ) → X i → ℝ) (urn : ℕ → ℝ → ℝ) (F : ℝ → ℝ)
    (hfin : ∀ i x, |graph i x - urn i (g.external i (g.tau z c i))| ≤ g.error z c i)
    (hD : ∀ i, Antitone (urn i)) (hc : ContinuousAt F c)
    (hOTS : ∀ w, Tendsto (fun i => urn i (g.N i*(g.center z i+w)/2)) atTop (𝓝 (F w)))
    {ε : ℝ} (hε : 0<ε) : ∀ᶠ i in atTop, ∀ x : X i, |graph i x-F c| < ε := by
  have he := (tendsto_order.mp (error_zero g z c)).2 (ε/2) (by linarith)
  have hu := Metric.tendsto_nhds.mp (rounded_binary_limit g z c urn F hD hc hOTS) (ε/2) (by linarith)
  filter_upwards [he,hu] with i hi hu
  rw [Real.dist_eq] at hu
  intro x
  linarith [abs_sub_le (graph i x) (urn i (g.external i (g.tau z c i))) (F c),hfin i x]

#print axioms uniform_transfer
end
end UrnWindow.Degrees
