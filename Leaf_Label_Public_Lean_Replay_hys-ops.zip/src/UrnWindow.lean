import PhysicalClock
open Filter Topology
namespace UrnWindow
noncomputable section

structure Degrees where
  r : ℕ → ℕ
  s : ℕ → ℕ
  two : ∀ i, 2 ≤ r i
  small : ∀ i, r i ≤ s i
  grows : Tendsto r atTop atTop

namespace Degrees

def population (g : Degrees) (i : ℕ) := g.r i + g.s i
abbrev N (g : Degrees) (i : ℕ) : ℝ := g.population i
def Q (g : Degrees) (i : ℕ) : ℝ := TwoHubUnequal.clock (g.population i + 2)
abbrev k (g : Degrees) (i : ℕ) : ℝ := (g.r i : ℝ)-1

lemma sizes (g : Degrees) (i : ℕ) :
    2 ≤ (g.r i:ℝ) ∧ (g.r i:ℝ) ≤ (g.s i:ℝ) ∧ 4 ≤ g.N i ∧
      g.N i = (g.r i:ℝ)+g.s i := by
  have hr : (2:ℝ) ≤ g.r i := by exact_mod_cast g.two i
  have hs : (g.r i:ℝ) ≤ g.s i := by exact_mod_cast g.small i
  simp only [N,population,Nat.cast_add]
  exact ⟨hr,hs,by linarith, trivial⟩

lemma clock_eq (g : Degrees) (i : ℕ) :
    g.Q i = (g.N i+2)*(g.N i+1)*g.N i*(g.N i-1)/2 := by
  let m := g.population i - 2
  have h : m+2 = g.population i := by dsimp [m,population]; have := g.two i; omega
  have hN : TwoHubUnequal.N 0 m = g.N i := by
    simp only [TwoHubUnequal.N, Nat.cast_zero,zero_add]
    exact_mod_cast h
  have hQ : TwoHubUnequal.Q 0 m = g.Q i := by
    unfold TwoHubUnequal.Q Q
    congr 1
    omega
  rw [←hQ,TwoHubUnequal.Qexact,hN]

lemma clock_lower (g : Degrees) (i : ℕ) : (g.N i)^4 /4 ≤ g.Q i := by
  have hn := (sizes g i).2.2.1
  rw [clock_eq]
  nlinarith [sq_nonneg (g.N i),pow_nonneg (by linarith : 0≤g.N i) 3,
    sq_nonneg ((g.N i)^2),mul_nonneg (by linarith : 0≤g.N i-2) (sq_nonneg (g.N i))]
lemma clk_pos (g : Degrees) (i : ℕ) : 0<g.Q i := by
  have hn := (sizes g i).2.2.1
  have hl := clock_lower g i
  exact lt_of_lt_of_le (by positivity) hl

lemma N_infty (g : Degrees) : Tendsto g.N atTop atTop := by
  apply tendsto_atTop_mono (f:=fun i => (g.r i:ℝ)) _ (tendsto_natCast_atTop_atTop.comp g.grows)
  intro i
  rw [(sizes g i).2.2.2]
  linarith [Nat.cast_nonneg (α := ℝ) (g.s i)]

lemma k_infty (g : Degrees) : Tendsto g.k atTop atTop :=
  (tendsto_natCast_atTop_atTop.comp g.grows).atTop_add (tendsto_const_nhds (x:= -(1:ℝ)))

lemma step_size (g : Degrees) : Tendsto (fun i => g.N i / g.Q i) atTop (𝓝 0) := by
  apply squeeze_zero (fun i => by have := (sizes g i).2.2.1; exact div_nonneg (by linarith) (clk_pos g i).le)
    _ ((tendsto_const_nhds (x:=(1:ℝ))).div_atTop (N_infty g))
  intro i
  have hn := (sizes g i).2.2.1
  have h := clock_lower g i
  rw [div_le_div_iff₀ (clk_pos g i) (by linarith)]
  have hn2 : 4 ≤ (g.N i)^2 := by nlinarith [sq_nonneg (g.N i-2)]
  nlinarith [mul_nonneg (sub_nonneg.mpr hn2) (sq_nonneg (g.N i))]

inductive Center
  | halfLogN
  | logK

def center (g : Degrees) : Center → ℕ → ℝ
  | .halfLogN, i => Real.log (g.N i)/2
  | .logK, i => Real.log (g.k i)

lemma center_infty (g : Degrees) (z : Center) : Tendsto (g.center z) atTop atTop := by
  cases z with
  | halfLogN => exact ((Real.tendsto_log_atTop.comp (N_infty g)).atTop_div_const (by norm_num : (0:ℝ)<2))
  | logK => exact Real.tendsto_log_atTop.comp (k_infty g)

lemma center_le (g : Degrees) (z : Center) (i : ℕ) :
    0 ≤ g.center z i ∧ g.center z i ≤ Real.log (g.N i) := by
  obtain ⟨hr,hs,hn,he⟩ := sizes g i
  have hp := Real.log_nonneg (by linarith : 1 ≤ g.N i)
  cases z with
  | halfLogN => dsimp [center]; constructor <;> linarith
  | logK =>
    dsimp [center,k]
    exact ⟨Real.log_nonneg (by linarith),Real.log_le_log (by linarith) (by linarith)⟩

def time (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) : ℕ :=
  ⌊(g.center z i+c) * g.Q i / g.N i⌋₊

def tau (g : Degrees) (z : Center) (c : ℝ) (i : ℕ) : ℝ := (g.time z c i : ℝ)/g.Q i

lemma rounding (g : Degrees) (z : Center) (c : ℝ) :
    ∀ᶠ i in atTop,
      -g.N i / g.Q i ≤ g.N i * g.tau z c i - (g.center z i+c) ∧
      g.N i * g.tau z c i - (g.center z i+c) ≤ 0 := by
  have hpos := ((center_infty g z).atTop_add (tendsto_const_nhds (x:=c))).eventually_ge_atTop 0
  filter_upwards [hpos] with i hi
  have hn : 0<g.N i := by linarith [(sizes g i).2.2.1]
  have hq := clk_pos g i
  have flo := Nat.floor_le (div_nonneg (mul_nonneg hi hq.le) hn.le)
  have cei := (Nat.lt_floor_add_one ((g.center z i+c)*g.Q i/g.N i)).le
  have hl := (le_div_iff₀ hn).mp flo
  have hu := (div_le_iff₀ hn).mp cei
  change (g.time z c i:ℝ) * g.N i ≤ _ at hl
  change _ ≤ ((g.time z c i:ℝ)+1) * g.N i at hu
  dsimp only [tau]
  constructor
  · field_simp [hq.ne']
    nlinarith
  · rw [sub_nonpos,mul_div_assoc' _ _ _, div_le_iff₀ hq]
    nlinarith

lemma rounding_limit (g : Degrees) (z : Center) (c : ℝ) :
    Tendsto (fun i => g.N i * g.tau z c i - (g.center z i+c)) atTop (𝓝 0) := by
  apply tendsto_of_tendsto_of_tendsto_of_le_of_le' (by simpa [neg_div] using (step_size g).neg)
    tendsto_const_nhds ((rounding g z c).mono fun _ h => h.1) ((rounding g z c).mono fun _ h => h.2)

end Degrees
end
end UrnWindow
