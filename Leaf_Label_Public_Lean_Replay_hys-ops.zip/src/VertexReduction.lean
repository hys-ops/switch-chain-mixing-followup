import PhysicalReduction
import IncidentRed
import BinaryGray
open Finset HubTransfer OAI.Problem315
open scoped Matrix Classical
noncomputable section
namespace PhysicalReduction
open RestrictedTV TwoHubUnequal TwoHubHorizontal GraphSplit
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}
abbrev noexit (n r s t : ℕ) : ℝ := (1-(r:ℝ)*s/clock n)^t
abbrev adjerr (n r s t : ℕ) : ℝ := (1-((r+s-2:ℕ):ℝ)/clock n)^t

theorem mix_tv {X : Type*} [Fintype X] (a b : X→ℝ) (w : ℝ) (hw : 0≤w) :
    tv (fun x=>w*a x+(1-w)*b x) b = w*tv a b := by
  unfold tv
  have h (x:X) : |w*a x+(1-w)*b x-b x|=w*|a x-b x| := by
    rw [show w*a x+(1-w)*b x-b x=w*(a x-b x) by ring,abs_mul,abs_of_nonneg hw]
  simp only [h,←mul_sum];ring

theorem nonedge_approx (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G : GraphState n d) (he : ¬G.val.Adj a c) (t : ℕ) :
    tv (kernelPow n d t G) ((U a c G) ᵥ* (H d a c)^t) ≤ 3*t/clock n + noexit n r s t := by
  let U₀ := U a c G
  let T := (H d a c)^t
  let w := noexit n r s t
  have hT := stochastic_pow (LeafSplit.h_stoch (isEdge a c) (chain d) (physical_stochastic hn)) t
  have hu1 := incident_mass sp hn (by linarith) G he
  have hu (x) : 0≤U₀ x := div_nonneg
    (LeafSplit.cross_bounds _ _ (physical_stochastic hn) G x).1
    (LeafSplit.ex_bounds _ _ (physical_stochastic hn) G).1
  have hv (x) : 0≤(U₀ ᵥ* T) x := sum_nonneg fun y _=>mul_nonneg (hu y) (hT.1 y x)
  have hv1 : ∑ x,(U₀ ᵥ* T) x=1 := by
    simp only [Matrix.vecMul,dotProduct]
    rw [sum_comm];simp_rw [←mul_sum];change (∑ x,U₀ x*(∑ y,T x y))=1
    simp_rw [show ∀x,∑ y,T x y=1 from hT.2,mul_one];exact hu1
  have hw : 0≤w := by
    have h:=(LeafSplit.ex_bounds (isEdge a c) (chain d) (physical_stochastic hn) G).2
    rw [exit_vertex sp G he] at h;exact pow_nonneg (sub_nonneg.mpr h) t
  let F := fun y=>w*T G y+(1-w)*(U₀ ᵥ* T) y
  have h1 : tv (kernelPow n d t G) F≤3*t/clock n := vertex_start sp hn hs hrs G he t
  have h2 : tv F (U₀ ᵥ* T) ≤ w := by
    rw [show F=fun y=>w*T G y+(1-w)*(U₀ ᵥ* T) y from rfl,mix_tv _ _ _ hw]
    exact mul_le_of_le_one_right hw (prob_tv_le (hT.1 G) hv (hT.2 G) hv1)
  exact (tv_triangle _ F _).trans (add_le_add h1 h2)

theorem support_some (sp : Spec n r s d a c) (hn : 4≤n) (hrs : 0<(r:ℝ)*s)
    (G : GraphState n d) (he : ¬G.val.Adj a c) : ∃J,U a c G J≠0 := by
  by_contra! hh
  have h:=incident_mass sp hn hrs G he
  simp [hh] at h

/-- Each unjoined starting graph admits an actual (supported) first-entry state.
    Relative to the red set at *any* such state, the complete graph row has a
    finite error on the original discrete clock, uniform over all labels. -/
theorem vertex_binary (sp : Spec n r s d a c) (hn : 4≤n) (hs : 2≤s) (hrs : 2≤(r:ℝ)*s)
    (G J : GraphState n d) (he : ¬G.val.Adj a c) (hJ : U a c G J≠0) (t : ℕ) :
    |tvDistanceFrom n d t G-Bdist n r s t (redProjection sp J)| ≤
      3*t/clock n+noexit n r s t+gray n s t+adjerr n r s t+stationary r s := by
  let U₀ := U a c G
  let T := (H d a c)^t
  let B := bin n r s t
  let b := B (redProjection sp J)
  have uj := (HubMarks.incidence_marked sp G J he hJ).1
  have Tclose : tv (U₀ ᵥ* T) (density sp b)≤gray n s t + adjerr n r s t := by
    apply to_mixture U₀ _ (incident_mass sp hn (by linarith) G he) T
    · intro L hL
      have hL' := (HubMarks.incidence_marked sp G L he hL).1
      have hl:=heat_density sp hn L hL' t
      obtain ⟨i,j,heq⟩:=incident_red_swap sp G J L he hJ hL
      have hc:=GraphGray.clock_big sp hn
      rw [GraphGray.label_card sp] at hc
      have ha := BinaryGray.binary_adjacent (redProjection sp J) i j (clock_pos hn) hc t
      rw [←heq] at ha
      have hd : tv (density sp (B (redProjection sp L))) (density sp b)≤adjerr n r s t := by
        rw [density_distance_pair sp J uj,reverse];exact ha
      exact (tv_triangle _ (density sp (B (redProjection sp L))) _).trans (add_le_add hl hd)
    · intro x;exact div_nonneg (LeafSplit.cross_bounds _ _ (physical_stochastic hn) G x).1
        (LeafSplit.ex_bounds _ _ (physical_stochastic hn) G).1
  have hh:=four_tv (kernelPow n d t G) (density sp b) (unif _) (reference d a c)
  rw [density_distance sp J uj b,ref_cost sp hn J uj] at hh
  have h1:=nonedge_approx sp hn hs hrs G he t
  have h2:=tv_triangle (kernelPow n d t G) (U₀ ᵥ* T) (density sp b)
  rw [LeafDrift.actual_tv,←LeafDrift.actual_kernel_pow];unfold Bdist
  change |tv (kernelPow n d t G) (unif _)-tv b (unif _)|≤_
  change tv (kernelPow n d t G) (U₀ ᵥ* T)≤_ at h1
  linarith
#print axioms vertex_binary
end PhysicalReduction
