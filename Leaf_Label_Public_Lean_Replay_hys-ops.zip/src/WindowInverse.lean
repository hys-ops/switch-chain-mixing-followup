import WorstLimit
import DiscreteWindow
open Filter Topology OAI.Problem315 UrnWindow UrnWindow.Degrees
namespace GrowingInverse
noncomputable section

variable (g : Degrees)
  {d : (i:ℕ)→Fin (g.population i+2)→ℕ}
  {a b : (i:ℕ)→Fin (g.population i+2)}
  (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))

def WindowLaw (C : Center) (F : ℝ→ℝ) := ∀ c η : ℝ, 0<η → ∀ᶠ i in atTop,
  ∀ G : GraphState (g.population i+2) (d i), |tvDistanceFrom _ (d i) (g.time C c i) G-F c|<η

theorem worst_profile (C : Center) (F : ℝ→ℝ) (H : WindowLaw (d:=d) g C F) (c : ℝ) :
    Tendsto (fun i=>Avoid.worstTV (sp i) (g.time C c i)) atTop (𝓝 (F c)) := by
  apply Metric.tendsto_nhds.mpr;intro η hη
  filter_upwards [H c η hη] with i hi
  have hn : 4≤g.population i+2 := by unfold population;have := g.two i;have := g.small i;omega
  obtain ⟨E,he⟩ := Avoid.connected_exists (sp i) hn (by have := g.two i;omega) (by have := g.two i;have := g.small i;omega)
  obtain ⟨V,hv⟩ := Avoid.separated_exists (sp i)
  rw [Real.dist_eq,Avoid.worst_eq (sp i) _ E V he hv]
  rcases max_choice (tvDistanceFrom _ _ (g.time C c i) E) (tvDistanceFrom _ _ (g.time C c i) V) with h|h
  · rw [h];exact hi E
  · rw [h];exact hi V

/-- Strict left and right crossings are all inversion needs about the limiting
curve.  The output is the second-order, centered Q/N clock. -/
theorem centered_inverse (C : Center) (F : ℝ→ℝ) (H : WindowLaw (d:=d) g C F)
    (ε w : ℝ) (hleft : ∀v<w, ε<F v) (hright : ∀v>w,F v<ε) :
    Tendsto (fun i=>(Avoid.threshold (sp i) ε:ℝ)*g.step i - g.center C i) atTop (𝓝 w) := by
  have profile := worst_profile g sp C F H
  have clock (v : ℝ) : Tendsto (fun i => (g.time C v i:ℝ)*g.step i-g.center C i) atTop (𝓝 v) := by
    have h := (g.rounding_limit C v).add_const v
    simp only [zero_add] at h
    apply h.congr;intro i;rw [time_step];ring
  have usable (u : ℝ) (hu : w<u) : ∀ᶠ i in atTop,Avoid.worstTV (sp i) (g.time C u i)≤ε :=
    ((tendsto_order.mp (profile u)).2 ε (hright u hu)).mono (fun _ h=>h.le)
  apply tendsto_order.mpr;constructor
  · intro z hz
    obtain ⟨v,hzv,hvw⟩ := exists_between hz
    have hlo := (tendsto_order.mp (profile v)).1 ε (hleft v hvw)
    have hbelow := (tendsto_order.mp (clock v)).1 z hzv
    filter_upwards [usable (w+1) (by linarith),hlo,hbelow] with i ht hv hy
    have hex : {t : ℕ | Avoid.worstTV (sp i) t≤ε}.Nonempty := ⟨_,ht⟩
    have hn : 4≤g.population i+2 := by unfold population;have := g.two i;have := g.small i;omega
    have hl : g.time C v i < Avoid.threshold (sp i) ε := by
      by_contra! hh
      exact (not_lt_of_ge ((Avoid.worst_antitone (sp i) hn hh).trans (Nat.sInf_mem hex))) hv
    exact hy.trans_le (sub_le_sub_right (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr hl.le) (step_pos g i).le) _)
  · intro z hz
    obtain ⟨v,hwv,hvz⟩ := exists_between hz
    filter_upwards [usable v hwv,(tendsto_order.mp (clock v)).2 z hvz] with i h ht
    have he : Avoid.threshold (sp i) ε≤g.time C v i := Nat.sInf_le h
    exact (sub_le_sub_right (mul_le_mul_of_nonneg_right (Nat.cast_le.mpr he) (step_pos g i).le) _).trans_lt ht

theorem inverse_of_anti (C : Center) (F : ℝ→ℝ) (H : WindowLaw (d:=d) g C F) (hF : StrictAnti F)
    {ε w : ℝ} (he : F w=ε) :
    Tendsto (fun i=>(Avoid.threshold (sp i) ε:ℝ)*g.step i - g.center C i) atTop (𝓝 w) :=
  centered_inverse g sp C F H ε w (fun _ h=>he ▸ hF h) (fun _ h=>he ▸ hF h)

include sp in
theorem eventually_mixes (C : Center) (F : ℝ→ℝ) (H : WindowLaw (d:=d) g C F)
    {ε u : ℝ} (he : F u<ε) :
    ∀ᶠ i in atTop, ∃t, ∀G : GraphState _ (d i), tvDistanceFrom _ (d i) t G≤ε := by
  filter_upwards [(tendsto_order.mp (worst_profile g sp C F H u)).2 ε he] with i hi
  exact ⟨g.time C u i,(Avoid.worst_le_iff (sp i) _ _).1 hi.le⟩

#print axioms centered_inverse
end
end GrowingInverse
