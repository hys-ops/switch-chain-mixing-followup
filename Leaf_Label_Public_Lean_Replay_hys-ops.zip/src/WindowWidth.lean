import ThreeRegimeInverse
open Filter Topology UrnWindow UrnWindow.Degrees OAI.Problem315
namespace GrowingInverse
noncomputable section
variable (g : Degrees) {d : (i:ℕ)→Fin (g.population i+2)→ℕ}
  {a b : (i:ℕ)→Fin (g.population i+2)}
  (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))
  (R : Regime) (h : R.holds g) {ε δ : ℝ} (he : 0<ε) (hed : ε<δ) (hd : δ<1)

theorem inverse_order :
    profileInverse g R h δ (he.trans hed) hd < profileInverse g R h ε he (hed.trans hd) := by
  by_contra! H
  have hh := (curve_anti g R h).antitone H
  rw [profileInverse_spec,profileInverse_spec] at hh
  linarith

theorem window_width :
    Tendsto (fun i=>((Avoid.threshold (sp i) ε:ℝ)-(Avoid.threshold (sp i) δ:ℝ))*g.step i) atTop
      (𝓝 (profileInverse g R h ε he (hed.trans hd)-profileInverse g R h δ (he.trans hed) hd)) ∧
    0<profileInverse g R h ε he (hed.trans hd)-profileInverse g R h δ (he.trans hed) hd := by
  constructor
  · have hh := (original_time g sp R h ε he (hed.trans hd)).sub (original_time g sp R h δ (he.trans hed) hd)
    apply hh.congr;intro i;ring
  · exact sub_pos.mpr (inverse_order g R h he hed hd)

include R h he hed hd in
theorem cutoff_ratio :
    Tendsto (fun i=>(Avoid.threshold (sp i) ε:ℝ)/(Avoid.threshold (sp i) δ:ℝ)) atTop (𝓝 1) := by
  have D := (window_width g sp R h he hed hd).1
  have ht : Tendsto (fun i=>(Avoid.threshold (sp i) δ:ℝ)*g.step i) atTop atTop := by
    apply ((original_time g sp R h δ (he.trans hed) hd).add_atTop (g.center_infty R.window)).congr
    intro i;ring
  have ratio := (D.div_atTop ht).const_add 1
  simp only [add_zero] at ratio
  apply ratio.congr'
  filter_upwards [ht.eventually_gt_atTop 0] with i hi
  have hs := (step_pos g i).ne'
  have ht' : (Avoid.threshold (sp i) δ:ℝ)≠0 := by intro hz;rw [hz,zero_mul] at hi;linarith
  field_simp
  ring
#print axioms window_width
#print axioms cutoff_ratio
end
end GrowingInverse
