import Starts
import MarkovTV
namespace Avoid
open OAI.Problem315 TwoHubUnequal Finset Filter Topology
open scoped BigOperators Matrix
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n r s : ℕ} {d : Fin n → ℕ} {a c : Fin n}

def edgeCurve (r : ℕ) (u : ℝ) : ℝ := 1-(1-Real.exp (-u))^(r+1)
def vertexCurve (r : ℕ) (u : ℝ) : ℝ := 1-(1-Real.exp (-(u*r)))*(1-Real.exp (-u))^r

theorem profile_order (hr : 1≤r) {u : ℝ} (hu : 0≤u) : vertexCurve r u≤edgeCurve r u := by
  have hmax : Real.exp (-(u*r))≤Real.exp (-u) := by
    apply Real.exp_le_exp.mpr
    have h : 1≤(r:ℝ) := by exact_mod_cast hr
    nlinarith [mul_nonneg hu (sub_nonneg.mpr h)]
  have hp : 0≤1-Real.exp (-u) := by have := Real.exp_le_one_iff.mpr (neg_nonpos.mpr hu);linarith
  unfold vertexCurve edgeCurve
  rw [pow_succ]
  nlinarith only [mul_le_mul_of_nonneg_left (sub_le_sub_left hmax 1) (pow_nonneg hp r)]

theorem worst_limit_of_layers {r : ℕ} (hr : 2≤r) (F : Family r) (u : ℝ) (hu : 0≤u)
    (edgeLaw : ∀ (G : (k:ℕ) → GraphState (r+k+4) (F.d k)),
      (∀k,(G k).1.Adj (F.a k) (F.c k)) →
      Tendsto (fun k => tvDistanceFrom _ (F.d k) (localTime r u k) (G k)) atTop (𝓝 (edgeCurve r u)))
    (vertexLaw : ∀ (G : (k:ℕ) → GraphState (r+k+4) (F.d k)),
      (∀k,¬(G k).1.Adj (F.a k) (F.c k)) →
      Tendsto (fun k => tvDistanceFrom _ (F.d k) (localTime r u k) (G k)) atTop (𝓝 (vertexCurve r u))) :
    Tendsto (fun k => worstTV (F.spec k) (localTime r u k)) atTop (𝓝 (edgeCurve r u)) := by
  classical
  choose V hV using (fun k => separated_exists (F.spec k))
  choose E hE using (fun k => connected_exists (F.spec k) (by omega) (by omega) (by omega))
  have H := (edgeLaw E hE).max (vertexLaw V hV)
  rw [max_eq_left (profile_order (by omega) hu)] at H
  exact H.congr (fun k => (worst_eq (F.spec k) _ _ _ (hE k) (hV k)).symm)

theorem worst_le_iff (sp : TwoHubUnequal.Spec n r s d a c) (t : ℕ) (ε : ℝ) :
    worstTV sp t ≤ ε ↔ ∀ G : GraphState n d,tvDistanceFrom n d t G ≤ ε := by
  simp [worstTV,sup'_le_iff]

theorem row_antitone (hn : 4≤n) (G : GraphState n d) : Antitone (fun t => tvDistanceFrom n d t G) := by
  apply antitone_nat_of_succ_le
  intro t
  let P : Matrix (GraphState n d) (GraphState n d) ℝ := switchKernel n d
  let u : GraphState n d → ℝ := fun _ => 1/(stateCount n d:ℝ)
  have hP : HubTransfer.Stochastic P := ⟨switchKernel_nonneg,switchKernel_row_sum hn⟩
  have hstat : u ᵥ* P=u := by
    funext y
    change (∑x,(1/(stateCount n d:ℝ))*P x y)=_
    rw [←mul_sum];change _*(∑x,switchKernel n d x y)=_
    rw [show (∑x,switchKernel n d x y)=1 from switchKernel_column_sum hn y,mul_one]
  have h := HubTransfer.tv_contract P hP (kernelPow n d t G) u
  rw [hstat] at h
  convert h using 1 <;> unfold tvDistanceFrom HubTransfer.tv <;> rw [one_div,mul_comm] <;> rfl

theorem worst_antitone (sp : TwoHubUnequal.Spec n r s d a c) (hn : 4≤n) : Antitone (worstTV sp) := by
  intro i j h
  apply (worst_le_iff _ _ _).mpr
  intro G
  exact (row_antitone hn G h).trans (le_sup' _ (mem_univ G))

def threshold (sp : TwoHubUnequal.Spec n r s d a c) (ε : ℝ) : ℕ :=
  sInf {t : ℕ | worstTV sp t≤ε}

theorem threshold_original (sp : TwoHubUnequal.Spec n r s d a c) (h : ∃t,MixedAt n d t) :
    threshold sp (1/4)=mixingTime n d h := by
  classical
  have he : ∀t, worstTV sp t≤1/4 ↔ MixedAt n d t := fun t => worst_le_iff _ _ _
  have hs : {t : ℕ | worstTV sp t ≤ 1/4} = {t | MixedAt n d t} := Set.ext he
  unfold threshold mixingTime
  rw [hs]
  exact le_antisymm (Nat.sInf_le (Nat.find_spec h)) (Nat.find_min' h (Nat.sInf_mem h))
#print axioms worst_limit_of_layers
#print axioms worst_antitone
end
end Avoid
