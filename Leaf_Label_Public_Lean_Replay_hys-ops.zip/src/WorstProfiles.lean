import WindowInverse
import CriticalEndpoint
import SparseHubProfile
open Filter Topology UrnWindow UrnWindow.Degrees OAI.Problem315
noncomputable section
namespace TwoHubWorst
variable (g : Degrees) {d : (i:ℕ)→Fin (g.population i+2)→ℕ}
  {a b : (i:ℕ)→Fin (g.population i+2)}
  (sp : ∀i,TwoHubUnequal.Spec (g.population i+2) (g.r i) (g.s i) (d i) (a i) (b i))

/-- Total variation maximized over all labeled degree realizations, including
both hub adjacency statuses. The windows and time are discrete. -/
theorem sparse (hs : Tendsto g.ratio atTop (𝓝 0)) (c : ℝ) :
    Tendsto (fun i=>Avoid.worstTV (sp i) (g.time .logK c i)) atTop (𝓝 (gumbel c)) :=
  GrowingInverse.worst_profile g sp .logK gumbel
    (fun u η hη => HubMarks.sparse_graph_uniform g hs d a b sp u η hη) c

theorem critical {α : ℝ} (hp : 0<α) (hr : Tendsto g.ratio atTop (𝓝 (Real.sqrt α))) (c : ℝ) :
    Tendsto (fun i=>Avoid.worstTV (sp i) (g.time .halfLogN c i)) atTop (𝓝 (Degrees.critical α c)) :=
  GrowingInverse.worst_profile g sp .halfLogN (Degrees.critical α)
    (fun u _ hη=>CriticalResult.critical_graph_uniform g hp hr u d a b sp hη) c

#print axioms sparse
#print axioms critical
end TwoHubWorst
