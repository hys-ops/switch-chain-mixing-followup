# Source and build provenance

The original is OpenAI’s *Polynomial mixing of the switch chain for every graphical degree sequence*, dated 25 September 2026. The formalization lives under `lean/OAI/Probability/SwitchChain`. The public catalogue uses problem number 131. Its Lean declarations retain the original internal namespace `OAI.Problem315`.

- [Pinned repository](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae)
- [Source modules](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/lean/OAI/Probability/SwitchChain)
- [Catalogue scope](https://github.com/openai/math/blob/4eaee87548250b2682affda7d05d947c05554bae/lean/docs/131.md)
- [Manuscript and upstream PDF](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/preprints/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026)

The original theorem file is `upstream/OAI/Probability/SwitchChain/Main.lean`. Starting with its imports gives exactly 165 Lean files, 22,691 lines and 921,825 bytes. These are the files in `upstream/`. For each file, `config/source-lock.json` records the Git blob identifier supplied by GitHub’s directory listing at the pinned commit and an independent SHA-256 hash. The build recomputes both, checks that every upstream file is reachable, and checks four byte-exact ranges from the two original slice-definition files against the independent slice module. The small `config/source-identity.json` lists those ranges. The upstream PDF’s SHA-256 is `e70eab92c1315e6706eea3613e9826871e009d1ef8de31f82d5750d026240af3`.

`LICENSE` is the Apache 2.0 license from the repository root, Git blob `261eeb9e9f8b2b4b0d119366dda99c6fd7d35c64`. Original files remain byte-for-byte in `upstream/`. The Apache 2.0 notice covers the original source files and the upstream material reused in the independent slice adapter. The user may choose licensing terms for newly written material before publication. The preparation of the supplementary proofs and checks used AI. The pinned source authors did not review or endorse this package to our knowledge.

The independent build uses Lean 4.34.1, compiler commit `5045d0056413266e57c625dcd7c365b10e377c52`, and Mathlib commit `d13f23b723b8a846827a245b89c10fc7d3f11612`. The small Lake configuration and manifest in `config/` pin the dependencies of the scoped build. The replay reads only third-party package object directories and the current run’s empty output directory. It checks every package checkout against that manifest. Each graph-specific object, including those for the old endpoint and the new proofs, is built locally. Verification assumes the supplied Lean executable and third-party Mathlib dependency cache. The replay never downloads dependencies.

## Proof identity

The handwritten short proof follows a random path between independent uniform subsets. The alternate handwritten proof uses the Johnson spectrum. There are two checked global Lean endpoints:

| Lean endpoint | Local implementation used by its proof term |
|---|---|
| `OAI.Problem315.VerifiedSwitch.switch_mixing` | A central sum of involutions and an antisymmetric eigenfunction yield the uniform eigenvalue bound 2. The graph endpoint does not call the all- N sharp result. |
| `OAI.Problem315.SharpSliceRoute.switch_mixing` | A separate antisymmetric-eigenfunction argument proves the sharp lower bound  N on nonconstant Johnson slices. The two distinguished labels and their  N−2 incident pairs account for the  N energy units. If  N≥2 this implies the uniform bound 2. On  N≤1 all equal-size subsets agree. |

Both routes use the same graph fiber and global pair-resampling estimates. The sharp route and the uniform route share the underlying graph definitions, slice action and basic energy machinery. The weak uniform eigenvalue theorem disappears from the sharp proof term, and the sharp theorem disappears from the uniform proof term. Neither formal argument is a line-by-line encoding of the note’s random paths or its different proof of the Johnson spectrum. `ExactJohnson.exists_attaining_mode` and the original-type adapter `OAI.Problem315.SliceGap.attaining_mode` also certify attainment for 0 < q < N. The global switch-chain bound only needs the lower inequality.

`DependencyAudit.lean` traverses types and values (including opaque theorem values) of constants, classifying project declarations by *defining module*. This includes private names and generated proof auxiliaries. Libraries compiled before the project cannot refer to the later project proofs. The test covers both final mixing-time proof terms. It asserts the use of six upstream inputs for each and the exclusion of the two old public mixing/TV theorems and three old comparison bounds. The original endpoint is nonetheless elaborated and its three-axiom report is printed for comparison. Requests for all constants’ data rather than the specific audit can be satisfied by inspecting the included Lean sources and generated objects.
