# A sharper fiber comparison for the lazy graph switch chain

[Read the four-page note](paper/note.pdf) · [TeX source](paper/note.tex) · [Proof and source provenance](PROVENANCE.md) · [Build modes](REPRODUCE.md)

The follow-up strengthens OpenAI's Theorem 1.1 from **2n⁸ to n⁶** for the same lazy four-vertex proposal, every graphical labeled degree sequence on n ≥ 4 vertices and worst-start total-variation distance 1/4. Pages 1–2 give the short proof and an equation-by-equation comparison with §§7.3–7.4. Page 3 proves the exact Johnson gap. Page 4 explains which arguments Lean checks.

To inspect the evidence using only Python, run `python3 scripts/check_receipts.py` from the kit root. This regenerates the build inputs and checks their hashes and the saved Lean logs. The instructions below rerun Lean.

## Reproduce with Lean 4.34.1

Use Python 3.10+, Git, and the Lean 4.34.1 Linux toolchain (the reported runs use Linux). The commands below use Bash and start in the unpacked directory containing this README. If you already have the pinned dependencies, skip the first block and set LEAN_BIN and PACKAGES to their absolute paths. No original graph object files are needed.

**Prepare the third-party packages.** With Elan installed and its executables on the path, allow network access to the Lean toolchain, Git remotes and the Mathlib cache. The lockfile records the Git revisions. The build below uses only the listed Mathlib imports and their dependencies. On a first installation the dependency download and disk usage can be substantial.

~~~bash
KIT="$(pwd -P)"
(
  cd "$KIT/config"
  lean --version
  lake exe cache get $(cat focused-imports.txt) Mathlib.Data.Fintype.Powerset
)
LEAN_BIN="$(cd "$KIT/config" && lean --print-prefix)/bin/lean"
PACKAGES="$KIT/config/.lake/packages"
~~~

**Run the checks.** With a suitable existing package cache, the following is offline. The replay rejects a nonempty build directory, checks the package revisions and the 165 upstream source hashes, and builds fresh project objects. Two parallel modules are optional; use --jobs 1 on a memory-constrained machine.

~~~bash
RUN="$(mktemp -d)"
python3 scripts/replay.py --mode named --lean "$LEAN_BIN" \
  --packages "$PACKAGES" --build "$RUN/named" --jobs 2
cat "$RUN/named/logs/DependencyAudit.log"
cat "$RUN/named/receipt.json"
~~~

The **named** run preserves all upstream module names, boundaries and declaration bodies, and narrows the broad Mathlib imports. The distributed originals are byte-identical to the pinned source. The **focused** route recompiles the same source bodies in one module with a separate section for each file:

~~~bash
python3 scripts/replay.py --mode focused --lean "$LEAN_BIN" \
  --packages "$PACKAGES" --build "$RUN/focused" --jobs 2
~~~

The optional `--mode native` keeps the literal upstream imports and requires a full Mathlib cache (`cd config && lake exe cache get Mathlib`). See the recorded runs for the extent actually tested. The Lean executable and third-party dependencies are prerequisites.

## Recorded runs on 21 November 2026

| Mode | What was rebuilt and checked | Evidence |
|---|---|---|
| Named | 176 modules, including all 165 original module names, the import adapter and ten follow-up modules. Both final mixing-time proof terms passed. | [Full receipt](checks/named/receipt.json) · [Dependency log](checks/named/logs/DependencyAudit.log) |
| Focused | Two clean runs, each compiling the 165 upstream source bodies as one module plus ten follow-up modules. All eleven generated source, object and log hashes matched between runs. | [First receipt](checks/focused/receipt.json) · [Independent replay](checks/focused-independent/receipt.json) |
| Native | One original module, Definitions.lean, compiled with its literal Mathlib umbrella import. A complete 165-module native build was not run. | [Probe](checks/native-probe/probe.json) |

Every full run used fresh graph objects and a previously prepared, pinned third-party cache. All 18 reported declarations have only `propext`, `Classical.choice` and `Quot.sound` as axioms. The [run index](checks/runs.json) gives UTC timestamps, timings and hashes. These are local reproductions, independent of any public comparator service or human review.

## What is formalized

The graph endpoints below use prefix `OAI.Problem315.` for public family 131. Compare the original [graph space, proposal and mixing definitions](upstream/OAI/Probability/SwitchChain/Definitions.lean) and [Theorem 1.1 endpoint](upstream/OAI/Probability/SwitchChain/Main.lean) with the new [graph comparison](lean/SharpSwitch.lean), [uniform endpoint](lean/VerifiedSwitch.lean) and [sharp endpoint](lean/SharpSliceRoute.lean).

| Mathematical assertion | Lean declaration or scope |
|---|---|
| Uniform slice gap ≥ 2 | `InvolutionGap.quarter_variance` and `ConcreteJohnson.variance_le_quarter_swap_squared_differences`. The proof uses an antisymmetric difference of a moved eigenfunction. |
| Nonconstant slice gap exactly N | `ExactJohnson.eigen_ge_card`, `ExactJohnson.sharp_slice_inequality` and `ExactJohnson.exact_gap` (including an attaining coordinate mode). |
| Poincaré gap ≥ 1/Q and TV ≤ √M exp(−t/Q)/2 | `VerifiedSwitch.switch_gap` and `VerifiedSwitch.switch_tv`, where Q = 12 C(n,4), M is the number of realizations, and P is the upstream kernel. |
| Mixing time ≤ n⁶ through the uniform route | `VerifiedSwitch.switch_mixing`. The proof term uses the uniform slice inequality. |
| Mixing time ≤ n⁶ through the sharp route | `SharpSliceRoute.switch_mixing`. The proof term uses the sharp all-N inequality, handles N ≤ 1 separately, and shares the graph comparison and mixing estimate with the uniform route. |

The random paths on page 1, the filtration and the two-state example on page 3 are written proofs. See the [proof-term audit](lean/DependencyAudit.lean) for the two formal routes and their shared upstream inputs. The formal arithmetic uses M ≤ 2^(n²); the written proof uses M ≤ 2^C(n,2).

## Origin and credit

OpenAI, *Polynomial mixing of the switch chain for every graphical degree sequence*, 25 September 2026. The official 22-page PDF has SHA-256 `e70eab92c1315e6706eea3613e9826871e009d1ef8de31f82d5750d026240af3`. All source references are pinned to commit `4eaee87548250b2682affda7d05d947c05554bae`. [Original manuscript and TeX](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/preprints/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026) · [Graph formalization](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/lean/OAI/Probability/SwitchChain) · [Upstream scope record](https://github.com/openai/math/blob/4eaee87548250b2682affda7d05d947c05554bae/lean/docs/131.md)

The 165 modules in `upstream/` are OpenAI's, distributed under the original [Apache License 2.0](LICENSE). [Provenance](PROVENANCE.md) identifies reused fragments, toolchain and commit pins; [the source lock](config/source-lock.json) lists every file and hash.

Public byline: [                    ]. The initiating contributor set the question, directed the comparisons and selected the scope. ChatGPT/Codex drafted and revised the arguments, Lean extensions, exposition and tooling. A separate AI review checked the written proofs. No independent human mathematical sign-off is recorded for this follow-up.

## Rebuild the PDF

From the kit root, run the following with pdfLaTeX, Latin Modern, amsmath, amssymb, geometry, booktabs and hyperref installed.

~~~bash
(cd paper && pdflatex -halt-on-error note.tex && pdflatex -halt-on-error note.tex)
~~~
