# Replaying the graph proof

From the root of this kit, use Python 3.10+, Git, the pinned Lean executable, and the compiled third-party packages specified in `config/lake-manifest.json`. For a new local dependency cache with network access, copy `config/lakefile.lean`, `config/lake-manifest.json` and `config/lean-toolchain` into an empty directory and run `lake exe cache get` there with the pinned toolchain. Lake uses the included manifest. For the verification itself the package cache already needs to exist and the replay runs offline.

```bash
python3 scripts/replay.py --mode named \
  --lean /path/to/lean-4.34.1/bin/lean \
  --packages /path/to/project/.lake/packages \
  --build /tmp/switch-chain-named --jobs 2
```

Choose an empty output directory for each run. To generate a smaller number of build objects, change `named` to `focused`. Each worker invokes Lean with `-j1 -DElab.async=false -DautoImplicit=false`.

| Mode | Upstream module structure | Source treatment |
|---|---|---|
| `named` | All 165 original OAI module names and import edges between them, including the original Main module | Exactly 36 occurrences of the broad `import Mathlib` header become `import GraphMathlibImports`. Its 30 imports are listed in `config/focused-imports.txt`. All upstream declaration bodies are retained. The original and the new local declarations have their own defining modules. |
| `focused` | A generated `SourceFocused` module with an explicit section per original file | In dependency order, remove original import lines and put the remaining text unchanged in each section. A deterministic source map in the output directory associates each section with the original module. Generated versions of two extension files point their upstream import there. |
| `native` | All 165 original OAI module names | Every byte of the 165 upstream input files is copied unchanged. This mode uses the full Mathlib umbrella in each relevant import closure and may require substantial time and memory. See the executed checks below for its test scope. |

`scripts/replay.py` validates the input/source hashes and scans new Lean sources for explicit `sorry`, `admit`, and axiom declarations. At the end it requires 18 axiom printouts across eight modules to contain exactly `propext`, `Classical.choice`, and `Quot.sound`. It also checks both endpoint dependency audits. The result is `receipt.json` in your output directory, with individual timings, source hashes, object hashes and log hashes. Some modules produce Lean style-linter notices. Source hashes and mathematical checks are appropriate for comparison across operating systems or build modes. Serialized artifact hashes are recorded for the particular run.

## Drop-in use

Add the ten files from `lean/` to the Lean source search path of the pinned OpenAI project. `VerifiedSwitch.lean` imports `SharpSwitch`, which imports the original `OAI.Probability.SwitchChain.Main`; `SliceGap.lean` imports the original `OAI.Probability.SwitchChain.SlicePathComparison`. Import `VerifiedSwitch` for the strengthened Poincaré, arbitrary-time TV and mixing estimates. Import `SharpSliceRoute` to use the alternative sharp-fiber proof; import `DependencyAudit` to run the proof-dependency tests. For the exact all- N statement and eigenvector, import `SliceGap`.

The declarations `OAI.Problem315.VerifiedSwitch.switch_gap`, `switch_tv` and `switch_mixing` quantify over every graphical degree vector on `Fin n` with `4 ≤ n`, using the actual `switchKernel`, `tvDistanceFrom`, `MixedAt` and `mixingTime` of the source. The single-state case is included under the source’s Poincaré formulation. This proof establishes the specified chain estimates. The exact uniform sampling algorithm in the original manuscript is a separate result.

## Inspecting the receipts

Run `python3 scripts/check_receipts.py` from the extracted kit to check the retained logs and source hashes without requiring Lean. This recomputes the two upstream hashes for every original source file, checks the four copied slice fragments, scans all supplied project Lean files for placeholder and axiom tokens, and reconstructs each mode's source files in a temporary directory. It compares them with the actual inputs recorded by the compiler runs and verifies the axiom printouts and dependency reports. A full replay also rebuilds every project object.

`checks/runs.json` records each completed build's ISO 8601 UTC interval, worker count, elapsed time, and receipt hash. `checks/named/` contains the separate-name run. `checks/focused/` and `checks/focused-independent/` contain the independent clean runs of the generated layout. `checks/native-probe/probe.json` records the individual unmodified Mathlib-umbrella probe. All named/focused builds use the same locked toolchain and dependency packages.
