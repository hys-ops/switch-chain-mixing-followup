import InvolutionGap
import Mathlib.GroupTheory.Perm.Sign
import Mathlib.Tactic.Group
import Mathlib.Data.Fintype.Powerset

-- The following slice and action declarations use the pinned source's terms verbatim.
-- Their separate namespace allows the original modules to coexist with this independent check.
namespace ConcreteJohnson
noncomputable section
open scoped BigOperators RealInnerProductSpace
variable {α : Type*} [sectionFintypeα : Fintype α] [sectionDecidableEqα : DecidableEq α]
theorem exists_perm_map_eq (s t : Finset α) (hcard : s.card = t.card) :
    ∃ σ : Equiv.Perm α, s.map σ.toEmbedding = t := by
  classical
  let e : s ≃ t := Fintype.equivOfCardEq (by simpa using hcard)
  let σ : Equiv.Perm α := e.extendSubtype
  refine ⟨σ, Finset.eq_of_subset_of_card_le ?_ ?_⟩
  · intro y hy
    obtain ⟨x, hx, rfl⟩ := Finset.mem_map.mp hy
    exact e.extendSubtype_mem x hx
  · simpa using hcard.ge

abbrev Slice (α : Type*) (q : ℕ) := {s : Finset α // s.card = q}

def relabel {q : ℕ} (σ : Equiv.Perm α) (s : Slice α q) : Slice α q :=
  ⟨s.val.map σ.toEmbedding, by simpa using s.property⟩

include sectionFintypeα sectionDecidableEqα in
@[simp] theorem relabel_one {q : ℕ} (s : Slice α q) : relabel 1 s = s := by
  have retainedsectionFintypeα := sectionFintypeα
  have retainedsectionDecidableEqα := sectionDecidableEqα
  apply Subtype.ext
  change s.val.map (Function.Embedding.refl α) = s.val
  exact Finset.map_refl

include sectionFintypeα sectionDecidableEqα in
@[simp] theorem relabel_mul {q : ℕ} (σ τ : Equiv.Perm α) (s : Slice α q) :
    relabel (σ * τ) s = relabel σ (relabel τ s) := by
  have retainedsectionFintypeα := sectionFintypeα
  have retainedsectionDecidableEqα := sectionDecidableEqα
  apply Subtype.ext
  simp only [relabel, Finset.map_map]
  rfl

def relabelEquiv {q : ℕ} (σ : Equiv.Perm α) : Equiv.Perm (Slice α q) where
  toFun := relabel σ
  invFun := relabel σ⁻¹
  left_inv s := by rw [← relabel_mul, inv_mul_cancel, relabel_one]
  right_inv s := by rw [← relabel_mul, mul_inv_cancel, relabel_one]

@[simp] theorem relabelEquiv_apply {q : ℕ} (σ : Equiv.Perm α) (s : Slice α q) :
    relabelEquiv σ s = relabel σ s := rfl

theorem exists_relabel_eq {q : ℕ} (s t : Slice α q) :
    ∃ σ : Equiv.Perm α, relabel σ s = t := by
  obtain ⟨σ, hσ⟩ := exists_perm_map_eq s.val t.val (s.property.trans t.property.symm)
  exact ⟨σ, Subtype.ext hσ⟩

def swaps : Finset (Equiv.Perm α) := by
  classical
  exact Finset.univ.filter Equiv.Perm.IsSwap

@[simp] theorem mem_swaps (σ : Equiv.Perm α) : σ ∈ swaps ↔ Equiv.Perm.IsSwap σ := by
  classical
  simp [swaps]

abbrev Move (α : Type*) [Fintype α] [DecidableEq α] := ↥(swaps (α := α))

def conjugate (a : Equiv.Perm α) (t : Move α) : Move α := by
  refine ⟨a * t.1 * a⁻¹, (mem_swaps _).2 ?_⟩
  obtain ⟨i,j,hij,e⟩ := (mem_swaps _).1 t.2
  rw [e, Equiv.mul_swap_eq_swap_mul, mul_inv_cancel_right]
  exact ⟨a i, a j, fun h => hij (a.injective h), rfl⟩

def conjEquiv (a : Equiv.Perm α) : Move α ≃ Move α where
  toFun := conjugate a
  invFun := conjugate a⁻¹
  left_inv t := by apply Subtype.ext; change a⁻¹ * (a * t.1 * a⁻¹) * (a⁻¹)⁻¹ = _; group
  right_inv t := by apply Subtype.ext; change a * (a⁻¹ * t.1 * (a⁻¹)⁻¹) * a⁻¹ = _; group

def move {q : ℕ} (t : Move α) : Equiv.Perm (Slice α q) := relabelEquiv t.1

theorem inv_move {q : ℕ} (t : Move α) (x : Slice α q) : move t (move t x) = x := by
  change relabel t.1 (relabel t.1 x) = x
  obtain ⟨a,b,_,e⟩ := (mem_swaps _).1 t.2
  rw [← relabel_mul, e, Equiv.swap_mul_self, relabel_one]

theorem central_move {q : ℕ} (a : Move α) (f : InvolutionGap.E (Slice α q)) :
    InvolutionGap.lap move (InvolutionGap.pull (move a) f) =
    InvolutionGap.pull (move a) (InvolutionGap.lap move f) := by
  ext x
  change (∑ t : Move α, (f (relabel a.1 x) - f (relabel a.1 (relabel t.1 x)))) =
    ∑ t : Move α, (f (relabel a.1 x) - f (relabel t.1 (relabel a.1 x)))
  apply Fintype.sum_equiv (conjEquiv a.1)
  intro t
  have eqm : ((conjEquiv a.1) t).1 * a.1 = a.1 * t.1 := by
    change (a.1 * t.1 * a.1⁻¹) * a.1 = a.1 * t.1
    group
  simp only [← relabel_mul, eqm]

theorem connected_move {q : ℕ} [Nonempty (Slice α q)] (f : Slice α q → ℝ)
    (hh : ∀ (t : Move α) x, f (move t x) = f x) (x y : Slice α q) : f x = f y := by
  obtain ⟨σ,hσ⟩ := exists_relabel_eq x y
  have hi (g : Equiv.Perm α) : ∀ u : Slice α q, f (relabel g u) = f u := by
    induction g using Equiv.Perm.swap_induction_on with
    | one => intro u; rw [relabel_one]
    | swap_mul g a b hab ih =>
      intro u
      have hh' : f (relabel (Equiv.swap a b) (relabel g u)) = f (relabel g u) :=
        hh ⟨Equiv.swap a b, (mem_swaps _).2 ⟨a,b,hab,rfl⟩⟩ (relabel g u)
      rw [relabel_mul, hh', ih]
  simpa only [hσ] using (hi σ x).symm

theorem variance_le_quarter_swap_squared_differences {q : ℕ} [Nonempty (Slice α q)]
    (f : Slice α q → ℝ) :
    (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ)) ^ 2) ≤
      (1/4 : ℝ) * ∑ σ ∈ swaps, ∑ s, (f s - f (relabel σ s)) ^ 2 := by
  have h := InvolutionGap.quarter_variance move inv_move central_move connected_move f
  rw [← Finset.sum_coe_sort (swaps (α := α))
    (fun σ => ∑ s, (f s - f (relabel σ s)) ^ 2)]
  exact h

#print axioms variance_le_quarter_swap_squared_differences
end
end ConcreteJohnson
