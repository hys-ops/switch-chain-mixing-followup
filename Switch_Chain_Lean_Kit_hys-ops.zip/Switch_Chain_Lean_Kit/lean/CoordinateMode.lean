import SharpVariance

noncomputable section
open scoped BigOperators RealInnerProductSpace
open ConcreteJohnson InvolutionGap
namespace ExactJohnson
variable {α : Type*} [Fintype α] [DecidableEq α] {q : ℕ}

theorem swap_sum_at_coordinate (c : α → ℝ) (a : α) :
    (∑ σ ∈ swaps, (c a - c (σ a))) = (Fintype.card α : ℝ) * c a - ∑ k, c k := by
  classical
  let K := Finset.univ.erase a
  let A := K.image (Equiv.swap a)
  have hsub : A ⊆ swaps := by
    intro σ hσ
    obtain ⟨k,hk,rfl⟩ := Finset.mem_image.mp hσ
    exact (mem_swaps _).2 ⟨a,k,(Finset.mem_erase.mp hk).1.symm,rfl⟩
  have hnot (σ : Equiv.Perm α) (hs : σ ∈ swaps) (hn : σ ∉ A) : σ a = a := by
    obtain ⟨i,j,hij,rfl⟩ := (mem_swaps _).1 hs
    by_cases hi : a = i
    · subst i
      exact False.elim (hn (Finset.mem_image.mpr ⟨j,
        Finset.mem_erase.mpr ⟨hij.symm,Finset.mem_univ _⟩,rfl⟩))
    by_cases hj : a = j
    · subst j
      exact False.elim (hn (Finset.mem_image.mpr ⟨i,
        Finset.mem_erase.mpr ⟨hij,Finset.mem_univ _⟩,Equiv.swap_comm _ _⟩))
    exact Equiv.swap_apply_of_ne_of_ne hi hj
  have he := Finset.sum_subset (f := fun σ : Equiv.Perm α => c a - c (σ a)) hsub
    (fun σ hσ hn => by rw [hnot σ hσ hn, sub_self])
  rw [← he]
  change (∑ σ ∈ K.image (Equiv.swap a), (c a - c (σ a))) = _
  rw [Finset.sum_image (Equiv.swap_injective_of_left a).injOn]
  simp only [Equiv.swap_apply_left]
  have hh := Finset.sum_erase_add (s := (Finset.univ : Finset α))
    (fun k => c a - c k) (Finset.mem_univ a)
  simp only [sub_self, add_zero] at hh
  change (∑ k ∈ Finset.univ.erase a, (c a - c k)) = _
  rw [hh, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]

def val (a : α) (x : Slice α q) : ℝ := if a ∈ x.1 then 1 else 0

theorem val_relabel (a : α) (x : Slice α q) (σ : Equiv.Perm α) (hs : σ ∈ swaps) :
    val a (relabel σ x) = val (σ a) x := by
  obtain ⟨b,c,_,rfl⟩ := (mem_swaps _).1 hs
  simp only [val, mem_relabel_swap]

def mode (a b : α) : E (Slice α q) := WithLp.toLp 2 (fun x => val a x - val b x)

theorem coordinate_eigen (a b : α) :
    lap move (mode (q := q) a b) = (Fintype.card α : ℝ) • mode a b := by
  ext x
  change (∑ σ : Move α, ((val a x - val b x) -
      (val a (relabel σ.1 x) - val b (relabel σ.1 x)))) =
    (Fintype.card α : ℝ) * (val a x - val b x)
  rw [Finset.sum_coe_sort (swaps (α := α)) (fun σ =>
    (val a x - val b x) - (val a (relabel σ x) - val b (relabel σ x)))]
  have ht (σ : Equiv.Perm α) (h : σ ∈ swaps) :
      (val a x - val b x) - (val a (relabel σ x) - val b (relabel σ x)) =
      (val a x - val (σ a) x) - (val b x - val (σ b) x) := by
    rw [val_relabel a x σ h, val_relabel b x σ h]; ring
  rw [Finset.sum_congr rfl ht, Finset.sum_sub_distrib,
    swap_sum_at_coordinate (fun k => val k x) a, swap_sum_at_coordinate (fun k => val k x) b]
  ring

theorem exists_attaining_mode (hq : 0 < q) (hN : q < Fintype.card α) :
    ∃ g : E (Slice α q), g ≠ 0 ∧ (∑ x, g x) = 0 ∧ lap move g = (Fintype.card α : ℝ) • g := by
  classical
  obtain ⟨u,_,hu⟩ := Finset.exists_subset_card_eq (s := (Finset.univ : Finset α)) (by simpa using hN.le)
  let x : Slice α q := ⟨u,hu⟩
  obtain ⟨a,ha⟩ := Finset.card_pos.mp (hu.symm ▸ hq)
  have hbex : ∃ b : α, b ∉ u := by
    by_contra! he
    have hfull : u = Finset.univ := Finset.eq_univ_of_forall he
    rw [hfull, Finset.card_univ] at hu
    omega
  obtain ⟨b,hb⟩ := hbex
  let g := mode (q := q) a b
  have hg : g ≠ 0 := by
    intro he
    have hh := congrArg (fun v : E (Slice α q) => v x) he
    change (if a ∈ u then (1:ℝ) else 0) - (if b ∈ u then 1 else 0) = 0 at hh
    simpa [ha, hb] using hh
  have he := coordinate_eigen (q := q) a b
  refine ⟨g,hg,?_,he⟩
  have hzero : (∑ x, lap move g x) = 0 := by
    simp only [lap_apply]
    rw [Finset.sum_comm]
    apply Finset.sum_eq_zero
    intro i _
    rw [Finset.sum_sub_distrib, Equiv.sum_comp (move i) g, sub_self]
  have hscalar : (Fintype.card α : ℝ) * (∑ x, g x) = 0 := by
    rw [Finset.mul_sum]
    change ∑ x, (((Fintype.card α : ℝ) • g) x) = 0
    rw [← he]; exact hzero
  exact (mul_eq_zero.mp hscalar).resolve_left (by exact_mod_cast (lt_trans hq hN).ne')

theorem exact_gap (hq : 0 < q) (hN : q < Fintype.card α) :
    (∀ (lam : ℝ) (g : E (Slice α q)), g ≠ 0 → (∑ x, g x) = 0 →
      lap move g = lam • g → (Fintype.card α : ℝ) ≤ lam) ∧
    (∃ g : E (Slice α q), g ≠ 0 ∧ (∑ x, g x) = 0 ∧
      lap move g = (Fintype.card α : ℝ) • g) := by
  classical
  refine ⟨?_, exists_attaining_mode hq hN⟩
  intro lam g hg hc he
  obtain ⟨u,_,hu⟩ := Finset.exists_subset_card_eq (s := (Finset.univ : Finset α))
    (by simpa using hN.le)
  let x₀ : Slice α q := ⟨u,hu⟩
  letI : Nonempty (Slice α q) := ⟨x₀⟩
  by_cases hh : ∃ (i : Move α) (x : Slice α q), g x ≠ g (move i x)
  · obtain ⟨i,x,hx⟩ := hh
    exact eigen_ge_card lam g he i x hx
  · push Not at hh
    have hi := connected_move (f := (g : Slice α q → ℝ)) (fun i x => (hh i x).symm)
    have hconst : (∑ x, g x) = (Fintype.card (Slice α q) : ℝ) * g x₀ := by
      calc
        _ = ∑ _x : Slice α q, g x₀ := Finset.sum_congr rfl fun x _ => hi x x₀
        _ = _ := by simp
    have hsize : (Fintype.card (Slice α q) : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
    rw [hconst] at hc
    have hz := (mul_eq_zero.mp hc).resolve_left hsize
    exfalso
    apply hg
    ext x
    change g x = 0
    exact (hi x x₀).trans hz

#print axioms coordinate_eigen
#print axioms exists_attaining_mode
#print axioms exact_gap
end ExactJohnson
