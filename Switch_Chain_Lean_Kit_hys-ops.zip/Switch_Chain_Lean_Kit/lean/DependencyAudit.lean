import VerifiedSwitch
import SharpSliceRoute
import Lean.Util.FoldConsts

open Lean

namespace SwitchDependencyAudit

private def localModule (env : Environment) (n : Name) : Bool := Id.run do
  let some i := env.getModuleIdxFor? n | return false
  let m := env.allImportedModuleNames[i.toNat]!
  return m == `SourceFocused || m.toString.startsWith "OAI.Probability.SwitchChain." ||
    [`SharpSwitch, `VerifiedSwitch, `SharpSliceRoute, `InvolutionGap, `ConcreteJohnson,
     `ExactJohnson, `SharpVariance, `CoordinateMode, `SliceGap].contains m

/-- Traverse both the types and proof bodies of every project declaration, including
private declarations and elaborator auxiliaries, identified by defining module. -/
private partial def inspect (env : Environment) (todo : List Name) (seen : NameSet) : NameSet :=
  match todo with
  | [] => seen
  | n :: rest =>
    if seen.contains n || !localModule env n then inspect env rest seen
    else
      let more := (env.find? n).map (fun info => info.getUsedConstantsAsSet.toList) |>.getD []
      inspect env (more ++ rest) (seen.insert n)

run_cmd
  let env ← getEnv
  let common := [`OAI.Problem315.PairResampling.uniformVariance_le_generator,
    `OAI.Problem315.PairResampling.tripleGenerator_square,
    `OAI.Problem315.PairEquality.actual_named_interaction,
    `OAI.Problem315.PairEquality.pair_projection_budget,
    `OAI.Problem315.PairFiber.assignment_swap_squared_differences_le_proposals,
    `OAI.Problem315.PairSquaredEnergy.pairSwitchLaplacian_energy]
  let former := [`OAI.Problem315.switch_chain_main, `OAI.Problem315.switch_chain_tv_bound,
    `OAI.Problem315.SlicePathComparison.variance_le_swap_squared_differences,
    `OAI.Problem315.PairFiber.assignment_variance_le_swap_squared_differences,
    `OAI.Problem315.PairFiber.inner_fluctuation_le_pairSwitchLaplacian]
  let involution := [`InvolutionGap.quarter_variance,
    `ConcreteJohnson.variance_le_quarter_swap_squared_differences]
  let sharp := [`ExactJohnson.sharp_slice_inequality, `ExactJohnson.eigen_ge_card,
    `ExactJohnson.lower_on_antisymmetric]
  for (target, req, ban) in
    [(`OAI.Problem315.VerifiedSwitch.switch_mixing, common ++ involution, former ++ sharp),
     (`OAI.Problem315.SharpSliceRoute.switch_mixing, common ++ sharp, former ++ involution)] do
    let seen := inspect env [target] {}
    logInfo m!"target {target}"
    for n in req do
      unless seen.contains n do throwError "missing required dependency {n}"
      logInfo m!"uses {n}"
    for n in ban do
      if seen.contains n then throwError "unexpected old/sibling dependency {n}"
      logInfo m!"bypasses {n}"

end SwitchDependencyAudit
