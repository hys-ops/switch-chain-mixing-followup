import ConcreteJohnson
import Mathlib.Tactic.Tauto

namespace ExactJohnson
noncomputable section
open scoped BigOperators RealInnerProductSpace
open ConcreteJohnson

variable {α : Type*} [Fintype α] [DecidableEq α] {q : ℕ}

theorem mem_relabel_swap (a b z : α) (x : Slice α q) :
    z ∈ (relabel (Equiv.swap a b) x).1 ↔ Equiv.swap a b z ∈ x.1 :=
  Finset.mem_map_equiv

theorem fixed_of_same (a b : α) (x : Slice α q) (h : a ∈ x.1 ↔ b ∈ x.1) :
    relabel (Equiv.swap a b) x = x := by
  apply Subtype.ext
  ext z
  rw [mem_relabel_swap]
  by_cases ha : z = a
  · subst z; simpa only [Equiv.swap_apply_left] using h.symm
  by_cases hb : z = b
  · subst z; simpa only [Equiv.swap_apply_right] using h
  rw [Equiv.swap_apply_of_ne_of_ne ha hb]

theorem local_pair (a b k : α) (hab : a ≠ b) (hak : a ≠ k) (hbk : b ≠ k)
    (g : Slice α q → ℝ)
    (hz : ∀ x : Slice α q, (a ∈ x.1 ↔ b ∈ x.1) → g x = 0)
    (x : Slice α q) :
    g x * (g x - g (relabel (Equiv.swap a k) x)) +
      g x * (g x - g (relabel (Equiv.swap b k) x)) = (g x)^2 := by
  by_cases h : a ∈ x.1 ↔ b ∈ x.1
  · rw [hz x h]; ring
  by_cases h' : a ∈ x.1 ↔ k ∈ x.1
  · have hm : g (relabel (Equiv.swap b k) x) = 0 := by
      apply hz
      simpa only [mem_relabel_swap, Equiv.swap_apply_left,
        Equiv.swap_apply_of_ne_of_ne hab hak] using h'
    rw [fixed_of_same a k x h', hm]; ring
  · have h'' : b ∈ x.1 ↔ k ∈ x.1 := by tauto
    have hm : g (relabel (Equiv.swap a k) x) = 0 := by
      apply hz
      simpa only [mem_relabel_swap, Equiv.swap_apply_left,
        Equiv.swap_apply_of_ne_of_ne hab.symm hbk] using h''.symm
    rw [fixed_of_same b k x h'', hm]; ring

def other (a b : α) : Finset α := (Finset.univ.erase a).erase b

theorem mem_other (a b k : α) : k ∈ other a b ↔ k ≠ a ∧ k ≠ b := by
  simp [other, and_comm]

theorem card_other (a b : α) (hab : a ≠ b) :
    (other a b).card + 2 = Fintype.card α := by
  have h₂ : 1 < (Finset.univ : Finset α).card :=
    Finset.one_lt_card.mpr ⟨a, Finset.mem_univ _, b, Finset.mem_univ _, hab⟩
  simp only [Finset.card_univ] at h₂
  unfold other
  rw [Finset.card_erase_of_mem (Finset.mem_erase.mpr ⟨hab.symm, Finset.mem_univ _⟩),
    Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ]
  omega

theorem star_sum_le (a b : α) (hab : a ≠ b) (w : Equiv.Perm α → ℝ)
    (hw : ∀ σ, 0 ≤ w σ) :
    w (Equiv.swap a b) +
      (∑ k ∈ other a b, (w (Equiv.swap a k) + w (Equiv.swap b k))) ≤
      ∑ σ ∈ swaps, w σ := by
  classical
  let K := other a b
  let A := K.image (Equiv.swap a)
  let B := K.image (Equiv.swap b)
  have hk (k : α) (h : k ∈ K) : k ≠ a ∧ k ≠ b := (mem_other a b k).1 h
  have hd : Disjoint A B := by
    apply Finset.disjoint_left.mpr
    intro s ha hb
    obtain ⟨k,hk',rfl⟩ := Finset.mem_image.mp ha
    obtain ⟨l,hl,he⟩ := Finset.mem_image.mp hb
    have h := congrArg (fun σ : Equiv.Perm α => σ a) he
    change Equiv.swap b l a = Equiv.swap a k a at h
    rw [Equiv.swap_apply_of_ne_of_ne hab (hk l hl).1.symm, Equiv.swap_apply_left] at h
    exact (hk k hk').1 h.symm
  have hn : Equiv.swap a b ∉ A ∪ B := by
    intro hm
    rcases Finset.mem_union.mp hm with h | h
    · obtain ⟨k,hk',he⟩ := Finset.mem_image.mp h
      exact (hk k hk').2 (Equiv.swap_injective_of_left a he)
    · obtain ⟨k,hk',he⟩ := Finset.mem_image.mp h
      have h := congrArg (fun σ : Equiv.Perm α => σ a) he
      change Equiv.swap b k a = Equiv.swap a b a at h
      rw [Equiv.swap_apply_of_ne_of_ne hab (hk k hk').1.symm, Equiv.swap_apply_left] at h
      exact hab h
  have hsub : insert (Equiv.swap a b) (A ∪ B) ⊆ swaps := by
    intro s hs
    apply (mem_swaps _).2
    rcases Finset.mem_insert.mp hs with e | h
    · exact ⟨a,b,hab,e⟩
    rcases Finset.mem_union.mp h with h | h
    · obtain ⟨k,hk',rfl⟩ := Finset.mem_image.mp h
      exact ⟨a,k,(hk k hk').1.symm,rfl⟩
    · obtain ⟨k,hk',rfl⟩ := Finset.mem_image.mp h
      exact ⟨b,k,(hk k hk').2.symm,rfl⟩
  have h := Finset.sum_le_sum_of_subset_of_nonneg (f := w) hsub (fun s _ _ => hw s)
  rw [Finset.sum_insert hn, Finset.sum_union hd] at h
  have ha : (∑ s ∈ A, w s) = ∑ k ∈ K, w (Equiv.swap a k) :=
    Finset.sum_image (Equiv.swap_injective_of_left a).injOn
  have hb : (∑ s ∈ B, w s) = ∑ k ∈ K, w (Equiv.swap b k) :=
    Finset.sum_image (Equiv.swap_injective_of_left b).injOn
  rw [ha,hb,← Finset.sum_add_distrib] at h
  exact h

def weight (g : InvolutionGap.E (Slice α q)) (σ : Equiv.Perm α) : ℝ :=
    ∑ x, g x * (g x - g (relabel σ x))

theorem weight_nonneg (g : InvolutionGap.E (Slice α q)) (σ : Equiv.Perm α) :
    0 ≤ weight g σ := by
  have hnorm : (∑ x : Slice α q, (g (relabel σ x))^2) = ∑ x, (g x)^2 :=
    Equiv.sum_comp (relabelEquiv σ) (fun x => (g x)^2)
  have h : 0 ≤ ∑ x, (g x - g (relabel σ x))^2 :=
    Finset.sum_nonneg fun _ _ => sq_nonneg _
  simp only [sub_sq, Finset.sum_add_distrib, Finset.sum_sub_distrib,
    mul_assoc, ← Finset.mul_sum, hnorm] at h
  simp only [weight, mul_sub, ← sq, Finset.sum_sub_distrib]
  linarith

theorem inner_as_weights (g : InvolutionGap.E (Slice α q)) :
    ⟪g, InvolutionGap.lap move g⟫ = ∑ σ ∈ swaps, weight g σ := by
  rw [← Finset.sum_coe_sort (swaps (α := α)) (weight g), InvolutionGap.inner_as_sum]
  simp only [InvolutionGap.lap_apply, Finset.mul_sum]
  exact Finset.sum_comm

theorem lower_on_antisymmetric (g : InvolutionGap.E (Slice α q))
    (a b : α) (hab : a ≠ b)
    (hanti : ∀ x, g (relabel (Equiv.swap a b) x) = - g x) :
    (Fintype.card α : ℝ) * ‖g‖ ^ 2 ≤ ⟪g, InvolutionGap.lap move g⟫ := by
  classical
  have hz (x : Slice α q) (hh : a ∈ x.1 ↔ b ∈ x.1) : g x = 0 := by
    have h := hanti x
    rw [fixed_of_same a b x hh] at h
    linarith
  have hs := star_sum_le a b hab (weight g) (weight_nonneg g)
  rw [← inner_as_weights] at hs
  have hone : weight g (Equiv.swap a b) = 2 * ‖g‖^2 := by
    rw [InvolutionGap.norm_sq_as_sum, Finset.mul_sum]
    exact Finset.sum_congr rfl fun x _ => by rw [hanti]; ring
  have hpair (k : α) (hk : k ∈ other a b) :
      weight g (Equiv.swap a k) + weight g (Equiv.swap b k) = ‖g‖^2 := by
    rw [weight, weight, ← Finset.sum_add_distrib, InvolutionGap.norm_sq_as_sum]
    exact Finset.sum_congr rfl fun x _ => local_pair a b k hab
      ((mem_other a b k).1 hk).1.symm ((mem_other a b k).1 hk).2.symm g hz x
  rw [hone, Finset.sum_congr rfl hpair, Finset.sum_const, nsmul_eq_mul] at hs
  have hcard : ((other a b).card : ℝ) + 2 = Fintype.card α := by
    exact_mod_cast card_other a b hab
  rw [← hcard]; linarith only [hs]

theorem eigen_ge_card (lam : ℝ) (f : InvolutionGap.E (Slice α q))
    (he : InvolutionGap.lap move f = lam • f) (i : Move α) (x₀ : Slice α q)
    (hm : f x₀ ≠ f (move i x₀)) : (Fintype.card α : ℝ) ≤ lam := by
  classical
  let g := f - InvolutionGap.pull (move i) f
  have hg (x : Slice α q) : g x = f x - f (move i x) := rfl
  have hg0 : g ≠ 0 := by
    intro hz
    have h := congrArg (fun v : InvolutionGap.E (Slice α q) => v x₀) hz
    exact hm (sub_eq_zero.mp h)
  have he' : InvolutionGap.lap move g = lam • g := by
    change InvolutionGap.lap move (f - InvolutionGap.pull (move i) f) = _
    rw [map_sub, central_move, he]
    ext x
    change lam * f x - lam * f (move i x) = lam * (f x - f (move i x))
    ring
  obtain ⟨a,b,hab,hi⟩ := (mem_swaps _).1 i.2
  have hanti (x : Slice α q) : g (relabel (Equiv.swap a b) x) = -g x := by
    rw [← hi]
    change g (move i x) = -g x
    simp only [hg, inv_move]
    ring
  have h := lower_on_antisymmetric g a b hab hanti
  rw [he', inner_smul_right, real_inner_self_eq_norm_sq] at h
  exact (mul_le_mul_iff_left₀ (sq_pos_of_pos (norm_pos_iff.mpr hg0))).mp h

#print axioms lower_on_antisymmetric
#print axioms eigen_ge_card
end
end ExactJohnson
