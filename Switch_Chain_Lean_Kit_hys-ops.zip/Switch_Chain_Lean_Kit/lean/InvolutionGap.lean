import Mathlib.Analysis.InnerProductSpace.PiL2
import Mathlib.Analysis.InnerProductSpace.Spectrum
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Push

noncomputable section
open scoped BigOperators RealInnerProductSpace
namespace InvolutionGap

variable {X I : Type*} [Fintype X] [Fintype I]
abbrev E (X : Type*) := EuclideanSpace ℝ X

def lap (τ : I → Equiv.Perm X) : E X →ₗ[ℝ] E X where
  toFun f := WithLp.toLp 2 (fun x => ∑ i, (f x - f (τ i x)))
  map_add' f g := by
    ext x
    change (∑ i, ((f x + g x) - (f (τ i x) + g (τ i x)))) = _
    change _ = (∑ i, (f x - f (τ i x))) + ∑ i, (g x - g (τ i x))
    rw [← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl fun i _ => by ring
  map_smul' c f := by
    ext x
    change (∑ i, (c * f x - c * f (τ i x))) = c * ∑ i, (f x - f (τ i x))
    simp only [mul_sub, Finset.mul_sum]

@[simp] theorem lap_apply (τ : I → Equiv.Perm X) (f : E X) (x : X) :
    lap τ f x = ∑ i, (f x - f (τ i x)) := rfl

theorem inner_as_sum (f g : E X) : ⟪f,g⟫ = ∑ x, f x * g x := by
  simp only [PiLp.inner_apply, RCLike.inner_apply, conj_trivial, mul_comm]

theorem bilinear (τ : I → Equiv.Perm X) (hs : ∀ i x, τ i (τ i x) = x)
    (f g : E X) :
    2 * ⟪f, lap τ g⟫ =
      ∑ i, ∑ x, (f x - f (τ i x)) * (g x - g (τ i x)) := by
  rw [inner_as_sum]
  simp only [lap_apply, Finset.mul_sum]
  rw [Finset.sum_comm]
  apply Finset.sum_congr rfl
  intro i _
  have hid := Equiv.sum_comp (τ i) (fun x => f x * (g x - g (τ i x)))
  simp only [hs] at hid
  calc
    (∑ x, 2 * (f x * (g x - g (τ i x)))) =
        (∑ x, f x * (g x - g (τ i x))) + (∑ x, f x * (g x - g (τ i x))) := by
          rw [← Finset.sum_add_distrib]
          exact Finset.sum_congr rfl fun x _ => by ring
    _ = (∑ x, f x * (g x - g (τ i x))) + ∑ x, f (τ i x) * (g (τ i x) - g x) := by
          rw [hid]
    _ = _ := by
          rw [← Finset.sum_add_distrib]
          exact Finset.sum_congr rfl fun x _ => by ring

theorem norm_sq_as_sum (f : E X) : ‖f‖ ^ 2 = ∑ x, (f x) ^ 2 := by
  rw [← real_inner_self_eq_norm_sq, inner_as_sum]
  simp [sq]

theorem symmetric (τ : I → Equiv.Perm X) (hs : ∀ i x, τ i (τ i x) = x) :
    (lap τ).IsSymmetric := by
  intro f g
  rw [real_inner_comm]
  have h1 := bilinear τ hs g f
  have h2 := bilinear τ hs f g
  rw [show (∑ i, ∑ x, (g x - g (τ i x)) * (f x - f (τ i x))) =
      ∑ i, ∑ x, (f x - f (τ i x)) * (g x - g (τ i x)) by
        simp only [mul_comm]] at h1
  linarith

theorem energy (τ : I → Equiv.Perm X) (hs : ∀ i x, τ i (τ i x) = x)
    (f : E X) :
    2 * ⟪f, lap τ f⟫ = ∑ i, ∑ x, (f x - f (τ i x)) ^ 2 := by
  simpa only [sq] using bilinear τ hs f f

def pull (σ : Equiv.Perm X) (f : E X) : E X := WithLp.toLp 2 (fun x => f (σ x))

theorem eigen_gap (τ : I → Equiv.Perm X) (hs : ∀ i x, τ i (τ i x) = x)
    (hc : ∀ i (f : E X), lap τ (pull (τ i) f) = pull (τ i) (lap τ f))
    (lam : ℝ) (f : E X) (he : lap τ f = lam • f)
    (i : I) (x₀ : X) (hm : f x₀ ≠ f (τ i x₀)) : 2 ≤ lam := by
  classical
  let g := f - pull (τ i) f
  have hg (x : X) : g x = f x - f (τ i x) := rfl
  have hneg (x : X) : g (τ i x) = -g x := by simp only [hg, hs]; ring
  have hg0 : g ≠ 0 := by
    intro hz
    have h := congrArg (fun v : E X => v x₀) hz
    change f x₀ - f (τ i x₀) = 0 at h
    exact hm (sub_eq_zero.mp h)
  have he' : lap τ g = lam • g := by
    change lap τ (f - pull (τ i) f) = _
    rw [map_sub, hc, he]
    ext x
    change lam * f x - lam * f (τ i x) = lam * (f x - f (τ i x))
    ring
  have hsum := Finset.single_le_sum (s := (Finset.univ : Finset I))
    (f := fun j => ∑ x, (g x - g (τ j x)) ^ 2)
    (fun j _ => Finset.sum_nonneg fun x _ => sq_nonneg _) (Finset.mem_univ i)
  rw [← energy τ hs, he', inner_smul_right, real_inner_self_eq_norm_sq] at hsum
  have hone : (∑ x, (g x - g (τ i x)) ^ 2) = 4 * ‖g‖ ^ 2 := by
    rw [norm_sq_as_sum, Finset.mul_sum]
    exact Finset.sum_congr rfl fun x _ => by rw [hneg]; ring
  rw [hone] at hsum
  have hn : 0 < ‖g‖ ^ 2 := sq_pos_of_pos (norm_pos_iff.mpr hg0)
  by_contra! hbad
  have := mul_lt_mul_of_pos_right hbad hn
  nlinarith only [hsum, this]

theorem quarter_variance [Nonempty X]
    (τ : I → Equiv.Perm X) (hs : ∀ i x, τ i (τ i x) = x)
    (hc : ∀ i (f : E X), lap τ (pull (τ i) f) = pull (τ i) (lap τ f))
    (hconn : ∀ f : X → ℝ, (∀ i x, f (τ i x) = f x) → ∀ x y, f x = f y)
    (F : X → ℝ) :
    (∑ x, (F x - (∑ y, F y) / (Fintype.card X : ℝ)) ^ 2) ≤
      (1/4 : ℝ) * ∑ i, ∑ x, (F x - F (τ i x)) ^ 2 := by
  classical
  let μ : ℝ := (∑ x, F x) / Fintype.card X
  let f : E X := WithLp.toLp 2 (fun x => F x - μ)
  have hval (x : X) : f x = F x - μ := rfl
  have hcenter : ∑ x, f x = 0 := by
    have hsize : (Fintype.card X : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
    simp only [hval, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, μ]
    field_simp
    <;> ring
  let hT := symmetric τ hs
  let b := hT.eigenvectorBasis (rfl : Module.finrank ℝ (E X) = Module.finrank ℝ (E X))
  let ev := hT.eigenvalues (rfl : Module.finrank ℝ (E X) = Module.finrank ℝ (E X))
  have he (j : Fin (Module.finrank ℝ (E X))) : lap τ (b j) = ev j • b j :=
    hT.apply_eigenvectorBasis rfl j
  have hnorm : 2 * ‖f‖ ^ 2 ≤ ⟪f, lap τ f⟫ := by
    rw [← b.sum_sq_inner_right f, ← b.sum_inner_mul_inner f (lap τ f), Finset.mul_sum]
    apply Finset.sum_le_sum
    intro j _
    have hd : ⟪b j, lap τ f⟫ = ev j * ⟪b j, f⟫ := by
      rw [← hT (b j) f, he, inner_smul_left]
      simp
    rw [hd, real_inner_comm f (b j)]
    by_cases hfix : ∀ i x, b j (τ i x) = b j x
    · let x₀ := Classical.choice (inferInstance : Nonempty X)
      have h := hconn (b j) hfix
      have hz : ⟪b j, f⟫ = 0 := by
        rw [inner_as_sum]
        calc
          (∑ x, b j x * f x) = ∑ x, b j x₀ * f x :=
            Finset.sum_congr rfl fun x _ => by rw [h x x₀]
          _ = 0 := by rw [← Finset.mul_sum, hcenter, mul_zero]
      have hz' : ⟪f, b j⟫ = 0 := (real_inner_comm _ _).trans hz
      simp only [hz, hz', zero_pow (by decide : 2 ≠ 0), mul_zero, zero_mul, le_refl]
    · push Not at hfix
      obtain ⟨i,x,hx⟩ := hfix
      have hge := eigen_gap τ hs hc (ev j) (b j) (he j) i x (Ne.symm hx)
      have hsmt : ⟪f, b j⟫ = ⟪b j, f⟫ := real_inner_comm _ _
      simp only [hsmt]
      nlinarith only [mul_nonneg (sub_nonneg.mpr hge) (sq_nonneg ⟪b j, f⟫)]
  have hin := energy τ hs f
  rw [norm_sq_as_sum] at hnorm
  simp only [hval, sub_sub_sub_cancel_right] at hnorm hin
  change (∑ x, (F x - μ) ^ 2) ≤ _
  linarith

#print axioms eigen_gap
#print axioms quarter_variance
end InvolutionGap
