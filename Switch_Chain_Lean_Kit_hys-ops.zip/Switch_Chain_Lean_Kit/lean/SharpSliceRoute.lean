import SharpSwitch
import SliceGap

namespace OAI.Problem315.SharpSliceRoute

open SlicePermutationAction SlicePathComparison

/-- The sharp factor 2N supplies the uniform factor four. For N ≤ 1
transitive relabeling fixes every state and the centered sum is zero. -/
theorem slice_variance : SharpSwitch.SliceVariance := by
  classical
  intro α _ _ q _ f
  by_cases hN : 2 ≤ Fintype.card α
  · have h := SliceGap.sharp_variance f
    change 2 * (Fintype.card α : ℝ) *
      (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ))^2) ≤
      ∑ σ ∈ swaps, ∑ s, (f s - f (relabel σ s))^2 at h
    have hr : (2 : ℝ) ≤ Fintype.card α := by exact_mod_cast hN
    have hv : 0 ≤ ∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ))^2 :=
      Finset.sum_nonneg fun s _ => sq_nonneg _
    nlinarith [mul_nonneg (sub_nonneg.mpr hr) hv]
  · have hsub : Subsingleton α := Fintype.card_le_one_iff_subsingleton.mp (by omega)
    have collapse (s t : Slice α q) : s = t := by
      obtain ⟨σ,hσ⟩ := exists_relabel_eq s t
      have h1 : σ = 1 := Equiv.ext fun _ => hsub.elim _ _
      simpa only [h1, relabel_one] using hσ
    have hc : (Fintype.card (Slice α q) : ℝ) ≠ 0 := by
      exact_mod_cast Fintype.card_ne_zero
    have hm (s : Slice α q) : (∑ t, f t) / (Fintype.card (Slice α q) : ℝ) = f s := by
      have he : (∑ t, f t) = ∑ _t : Slice α q, f s :=
        Finset.sum_congr rfl fun t _ => congrArg f (collapse t s)
      rw [he, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
      field_simp
    have hz : (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ))^2) = 0 :=
      Finset.sum_eq_zero fun s _ => by rw [hm s, sub_self]; norm_num
    rw [hz]
    positivity

/-- The same endpoint, this time passing through the all-N sharp slice theorem. -/
theorem switch_mixing {n : ℕ} {d : Fin n → ℕ} (hn : 4 ≤ n) (hd : Graphical n d) :
    ∃ h : (∃ t : ℕ, MixedAt n d t), mixingTime n d h ≤ n ^ 6 :=
  SharpSwitch.switch_mixing slice_variance hn hd

#print axioms slice_variance
#print axioms switch_mixing
end OAI.Problem315.SharpSliceRoute
