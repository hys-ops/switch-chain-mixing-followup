import OAI.Probability.SwitchChain.Main

namespace OAI.Problem315.SharpSwitch

noncomputable section
open scoped BigOperators RealInnerProductSpace
open PairResampling SlicePermutationAction
attribute [local instance] Classical.propDecidable

/-- Uniform slice Poincare inequality in unnormalized squared-difference convention.
A slice with at most one state has zero on both sides. -/
def SliceVariance : Prop :=
  ∀ (α : Type) [Fintype α] [DecidableEq α] (q : ℕ) [Nonempty (Slice α q)]
    (f : Slice α q → ℝ),
    (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ)) ^ 2) ≤
      (1 / 4 : ℝ) * ∑ σ ∈ SlicePathComparison.swaps, ∑ s,
        (f s - f (relabel σ s)) ^ 2

theorem assignment_variance (hslice : SliceVariance)
    {n : ℕ} (G : SimpleGraph (Fin n)) (i j : Fin n) (f : PairFiber.Assignment G i j → ℝ) :
    (∑ T, (f T - (∑ U, f U) / (Fintype.card (PairFiber.Assignment G i j) : ℝ)) ^ 2) ≤
      (1 / 4 : ℝ) * ∑ T, ∑ σ ∈ SlicePathComparison.swaps,
        (f T - f (PairFiber.assignmentRelabel G i j σ T)) ^ 2 := by
  classical
  let e := PairFiber.assignmentSliceEquiv G i j
  let : Nonempty (PairFiber.Assignment G i j) :=
    ⟨⟨PairFiber.leftSet G i j, PairFiber.leftSet_subset_singletonSet G i j, rfl⟩⟩
  let : Nonempty (Slice (PairFiber.singletonSet G i j) (PairFiber.leftSet G i j).card) :=
    ⟨e (Classical.arbitrary _)⟩
  have h := hslice (PairFiber.singletonSet G i j) (PairFiber.leftSet G i j).card
    (fun s => f (e.symm s))
  have hmean : (∑ s, f (e.symm s)) = ∑ x, f x := Equiv.sum_comp e.symm f
  have hcard := Fintype.card_congr e.symm
  rw [hmean, hcard] at h
  rw [Finset.sum_comm] at h
  have hleft : (∑ s, (f (e.symm s) - (∑ x, f x) /
      (Fintype.card (PairFiber.Assignment G i j) : ℝ)) ^ 2) =
      ∑ x, (f x - (∑ y, f y) / (Fintype.card (PairFiber.Assignment G i j) : ℝ)) ^ 2 :=
    Equiv.sum_comp e.symm (fun x => (f x - (∑ y, f y) /
      (Fintype.card (PairFiber.Assignment G i j) : ℝ)) ^ 2)
  have hright : (∑ s, ∑ σ ∈ SlicePathComparison.swaps,
      (f (e.symm s) - f (e.symm (relabel σ s))) ^ 2) =
      ∑ x, ∑ σ ∈ SlicePathComparison.swaps,
        (f x - f (PairFiber.assignmentRelabel G i j σ x)) ^ 2 := by
    apply Fintype.sum_equiv e.symm
    intro s
    simp [PairFiber.assignmentRelabel, e]
  -- Commute the two finite sums on the energy side only.
  rw [hleft, hright] at h
  exact h

theorem local_comparison (hslice : SliceVariance)
    {n : ℕ} {d : Fin n → ℕ} (f : StateSpace n d) (a : Finset (Fin n))
    (ha : a ∈ pairs n) :
    inner ℝ f (fluctuation n d a f) ≤ (1 / 2 : ℝ) *
      ∑ G : GraphState n d, f G * pairSwitchLaplacian n d a (fun H => f H) G := by
  classical
  have hcardA : a.card = 2 := (Finset.mem_powersetCard.mp ha).2
  obtain ⟨i,j,hij,rfl⟩ := Finset.card_eq_two.mp hcardA
  let E : GraphState n d → ℝ := fun H =>
    ∑ p ∈ allProposals n,
      if ({i,j} : Finset (Fin n)) ∈ SwitchPairFiber.crossingPairs p then
        (f H - f (proposalState H p)) ^ 2 else 0
  have hlocal (G : GraphState n d) :
      (∑ T : PairFiber.Assignment G.val i j,
        (f ((PairFiber.stateFiberEquiv G i j hij).symm T).val -
          expectation n d {i,j} f G) ^ 2) ≤
      (1 / 4 : ℝ) * ∑ T : PairFiber.Assignment G.val i j,
        E ((PairFiber.stateFiberEquiv G i j hij).symm T).val := by
    let R : PairFiber.Assignment G.val i j → GraphState n d :=
      fun T => ((PairFiber.stateFiberEquiv G i j hij).symm T).val
    have hcard : Fintype.card (PairFiber.Assignment G.val i j) =
        Nat.choose (PairFiber.singletonSet G.val i j).card (PairFiber.leftSet G.val i j).card := by
      rw [← Nat.card_eq_fintype_card]
      exact PairFiber.assignment_natCard G.val i j
    have hmean := PairFiber.expectation_eq_assignment_average G i j hij f
    rw [← hcard] at hmean
    have hvar := assignment_variance hslice G.val i j (fun T => f (R T))
    change (∑ T : PairFiber.Assignment G.val i j, (f (R T) -
      (∑ U, f (R U)) / (Fintype.card (PairFiber.Assignment G.val i j) : ℝ)) ^ 2) ≤ _ at hvar
    rw [← hmean] at hvar
    apply hvar.trans
    apply mul_le_mul_of_nonneg_left _ (by norm_num)
    apply Finset.sum_le_sum
    intro T _
    exact PairFiber.assignment_swap_squared_differences_le_proposals G i j hij T (fun H => f H)
  have h := PairFiber.inner_fluctuation_le_of_assignment_sum_bound i j hij f E
    (1 / 4 : ℝ) hlocal
  calc
    _ ≤ (1 / 4 : ℝ) * ∑ G, E G := h
    _ = _ := by
      rw [PairSquaredEnergy.pairSwitchLaplacian_energy]
      dsimp only [E]
      ring

theorem generator_comparison (hslice : SliceVariance) {n : ℕ} {d : Fin n → ℕ}
    (f : StateSpace n d) :
    ⟪f, generator n d f⟫ ≤
      ∑ G : GraphState n d, f G * switchLaplacian n d (fun H => f H) G := by
  calc
    _ = ∑ a ∈ pairs n, ⟪f, fluctuation n d a f⟫ := by
      rw [generator_apply, inner_sum]
    _ ≤ ∑ a ∈ pairs n, (1 / 2 : ℝ) *
        ∑ G : GraphState n d, f G * pairSwitchLaplacian n d a (fun H => f H) G :=
      Finset.sum_le_sum fun a ha => local_comparison hslice f a ha
    _ = _ := by
      rw [← Finset.mul_sum, Finset.sum_comm]
      simp_rw [← Finset.mul_sum]
      simp only [pairs, sum_pairSwitchLaplacian]
      rw [Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro G _
      ring

theorem switch_gap (hslice : SliceVariance) {n : ℕ} {d : Fin n → ℕ}
    (hn : 4 ≤ n) (hd : Graphical n d) :
    hasSpectralGapAtLeast n d (1 / (12 * (n.choose 4 : ℝ))) := by
  have hsquare (f : StateSpace n d) :
      ⟪f, generator n d f⟫ ≤ ⟪generator n d f, generator n d f⟫ := by
    apply generator_square_of_local (by omega) f (tripleGenerator_square f)
    exact disjoint_sum_nonneg_of_named_interaction_budget f
      (fun i j k l h => PairEquality.actual_named_interaction i j k l h f)
      (fun a _ => PairEquality.pair_projection_budget a f)
  intro f
  have h := uniformVariance_le_generator hd hsquare f
  have hl := div_le_div_of_nonneg_right
    (generator_comparison hslice (WithLp.toLp 2 f)) (Nat.cast_nonneg (stateCount n d))
  have hh : uniformVariance n d f ≤ uniformInner n d f (switchLaplacian n d f) :=
    h.trans hl
  rw [dirichletEnergy_eq_switchLaplacian (switchKernel_row_sum hn)]
  rw [one_div, ← div_eq_inv_mul]
  exact div_le_div_of_nonneg_right hh (by positivity)

theorem switch_tv (hslice : SliceVariance) {n : ℕ} {d : Fin n → ℕ}
    (hn : 4 ≤ n) (hd : Graphical n d) (t : ℕ) (G : GraphState n d) :
    tvDistanceFrom n d t G ≤ Real.sqrt (stateCount n d : ℝ) / 2 *
      Real.exp (- (t : ℝ) / (12 * (n.choose 4 : ℝ))) := by
  have hc : (1 : ℝ) ≤ (n.choose 4 : ℝ) := by exact_mod_cast Nat.choose_pos hn
  have hγ : (1 : ℝ) / (12 * (n.choose 4 : ℝ)) ≤ 1 := by
    apply (div_le_iff₀ (by positivity)).mpr
    linarith
  have h := switch_tv_bound_of_gap n d
    (fun H => by simpa only [allGraphStates] using switchKernel_row_sum hn H)
    hγ (switch_gap hslice hn hd) t G
  have heq : -(1 / (12 * (n.choose 4 : ℝ))) * (t : ℝ) =
      -(t : ℝ) / (12 * (n.choose 4 : ℝ)) := by ring
  simpa only [heq] using h

theorem switch_mixing (hslice : SliceVariance) {n : ℕ} {d : Fin n → ℕ}
    (hn : 4 ≤ n) (hd : Graphical n d) :
    ∃ h : (∃ t : ℕ, MixedAt n d t), mixingTime n d h ≤ n ^ 6 := by
  apply exists_mixingTime_le_of_mixedAt n d (n^6)
  intro G
  apply (switch_tv hslice hn hd (n^6) G).trans
  have he := exponential_tv_bound_at_polynomial_time n (stateCount n d) hn
    (by simpa [pow_two] using stateCount_le_two_pow_square n d)
  have hnR : (n : ℝ) ≠ 0 := by exact_mod_cast (show n ≠ 0 by omega)
  have hcR : (n.choose 4 : ℝ) ≠ 0 := by exact_mod_cast (Nat.choose_pos hn).ne'
  have heq : - ((n^6 : ℕ) : ℝ) / (12 * (n.choose 4 : ℝ)) =
      - ((2*n^8 : ℕ) : ℝ) / (24 * (n : ℝ)^2 * (n.choose 4 : ℝ)) := by
    push_cast
    field_simp
    <;> ring
  rwa [heq]

end
end OAI.Problem315.SharpSwitch
