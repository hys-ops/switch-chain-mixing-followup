import ExactJohnson

noncomputable section
open scoped BigOperators RealInnerProductSpace
open ConcreteJohnson InvolutionGap
namespace ExactJohnson
variable {α : Type*} [Fintype α] [DecidableEq α] {q : ℕ}

theorem sharp_slice_inequality [Nonempty (Slice α q)] (F : Slice α q → ℝ) :
    2 * (Fintype.card α : ℝ) *
      (∑ x, (F x - (∑ y, F y) / (Fintype.card (Slice α q) : ℝ)) ^ 2) ≤
      ∑ σ ∈ swaps, ∑ x, (F x - F (relabel σ x)) ^ 2 := by
  classical
  let μ : ℝ := (∑ x, F x) / Fintype.card (Slice α q)
  let f : E (Slice α q) := WithLp.toLp 2 (fun x => F x - μ)
  have hval (x : Slice α q) : f x = F x - μ := rfl
  have hcenter : ∑ x, f x = 0 := by
    have hsize : (Fintype.card (Slice α q) : ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
    simp only [hval, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul, μ]
    field_simp
    <;> ring
  let hT := symmetric (move (α := α) (q := q)) inv_move
  let b := hT.eigenvectorBasis (rfl : Module.finrank ℝ (E (Slice α q)) = Module.finrank ℝ (E (Slice α q)))
  let ev := hT.eigenvalues (rfl : Module.finrank ℝ (E (Slice α q)) = Module.finrank ℝ (E (Slice α q)))
  have he (j : Fin (Module.finrank ℝ (E (Slice α q)))) : lap move (b j) = ev j • b j :=
    hT.apply_eigenvectorBasis rfl j
  have hnorm : (Fintype.card α : ℝ) * ‖f‖ ^ 2 ≤ ⟪f, lap move f⟫ := by
    rw [← b.sum_sq_inner_right f, ← b.sum_inner_mul_inner f (lap move f), Finset.mul_sum]
    apply Finset.sum_le_sum
    intro j _
    have hd : ⟪b j, lap move f⟫ = ev j * ⟪b j, f⟫ := by
      rw [← hT (b j) f, he, inner_smul_left]
      simp
    rw [hd, real_inner_comm f (b j)]
    by_cases hfix : ∀ i x, b j (move i x) = b j x
    · let x₀ := Classical.choice (inferInstance : Nonempty (Slice α q))
      have h := connected_move (b j) hfix
      have hz : ⟪b j, f⟫ = 0 := by
        rw [inner_as_sum]
        calc
          (∑ x, b j x * f x) = ∑ x, b j x₀ * f x :=
            Finset.sum_congr rfl fun x _ => by rw [h x x₀]
          _ = 0 := by rw [← Finset.mul_sum, hcenter, mul_zero]
      have hz' : ⟪f, b j⟫ = 0 := (real_inner_comm _ _).trans hz
      simp only [hz, hz', zero_pow (by decide : 2 ≠ 0), mul_zero, zero_mul, le_refl]
    · push Not at hfix
      obtain ⟨i,x,hx⟩ := hfix
      have hge := eigen_ge_card (ev j) (b j) (he j) i x (Ne.symm hx)
      have hsmt : ⟪f, b j⟫ = ⟪b j, f⟫ := real_inner_comm _ _
      simp only [hsmt]
      nlinarith only [mul_nonneg (sub_nonneg.mpr hge) (sq_nonneg ⟪b j, f⟫)]
  have hin := energy move inv_move f
  rw [norm_sq_as_sum] at hnorm
  simp only [hval, sub_sub_sub_cancel_right] at hnorm hin
  rw [← Finset.sum_coe_sort (swaps (α := α)) (fun σ => ∑ x, (F x - F (relabel σ x)) ^ 2)]
  change 2 * (Fintype.card α : ℝ) * (∑ x, (F x - μ) ^ 2) ≤
    ∑ i : Move α, ∑ x, (F x - F (move i x))^2
  linarith only [hnorm, hin]

#print axioms sharp_slice_inequality
end ExactJohnson
