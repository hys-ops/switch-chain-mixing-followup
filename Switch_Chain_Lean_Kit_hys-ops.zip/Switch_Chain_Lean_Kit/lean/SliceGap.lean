import CoordinateMode
import OAI.Probability.SwitchChain.SlicePathComparison

namespace OAI.Problem315.SliceGap
noncomputable section
open scoped BigOperators
open SlicePermutationAction SlicePathComparison
variable {α : Type*} [Fintype α] [DecidableEq α]

theorem variance_le_quarter_swap_squared_differences {q : ℕ} [Nonempty (Slice α q)]
    (f : Slice α q → ℝ) :
    (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ)) ^ 2) ≤
      (1/4 : ℝ) * ∑ σ ∈ swaps, ∑ s, (f s - f (relabel σ s)) ^ 2 := by
  exact ConcreteJohnson.variance_le_quarter_swap_squared_differences f

theorem sharp_variance {q : ℕ} [Nonempty (Slice α q)] (f : Slice α q → ℝ) :
    2 * (Fintype.card α : ℝ) *
      (∑ s, (f s - (∑ t, f t) / (Fintype.card (Slice α q) : ℝ)) ^ 2) ≤
      ∑ σ ∈ swaps, ∑ s, (f s - f (relabel σ s))^2 :=
  ExactJohnson.sharp_slice_inequality f

theorem attaining_mode {q : ℕ} (hq : 0 < q) (hN : q < Fintype.card α) :
    ∃ g : InvolutionGap.E (Slice α q), g ≠ 0 ∧ (∑ x, g x) = 0 ∧
      InvolutionGap.lap (fun σ : ↥(swaps (α := α)) => relabelEquiv σ.1) g =
        (Fintype.card α : ℝ) • g :=
  ExactJohnson.exists_attaining_mode hq hN

#print axioms variance_le_quarter_swap_squared_differences
#print axioms sharp_variance
#print axioms attaining_mode
end
end OAI.Problem315.SliceGap
