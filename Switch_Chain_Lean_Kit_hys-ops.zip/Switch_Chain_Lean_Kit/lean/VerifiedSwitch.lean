import SharpSwitch
import SliceGap

namespace OAI.Problem315.VerifiedSwitch

private theorem slice_variance : SharpSwitch.SliceVariance := by
  intro α _ _ q _ f
  exact SliceGap.variance_le_quarter_swap_squared_differences f

/-- Gap for the original switch kernel at uniform stationarity. -/
theorem switch_gap {n : ℕ} {d : Fin n → ℕ} (hn : 4 ≤ n) (hd : Graphical n d) :
    hasSpectralGapAtLeast n d (1 / (12 * (n.choose 4 : ℝ))) :=
  SharpSwitch.switch_gap slice_variance hn hd

/-- Total variation at arbitrary discrete time for each original graph state. -/
theorem switch_tv {n : ℕ} {d : Fin n → ℕ} (hn : 4 ≤ n) (hd : Graphical n d)
    (t : ℕ) (G : GraphState n d) :
    tvDistanceFrom n d t G ≤ Real.sqrt (stateCount n d : ℝ) / 2 *
      Real.exp (- (t : ℝ) / (12 * (n.choose 4 : ℝ))) :=
  SharpSwitch.switch_tv slice_variance hn hd t G

/-- Worst-start total-variation mixing at threshold one quarter. -/
theorem switch_mixing {n : ℕ} {d : Fin n → ℕ} (hn : 4 ≤ n) (hd : Graphical n d) :
    ∃ h : (∃ t : ℕ, MixedAt n d t), mixingTime n d h ≤ n ^ 6 :=
  SharpSwitch.switch_mixing slice_variance hn hd

#print axioms OAI.Problem315.switch_chain_main
#print axioms switch_gap
#print axioms switch_tv
#print axioms switch_mixing

end OAI.Problem315.VerifiedSwitch
