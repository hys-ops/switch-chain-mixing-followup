#!/usr/bin/env python3
"""Validate the retained source/log receipts without calling Lean."""
import sys
sys.dont_write_bytecode = True
import json
import re
from pathlib import Path
from tempfile import TemporaryDirectory

from replay import ROOT, audit_logs, digest, materialize, require, source_file, source_tree

def main():
    inputs = source_tree()
    sources = list(inputs.values()) + [p.read_text() for p in (ROOT/'lean').glob('*.lean')]
    for source in sources:
        require(not re.search(r'\b(sorry|admit|sorryAx|axiom)\b', source), 'placeholder or axiom in supplied project text')
    print(len(sources), 'project source files pass the placeholder/axiom-token scan')
    runs = json.loads((ROOT / 'checks/runs.json').read_text())
    require(digest(ROOT/'scripts/replay.py') == runs['public_script_sha256'], 'replay script digest')
    require(digest(ROOT/'config/source-lock.json') == runs['upstream_lock_sha256'], 'source lock digest')
    for run in runs['complete_runs']:
        directory = ROOT / 'checks' / run['folder']
        receipt = json.loads((directory / 'receipt.json').read_text())
        require(digest(directory/'receipt.json') == run['receipt_sha256'], directory)
        require(receipt['all_checks_passed'], directory)
        require(receipt['axioms'] == audit_logs(directory/'logs'), directory)
        with TemporaryDirectory() as td:
            src = Path(td)/'src'
            src.mkdir()
            material = materialize(receipt['mode'],src,inputs)
            require(set(material) == set(receipt['modules']), 'module set mismatch')
            for module, recorded in receipt['modules'].items():
                require(digest(src/source_file(module)) == recorded['source_sha256'], module)
                require(digest(directory/'logs'/(module+'.log')) == recorded['log_sha256'], module)
                require(recorded['code'] == 0, module)
        print(run['folder'], len(material), 'modules, generated source hashes, preserved logs and both proof paths match')
if __name__ == '__main__':
    main()
