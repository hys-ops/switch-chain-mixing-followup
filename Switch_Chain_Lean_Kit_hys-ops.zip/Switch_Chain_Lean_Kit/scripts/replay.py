#!/usr/bin/env python3
"""Build only the authenticated graph closure and its extensions, in a new directory."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
PREFIX = "OAI.Probability.SwitchChain."
PIN = "4eaee87548250b2682affda7d05d947c05554bae"
LEAN_COMMIT = "5045d0056413266e57c625dcd7c365b10e377c52"
IMPORT = re.compile(r"^import ([^\s]+)[ \t]*\n", re.M)
ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
AXIOM = re.compile(r"'([^']+)' depends on axioms: \[([^\]]+)\]")
REQUIRED_REPORTS = {
    "InvolutionGap": 2, "ConcreteJohnson": 1, "ExactJohnson": 2, "SharpVariance": 1,
    "CoordinateMode": 3, "SliceGap": 3, "VerifiedSwitch": 4, "SharpSliceRoute": 2,
}

def require(condition, message):
    if not condition:
        raise ValueError(str(message))

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write_json(path, obj):
    path.write_text(json.dumps(obj, indent=2) + "\n")

def source_file(module):
    return Path(*module.split(".")).with_suffix(".lean")

def source_tree():
    source = ROOT / "upstream"
    lock = json.loads((ROOT / "config/source-lock.json").read_text())
    require(set(lock) == {str(p.relative_to(source)) for p in source.rglob("*.lean")}, "source inventory")
    texts = {}
    for name, sums in lock.items():
        data = (source / name).read_bytes()
        require(hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest() == sums["git_blob"], name)
        require(hashlib.sha256(data).hexdigest() == sums["sha256"], name)
        texts[name[:-5].replace("/", ".")] = data.decode()
    ordered = {}
    def visit(module):
        if module in ordered:
            return
        for dep in IMPORT.findall(texts[module]):
            if dep != "Mathlib":
                require(dep.startswith(PREFIX), dep)
                visit(dep)
        ordered[module] = texts[module]
    visit(PREFIX + "Main")
    require(set(ordered) == set(texts) and len(ordered) == 165, "pinned transitive closure")
    identity = json.loads((ROOT / "config/source-identity.json").read_text())
    own = (ROOT / "lean/ConcreteJohnson.lean").read_text()
    for item in identity:
        text = ordered[PREFIX + item["module"]]
        span = text[text.index(item["first"]):text.index(item["stop"])]
        require(len(span.encode()) == item["bytes"] and own.count(span) == 1, item)
        require(hashlib.sha256(span.encode()).hexdigest() == item["sha256"], item)
    return ordered

def materialize(mode, src, upstream):
    mods = {}
    headers = (ROOT / "config/focused-imports.txt").read_text().splitlines()
    head = "".join("import " + n + "\n" for n in headers)
    if mode == "focused":
        merged = head + "\n"
        mapping = {}
        for m, text in upstream.items():
            section = "SourceFile" + m.rsplit(".", 1)[1]
            merged += f"section {section}\n"
            start = merged.count("\n") + 1
            merged += IMPORT.sub("", text) + "\n"
            mapping[m] = [start, merged.count("\n")]
            merged += f"end {section}\n\n"
        mods["SourceFocused"] = merged
        write_json(src.parent / "source-map.json", mapping)
    else:
        if mode == "named":
            mods["GraphMathlibImports"] = head
        for m, text in upstream.items():
            mods[m] = text if mode == "native" else text.replace("import Mathlib\n", "import GraphMathlibImports\n")
    for path in sorted((ROOT / "lean").glob("*.lean")):
        text = path.read_text()
        require(not re.search(r"\b(sorry|admit|sorryAx|axiom)\b",text), path.name + " placeholder or axiom")
        if mode == "focused":
            for m in (PREFIX + "Main", PREFIX + "SlicePathComparison"):
                text = text.replace("import " + m + "\n", "import SourceFocused\n")
        mods[path.stem] = text
    for module, text in mods.items():
        path = src / source_file(module)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text)
    return mods

def dependency_cache(packages):
    manifest = json.loads((ROOT / "config/lake-manifest.json").read_text())
    result = []
    for spec in manifest["packages"]:
        repo = packages / spec["name"]
        rev = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
        require(rev == spec["rev"], f"{repo} must be at {spec['rev']}")
        directory = repo / ".lake/build/lib/lean"
        if directory.is_dir():
            require(not (directory/"OAI").exists(), f"unexpected OAI objects in {directory}")
            for module in ["SourceFocused","SliceGap","SharpSwitch","VerifiedSwitch","ExactJohnson"]:
                require(not (directory/(module+".olean")).exists(), f"unexpected local module in {directory}")
            result.append(directory.resolve())
    require(bool(result), "missing Mathlib dependency cache")
    return result

def audit_logs(logs):
    results = {}
    for module, count in REQUIRED_REPORTS.items():
        reports = AXIOM.findall((logs / (module + ".log")).read_text())
        require(len(reports) == count, f"{module}: expected {count} axiom reports")
        for name, axioms in reports:
            require(set(a.strip() for a in axioms.split(",")) == ALLOWED_AXIOMS, (module, name, axioms))
            results[name] = sorted(ALLOWED_AXIOMS)
    audit = (logs/"DependencyAudit.log").read_text()
    require(audit.count("target OAI.") == 2 and audit.count("uses ") == 17 and audit.count("bypasses ") == 15, "incomplete dependency audit")
    return results

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--mode", choices=("focused","named","native"), default="focused")
    p.add_argument("--lean", type=Path, required=True)
    p.add_argument("--packages", type=Path, required=True, help="pinned Lake third-party packages directory")
    p.add_argument("--build", type=Path, required=True, help="fresh empty work directory")
    p.add_argument("--jobs", type=int, default=1)
    args = p.parse_args()
    require(args.jobs >= 1, "jobs must be positive")
    work = args.build.resolve()
    require(not work.exists() or not any(work.iterdir()), "--build must be empty for a clean replay")
    src, out, logs = (work/n for n in ("src","out","logs"))
    for d in (src,out,logs):
        d.mkdir(parents=True)
    lean = args.lean.resolve()
    external = dependency_cache(args.packages.resolve())
    env = os.environ.copy()
    env["LEAN_PATH"] = os.pathsep.join(str(x) for x in [out, *external])
    env["LEAN_NUM_THREADS"] = "1"
    version = subprocess.check_output([str(lean),"--version"], env=env, text=True).strip()
    require("version 4.34.1," in version and LEAN_COMMIT in version, version)
    upstream = source_tree()
    mods = materialize(args.mode,src,upstream)
    deps = {m: set(IMPORT.findall(t)) & mods.keys() for m,t in mods.items()}
    record = {"mode":args.mode,"lean":version,"upstream":PIN,"source_files":len(upstream),
        "original_source_bytes":sum(len(t.encode()) for t in upstream.values()),
        "original_source_lines":sum(len(t.splitlines()) for t in upstream.values()),
        "external_package_paths":[p.parents[3].name for p in external],"old_project_objects_on_path":False,
        "compile_options":["-j1","-DElab.async=false","-DautoImplicit=false"],
        "parallel_jobs":args.jobs,"modules":{}}
    options = record["compile_options"]
    def compile_one(module):
        begin = time.monotonic()
        path = source_file(module)
        olean = (out/path).with_suffix(".olean")
        olean.parent.mkdir(parents=True,exist_ok=True)
        r = subprocess.run([str(lean),*options,"-o",str(olean),str(path)],cwd=src,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        log = logs / (module+".log")
        log.write_bytes(r.stdout)
        text = r.stdout.decode()
        require(r.returncode == 0 and olean.exists() and "sorryAx" not in text and "uses 'sorry'" not in text,
            f"{module} failed: {text[-3000:]}")
        return {"seconds":round(time.monotonic()-begin,3),"code":r.returncode,"source_sha256":digest(src/path),
            "olean_sha256":digest(olean),"log_sha256":digest(log),"warnings":len(re.findall(r"warning:",text))}
    begin = time.monotonic()
    pending = set(mods)
    live = {}
    with ThreadPoolExecutor(args.jobs) as pool:
        while pending or live:
            ready = sorted(m for m in pending if deps[m] <= record["modules"].keys())
            for m in ready[:args.jobs-len(live)]:
                live[pool.submit(compile_one,m)] = m
                pending.remove(m)
            require(bool(live), "import cycle")
            finished, _ = wait(live,return_when=FIRST_COMPLETED)
            for f in finished:
                m = live.pop(f)
                record["modules"][m] = f.result()
                print(f"{len(record['modules'])}/{len(mods)} {m}",flush=True)
                write_json(work/"progress.json", record)
    record["axioms"] = audit_logs(logs)
    record["elapsed_seconds"] = round(time.monotonic()-begin,3)
    record["all_checks_passed"] = True
    write_json(work/"receipt.json",record)
    print("Verified. Receipt:",work/"receipt.json")
if __name__ == "__main__":
    main()
