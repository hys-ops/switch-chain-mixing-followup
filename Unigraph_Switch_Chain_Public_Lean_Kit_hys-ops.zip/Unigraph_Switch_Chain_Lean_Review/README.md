# Worst-case mixing of the four-vertex switch chain on unigraphs

Submitted for public review by **hys-ops**. Start with the English proof in **note/note.pdf**. The theorem at issue is Theorem 9.1 of §9 in the 25-page *Switch_Chain_Unigraph_Revised.pdf* (SHA-256 04331774b3c63eaadee2ba26629020a01cb364c36bd1f0f6b95a9f94ec00970b). This packet has its own scope and build.

## The result

The state is a labeled simple undirected graph with prescribed degree at each label. Unigraphicity means that any two such graphs are isomorphic. Put Q = 12 choose(n,4). The kernel deliberately holds with probability 1/2. In the other half it samples one four-set and one of six ordered matching pairs uniformly. Rejected proposals hold. Each distinct feasible neighbor has probability 1/Q. Stationarity is uniform on the labeled realizations. The threshold is total variation 1/4 from the worst labeled starting state.

| Statement | Fully applied Lean declaration |
|---|---|
| All unigraphs, every time and start, product bound with factors 1 + (m!−1) exp(−mt/Q) | OAI.Problem315.UnigraphUpper.unigraph_product_bound |
| Worst-start mixing time ≤ ceil(Q log(3n)) for n ≥ 4 | OAI.Problem315.UnigraphUpper.unigraph_mixing_upper |
| Exactly 2^k labeled realizations before padding, with explicit degree at each vertex | LayeredLower.cardinal_states and LayeredLower.explicit_degree |
| Every padded realization is represented once by a k-bit word for k = floor(n/4), and all are isomorphic | LayeredLower.Padding.cube and LayeredLower.Padding.family_unigraphic |
| On the padded family, probability 1−k/Q of holding, 1/Q for each flip, zero at every other distinct state | LayeredLower.Padding.family_hold, family_flip and family_off_diagonal |
| On that actual family, Q log(k/16)/8 < mixingTime ≤ ceil(Q log(3n)) for every n ≥ 4 | LayeredLower.Padding.finite_mixingTime_bounds |
| For every n ≥ 65536 the maximum W(n) satisfies n⁴ log(n)/512 < W(n) ≤ 2 n⁴ log(n), and is attained | UnigraphWorst.worst_bounds and UnigraphWorst.worst_attained |
| W(n) = Θ(n⁴ log n) at infinity, with both bounds discharged | UnigraphWorst.worst_theta |

Here m ranges over degree multiplicities. A singleton contributes 1. The finite-n lower bound can be nonpositive for small k. The displayed constants suffice for the asymptotic assertion.

## What the proofs use

The note gives a direct randomized exchange-path proof of J ≤ 2L. The formal proof bounds a transposition by twice conditional mean subtraction on its row fiber, then uses the previously checked fiber comparison. It proves the permutation gap in the given clock by antisymmetrizing an eigenfunction at a transposition. The lifted eigenbasis proof controls the graph trace by the regular product trace using Jensen's and Bessel's inequalities. The real degree-block action, isometric lift, generator comparison and factor eigenbasis are provided by the project. All analytical hypotheses disappear from the three final upper statements.

The note derives the lower family's representation by peeling its outermost degree classes. Lean uses an equivalent exposed linear functional. Assign opposite, strictly ordered layer weights to centers and leaves. Prescribed degrees fix the sum of the weights of the endpoints over all present edges. In the given realization every positive-sum edge is present and every negative-sum edge absent, so any realization attaining the same value must agree on all those pairs. The zero-sum pairs form disjoint 2-by-2 matching blocks. A label permutation flips each matching. An actual switch has one affected block, and each bit flip is attained by one proposal. The first and second sign moments give variance ≤ k and produce an event separating the source's original half-ℓ¹ distance from stationarity.

See **checks/logs/UnigraphAudit.log** for exact endpoint types and checked proof-term paths. The Θ declaration reaches the new upper product estimate, the padded cube construction and the original kernel. It bypasses both the original global TV/mixing bound and the separate n⁶ TV/mixing bound. The older fiber comparison remains an upper-proof dependency. The auxiliary declaration in ClosedLower.lean uses the original theorem to supply a finite-time existence witness. The joint endpoint and the corresponding finite-n two-sided declaration obtain that witness from the new upper bound.

## Reproduce

Python 3.10+, Git, Lean 4.34.1 at commit 5045d0056413266e57c625dcd7c365b10e377c52, and the exact compiled packages from dependencies/config/lake-manifest.json are required for a Lean build. The manifest pins Mathlib to d13f23b723b8a846827a245b89c10fc7d3f11612. To prepare the dependencies on a machine with elan and a network connection, copy dependencies/config/{lakefile.lean,lake-manifest.json,lean-toolchain} into a fresh directory and run “lake exe cache get” there. “lean --version” identifies the executable; the replay takes its absolute path.

From the extracted packet directory, run:

```bash
python3 verify.py
python3 checks/independent.py > my-enumeration.json
cmp my-enumeration.json checks/checks.json
python3 replay.py --lean /path/to/lean-4.34.1/bin/lean \
  --packages /path/to/dependency-project/.lake/packages \
  --build /tmp/unigraph-fresh --jobs 2
```

The final command requires a new or empty output directory. The replay gives Lean an isolated project-object directory and the pinned third-party libraries. Its generated receipt records each source, object, compiler exit status, log, local imports, axiom output and dependency key. For the retained standalone run the finished sources and replay script were extracted from the archived reviewer ZIP, then all 221 modules were compiled in a single invocation into an empty directory. A preceding two-stage build checked the same 221 modules. Source hashes, import lists and axiom reports matched across both runs. The official input consists of 165 byte-exact source files. In the executed named-module mode, 36 broad Mathlib import lines are narrowed to a fixed 30-import header. The declarations and the import links among the 165 original modules are preserved. The script also accepts --native to retain the upstream Mathlib umbrella; the retained run used named mode. Mathlib and the compiler are external trusted dependencies. The packet does not contain compiler binaries.

Read **checks/receipt.json** for the compiler record, **proofs/UnigraphWorst.lean** for the joint theorem, **proofs/UnigraphUpper.lean** for the graph upper, and **proofs/PaddedExact.lean** for the exact lower example. The finite enumeration starts with degree vectors, enumerates all possible labeled neighborhoods, then tests all ordered four-vertex proposals using integers. The 13 inputs n=4,…,16 give 72 states and 364,704 tested proposals. The per-state deliberate hold is accounted for separately. Three-step distributions and moment checks use exact fractions. These computational experiments are separate from the general Lean theorems.

## Provenance and review status

The original manuscript is OpenAI's *Polynomial mixing of the switch chain for every graphical degree sequence*, dated 25 September 2026. The archive uses the original namespace OAI.Problem315 for catalogue family 131. The original PDF SHA-256 is e70eab92c1315e6706eea3613e9826871e009d1ef8de31f82d5750d026240af3. The upstream repository is openai/math at commit 4eaee87548250b2682affda7d05d947c05554bae. See dependencies/config/source-lock.json for each original Git blob ID and SHA-256, dependencies/config/provenance.json for the source records, and dependencies/UPSTREAM-LICENSE for the upstream Apache 2.0 license. The eight files under dependencies/row-fiber come from the prior conditional-exchange work and include material adapted from those original sources. The upstream Apache 2.0 notice applies to the upstream material; it is not a blanket license for newly prepared material. This submission does not assign a new license.

Barrus's Theorems 6 and 10 give the product structure and known undirected hypercube realization graphs used here. [Erdős et al.](https://arxiv.org/abs/1909.02308) use a bipartite cube lower family and mixing argument in §1.2 and a forced split-graph lift in §7.2. Normalizing to the original four-vertex proposal clock gives the same lower order on this known family; neither the family nor its mixing mechanism is claimed as new. Permutation gaps, cube mixing, transitive heat traces, and composition of some degree-sequence state spaces have published antecedents. The independent synthesis being proposed for mathematical review is the class-wide comparison and the matching worst order on this clock. Priority has not been established. A literature comparison is in checks/prior-art-ko.md.

The draft, code, adversarial reading and finite enumeration were produced with AI assistance. The checks are kernel compilation, axiom and dependency inspection, an independent mathematical rereading by an AI, and exact finite experiments. Independent human mathematical review remains open. The supplementary note corrects the draft's printed exponent from “3/4+o(U1)” to “3/4+o(1)” and proves a finite inequality directly.

[Original release](https://github.com/openai/math/tree/4eaee87548250b2682affda7d05d947c05554bae/lean/OAI/Probability/SwitchChain) · [Community manuscript page](https://mathcommunity.github.io/oai-math-revised/papers/Polynomial-Mixing-of-the-Switch-Chain-for-Every-Graphical-Degree-Sequence-September-25-2026/)
