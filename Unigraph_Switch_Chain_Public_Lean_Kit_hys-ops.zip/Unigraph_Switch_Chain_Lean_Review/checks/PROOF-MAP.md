# Comparing the two proofs

| §9 statement | Argument in the English note | Checked path from public graph types |
|---|---|---|
| Law on labeled realizations | Uniform stationarity from symmetry; one successful ordered quartet for each distinct neighbor | Original OAI.Probability.SwitchChain.Definitions, KernelNormalization, symmetry and row sums |
| Label exchange costs at most two graph energies | Uniform path from a subset to its complement on an anchor fiber, followed by counting opposite anchor pairs | LabelComparison.sameFiber_anchor, fiber_perm_energy, labelSwitch_comparison and the inherited sharpened row-fiber comparison |
| Single isomorphism class | Equal-degree permutations act transitively | KernelEquivariance.unigraph_kernel_transitive verifies the original kernel for each relabeling, including rejected proposals |
| Regular permutation trace | Isometric orbit lift, product factors and the permutation gap | DegreeProduct, OrbitLift, ProductLift, PermutationGap, PermutationModes, TensorBasis and PermutationProduct |
| Original quarter-TV upper | Point-start chi-square trace; simultaneous spectral comparison | UnigraphUpper.unigraph_product_bound uses squared-eigenvector overlap, Jensen and Bessel. The upper clock and original mixingTime are discharged in UnigraphUpper.unigraph_mixing_upper |
| Complete set of realizations | Outer layer saturates the degree sum, then peel | Exposed.forced_adjacency fixes all nonzero-weight pairs. Identify.stateEquiv and CubeUnigraph encode, decode and relabel. Degrees.explicit_degree gives each assigned integer degree |
| Exact one-step law | Symmetric difference detects one bit; proposals are unique | Transitions, PaddedMove and PaddedExact certify all n, including rejected proposals and isolate padding |
| TV separation | One- and two-sign eigenfunctions, variance bound, one threshold event | CubeWalk, CubeLower, CubeTV, CubeTransport, CubeUpstream, PaddedLower and PaddedExact |
| Worst order | Maximize over graphical unigraphic degree vectors | UnigraphWorst.worst_bounds, worst_attained and worst_theta. The maximum includes singleton state spaces and all admissible labeled vectors |

In this table a file name identifies a source module. Its Lean namespace can differ. See the fully qualified printed names in logs/UnigraphAudit.log and the theorem table in README.md.

The critical comparison, heat trace, all-realization bijection, actual one-step law and lower moment argument are all proved within the dependency closure of the final endpoints. A separate direct-written exchange-path proof and a peeling proof are provided in the note. The Lean endpoint uses the alternate proofs identified in the table. No Lean claim about publication priority or source authors' agreement is intended.
