"""Enumerate the specified labeled graph spaces and the paper's lazy proposal, with exact rationals."""
from collections import Counter
from fractions import Fraction
from itertools import combinations, permutations
from math import comb
import json


def realizations(residual, labels):
    active = [i for i in labels if residual[i] > 0]
    if not active:
        yield frozenset()
        return
    # Fix only the next vertex, never its neighbors. This enumerates every
    # completion exactly once without assuming forced layers or the answer.
    anchor = max(active, key=lambda i: residual[i])
    others = [i for i in active if i != anchor]
    if residual[anchor] > len(others):
        return
    for neighbors in combinations(others, residual[anchor]):
        remaining = residual.copy()
        remaining[anchor] = 0
        for v in neighbors:
            remaining[v] -= 1
        for rest in realizations(remaining, others):
            yield rest | frozenset(edge(anchor, v) for v in neighbors)


def edge(a, b):
    return min(a,b), max(a,b)


def label_swap(graph, a, b):
    def moved(v):
        return b if v == a else a if v == b else v
    return frozenset(edge(moved(x),moved(y)) for x,y in graph)


def actual_proposals(labels):
    for a,b,c,d in combinations(labels,4):
        pairings = [frozenset((edge(a,b),edge(c,d))),
                    frozenset((edge(a,c),edge(b,d))),
                    frozenset((edge(a,d),edge(b,c)))]
        yield from permutations(pairings,2)


def moment_check(rows, codes, k, Q, t=3):
    # Integer vector of numerators, using the transition matrix computed
    # from actual graph proposals. Only the check on the result uses Walsh.
    start = next(g for g,c in codes.items() if not any(c))
    numerators = Counter({start:1})
    for _ in range(t):
        updated = Counter()
        for g,mass in numerators.items():
            for h,weight in rows[g].items():
                updated[h] += mass*weight
        numerators = updated
    prob = {g:Fraction(numerators[g],Q**t) for g in codes}
    assert sum(prob.values()) == 1
    M = len(codes)
    z = {g:k-2*sum(c) for g,c in codes.items()}
    mu = sum(p*z[g] for g,p in prob.items())
    second = sum(p*z[g]**2 for g,p in prob.items())
    chi2 = M*sum(p*p for p in prob.values())-1
    total_variation = sum(abs(p-Fraction(1,M)) for p in prob.values())/2
    a, b = Fraction(Q-2,Q), Fraction(Q-4,Q)
    assert mu == k*a**t and second == k+k*(k-1)*b**t
    assert chi2 == sum(comb(k,j)*Fraction(Q-2*j,Q)**(2*t) for j in range(1,k+1))
    assert 4*total_variation**2 <= chi2
    return {'time':t, 'TV':str(total_variation), 'chi_square':str(chi2),
            'sum_of_signs_mean':str(mu), 'sum_of_signs_second_moment':str(second)}


def run(n):
    k = n//4
    degrees = []
    for i in range(1,k+1):
        degrees.extend([4*k-2*i]*2 + [2*i-1]*2)
    degrees.extend([0]*(n-4*k))
    labels = range(n)
    graphs = list(realizations(degrees, labels))
    codes = {g:tuple(edge(4*i,4*i+2) in g for i in range(k)) for g in graphs}
    assert len(set(codes.values())) == len(graphs) == 2**k
    proposals = list(actual_proposals(labels))
    assert len(proposals) == 6*comb(n,4)
    Q = 2*len(proposals)
    rows = {}
    for g in graphs:
        row = Counter({g:len(proposals)})  # intentional 1/2 hold, on the common denominator Q
        for removed, added in proposals:
            h = (g-removed)|added if removed <= g and g.isdisjoint(added) else g
            assert h in codes
            row[h] += 1
        assert len(row) == k+1 and row[g] == Q-k and sum(row.values()) == Q
        flip_counts = Counter()
        for h,weight in row.items():
            if h != g:
                changed = [i for i in range(k) if codes[g][i] != codes[h][i]]
                assert len(changed) == 1
                flip_counts[changed[0]] += weight
        assert flip_counts == Counter(range(k))
        # For these examples J=2L, checked against actual graph relabelings.
        swap_counts = Counter()
        for a,b in combinations(labels,2):
            if degrees[a] == degrees[b]:
                h = label_swap(g,a,b)
                if h != g:
                    swap_counts[h] += 1
        assert swap_counts == Counter({h:2*c for h,c in row.items() if h != g})
        rows[g] = row
    assert all(rows[h][g] == weight for g,row in rows.items() for h,weight in row.items())
    return dict(n=n,k=k,padding=n-4*k,degree_vector=degrees,states=len(graphs),
                ordered_proposals_per_state=len(proposals),proposals_checked=len(graphs)*len(proposals),
                successful_proposals_per_state=k,failed_proposals_per_state=len(proposals)-k,
                probability_denominator=Q,probability_flip_each_coordinate=str(Fraction(1,Q)),
                probability_hold=str(Fraction(Q-k,Q)),exact_moments=moment_check(rows,codes,k,Q))


if __name__=='__main__':
    cases = [run(n) for n in range(4,17)]
    print(json.dumps({'cases':cases,'total_states':sum(v['states'] for v in cases),
                      'total_ordered_proposals':sum(v['proposals_checked'] for v in cases)}, indent=2))
