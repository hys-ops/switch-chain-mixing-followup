**Suggested link text for the manuscript page**

A follow-up note gives the sharp worst-case order Θ(n⁴ log n) for the original lazy four-vertex switch chain restricted to unigraphic degree vectors, with the uniform law on labeled realizations and worst initial state. The upper bound uses equal-degree label transpositions. A known hypercube realization family (Barrus, Theorems 6 and 10; compare Erdős et al., arXiv:1909.02308, §§1.2, 7.2) gives the matching lower order after normalizing to the same proposal clock. The companion Lean 4.34.1 sources verify both endpoints on the original kernel.

Submitted for public review by hys-ops. The proof and formalization used AI assistance. Independent human review is invited.
