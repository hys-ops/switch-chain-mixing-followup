import Conjugacy
import CubeUpstream
import OAI.Probability.SwitchChain.Main
namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
variable {k : ℕ}

theorem vertex_degree_bound (k : ℕ) (v : V k) : deg k v ≤ 4*k-1 := by
  classical
  let x := CubeLower.origin k
  rw [←graph_deg x v]
  unfold graphDegree
  have h : univ.filter ((graph x).Adj v) ⊆ univ.erase v := by
    intro j hj; have hh := (mem_filter.mp hj).2
    exact mem_erase.mpr ⟨by intro h; subst j; exact (graph x).loopless.irrefl v hh,mem_univ _⟩
  simpa using card_le_card h

theorem witness (hk : 0<k) : ∃ t, MixedAt (4*k) (deg k) t :=
  ((switch_chain_main (4*k) (deg k) (by omega) (vertex_degree_bound k)
     ⟨state (CubeLower.origin k)⟩).1).choose

/-- Explicit lower bound for the original paper's half-L1 total variation. -/
theorem distance_lower (hk : 0<k) (t : ℕ) (ht : 8*(t:ℝ)≤Q k*Real.log ((k:ℝ)/16)) :
    (1:ℝ)/2 ≤ tvDistanceFrom (4*k) (deg k) t (state (CubeLower.origin k)) :=
  CubeLower.Upstream.tvDistanceFrom_bound (stateEquiv k) (operator_equiv hk) hk (Q_bounds hk).1 (Q_bounds hk).2 t ht

/-- Unconditional lower bound on the original paper's quarter-TV mixing time, for each k>0. -/
theorem mixing_lower (hk : 0<k) : Q k*Real.log ((k:ℝ)/16)/8 <
    (mixingTime (4*k) (deg k) (witness hk) : ℝ) :=
  CubeLower.Upstream.mixingTime_bound (stateEquiv k) (operator_equiv hk) hk (Q_bounds hk).1 (Q_bounds hk).2 (witness hk)

#print axioms distance_lower
#print axioms mixing_lower
end
end LayeredLower
