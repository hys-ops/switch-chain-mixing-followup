import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Nat.Choose.Bounds
import Mathlib.Tactic

namespace LayeredLower.AllClock

/-- The slack from the quartet clock and the integer number of complete blocks.
This statement holds at every size, including all four residue classes. -/
theorem lower_clock {n : ℕ} (hn : 65536 ≤ n) :
    (n : ℝ)^4 * Real.log n / 512 ≤
      (12 * (n.choose 4 : ℝ)) * Real.log (((n/4 : ℕ) : ℝ)/16) / 8 := by
  have hnR : (65536 : ℝ) ≤ n := by exact_mod_cast hn
  have hc : (n : ℝ) / 2 ≤ (n+1-4 : ℕ) := by
    have h : n ≤ 2*(n+1-4) := by omega
    have h' : (n : ℝ) ≤ 2*((n+1-4 : ℕ) : ℝ) := by exact_mod_cast h
    linarith
  have hpow := pow_le_pow_left₀ (by positivity : 0 ≤ (n : ℝ)/2) hc 4
  rw [show n + 1 - 4 = n - 3 by omega] at hpow
  have hchoose := Nat.pow_le_choose (α:=ℝ) 4 n
  norm_num [Nat.factorial] at hchoose
  have hQ : (n : ℝ)^4/32 ≤ 12*(n.choose 4 : ℝ) := by
    nlinarith [hpow]
  have hfloorN : n ≤ 8 * (n/4) := by omega
  have hfloor : (n : ℝ) ≤ 8*((n/4 : ℕ) : ℝ) := by exact_mod_cast hfloorN
  let s : ℝ := ((n/4 : ℕ) : ℝ)/16
  have hs1 : (n : ℝ)/128 ≤ s := by dsimp [s]; linarith
  have hs2 := pow_le_pow_left₀ (by positivity : 0 ≤ (n : ℝ)/128) hs1 2
  have hns : (n : ℝ) ≤ s^2 := by nlinarith [mul_nonneg (show 0 ≤ (n : ℝ) by positivity) (show 0 ≤ (n:ℝ)-16384 by linarith)]
  have hnpos : (0 : ℝ) < n := by linarith
  have hslog := Real.log_le_log hnpos hns
  rw [Real.log_pow] at hslog
  have hlog : Real.log (n : ℝ) / 2 ≤ Real.log s := by norm_num at hslog; linarith
  have hlog0 : 0 ≤ Real.log (n : ℝ) := Real.log_nonneg (by linarith)
  have hprod := mul_le_mul hQ hlog (by linarith) (by positivity)
  change (n : ℝ)^4 * Real.log n / 512 ≤ (12*(n.choose 4 : ℝ)) * Real.log s / 8
  linarith

#print axioms lower_clock
end LayeredLower.AllClock
