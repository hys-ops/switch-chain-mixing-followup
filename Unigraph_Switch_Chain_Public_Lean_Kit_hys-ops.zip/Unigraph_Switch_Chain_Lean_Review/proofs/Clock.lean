import OrbitTrace
import Mathlib.Data.Nat.Factorial.Basic
open scoped BigOperators
noncomputable section
namespace UnigraphTrace
private theorem factorial_term (m n : ℕ) (hn : 0<n) (hm : m≤n) (u : ℝ)
    (hu : Real.log (3*(n:ℝ)) ≤ u) :
    ((m.factorial:ℝ)-1)*Real.exp (-u*m) ≤ ((m:ℝ)/(3*n))^2 := by
  have hn' : 0 < (n:ℝ) := by exact_mod_cast hn
  have hx : 0 < 3*(n:ℝ) := by positivity
  by_cases hsmall : m≤1
  · interval_cases m <;> norm_num <;> positivity
  have hm' : 2 ≤ m := by omega
  have ht : Real.exp (-u) ≤ 1/(3*(n:ℝ)) := by
    rw [Real.exp_neg,← Real.exp_log hx,one_div]
    exact inv_anti₀ (Real.exp_pos _) (Real.exp_le_exp.mpr hu)
  have hf : (m.factorial:ℝ) ≤ (m:ℝ)^m := by exact_mod_cast Nat.factorial_le_pow m
  have hbase : (m:ℝ)/(3*n) ≤ 1 := by
    rw [div_le_one hx]
    have : (m:ℝ) ≤ n := by exact_mod_cast hm
    linarith
  calc
    _ ≤ (m:ℝ)^m * (Real.exp (-u))^m := by
      rw [←Real.exp_nat_mul,mul_comm (m:ℝ) (-u)]
      exact mul_le_mul_of_nonneg_right (by linarith) (Real.exp_nonneg _)
    _ ≤ (m:ℝ)^m * (1/(3*(n:ℝ)))^m :=
      mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (Real.exp_nonneg _) ht _) (by positivity)
    _ = ((m:ℝ)/(3*n))^m := by rw [← mul_pow];congr 1;ring
    _ ≤ _ := pow_le_pow_of_le_one (by positivity) hbase hm'

theorem clock_product {C : Type*} [Fintype C] (m : C → ℕ) (n : ℕ) (hn : 0<n)
    (hsum : ∑ c,m c ≤ n) {u : ℝ} (hu : Real.log (3*(n:ℝ)) ≤ u) :
    (∏ c,(1+(((m c).factorial:ℝ)-1)*Real.exp (-u*m c))) ≤ 5/4 := by
  let a (c : C) := (((m c).factorial:ℝ)-1)*Real.exp (-u*m c)
  have hpos : ∀ c,0≤a c := by
    intro c
    have h : (1:ℝ) ≤ (m c).factorial := by exact_mod_cast Nat.factorial_pos (m c)
    exact mul_nonneg (by linarith) (Real.exp_nonneg _)
  have hn' : 0 < (n:ℝ) := by exact_mod_cast hn
  have hsum' : (∑ c,(m c:ℝ)) ≤ n := by exact_mod_cast hsum
  have hsum2 : (∑ c, ((m c:ℝ)/(3*n))^2) ≤ 1/9 := by
    simp_rw [div_pow,← Finset.sum_div]
    rw [div_le_iff₀ (by positivity)]
    have hcs := Finset.sum_sq_le_sq_sum_of_nonneg (s:=Finset.univ) (f:=fun c => (m c:ℝ)) (by intros;positivity)
    have hs2 := pow_le_pow_left₀ (show 0 ≤ ∑ c,(m c:ℝ) by positivity) hsum' 2
    nlinarith
  have ht : (∑ c,a c) ≤ 1/9 := by
    apply le_trans _ hsum2
    apply Finset.sum_le_sum
    intro c _
    exact factorial_term (m c) n hn ((Finset.single_le_sum (f:=m) (by simp) (Finset.mem_univ c)).trans hsum) u hu
  calc
    (∏ c,(1+a c)) ≤ ∏ c,Real.exp (a c) := Finset.prod_le_prod₀
      (fun c _ => by linarith [hpos c]) (fun c _ => by linarith [Real.add_one_le_exp (a c)])
    _ = Real.exp (∑ c,a c) := (Real.exp_sum _ _).symm
    _ ≤ Real.exp (1/9) := Real.exp_le_exp.mpr ht
    _ ≤ (5:ℝ)/4 := by
      have hp := Real.exp_pos (-(1/9):ℝ)
      have hlo := Real.add_one_le_exp (-(1/9):ℝ)
      rw [show (1/9:ℝ) = -(-(1/9)) by ring, Real.exp_neg, inv_le_comm₀ hp (by norm_num : (0:ℝ)<5/4)]
      norm_num at *; linarith

theorem quarter_of_product {C : Type*} [Fintype C] (m : C → ℕ) (n : ℕ) (hn : 0<n)
    (hsum : ∑ c,m c ≤ n) (Q : ℝ) (hQ : 0<Q) (t : ℕ)
    (ht : Q*Real.log (3*(n:ℝ)) ≤ t) (d : ℝ)
    (hb : 4*d^2 ≤ (∏ c,(1+(((m c).factorial:ℝ)-1)*Real.exp (-(t:ℝ)/Q*m c)))-1) :
    d≤1/4 := by
  have hu : Real.log (3*(n:ℝ))≤(t:ℝ)/Q := (le_div_iff₀ hQ).mpr (by linarith)
  have hp := clock_product m n hn hsum hu
  have hneg : -(t:ℝ)/Q = -((t:ℝ)/Q) := by ring
  simp only [hneg] at hb
  nlinarith [sq_nonneg (d-1/4)]
#print axioms quarter_of_product
end UnigraphTrace
