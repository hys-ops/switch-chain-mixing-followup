import PaddedLower
import OAI.Probability.SwitchChain.Main

namespace LayeredLower.Padding
open OAI.Problem315
noncomputable section
attribute [local instance] Classical.propDecidable

/-- The upstream global theorem is used solely to exhibit *some* finite
mixing time, not to lower-bound it. -/
theorem eventually_mixed {n : ℕ} (hn : 4 ≤ n) : ∃ t, MixedAt n (family n) t := by
  obtain ⟨g⟩ := family_graphical n
  have dmax (v : Fin n) : family n v ≤ n-1 := by
    rw [←g.property v,degree_eq]
    have hh : g.val.degree v < n := by simpa using g.val.degree_lt_card_verts v
    omega
  exact ((switch_chain_main n (family n) hn dmax ⟨g⟩).1).choose

/-- The actual worst-start mixing time of a concrete, graphical unigraphic
degree assignment at every large size n, with no extra hypotheses. -/
theorem exists_slow_unigraph {n : ℕ} (hn : 65536 ≤ n) :
    ∃ d : Fin n → ℕ, Graphical n d ∧ UnigraphUpper.IsUnigraphic d ∧
      ∃ h : ∃ t, MixedAt n d t,
        (n:ℝ)^4 * Real.log n / 512 < (mixingTime n d h : ℝ) := by
  have h := eventually_mixed (show 4≤n by omega)
  exact ⟨family n,family_graphical n,family_unigraphic n,h,all_n_mixingTime hn h⟩

#print axioms eventually_mixed
#print axioms exists_slow_unigraph
end
end LayeredLower.Padding
