import Transitions
import CubeTransport
namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k : ℕ}

lemma flip_ne (x : Bits k) (i : Fin k) : CubeLower.flip i x ≠ x := by
  intro h; have h' := congrFun h i
  cases hh : x i <;> simp [CubeLower.flip,hh] at h'

lemma flip_inj (x : Bits k) : Function.Injective (fun i => CubeLower.flip i x) := by
  intro i j hij; by_contra h
  have h' := congrFun hij i
  cases hh : x i <;> simp [CubeLower.flip,h,hh] at h'

lemma indicator_neighbors (x y : Bits k) :
    (if ∃ i,y=CubeLower.flip i x then (1:ℝ)/Q k else 0) =
     ∑ i, if y=CubeLower.flip i x then (1:ℝ)/Q k else 0 := by
  by_cases h : ∃ i,y=CubeLower.flip i x
  · obtain ⟨i,hi⟩ := h; subst y
    simp only [eq_comm (a:=CubeLower.flip i x), (flip_inj x).eq_iff]
    simp
  · simp [show ∀ i,y≠CubeLower.flip i x from not_exists.mp h]

abbrev kernel (k : ℕ) := switchKernel (4*k) (deg k)

lemma split_row (x : Bits k) (f : GraphState (4*k) (deg k) → ℝ) :
    ∑ H, kernel k (state x) H * f H =
    kernel k (state x) (state x)*f (state x) + (∑ i,f (state (CubeLower.flip i x)))/Q k := by
  have he y : kernel k (state x) (state y) =
      (if y=x then kernel k (state x) (state x) else 0) +
      ∑ i,if y=CubeLower.flip i x then (1:ℝ)/Q k else 0 := by
    rw [←indicator_neighbors]
    by_cases h : y=x
    · subst y; have hn : ¬(∃ i,x=CubeLower.flip i x) := by rintro ⟨i,hi⟩;exact flip_ne _ _ hi.symm
      simp [hn]
    · simpa only [ite_eq_right h,zero_add] using off_diagonal x y (Ne.symm h)
  have hs := (stateEquiv k).sum_comp (fun H => kernel k (state x) H * f H)
  rw [←hs]
  change (∑ y, kernel k (state x) (state y)*f (state y)) = _
  have sumrep := Finset.sum_congr (s₁:=(univ : Finset (Bits k))) rfl (fun y _ => congrArg (fun z : ℝ => z * f (state y)) (he y))
  rw [sumrep]
  simp_rw [add_mul,Finset.sum_mul,ite_mul,zero_mul]
  rw [Finset.sum_add_distrib,Finset.sum_comm (s:=univ) (t:=univ) (f:=fun y i => if y=CubeLower.flip i x then (1/Q k)*f (state y) else 0)]
  simp only [Finset.sum_ite_eq',Finset.mem_univ,ite_true]
  simp [div_eq_mul_inv,←Finset.mul_sum,mul_comm]

lemma diagonal (hk : 0<k) (x : Bits k) :
    kernel k (state x) (state x)=1-(k:ℝ)/Q k := by
  have h := split_row x (fun _ => 1)
  have h' := switchKernel_row_sum (show 4≤4*k by omega) (state x)
  simp only [mul_one, Finset.sum_const, Finset.card_univ,Fintype.card_fin,nsmul_eq_mul,mul_one] at h
  change (∑ H, kernel k (state x) H)=1 at h'
  linarith

theorem operator_equiv (hk : 0<k) (f : GraphState (4*k) (deg k) → ℝ) (x : Bits k) :
    (∑ H, kernel k ((stateEquiv k) x) H * f H) = CubeLower.step (Q k) (fun y => f ((stateEquiv k) y)) x := by
  change (∑ H, kernel k (state x) H*f H) = _
  rw [split_row,diagonal hk]; rfl

lemma choose_four (n : ℕ) : n+1 ≤ (n+4).choose 4 := by
  induction n with
  | zero => decide
  | succ n ih =>
    have hh : 0<(n+4).choose 3 := Nat.choose_pos (by omega)
    have hp : (n+1+4).choose 4 = (n+4).choose 3 + (n+4).choose 4 := Nat.choose_succ_succ _ _
    omega

lemma Q_bounds (hk : 0<k) : 4≤Q k ∧ (k:ℝ)≤Q k := by
  have h := choose_four (4*k-4)
  rw [show 4*k-4+4=4*k by omega] at h
  have h₁ : 1≤(4*k).choose 4 := by omega
  have h₂ : k≤(4*k).choose 4 := by omega
  have ha : (1:ℝ)≤((4*k).choose 4:ℝ) := by exact_mod_cast h₁
  have hb : (k:ℝ)≤((4*k).choose 4:ℝ) := by exact_mod_cast h₂
  unfold Q; constructor <;> linarith

theorem quarter_mixed_requires (hk : 0<k) (t : ℕ)
    (htv : CubeLower.Transport.tv (CubeLower.Transport.kernelOp (kernel k)) (state (CubeLower.origin k)) t ≤ 1/4) :
    Q k * Real.log ((k:ℝ)/16)/8 < (t:ℝ) :=
  CubeLower.Transport.quarter_mixed_requires_equiv (stateEquiv k) (kernel k) (operator_equiv hk) hk (Q_bounds hk).1 (Q_bounds hk).2 t htv

#print axioms operator_equiv
#print axioms quarter_mixed_requires
end
end LayeredLower
