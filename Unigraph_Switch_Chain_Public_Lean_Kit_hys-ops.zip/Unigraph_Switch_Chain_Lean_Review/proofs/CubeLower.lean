import CubeWalk
open Finset
namespace CubeLower
def origin (k : ℕ) : Bits k := fun _ => false
theorem Z_origin (k : ℕ) : Z (origin k) = k := by simp [Z,origin,spin]
theorem mean_from_origin (k : ℕ) (Q : ℝ) (t : ℕ) :
    walk Q t Z (origin k) = (k:ℝ)*(1-2/Q)^t := by
  induction t with
  | zero => simp [walk,Z_origin]
  | succ t ih =>
    rw [walk,step_Z,walk_mul]
    dsimp only
    rw [ih,pow_succ]
    ring

theorem square_from_origin (k : ℕ) {Q : ℝ} (hQ : 4 ≤ Q) (t : ℕ) :
    walk Q t (fun x => Z x^2) (origin k) ≤ k + ((k:ℝ)*(1-2/Q)^t)^2 := by
  have h : 0 < Q := by linarith
  have hb : 0 ≤ 1-4/Q := sub_nonneg.mpr ((div_le_one h).mpr hQ)
  have hb' : 1-4/Q ≤ (1-2/Q)^2 := by
    nlinarith [sq_nonneg (2/Q), show (4:ℝ)/Q=2*(2/Q) by ring]
  induction t with
  | zero => simp [walk,Z_origin]
  | succ t ih =>
    rw [walk,step_Z2,walk_add,walk_mul,walk_const,pow_succ]
    dsimp only
    calc
      _ ≤ (1-4/Q)*(k + ((k:ℝ)*(1-2/Q)^t)^2)+4*k/Q := by gcongr
      _ = k + (1-4/Q)*((k:ℝ)*(1-2/Q)^t)^2 := by ring
      _ ≤ k + (1-2/Q)^2*((k:ℝ)*(1-2/Q)^t)^2 := by gcongr
      _ = _ := by ring

theorem uniform_square (k : ℕ) {Q : ℝ} (hq : Q ≠ 0) :
    uniform (k:=k) (fun x => Z x^2) = k := by
  have e := uniform_step Q (fun x : Bits k => Z x^2)
  rw [step_Z2,uni_add,uni_mul,uni_const] at e
  field_simp [hq] at e
  linarith

theorem centered_square (k : ℕ) {Q : ℝ} (hq : 4 ≤ Q) (t : ℕ)
    (m : ℝ) (hm : m = (k:ℝ)*(1-2/Q)^t) :
    walk Q t (fun x => (Z x-m)^2) (origin k) ≤ k := by
  have eq : (fun x : Bits k => (Z x-m)^2) =
      fun x => (Z x^2 + (-2*m)*Z x) + m^2 := by funext x; ring
  rw [eq,walk_add,walk_add,walk_mul,walk_const]
  dsimp only
  rw [mean_from_origin,← hm]
  have bound := square_from_origin k hq t
  rw [← hm] at bound
  nlinarith

noncomputable def threshold {k : ℕ} (m : ℝ) (x : Bits k) : ℝ :=
  if m ≤ 2*Z x then 1 else 0

/-- A specific measurable event separates the two laws; the left side is its
    time-t probability minus its uniform probability. -/
theorem threshold_separates {k : ℕ} {Q : ℝ} (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q)
    (t : ℕ) (m : ℝ) (hm : m = k*(1-2/Q)^t) (hpos : 0 < m)
    (hbig : 16*(k:ℝ) ≤ m^2) :
    (1:ℝ)/2 ≤ walk Q t (threshold m) (origin k) - uniform (k:=k) (threshold m) := by
  have hq : 0 < Q := by linarith
  have p1 (x : Bits k) : m^2 ≤ m^2 * threshold m x + 4*(Z x-m)^2 := by
    unfold threshold
    split_ifs with e
    · nlinarith [sq_nonneg (Z x-m)]
    · have hs := mul_self_le_mul_self (le_of_lt hpos) (show m ≤ 2*(m-Z x) by linarith)
      nlinarith
  have p2 (x : Bits k) : m^2 * threshold m x ≤ 4*Z x^2 := by
    unfold threshold
    split_ifs with e
    · have hs := mul_self_le_mul_self (le_of_lt hpos) e
      nlinarith
    · nlinarith [sq_nonneg (Z x)]
  have hw := walk_mono hq hkQ t p1 (origin k)
  rw [walk_const,walk_add,walk_mul,walk_mul] at hw
  have hu := uni_mono p2
  rw [uni_mul,uni_mul,uniform_square k hq.ne'] at hu
  have hv := centered_square k hQ t m hm
  have hs : m^2*(1/2) ≤ m^2*(walk Q t (threshold m) (origin k) - uniform (k:=k) (threshold m)) := by
    linarith
  exact (mul_le_mul_iff_right₀ (sq_pos_of_pos hpos)).mp hs

/-- Four-over-Q is a simple uniform exponent for the coordinate bias. -/
theorem bias_exp_lower {Q : ℝ} (hQ : 4 ≤ Q) : Real.exp (-4/Q) ≤ 1-2/Q := by
  have hq : 0 < Q := by linarith
  have h2 : 0 ≤ 1-2/Q := sub_nonneg.mpr ((div_le_one hq).mpr (by linarith))
  have hprod : 1 ≤ (1-2/Q)*(1+4/Q) := by
    apply (le_of_mul_le_mul_right _ (sq_pos_of_pos hq))
    field_simp [hq.ne']
    nlinarith
  rw [show -4/Q=-(4/Q) by ring,Real.exp_neg,inv_le_iff_one_le_mul₀ (Real.exp_pos _)]
  calc
    1 ≤ (1-2/Q)*(1+4/Q) := hprod
    _ ≤ _ := by
      gcongr
      linarith [Real.add_one_le_exp (4/Q)]

theorem logarithmic_signal {k : ℕ} {Q : ℝ} (hk : 0 < k) (hQ : 4 ≤ Q)
    (t : ℕ) (ht : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16)) :
    16*(k:ℝ) ≤ ((k:ℝ)*(1-2/Q)^t)^2 := by
  have hq : 0 < Q := by linarith
  have hk' : (0:ℝ) < k := by exact_mod_cast hk
  have hdiv : 8*(t:ℝ)/Q ≤ Real.log ((k:ℝ)/16) := by
    apply (div_le_iff₀ hq).mpr
    linarith
  have he := Real.exp_le_exp.mpr (neg_le_neg hdiv)
  rw [Real.exp_neg,Real.exp_log (by positivity : (0:ℝ) < k/16)] at he
  have hp : Real.exp (-4/Q)^t ≤ (1-2/Q)^t :=
    pow_le_pow_left₀ (Real.exp_pos _).le (bias_exp_lower hQ) _
  have hs := mul_self_le_mul_self (pow_pos (Real.exp_pos _) _).le hp
  have hident : Real.exp (-(8*(t:ℝ)/Q)) = Real.exp (-4/Q)^t * Real.exp (-4/Q)^t := by
    rw [← Real.exp_nat_mul,← Real.exp_add]
    congr 1
    ring
  rw [hident] at he
  have hlast : 16/(k:ℝ) ≤ ((1-2/Q)^t)^2 := by
    rw [inv_div] at he
    nlinarith
  have hf := (div_le_iff₀ hk').mp hlast
  calc
    16*(k:ℝ) ≤ (((1-2/Q)^t)^2*k)*k := mul_le_mul_of_nonneg_right hf hk'.le
    _ = _ := by ring

theorem tv_lower_log {k : ℕ} {Q : ℝ} (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q)
    (t : ℕ) (ht : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16)) :
    (1:ℝ)/2 ≤ walk Q t (threshold ((k:ℝ)*(1-2/Q)^t)) (origin k) -
        uniform (k:=k) (threshold ((k:ℝ)*(1-2/Q)^t)) := by
  have hq : 0 < Q := by linarith
  have hpos : 0 < 1-2/Q := sub_pos.mpr ((div_lt_one hq).mpr (by linarith))
  apply threshold_separates hQ hkQ t _ rfl
  · positivity
  · exact logarithmic_signal hk hQ t ht
#print axioms tv_lower_log
end CubeLower
