import CubeLower
open Finset
namespace CubeLower

def eventIndicator {k : ℕ} (E : Finset (Bits k)) (x : Bits k) : ℝ :=
  if x ∈ E then 1 else 0

/-- Total variation in its finite-state max-over-events definition. -/
noncomputable def tvFromOrigin (k : ℕ) (Q : ℝ) (t : ℕ) : ℝ :=
  (univ : Finset (Finset (Bits k))).sup' univ_nonempty fun E =>
    |walk Q t (eventIndicator E) (origin k) - uniform (eventIndicator E)|

theorem event_le_tv {k : ℕ} (Q : ℝ) (t : ℕ) (E : Finset (Bits k)) :
    walk Q t (eventIndicator E) (origin k) - uniform (eventIndicator E) ≤ tvFromOrigin k Q t := by
  apply (le_abs_self _).trans
  exact le_sup' (f := fun E : Finset (Bits k) =>
    |walk Q t (eventIndicator E) (origin k) - uniform (eventIndicator E)|) (mem_univ E)

theorem tv_bound {k : ℕ} {Q : ℝ} (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q)
    (t : ℕ) (ht : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16)) :
    (1:ℝ)/2 ≤ tvFromOrigin k Q t := by
  let m := (k:ℝ)*(1-2/Q)^t
  let E : Finset (Bits k) := univ.filter fun x => m ≤ 2*Z x
  have hE : eventIndicator E = threshold m := by
    funext x
    simp [E,eventIndicator,threshold]
  have h := event_le_tv Q t E
  rw [hE] at h
  exact (tv_lower_log hk hQ hkQ t ht).trans h

/-- Any quarter-mixed time must strictly exceed the displayed logarithmic time.
    This also applies to the worst-start mixing time since origin is one start. -/
theorem quarter_mixed_requires {k : ℕ} {Q : ℝ} (hk : 0 < k) (hQ : 4 ≤ Q)
    (hkQ : (k:ℝ) ≤ Q) (t : ℕ) (hTV : tvFromOrigin k Q t ≤ 1/4) :
    Q*Real.log ((k:ℝ)/16)/8 < (t:ℝ) := by
  by_contra! h
  have ht : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16) := by linarith
  linarith [tv_bound hk hQ hkQ t ht]

#print axioms tv_bound
#print axioms quarter_mixed_requires
end CubeLower
