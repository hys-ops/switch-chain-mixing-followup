import CubeTV
open Finset
namespace CubeLower
namespace Transport
variable {α : Type*} [Fintype α] [DecidableEq α]

def indicator (E : Finset α) (x : α) : ℝ := if x ∈ E then 1 else 0
noncomputable def average (f : α → ℝ) : ℝ := (∑ x, f x) / Fintype.card α
noncomputable def iterateStep (op : (α → ℝ) → α → ℝ) : ℕ → (α → ℝ) → α → ℝ
  | 0, f => f
  | t+1, f => iterateStep op t (op f)
noncomputable def tv (op : (α → ℝ) → α → ℝ) (x : α) (t : ℕ) : ℝ :=
  (univ : Finset (Finset α)).sup' univ_nonempty fun E =>
    |iterateStep op t (indicator E) x - average (indicator E)|
noncomputable def kernelOp (K : α → α → ℝ) (f : α → ℝ) (x : α) : ℝ :=
  ∑ y, K x y * f y

omit [DecidableEq α] in
theorem average_equiv {k : ℕ} (e : Bits k ≃ α) (f : α → ℝ) :
    average f = uniform (fun x => f (e x)) := by
  unfold average uniform
  rw [e.sum_comp f,Fintype.card_congr e]

omit [Fintype α] [DecidableEq α] in
theorem iterate_equiv {k : ℕ} {Q : ℝ} (e : Bits k ≃ α) (op : (α → ℝ) → α → ℝ)
    (hop : ∀ (f : α → ℝ) x, op f (e x) = step Q (fun y => f (e y)) x)
    (t : ℕ) (f : α → ℝ) (x : Bits k) :
    iterateStep op t f (e x) = walk Q t (fun y => f (e y)) x := by
  induction t generalizing f with
  | zero => rfl
  | succ t ih =>
    rw [iterateStep,walk,ih]
    exact congrArg (fun g => walk Q t g x) (funext (hop f))

private theorem tv_le {k : ℕ} {Q : ℝ} (e : Bits k ≃ α) (op : (α → ℝ) → α → ℝ)
    (hop : ∀ (f : α → ℝ) x, op f (e x) = step Q (fun y => f (e y)) x) (t : ℕ) :
    tv op (e (origin k)) t ≤ tvFromOrigin k Q t := by
  apply Finset.sup'_le
  intro E _
  let E' := E.map e.symm.toEmbedding
  have hi : (fun x => indicator E (e x)) = eventIndicator E' := by
    funext x
    simp [E',indicator,eventIndicator]
  rw [iterate_equiv e op hop, average_equiv e,hi]
  exact le_sup' (f := fun D : Finset (Bits k) =>
    |walk Q t (eventIndicator D) (origin k) - uniform (eventIndicator D)|) (mem_univ E')

theorem tv_equiv {k : ℕ} {Q : ℝ} (e : Bits k ≃ α) (op : (α → ℝ) → α → ℝ)
    (hop : ∀ (f : α → ℝ) x, op f (e x) = step Q (fun y => f (e y)) x) (t : ℕ) :
    tv op (e (origin k)) t = tvFromOrigin k Q t := by
  apply le_antisymm (tv_le e op hop t)
  apply Finset.sup'_le
  intro E _
  let D := E.map e.toEmbedding
  have hi : (fun x => indicator D (e x)) = eventIndicator E := by
    funext x
    simp [D,indicator,eventIndicator]
  have hd := le_sup' (f := fun H : Finset α =>
    |iterateStep op t (indicator H) (e (origin k)) - average (indicator H)|) (mem_univ D)
  change |iterateStep op t (indicator D) (e (origin k)) - average (indicator D)| ≤ tv op (e (origin k)) t at hd
  rw [iterate_equiv e op hop, average_equiv e,hi] at hd
  exact hd

/-- The graph-side input is only the exact state bijection and one-step row identity.
    Time evolution and TV equality follow for all times and events. -/
theorem quarter_mixed_requires_equiv {k : ℕ} {Q : ℝ} (e : Bits k ≃ α)
    (K : α → α → ℝ)
    (hK : ∀ (f : α → ℝ) x, (∑ y, K (e x) y * f y) = step Q (fun y => f (e y)) x)
    (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q) (t : ℕ)
    (htv : tv (kernelOp K) (e (origin k)) t ≤ 1/4) :
    Q * Real.log ((k:ℝ)/16) / 8 < (t:ℝ) := by
  rw [tv_equiv e (kernelOp K) hK] at htv
  exact quarter_mixed_requires hk hQ hkQ t htv

#print axioms tv_equiv
#print axioms quarter_mixed_requires_equiv
end Transport
end CubeLower
