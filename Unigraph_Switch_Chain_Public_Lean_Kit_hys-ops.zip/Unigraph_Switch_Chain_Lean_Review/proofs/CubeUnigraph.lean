import Identify
import KernelEquivariance
open OAI.Problem315
namespace LayeredLower
noncomputable section
variable {k : ℕ}

/-- In layer i, only the private leaves are permuted. The two centers keep their names. -/
def relabel (x y : Bits k) (v : V k) : V k :=
  let p := (code k).symm v
  pt p.1 p.2.1 (if p.2.1 then p.2.2 else p.2.2 ^^ (x p.1 ^^ y p.1))

@[simp] lemma relabel_pt (x y : Bits k) (i : Fin k) (s b : Bool) :
    relabel x y (pt i s b) = pt i s (if s then b else b ^^ (x i ^^ y i)) := by
  simp [relabel,pt]

theorem relabel_twice (x y : Bits k) (v : V k) : relabel x y (relabel x y v) = v := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v
  cases s <;> cases b <;> cases h : x i <;> cases j : y i <;> simp [h,j]

def relabelPerm (x y : Bits k) : Equiv.Perm (V k) :=
  ⟨relabel x y, relabel x y, relabel_twice x y, relabel_twice x y⟩

@[simp] lemma relabel_weight (x y : Bits k) (v : V k) : weight (relabel x y v) = weight v := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v
  simp

lemma relabel_mate (x y : Bits k) (v : V k) :
    relabel x y (mate x v) = mate y (relabel x y v) := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v
  cases s <;> cases b <;> cases h : x i <;> cases j : y i <;> simp [h,j]

/-- The fixed (positive weight sum) edges and the free matching edges both
    intertwine under the same vertex bijection. -/
def layerGraphIso (x y : Bits k) : graph x ≃g graph y where
  toEquiv := relabelPerm x y
  map_rel_iff' := by
    intro u v
    change (graph y).Adj (relabel x y u) (relabel x y v) ↔ (graph x).Adj u v
    have he (p q : V k) : relabel x y p = relabel x y q ↔ p = q := (relabelPerm x y).injective.eq_iff
    simp only [graph_adj,Back,relabel_weight,← relabel_mate, ne_eq, he]

/-- The exact unigraph predicate used in the upper-bound theorem holds for
    these actual labeled graph-degree realizations. -/
theorem isUnigraphic_deg (k : ℕ) : UnigraphUpper.IsUnigraphic (deg k) := by
  intro G H
  obtain ⟨x,rfl⟩ := (stateEquiv k).surjective G
  obtain ⟨y,rfl⟩ := (stateEquiv k).surjective H
  exact ⟨layerGraphIso x y⟩

#print axioms isUnigraphic_deg
end
end LayeredLower
