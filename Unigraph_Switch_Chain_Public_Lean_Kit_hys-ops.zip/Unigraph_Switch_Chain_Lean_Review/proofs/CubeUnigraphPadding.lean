import CubeUnigraph
import Padding
open OAI.Problem315
namespace LayeredLower.Padding

/-- Extending a sequence by any number of zero degrees preserves having a
    single unlabelled isomorphism class, for the original graph state space. -/
theorem isUnigraphic_extend {m n : ℕ} (h : m ≤ n) {d : Fin m → ℕ}
    (hd : UnigraphUpper.IsUnigraphic d) :
    UnigraphUpper.IsUnigraphic (extendDegrees (n:=n) d) := by
  intro G H
  obtain ⟨e⟩ := hd (trim h G) (trim h H)
  have ee : Nonempty ((G.val.comap (emb h)).map (emb h) ≃g (H.val.comap (emb h)).map (emb h)) :=
    ⟨padded_iso h e⟩
  simpa only [recovered] using ee

theorem isUnigraphic_layered_extend {k n : ℕ} (h : 4*k ≤ n) :
    UnigraphUpper.IsUnigraphic (extendDegrees (n:=n) (deg k)) :=
  isUnigraphic_extend h (isUnigraphic_deg k)

#print axioms isUnigraphic_layered_extend
end LayeredLower.Padding
