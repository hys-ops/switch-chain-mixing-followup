import CubeTransport
import OAI.Probability.SwitchChain.Definitions

open Finset OAI.Problem315
namespace CubeLower.Upstream
noncomputable section
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

theorem iterate_row (t : ℕ) (f : GraphState n d → ℝ) (G : GraphState n d) :
    Transport.iterateStep (Transport.kernelOp (switchKernel n d)) t f G =
    ∑ H, kernelPow n d t G H * f H := by
  induction t generalizing f with
  | zero =>
    classical
    simp [Transport.iterateStep,kernelPow]
  | succ t ih =>
    rw [Transport.iterateStep,ih]
    change (∑ H, kernelPow n d t G H * ∑ J, switchKernel n d H J*f J) =
      ∑ J, (∑ H, kernelPow n d t G H * switchKernel n d H J)*f J
    simp only [Finset.mul_sum,Finset.sum_mul,mul_assoc]
    rw [Finset.sum_comm]

theorem balanced_event {α : Type*} [Fintype α] [DecidableEq α] (u : α → ℝ)
    (hu : ∑ x, u x = 0) (E : Finset α) :
    |∑ x, u x*Transport.indicator E x| ≤ (1/2:ℝ)* ∑ x, |u x| := by
  have h : 2 * ∑ x, u x*Transport.indicator E x =
      ∑ x, (2*Transport.indicator E x-1)*u x := by
    simp_rw [sub_mul,one_mul,Finset.sum_sub_distrib,hu,sub_zero,mul_assoc,← Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro _ _
    ring
  have h' := Finset.abs_sum_le_sum_abs (fun x => (2*Transport.indicator E x-1)*u x) univ
  rw [← h,abs_mul,abs_of_pos (by norm_num : (0:ℝ)<2)] at h'
  have h'' (x : α) : |(2*Transport.indicator E x-1)*u x| = |u x| := by
    by_cases hx : x ∈ E <;> norm_num [Transport.indicator,hx]
  simp only [h''] at h'
  linarith

theorem eventTV_le_source (t : ℕ) (G : GraphState n d)
    (hrow : ∑ H, kernelPow n d t G H = 1) :
    Transport.tv (Transport.kernelOp (switchKernel n d)) G t ≤ tvDistanceFrom n d t G := by
  classical
  have : Nonempty (GraphState n d) := ⟨G⟩
  have hc : (Fintype.card (GraphState n d):ℝ) ≠ 0 := by exact_mod_cast Fintype.card_ne_zero
  apply Finset.sup'_le
  intro E _
  let c := (1:ℝ)/Fintype.card (GraphState n d)
  have hz : (∑ H, (kernelPow n d t G H-c))=0 := by
    simp [Finset.sum_sub_distrib,hrow,c,hc]
  have he := balanced_event _ hz E
  rw [iterate_row]
  have hsum : (∑ H, (kernelPow n d t G H-c)*Transport.indicator E H) =
      (∑ H, kernelPow n d t G H*Transport.indicator E H)-Transport.average (Transport.indicator E) := by
    simp only [sub_mul,Finset.sum_sub_distrib,←Finset.mul_sum,Transport.average,c]
    ring
  rw [hsum] at he
  simpa only [tvDistanceFrom,allGraphStates,stateCount,Finset.card_univ,c] using he

/-- The result uses the published half-L1 TV distance, its actual t-step
   transition, and the original graph with every one of its labeled states. -/
theorem tvDistanceFrom_bound {k : ℕ} {Q : ℝ} (e : Bits k ≃ GraphState n d)
    (hK : ∀ (f : GraphState n d → ℝ) x, (∑ y, switchKernel n d (e x) y * f y) =
      step Q (fun y => f (e y)) x)
    (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q) (t : ℕ)
    (ht : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16)) :
    (1:ℝ)/2 ≤ tvDistanceFrom n d t (e (origin k)) := by
  have hm := Transport.iterate_equiv e (Transport.kernelOp (switchKernel n d)) hK t (fun _ => 1) (origin k)
  rw [iterate_row,walk_const] at hm
  have hr : ∑ H, kernelPow n d t (e (origin k)) H = 1 := by simpa using hm
  have h := eventTV_le_source t (e (origin k)) hr
  rw [Transport.tv_equiv e _ hK] at h
  exact (tv_bound hk hQ hkQ t ht).trans h

theorem mixedAt_bound {k : ℕ} {Q : ℝ} (e : Bits k ≃ GraphState n d)
    (hK : ∀ (f : GraphState n d → ℝ) x, (∑ y, switchKernel n d (e x) y * f y) =
      step Q (fun y => f (e y)) x)
    (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q) (t : ℕ) (ht : MixedAt n d t) :
    Q*Real.log ((k:ℝ)/16)/8 < t := by
  by_contra! h
  have htime : 8*(t:ℝ) ≤ Q*Real.log ((k:ℝ)/16) := by linarith
  linarith [tvDistanceFrom_bound e hK hk hQ hkQ t htime, ht (e (origin k))]

theorem mixingTime_bound {k : ℕ} {Q : ℝ} (e : Bits k ≃ GraphState n d)
    (hK : ∀ (f : GraphState n d → ℝ) x, (∑ y, switchKernel n d (e x) y * f y) =
      step Q (fun y => f (e y)) x)
    (hk : 0 < k) (hQ : 4 ≤ Q) (hkQ : (k:ℝ) ≤ Q) (h : ∃ t, MixedAt n d t) :
    Q*Real.log ((k:ℝ)/16)/8 < (mixingTime n d h : ℝ) := by
  apply mixedAt_bound e hK hk hQ hkQ
  exact Nat.find_spec h

#print axioms tvDistanceFrom_bound
#print axioms mixingTime_bound
end
end CubeLower.Upstream
