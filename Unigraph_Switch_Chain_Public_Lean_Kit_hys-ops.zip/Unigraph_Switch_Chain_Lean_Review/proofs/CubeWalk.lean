import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Tactic

open Finset
namespace CubeLower
abbrev Bits (k : ℕ) := Fin k → Bool
def flip {k : ℕ} (i : Fin k) (x : Bits k) : Bits k := fun j => if j = i then !(x j) else x j
@[simp] theorem flip_twice {k : ℕ} (i : Fin k) (x : Bits k) :
    flip i (flip i x) = x := by
  funext j
  by_cases h : j = i <;> simp [flip,h]
def flipEquiv {k : ℕ} (i : Fin k) : Bits k ≃ Bits k :=
  ⟨flip i, flip i, flip_twice i, flip_twice i⟩
def spin (b : Bool) : ℝ := if b then -1 else 1
@[simp] theorem spin_neg (b : Bool) : spin (!b) = -spin b := by cases b <;> norm_num [spin]
@[simp] theorem spin_sq (b : Bool) : spin b ^ 2 = 1 := by cases b <;> norm_num [spin]
noncomputable def Z {k : ℕ} (x : Bits k) : ℝ := ∑ i, spin (x i)
theorem Z_flip {k : ℕ} (i : Fin k) (x : Bits k) : Z (flip i x) = Z x - 2 * spin (x i) := by
  classical
  have hi : i ∈ (univ : Finset (Fin k)) := mem_univ i
  unfold Z
  rw [← sum_erase_add _ _ hi, ← sum_erase_add _ (fun j => spin (x j)) hi]
  have h : ∑ j ∈ univ.erase i, spin (flip i x j) = ∑ j ∈ univ.erase i, spin (x j) := by
    apply sum_congr rfl
    intro j hj
    simp [flip,(mem_erase.mp hj).1]
  rw [h]
  simp [flip]
  ring

noncomputable def step {k : ℕ} (Q : ℝ) (f : Bits k → ℝ) (x : Bits k) : ℝ :=
  (1-k/Q)*f x + (∑ i, f (flip i x))/Q
noncomputable def walk {k : ℕ} (Q : ℝ) : ℕ → (Bits k → ℝ) → Bits k → ℝ
  | 0, f => f
  | t+1, f => walk Q t (step Q f)

theorem step_const {k : ℕ} (Q c : ℝ) :
    step (k:=k) Q (fun _ => c) = fun _ => c := by
  funext x
  simp [step]
  ring

theorem step_add {k : ℕ} (Q : ℝ) (f g : Bits k → ℝ) :
    step Q (fun x => f x+g x) = fun x => step Q f x + step Q g x := by
  funext x
  simp only [step,sum_add_distrib]
  ring
theorem step_mul {k : ℕ} (Q c : ℝ) (f : Bits k → ℝ) :
    step Q (fun x => c*f x) = fun x => c*step Q f x := by
  funext x
  simp only [step,← mul_sum]
  ring
theorem step_mono {k : ℕ} {Q : ℝ} (hQ : 0 < Q) (hk : (k:ℝ) ≤ Q)
    {f g : Bits k → ℝ} (h : ∀ x, f x ≤ g x) (x : Bits k) :
    step Q f x ≤ step Q g x := by
  unfold step
  gcongr
  · exact sub_nonneg.mpr ((div_le_one hQ).mpr hk)
  · exact h x
  · exact h _
theorem walk_const {k : ℕ} (Q c : ℝ) (t : ℕ) : walk (k:=k) Q t (fun _ => c) = fun _ => c := by
  induction t with
  | zero => rfl
  | succ t ih => rwa [walk,step_const]
theorem walk_add {k : ℕ} (Q : ℝ) (t : ℕ) (f g : Bits k → ℝ) :
    walk Q t (fun x => f x+g x) = fun x => walk Q t f x + walk Q t g x := by
  induction t generalizing f g with
  | zero => rfl
  | succ t ih => exact (congrArg (walk Q t) (step_add Q f g)).trans (ih _ _)
theorem walk_mul {k : ℕ} (Q c : ℝ) (t : ℕ) (f : Bits k → ℝ) :
    walk Q t (fun x => c*f x) = fun x => c*walk Q t f x := by
  induction t generalizing f with
  | zero => rfl
  | succ t ih => exact (congrArg (walk Q t) (step_mul Q c f)).trans (ih _)
theorem walk_mono {k : ℕ} {Q : ℝ} (hQ : 0 < Q) (hk : (k:ℝ) ≤ Q) (t : ℕ)
    {f g : Bits k → ℝ} (h : ∀ x, f x ≤ g x) (x : Bits k) : walk Q t f x ≤ walk Q t g x := by
  induction t generalizing f g with
  | zero => exact h x
  | succ t ih => exact ih (step_mono hQ hk h)

theorem step_Z {k : ℕ} (Q : ℝ) : step Q (Z (k:=k)) = fun x => (1-2/Q)*Z x := by
  funext x
  simp [step,Z_flip,sum_sub_distrib,← mul_sum]
  unfold Z
  ring
theorem step_Z2 {k : ℕ} (Q : ℝ) :
    step (k:=k) Q (fun x => Z x ^ 2) = fun x => (1-4/Q)*Z x ^ 2 + 4*k/Q := by
  funext x
  have h (i : Fin k) : Z (flip i x)^2 = Z x^2 + 4 - (4*Z x)*spin (x i) := by
    rw [Z_flip]
    nlinarith [spin_sq (x i)]
  simp only [step,h,sum_sub_distrib,sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul,← mul_sum]
  unfold Z
  ring

noncomputable def uniform {k : ℕ} (f : Bits k → ℝ) : ℝ :=
  (∑ x, f x) / Fintype.card (Bits k)
theorem uni_const {k : ℕ} (c : ℝ) : uniform (k:=k) (fun _ => c) = c := by
  simp [uniform]
theorem uni_add {k : ℕ} (f g : Bits k → ℝ) :
    uniform (fun x => f x+g x) = uniform f+uniform g := by simp [uniform,sum_add_distrib,add_div]
theorem uni_mul {k : ℕ} (c : ℝ) (f : Bits k → ℝ) :
    uniform (fun x => c*f x) = c*uniform f := by simp [uniform,← mul_sum,mul_div_assoc]
theorem uni_mono {k : ℕ} {f g : Bits k → ℝ} (h : ∀ x, f x ≤ g x) : uniform f ≤ uniform g := by
  unfold uniform
  gcongr
  exact h _
theorem uniform_step {k : ℕ} (Q : ℝ) (f : Bits k → ℝ) : uniform (step Q f) = uniform f := by
  have hinv (i : Fin k) : ∑ x, f (flip i x) = ∑ x, f x := (flipEquiv i).sum_comp f
  unfold uniform
  congr 1
  simp only [step,sum_add_distrib,← mul_sum,← sum_div,sum_comm (s:=univ (α:=Bits k)) (t:=univ (α:=Fin k)),
    hinv,sum_const,card_univ,Fintype.card_fin,nsmul_eq_mul]
  ring
end CubeLower
