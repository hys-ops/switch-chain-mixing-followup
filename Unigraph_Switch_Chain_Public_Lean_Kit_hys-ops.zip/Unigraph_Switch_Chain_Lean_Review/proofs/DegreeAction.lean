import KernelEquivariance

open scoped BigOperators RealInnerProductSpace
noncomputable section
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
open PairResampling
variable {n : ℕ} {d : Fin n → ℕ}

def degreeGroup (d : Fin n → ℕ) : Subgroup (Equiv.Perm (Fin n)) where
  carrier := { σ | ∀ v, d (σ v) = d v }
  one_mem' := fun _ => rfl
  mul_mem' {σ τ} hσ hτ v := (hσ (τ v)).trans (hτ v)
  inv_mem' {σ} hσ v := by simpa using (hσ (σ.symm v)).symm

abbrev Γ (d : Fin n → ℕ) := ↥(degreeGroup d)

def action (g : Γ d) : Equiv.Perm (GraphState n d) := labelEquiv g.1 g.2

theorem action_one (G : GraphState n d) : action (1 : Γ d) G = G := by
  apply Subtype.ext; ext u v; rfl

theorem action_mul (g h : Γ d) (G : GraphState n d) :
    action (g*h) G = action h (action g G) := by rfl

theorem exists_action (hu : IsUnigraphic d) (G H : GraphState n d) :
    ∃ g : Γ d, action g G = H := by
  obtain ⟨σ,hs,he⟩ := single_orbit hu G H
  exact ⟨⟨σ,hs⟩,he⟩

def groupAnchor (d : Fin n → ℕ) (a : Finset (Fin n)) : Γ d :=
  if h : ∃ p, Eligible (d := d) a p then
    ⟨Equiv.swap h.choose.1 h.choose.2, swap_preserves_degree _ _ h.choose_spec.2.2⟩
  else 1

theorem action_anchor (a : Finset (Fin n)) (G : GraphState n d) :
    action (groupAnchor d a) G = anchorSwap a G := by
  unfold groupAnchor anchorSwap
  split_ifs with h
  · rfl
  · exact action_one _

theorem groupAnchor_square (a : Finset (Fin n)) :
    groupAnchor d a * groupAnchor d a = 1 := by
  unfold groupAnchor
  split_ifs with h
  · apply Subtype.ext; exact Equiv.swap_mul_self _ _
  · exact one_mul _

def orbit (G : GraphState n d) (g : Γ d) : GraphState n d := action g G

theorem orbit_surj (hu : IsUnigraphic d) (G : GraphState n d) :
    Function.Surjective (orbit G) := exists_action hu G

def fiberSize (base H : GraphState n d) : ℕ :=
  (Finset.univ.filter (fun g : Γ d => orbit base g = H)).card

theorem fiberSize_eq (hu : IsUnigraphic d) (base A B : GraphState n d) :
    fiberSize base A = fiberSize base B := by
  obtain ⟨h,hh⟩ := exists_action hu A B
  unfold fiberSize
  apply Finset.card_bijective (Equiv.mulRight h) (Equiv.mulRight h).bijective
  intro g
  simp only [Finset.mem_filter, Finset.mem_univ, true_and]
  change (orbit base g = A) ↔ orbit base (g*h) = B
  change _ ↔ action h (orbit base g) = B
  rw [← hh]
  exact (action h).injective.eq_iff.symm

theorem fiberSize_pos (base : GraphState n d) : 0 < fiberSize base base := by
  apply Finset.card_pos.mpr
  exact ⟨1, Finset.mem_filter.mpr ⟨Finset.mem_univ _,action_one _⟩⟩

theorem sum_orbit (hu : IsUnigraphic d) (base : GraphState n d) (f : GraphState n d → ℝ) :
    (∑ g : Γ d, f (orbit base g)) = (fiberSize base base : ℝ) * ∑ H, f H := by
  classical
  have hf (H : GraphState n d) :
      (∑ g : Γ d, if orbit base g = H then f H else 0) = fiberSize base base * f H := by
    rw [← Finset.sum_filter]
    simp only [Finset.sum_const,nsmul_eq_mul]
    change (fiberSize base H : ℝ)*f H = _
    rw [fiberSize_eq hu base H base]
  calc
    _ = ∑ g : Γ d, ∑ H, if orbit base g = H then f H else 0 := by simp
    _ = _ := by rw [Finset.sum_comm]; simp_rw [hf]; rw [Finset.mul_sum]

def regMove (a : ↥(pairs n)) : Equiv.Perm (Γ d) := Equiv.mulRight (groupAnchor d a.1)

theorem regMove_involution (a : ↥(pairs n)) (g : Γ d) :
    regMove a (regMove a g) = g := by
  change (g*groupAnchor d a.1)*groupAnchor d a.1 = g
  rw [mul_assoc,groupAnchor_square,mul_one]

#print axioms fiberSize_eq
#print axioms sum_orbit
#print axioms regMove_involution
end OAI.Problem315.UnigraphUpper
