import DegreeAction

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

abbrev Colors (d : Fin n → ℕ) := ↥(Finset.univ.image d)
def color (d : Fin n → ℕ) (v : Fin n) : Colors d :=
  ⟨d v,Finset.mem_image_of_mem _ (Finset.mem_univ _)⟩
abbrev Block (d : Fin n → ℕ) (k : Colors d) := {v : Fin n // d v = k.1}
abbrev Blocks (d : Fin n → ℕ) := (k : Colors d) → Equiv.Perm (Block d k)

def sigmaVertices (d : Fin n → ℕ) : (Σ k : Colors d, Block d k) ≃ Fin n where
  toFun z := z.2.1
  invFun v := ⟨color d v,v,rfl⟩
  left_inv z := by
    rcases z with ⟨⟨k,hk⟩,⟨v,hv⟩⟩
    dsimp at hv
    subst k
    rfl
  right_inv _ := rfl

def restrictBlock (g : Γ d) (k : Colors d) : Equiv.Perm (Block d k) where
  toFun x := ⟨g.1 x.1,(g.2 x.1).trans x.2⟩
  invFun x := ⟨g.1.symm x.1,((g⁻¹ : Γ d).2 x.1).trans x.2⟩
  left_inv x := Subtype.ext (g.1.symm_apply_apply _)
  right_inv x := Subtype.ext (g.1.apply_symm_apply _)

def blocksPerm (g : Blocks d) : Equiv.Perm (Fin n) :=
  (sigmaVertices d).symm.trans ((Equiv.sigmaCongrRight g).trans (sigmaVertices d))

theorem blocksPerm_degree (g : Blocks d) (v : Fin n) : d (blocksPerm g v) = d v :=
  (g (color d v) ⟨v,rfl⟩).2

/-- Product decomposition of the actual group preserving the labelled degree map. -/
def blockEquiv (d : Fin n → ℕ) : Γ d ≃* Blocks d where
  toFun := restrictBlock
  invFun g := ⟨blocksPerm g,blocksPerm_degree g⟩
  left_inv g := by apply Subtype.ext; apply Equiv.ext; intro v; rfl
  right_inv g := by
    funext k
    apply Equiv.ext
    intro x
    apply Subtype.ext
    rcases k with ⟨k,hk⟩
    rcases x with ⟨v,hv⟩
    dsimp at hv
    subst k
    rfl
  map_mul' g h := by funext k; apply Equiv.ext; intro x; rfl

/-- Blocks are exactly the nonempty degree classes, whose cardinalities sum to n. -/
theorem block_card_sum (d : Fin n → ℕ) : (∑ k : Colors d, Fintype.card (Block d k)) = n := by
  rw [← Fintype.card_sigma,Fintype.card_congr (sigmaVertices d),Fintype.card_fin]

theorem card_block_pos (k : Colors d) : 0 < Fintype.card (Block d k) := by
  obtain ⟨v,_,hv⟩ := Finset.mem_image.mp k.2
  exact Fintype.card_pos_iff.mpr ⟨v,hv⟩

/-- A blockwise anchor permutation on the original labels. -/
def blockAnchor (k : Colors d) (u v : Block d k) : Γ d :=
  ⟨Equiv.swap u.1 v.1, swap_preserves_degree _ _ (u.2.trans v.2.symm)⟩

theorem blockAnchor_restrict_self (k : Colors d) (u v : Block d k) :
    blockEquiv d (blockAnchor k u v) k = Equiv.swap u v := by
  apply Equiv.ext
  intro w
  apply Subtype.ext
  change Equiv.swap u.1 v.1 w.1 = (Equiv.swap u v w).1
  by_cases hu : w = u
  · subst w; simp
  by_cases hv : w = v
  · subst w; simp
  rw [Equiv.swap_apply_of_ne_of_ne hu hv,
    Equiv.swap_apply_of_ne_of_ne (fun h => hu (Subtype.ext h)) (fun h => hv (Subtype.ext h))]

theorem blockAnchor_restrict_other (k l : Colors d) (hl : l ≠ k) (u v : Block d k) :
    blockEquiv d (blockAnchor k u v) l = 1 := by
  apply Equiv.ext; intro w; apply Subtype.ext
  change Equiv.swap u.1 v.1 w.1 = w.1
  apply Equiv.swap_apply_of_ne_of_ne
  · intro h
    exact hl (Subtype.ext (w.2.symm.trans ((congrArg d h).trans u.2)))
  · intro h
    exact hl (Subtype.ext (w.2.symm.trans ((congrArg d h).trans v.2)))

theorem updated_group (k : Colors d) (u v : Block d k) (g : Γ d) :
    (blockEquiv d) (g * blockAnchor k u v) =
      Function.update (blockEquiv d g) k (blockEquiv d g k * Equiv.swap u v) := by
  ext l w
  by_cases hl : l = k
  · subst l; simp only [map_mul,Pi.mul_apply,Function.update_self,blockAnchor_restrict_self]
  · simp only [map_mul,Pi.mul_apply,Function.update_of_ne hl,
      blockAnchor_restrict_other k l hl,mul_one]

#print axioms blockEquiv
#print axioms block_card_sum
#print axioms updated_group
end OAI.Problem315.UnigraphUpper
