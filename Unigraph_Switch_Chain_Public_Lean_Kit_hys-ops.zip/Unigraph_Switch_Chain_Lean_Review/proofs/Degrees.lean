import Family
namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k : ℕ}

def bi (u v : V k) : ℤ := if Back u v then 1 else 0

lemma block_core (i j : Fin k) (b : Bool) :
   ∑ z : Bool × Bool, bi (pt i true b) (pt j z.1 z.2) =
     2+2*(if i < j then 1 else 0) - (if j=i then 1 else 0) := by
  have hi := i.isLt; have hj := j.isLt
  classical
  simp only [Fintype.sum_prod_type,Fintype.sum_bool]
  by_cases e : i = j
  · subst j
    have hp : 0 < (k:ℤ) - i.val + ((k:ℤ)-i.val) := by omega
    cases b <;> simp [bi,Back,hp]
  · have a : 0 < (k:ℤ)-i.val + ((k:ℤ)-j.val) := by omega
    have ci : (i:ℕ)≠(j:ℕ) := fun h => e (Fin.ext h)
    cases b <;> simp [bi,Back,e,Ne.symm e,a] <;> split_ifs <;> omega

lemma block_leaf (i j : Fin k) (b : Bool) :
   ∑ z : Bool × Bool, bi (pt i false b) (pt j z.1 z.2) =
     2*(if j < i then 1 else 0) := by
  have hi := i.isLt; have hj := j.isLt
  classical
  simp only [Fintype.sum_prod_type,Fintype.sum_bool]
  by_cases e : i = j
  · subst j
    cases b <;> simp [bi,Back]
  · have ci : (i:ℕ)≠(j:ℕ) := fun h => e (Fin.ext h)
    cases b <;> simp [bi,Back,e] <;> split_ifs <;> omega

lemma degree_as_sum (v : V k) : (deg k v : ℤ)= (∑ j : Fin k, ∑ z : Bool × Bool, bi v (pt j z.1 z.2))+1 := by
  have he := (code k).sum_comp (bi v)
  rw [Fintype.sum_prod_type] at he
  change (deg k v : ℤ)= (∑ j,∑ z : Bool × Bool,bi v (code k (j,z)))+1
  rw [he]; simp [deg,bi,Finset.sum_boole]

private lemma count_below (i : Fin k) : ∑ j : Fin k, (if j < i then (1:ℤ) else 0) = (i:ℕ) := by
  rw [Finset.sum_boole]
  have he : univ.filter (· < i) = Iio i := by ext j;simp
  rw [he,Fin.card_Iio]

private lemma count_above (i : Fin k) : ∑ j : Fin k, (if i < j then (1:ℤ) else 0) = ((k-1-i.val:ℕ):ℤ) := by
  rw [Finset.sum_boole]
  have he : univ.filter (i < ·) = Ioi i := by ext j;simp
  rw [he,Fin.card_Ioi]

/-- The two explicit degrees, in zero-based layer numbering, are 4k−2i−2 and 2i+1. -/
theorem explicit_degree (i : Fin k) (s b : Bool) :
    deg k (pt i s b) = if s then 4*k-2*i.val-2 else 2*i.val+1 := by
  have hs:=degree_as_sum (pt i s b)
  have hi:=i.isLt
  cases s
  · simp only [block_leaf,←Finset.mul_sum,count_below] at hs
    simp; omega
  · simp only [block_core,Finset.sum_sub_distrib,Finset.sum_add_distrib,←Finset.mul_sum,count_above] at hs
    simp at hs; simp; omega

#print axioms explicit_degree
end
end LayeredLower
