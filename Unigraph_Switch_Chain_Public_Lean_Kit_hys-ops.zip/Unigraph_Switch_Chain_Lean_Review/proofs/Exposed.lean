import OAI.Probability.SwitchChain.ProposalUniqueness
import OAI.Probability.SwitchChain.FourVertexSwitch

/- A linear exposure certificate for fixed graph degrees. -/
namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable

variable {n : ℕ}
def ind (G : SimpleGraph (Fin n)) (u v : Fin n) : ℤ := if G.Adj u v then 1 else 0

lemma ind_symm (G : SimpleGraph (Fin n)) (u v : Fin n) : ind G u v = ind G v u := by
  simp only [ind, G.adj_comm]

lemma row_sum (G : SimpleGraph (Fin n)) (u : Fin n) : ∑ v, ind G u v = graphDegree G u := by
  simp [ind, graphDegree, Finset.sum_boole]

lemma weighted_handshake (w : Fin n → ℤ) (G : SimpleGraph (Fin n)) :
    ∑ u, ∑ v, (w u+w v) * ind G u v = 2*∑ u, w u*(graphDegree G u : ℤ) := by
  simp only [add_mul, Finset.sum_add_distrib]
  have hf : ∑ u, ∑ v, (w v * ind G u v) = ∑ u, ∑ v, (w u * ind G u v) := by
    rw [Finset.sum_comm]
    exact Finset.sum_congr rfl fun x _ => Finset.sum_congr rfl fun y _ => by rw [ind_symm G y x]
  rw [hf]
  simp only [← Finset.mul_sum,row_sum,two_mul]

/-- For a degree-fibre maximizer selecting every positive-weight edge and no
negative-weight edges, all nonzero-weight incidences are forced in the fibre. -/
theorem forced_adjacency (G H : SimpleGraph (Fin n)) (w : Fin n → ℤ)
    (hd : ∀ i, graphDegree G i = graphDegree H i)
    (pos : ∀ i j, i≠j → 0 < w i+w j → G.Adj i j)
    (neg : ∀ i j, w i+w j<0 → ¬ G.Adj i j) (u v : Fin n)
    (huv : w u+w v ≠ 0) : H.Adj u v ↔ G.Adj u v := by
  let E := fun i j => (w i+w j)*(ind G i j-ind H i j)
  have hn (i j : Fin n) : 0 ≤ E i j := by
    unfold E ind
    by_cases he : i=j
    · subst j; simp
    split_ifs with hg hh hh
    · simp
    · have h : 0 ≤ w i+w j := by by_contra! hall; exact neg i j hall hg
      simpa using h
    · have h : w i+w j ≤ 0 := by by_contra! hall; exact hg (pos i j he hall)
      simp; omega
    · simp
  have hz : ∑ i,∑ j,E i j=0 := by
    simp only [E,mul_sub,Finset.sum_sub_distrib,weighted_handshake,hd,sub_self]
  have hr : ∑ j,E u j=0 := (Finset.sum_eq_zero_iff_of_nonneg
    (fun i _ => Finset.sum_nonneg (fun j _ => hn i j))).1 hz u (by simp)
  have hentry := (Finset.sum_eq_zero_iff_of_nonneg (fun j _ => hn u j)).1 hr v (by simp)
  have heq : ind G u v = ind H u v := sub_eq_zero.mp ((mul_eq_zero.mp hentry).resolve_left huv)
  unfold ind at heq
  split_ifs at heq <;> simp_all

end
end LayeredLower
