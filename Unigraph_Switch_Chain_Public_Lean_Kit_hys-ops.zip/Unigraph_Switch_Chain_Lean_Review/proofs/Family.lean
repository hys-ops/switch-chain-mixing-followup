import Exposed

namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
abbrev Bits (k : ℕ) := Fin k → Bool
abbrev V (k : ℕ) := Fin (4*k)
variable {k : ℕ}

def code (k : ℕ) : (Fin k × Bool × Bool) ≃ V k := Fintype.equivOfCardEq (by simp [V]; omega)
def pt (i : Fin k) (s b : Bool) : V k := code k (i,s,b)
@[simp] lemma pt_eq {i j : Fin k} {s t a b : Bool} : pt i s a = pt j t b ↔ i=j ∧ s=t ∧ a=b := by simp [pt]
lemma vertex_cases (v : V k) : ∃ i s b, v = pt i s b := by
  obtain ⟨⟨i,s,b⟩,rfl⟩ := (code k).surjective v; exact ⟨i,s,b,rfl⟩

def weight (v : V k) : ℤ := let p := (code k).symm v; if p.2.1 then (k:ℤ)-p.1.val else -((k:ℤ)-p.1.val)
@[simp] lemma weight_pt (i : Fin k) (s b : Bool) : weight (pt i s b) = if s then (k:ℤ)-i.val else -((k:ℤ)-i.val) := by simp [weight,pt]
def mate (x : Bits k) (v : V k) : V k := let p := (code k).symm v; pt p.1 (!p.2.1) (p.2.2 ^^ x p.1)
@[simp] lemma mate_pt (x : Bits k) (i : Fin k) (s b : Bool) : mate x (pt i s b) = pt i (!s) (b ^^ x i) := by simp [mate,pt]
@[simp] lemma mate_mate (x : Bits k) (v : V k) : mate x (mate x v)=v := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v; cases s <;> cases b <;> cases H : x i <;> simp [H]
lemma mate_ne (x : Bits k) (v : V k) : v≠mate x v := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v; cases s <;> simp
@[simp] lemma mate_weights (x : Bits k) (v : V k) : weight v + weight (mate x v) = 0 := by
  obtain ⟨i,s,b,rfl⟩ := vertex_cases v; cases s <;> simp

def Back (u v : V k) : Prop := u≠v ∧ 0 < weight u+weight v

def graph (x : Bits k) : SimpleGraph (V k) where
  Adj u v := Back u v ∨ v=mate x u
  symm := ⟨by rintro u v (h|rfl)
              · exact Or.inl ⟨h.1.symm,by simpa [add_comm] using h.2⟩
              · simp⟩
  loopless := ⟨by intro u; simp [Back,mate_ne]⟩
@[simp] lemma graph_adj (x : Bits k) (u v : V k) : (graph x).Adj u v ↔ Back u v ∨ v=mate x u := Iff.rfl

def deg (k : ℕ) (u : V k) := (univ.filter (Back u)).card+1
lemma graph_deg (x : Bits k) (v : V k) : graphDegree (graph x) v=deg k v := by
  classical
  have h : mate x v ∉ univ.filter (Back v) := by simp [Back]
  have hs : univ.filter ((graph x).Adj v) = insert (mate x v) (univ.filter (Back v)) := by
    ext j; simp [or_comm]
  unfold graphDegree deg
  rw [hs,Finset.card_insert_of_notMem h]
def state (x : Bits k) : GraphState (4*k) (deg k) := ⟨graph x,graph_deg x⟩

lemma fixed (G : GraphState (4*k) (deg k)) {u v : V k} (hw : weight u+weight v ≠ 0) :
    G.val.Adj u v ↔ Back u v := by
  let x : Bits k := fun _ => false
  have h := forced_adjacency (graph x) G.val weight (fun j => (graph_deg _ _).trans (G.2 j).symm)
    (fun i j hij hp => Or.inl ⟨hij,hp⟩) (fun i j hn => by
      rintro (h|rfl)
      · exact (not_lt.mpr (le_of_lt h.2)) hn
      · rw [mate_weights] at hn; omega) u v hw
  rw [h,graph_adj]; constructor
  · rintro (h|rfl); exact h; exact (hw (mate_weights _ _)).elim
  · exact Or.inl

/-- The free graph at each vertex has exactly one neighbor. -/
lemma free_card (G : GraphState (4*k) (deg k)) (u : V k) :
   (univ.filter (fun v => G.val.Adj u v ∧ weight u+weight v = 0)).card=1 := by
  classical
  let F := univ.filter (fun v => G.val.Adj u v ∧ weight u+weight v = 0)
  let B := univ.filter (Back u)
  have he : univ.filter (G.val.Adj u) = B ∪ F := by
    ext v; simp only [B,F,mem_filter,mem_univ,true_and,mem_union]
    by_cases hw : weight u+weight v=0
    · have hn : ¬Back u v := by rintro ⟨_,h⟩; omega
      simp [hw,hn]
    · simp [hw,fixed G hw]
  have hd : Disjoint B F := Finset.disjoint_left.mpr (by
    intro v hv hf
    have hb := (mem_filter.mp hv).2.2
    have hz := (mem_filter.mp hf).2.2
    omega)
  have hrow := G.2 u
  change (univ.filter (G.val.Adj u)).card = B.card+1 at hrow
  rw [he,Finset.card_union_of_disjoint hd] at hrow
  change F.card=1; omega

lemma zero_iff (i j : Fin k) (s t a b : Bool) :
    weight (pt i s a) + weight (pt j t b)=0 ↔ j=i ∧ t= !s := by
  have hi := i.isLt; have hj := j.isLt
  cases s <;> cases t <;> simp [Fin.ext_iff] <;> omega

lemma row_choice (G : GraphState (4*k) (deg k)) (i : Fin k) (s b : Bool) :
   ∃! c : Bool, G.val.Adj (pt i s b) (pt i (!s) c) := by
  obtain ⟨v,hv⟩ := card_eq_one.mp (free_card G (pt i s b))
  have hh (w : V k) : G.val.Adj (pt i s b) w ∧ weight (pt i s b)+weight w=0 ↔ w=v := by
    simpa using (Finset.ext_iff.mp hv w)
  obtain ⟨j,t,c,hv⟩ := vertex_cases v
  have h := (hh v).mpr rfl
  rw [hv,zero_iff] at h
  obtain ⟨ha,hj,ht⟩ := h; subst j; subst t
  refine ⟨c,ha,fun d hd => ?_⟩
  have h' := (hh (pt i (!s) d)).mp ⟨hd,(zero_iff _ _ _ _ _ _).mpr ⟨rfl,rfl⟩⟩
  rw [hv] at h'; exact (pt_eq.mp h').2.2

end
end LayeredLower
