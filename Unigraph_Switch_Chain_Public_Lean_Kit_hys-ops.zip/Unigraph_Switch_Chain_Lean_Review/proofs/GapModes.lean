import Mathlib.Analysis.Matrix.PosDef
import Mathlib.LinearAlgebra.Matrix.ToLinearEquiv
import Mathlib.Tactic
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphModes
variable {A : Type*} [Fintype A] [DecidableEq A] [Nonempty A]

/-- A simple constant kernel and a lower bound on the nonzero eigenvalues
supply exactly the distinguished mode and complementary gaps in the product trace. -/
theorem gap_modes (D : Matrix A A ℝ) (hD : D.IsHermitian) (m : ℝ)
    (hone : D *ᵥ (fun _ => 1) = 0)
    (hkernel : ∀ f : A → ℝ, D *ᵥ f = 0 → ∃ z : ℝ, ∀ x, f x=z)
    (hgap : ∀ (f : A → ℝ) (v : ℝ), v ≠ 0 → f ≠ 0 → D *ᵥ f=v • f → m≤v) :
    ∃ (b : OrthonormalBasis A ℝ (EuclideanSpace ℝ A)) (ξ : A → ℝ) (a₀ : A),
      ξ a₀=0 ∧ (∀ a, a≠a₀ → m≤ξ a) ∧ (∀ i, D *ᵥ (b i : A→ℝ)=ξ i • (b i : A→ℝ)) := by
  classical
  let b := hD.eigenvectorBasis
  let ξ := hD.eigenvalues
  have heig (i : A) : D *ᵥ (b i : A→ℝ) = ξ i • (b i : A→ℝ) := hD.mulVec_eigenvectorBasis i
  have hnonzero (i : A) : (b i : A→ℝ) ≠ 0 :=
    (WithLp.ofLp_eq_zero 2).ne.2 (b.orthonormal.ne_zero i)
  let i0 := Classical.arbitrary A
  have hdet : D.det = 0 := Matrix.det_eq_zero_of_mulVec_eq_zero_of_mem_nonZeroDivisors hone
    (i := i0) (show (1:ℝ) ∈ nonZeroDivisors ℝ by simp)
  rw [hD.det_eq_prod_eigenvalues] at hdet
  obtain ⟨a₀, _, ha₀⟩ := Finset.prod_eq_zero_iff.mp hdet
  have hconst (i : A) (hi : ξ i=0) : ∃ z : ℝ, z ≠ 0 ∧ ∀ x, b i x=z := by
    obtain ⟨z,hz⟩ := hkernel _ (by simpa [hi] using heig i)
    refine ⟨z,?_,hz⟩
    intro h
    exact hnonzero i (by funext x; simpa [h] using hz x)
  refine ⟨b,ξ,a₀,ha₀,?_,heig⟩
  intro a ha
  apply hgap _ _ _ (hnonzero a) (heig a)
  intro hz
  obtain ⟨c,hc,hci⟩ := hconst a hz
  obtain ⟨d,hd,hdi⟩ := hconst a₀ ha₀
  have orth := (orthonormal_iff_ite.mp b.orthonormal) a a₀
  change (∑ x : A,b a₀ x * b a x) = (if a=a₀ then 1 else 0) at orth
  simp only [hci, hdi, ha, ↓reduceIte, Finset.sum_const, Finset.card_univ, nsmul_eq_mul] at orth
  exact (mul_ne_zero (by exact_mod_cast Fintype.card_ne_zero) (mul_ne_zero hd hc)) orth

#print axioms gap_modes
end UnigraphModes
