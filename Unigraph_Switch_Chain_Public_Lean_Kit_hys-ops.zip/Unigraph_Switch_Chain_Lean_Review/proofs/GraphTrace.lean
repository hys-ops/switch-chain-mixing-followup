import KernelEquivariance
import OrbitTrace

open scoped BigOperators RealInnerProductSpace Matrix
noncomputable section
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
open PairResampling
variable {n : ℕ} {d : Fin n → ℕ}

abbrev graphP (d : Fin n → ℕ) : Matrix (GraphState n d) (GraphState n d) ℝ :=
  Matrix.of (switchKernel n d)

theorem graphP_psd (hn : 4 ≤ n) : (graphP d).PosSemidef := by
  refine Matrix.posSemidef_iff_dotProduct_mulVec.mpr ⟨?_,?_⟩
  · apply Matrix.IsHermitian.ext
    intro G H
    simpa using switchKernel_symm (d := d) H G
  · intro f
    have hp := FiniteKernel.lazy_inner_nonneg (switchKernel n d) (switchKernel_row_sum hn)
      switchKernel_symm switchKernel_nonneg switchKernel_self_ge_half f
    simpa [graphP,Matrix.mulVec,dotProduct] using hp

theorem rowTV_eq (t : ℕ) (G : GraphState n d) :
    UnigraphTrace.rowTV (graphP d) t G = tvDistanceFrom n d t G := by
  unfold UnigraphTrace.rowTV tvDistanceFrom
  rw [← kernelPow_eq_matrix_pow]
  simp only [stateCount,allGraphStates, Finset.card_univ, div_eq_inv_mul,mul_one]

/-- Pointwise total variation for the actual graph chain is controlled by its
matrix trace when all realizations are isomorphic. -/
theorem unigraph_tv_trace (hn : 4 ≤ n) (hu : IsUnigraphic d) (t : ℕ) (G : GraphState n d) :
    4 * (tvDistanceFrom n d t G)^2 ≤ ((graphP d)^(2*t)).trace - 1 := by
  rw [← rowTV_eq]
  apply UnigraphTrace.rowTV_trace _ (Matrix.IsSymm.ext (fun A B => switchKernel_symm B A))
    (switchKernel_row_sum hn) (unigraph_kernel_transitive hu)

/-- On the original clock the comparison is J ≤ 2 Q (I−P). -/
theorem graphP_energy (hn : 4 ≤ n) (x : StateSpace n d) :
    (∑ G, x G * labelLaplacian (fun H => x H) G) ≤
      2*(12*(n.choose 4 : ℝ))*(‖x‖^2 - ⟪x,(graphP d).toEuclideanLin x⟫) := by
  let Q : ℝ := 12*(n.choose 4 : ℝ)
  have hc : (0 : ℝ) < n.choose 4 := by exact_mod_cast Nat.choose_pos hn
  have hQ : Q ≠ 0 := by dsimp [Q]; positivity
  have hp (G : GraphState n d) :
      switchLaplacian n d (fun H => x H) G =
      Q*(x G - (graphP d).toEuclideanLin x G) := by
    have h := sub_markovApply_eq_switchLaplacian (switchKernel_row_sum hn) (fun H => x H) G
    change x G - ((graphP d).toEuclideanLin x) G = _ / Q at h
    linarith [(eq_div_iff hQ).mp h]
  have h := labelSwitch_comparison (fun H => x H)
  simp_rw [hp] at h
  rw [InvolutionGap.norm_sq_as_sum, PairResampling.state_inner]
  apply h.trans_eq
  change _ = 2*Q*_
  simp_rw [show ∀ a b : ℝ, a*(Q*(a-b)) = Q*(a^2-a*b) by intro a b;ring]
  rw [← Finset.mul_sum, Finset.sum_sub_distrib]
  ring

#print axioms graphP_psd
#print axioms unigraph_tv_trace
#print axioms graphP_energy
end OAI.Problem315.UnigraphUpper
