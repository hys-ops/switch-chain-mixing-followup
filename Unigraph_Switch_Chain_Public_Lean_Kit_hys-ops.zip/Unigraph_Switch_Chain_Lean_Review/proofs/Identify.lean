import Family
namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k : ℕ}

lemma bool_alt (p : Bool → Prop) (hp : ∃! b,p b) : p false ↔ ¬p true := by
  obtain ⟨b,hb,hu⟩ := hp
  cases b
  · have hn : ¬p true := by intro h; simpa using hu true h
    simp [hb,hn]
  · have hn : ¬p false := by intro h; simpa using hu false h
    simp [hb,hn]

lemma two_permutation (R : Bool → Bool → Prop)
    (hr : ∀ b,∃! c,R b c) (hc : ∀ c,∃! b,R b c) (b c : Bool) :
    R b c ↔ c = (b ^^ (if R false false then false else true)) := by
  have r0 := bool_alt _ (hr false); have r1 := bool_alt _ (hr true)
  have c0 := bool_alt _ (hc false); have c1 := bool_alt _ (hc true)
  cases b <;> cases c <;> by_cases h : R false false <;> simp [h] <;> tauto

def decode (G : GraphState (4*k) (deg k)) : Bits k := fun i =>
  if G.val.Adj (pt i true false) (pt i false false) then false else true

lemma paired (G : GraphState (4*k) (deg k)) (i : Fin k) (s b c : Bool) :
   G.val.Adj (pt i s b) (pt i (!s) c) ↔ c=(b ^^ decode G i) := by
  let R := fun b c => G.val.Adj (pt i true b) (pt i false c)
  have hr (b : Bool) : ∃! c,R b c := row_choice G i true b
  have hc (c : Bool) : ∃! b,R b c := by
    simpa only [R,G.val.adj_comm,Bool.not_false] using row_choice G i false c
  have h (b c : Bool) : R b c ↔ c=(b ^^ decode G i) := two_permutation R hr hc b c
  cases s
  · rw [G.val.adj_comm]; change R c b ↔ _
    rw [h]; cases b <;> cases c <;> cases decode G i <;> decide
  · exact h b c

lemma state_decode (G : GraphState (4*k) (deg k)) : state (decode G) = G := by
  apply Subtype.ext; ext u v
  change (graph (decode G)).Adj u v ↔ G.val.Adj u v
  by_cases hw : weight u+weight v=0
  · obtain ⟨i,s,b,rfl⟩ := vertex_cases u; obtain ⟨j,t,c,rfl⟩ := vertex_cases v
    obtain ⟨rfl,rfl⟩ := (zero_iff _ _ _ _ _ _).mp hw
    have hn : ¬Back _ _ := fun h => (ne_of_gt h.2) hw
    rw [paired,graph_adj,or_iff_right hn,mate_pt,pt_eq]; simp
  · rw [fixed G hw,graph_adj]
    constructor
    · rintro (h|rfl); exact h; exact (hw (mate_weights _ _)).elim
    · exact Or.inl

lemma decode_state (x : Bits k) : decode (state x) = x := by
  funext i
  have hz : weight (pt i true false)+weight (pt i false false)=0 := by simp
  change (if (graph x).Adj (pt i true false) (pt i false false) then false else true) = x i
  cases h : x i <;> simp [Back,h]

/-- The actual upstream graph state space for this degree family is a k-dimensional cube. -/
def stateEquiv (k : ℕ) : Bits k ≃ GraphState (4*k) (deg k) :=
  ⟨state,decode,decode_state,state_decode⟩

theorem cardinal_states (k : ℕ) : stateCount (4*k) (deg k) = 2^k := by
  classical
  simpa [stateCount,allGraphStates] using (Fintype.card_congr (stateEquiv k)).symm

#print axioms stateEquiv
#print axioms cardinal_states
end
end LayeredLower
