import VerifiedSwitch

noncomputable section
open scoped BigOperators RealInnerProductSpace

namespace OAI.Problem315.UnigraphUpper
open PairResampling
attribute [local instance] Classical.propDecidable

variable {n : ℕ} {d : Fin n → ℕ}

/-- Degrees of a pullback graph are the degrees at its relabeled vertices. -/
theorem degree_comap (G : SimpleGraph (Fin n)) (σ : Equiv.Perm (Fin n)) (v : Fin n) :
    graphDegree (G.comap σ) v = graphDegree G (σ v) := by
  classical
  unfold graphDegree
  apply Finset.card_bijective σ σ.bijective
  intro i
  simp only [Finset.mem_filter, Finset.mem_univ, true_and, SimpleGraph.comap_adj]

/-- Relabel labeled realizations using an actual degree-preserving permutation. -/
def labelEquiv (σ : Equiv.Perm (Fin n)) (hσ : ∀ v, d (σ v) = d v) :
    Equiv.Perm (GraphState n d) where
  toFun G := ⟨G.1.comap σ, fun v => (degree_comap G.1 σ v).trans ((G.2 (σ v)).trans (hσ v))⟩
  invFun G := ⟨G.1.comap σ.symm, fun v => (degree_comap G.1 σ.symm v).trans <| by
    rw [G.2 (σ.symm v), ← hσ (σ.symm v), σ.apply_symm_apply]⟩
  left_inv G := by apply Subtype.ext; ext u v; simp
  right_inv G := by apply Subtype.ext; ext u v; simp

theorem swap_preserves_degree (i j : Fin n) (hd : d i = d j) :
    ∀ v, d (Equiv.swap i j v) = d v := by
  intro v
  by_cases hi : v = i
  · subst v; simp [hd]
  by_cases hj : v = j
  · subst v; simp [hd]
  rw [Equiv.swap_apply_of_ne_of_ne hi hj]

def swapLabels (i j : Fin n) (hd : d i = d j) : Equiv.Perm (GraphState n d) :=
  labelEquiv (Equiv.swap i j) (swap_preserves_degree i j hd)

theorem sameFiber_swap (i j : Fin n) (hd : d i = d j) (G : GraphState n d) :
    SameFiber {i,j} G.1 ((swapLabels i j hd) G).1 := by
  classical
  apply (sameFiber_state_iff {i,j} _ _).2
  constructor
  · intro u hu v hv
    change G.1.Adj u v ↔ G.1.Adj (Equiv.swap i j u) (Equiv.swap i j v)
    simp only [Finset.mem_insert, Finset.mem_singleton] at hu hv
    rw [Equiv.swap_apply_of_ne_of_ne (fun h => hu (Or.inl h)) (fun h => hu (Or.inr h)),
      Equiv.swap_apply_of_ne_of_ne (fun h => hv (Or.inl h)) (fun h => hv (Or.inr h))]
  · intro u hu v hv
    change G.1.Adj u v ↔ G.1.Adj (Equiv.swap i j u) (Equiv.swap i j v)
    simp only [Finset.mem_insert, Finset.mem_singleton] at hu hv
    rcases hu with rfl | rfl <;> rcases hv with rfl | rfl <;> simp [SimpleGraph.adj_comm]

/-- Any fiber-preserving permutation has its squared differences controlled by
four times the original fiber projection energy in counting measure. -/
theorem fiber_perm_energy (a : Finset (Fin n)) (e : Equiv.Perm (GraphState n d))
    (he : ∀ G, SameFiber a G.1 (e G).1) (f : StateSpace n d) :
    (∑ G, (f G - f (e G))^2) ≤ 4 * ⟪f,fluctuation n d a f⟫ := by
  classical
  let g := fluctuation n d a f
  have hdif (x : GraphState n d) : f x - f (e x) = g x - g (e x) := by
    have hm : expectation n d a f x = expectation n d a f (e x) :=
      (expectation_mem a f) x (e x) (he x)
    change _ = fluctuation n d a f x - fluctuation n d a f (e x)
    rw [fluctuation_eq_sub]
    change _ = (f x - expectation n d a f x) - (f (e x) - expectation n d a f (e x))
    linarith
  have hsq (x : GraphState n d) : (g x - g (e x))^2 ≤ 2*((g x)^2+(g (e x))^2) := by
    nlinarith [sq_nonneg (g x + g (e x))]
  have heq := Equiv.sum_comp e (fun x => (g x)^2)
  have hnorm : (∑ x, (g x)^2) = ⟪f,fluctuation n d a f⟫ := by
    rw [inner_fluctuation, InvolutionGap.norm_sq_as_sum]
  simp_rw [hdif]
  calc
    _ ≤ ∑ x, 2*((g x)^2+(g (e x))^2) := Finset.sum_le_sum fun x _ => hsq x
    _ = _ := by rw [← Finset.mul_sum, Finset.sum_add_distrib, heq, hnorm]; ring

def Eligible (a : Finset (Fin n)) (p : Fin n × Fin n) : Prop :=
  p.1 ≠ p.2 ∧ a = {p.1,p.2} ∧ d p.1 = d p.2

/-- Equal-degree unordered anchors swap their labels. All others act trivially. -/
def anchorSwap (a : Finset (Fin n)) : Equiv.Perm (GraphState n d) :=
  if h : ∃ p, Eligible (d := d) a p then
    swapLabels h.choose.1 h.choose.2 h.choose_spec.2.2
  else 1

theorem sameFiber_anchor (a : Finset (Fin n)) (G : GraphState n d) :
    SameFiber a G.1 ((anchorSwap a) G).1 := by
  unfold anchorSwap
  split_ifs with h
  · have hx := h.choose_spec
    exact Eq.mp (congrArg (fun z => SameFiber z G.1 ((swapLabels _ _ hx.2.2) G).1)
      hx.2.1.symm) (sameFiber_swap _ _ hx.2.2 G)
  · exact SameFiber.refl a G.1

theorem anchorSwap_apply (i j : Fin n) (hij : i ≠ j) (hd : d i = d j)
    (G : GraphState n d) : anchorSwap {i,j} G = swapLabels i j hd G := by
  classical
  let a : Finset (Fin n) := {i,j}
  have h : ∃ p, Eligible (d := d) a p := ⟨(i,j),hij,rfl,hd⟩
  change (anchorSwap a) G = _
  rw [anchorSwap, dite_eq_left h]
  have hx := h.choose_spec
  have hp : ({i,j} : Set (Fin n)) = {h.choose.1,h.choose.2} := by
    simpa [a] using congrArg (fun (s : Finset (Fin n)) => (s : Set (Fin n))) hx.2.1
  have hs : Equiv.swap h.choose.1 h.choose.2 = Equiv.swap i j := by
    rcases Set.pair_eq_pair_iff.mp hp with h | h
    · rw [← h.1, ← h.2]
    · rw [← h.1, ← h.2, Equiv.swap_comm]
  apply Subtype.ext
  change G.1.comap _ = G.1.comap _
  rw [hs]

def labelLaplacian (f : GraphState n d → ℝ) (G : GraphState n d) : ℝ :=
  ∑ a ∈ pairs n, (f G - f (anchorSwap a G))

/-- Dirichlet form of a single unweighted label move, in counting measure. -/
theorem energy_perm {X : Type*} [Fintype X] (f : X → ℝ) (e : Equiv.Perm X) :
    2*(∑ x, f x * (f x - f (e x))) = ∑ x, (f x - f (e x))^2 := by
  classical
  have he := Equiv.sum_comp e (fun x => (f x)^2)
  have hcalc : (∑ x, (f x - f (e x))^2) =
      2*(∑ x, f x * (f x - f (e x))) + (∑ x, f (e x)^2) - ∑ x, f x^2 := by
    rw [Finset.mul_sum, ← Finset.sum_add_distrib, ← Finset.sum_sub_distrib]
    apply Finset.sum_congr rfl
    intro x _
    ring
  linarith

theorem labelLaplacian_energy (f : GraphState n d → ℝ) :
    2*(∑ G, f G * labelLaplacian f G) = ∑ a ∈ pairs n, ∑ G, (f G - f (anchorSwap a G))^2 := by
  calc
    _ = 2*(∑ a ∈ pairs n, ∑ G, f G * (f G - f (anchorSwap a G))) := by
      congr 1
      unfold labelLaplacian
      simp_rw [Finset.mul_sum]
      rw [Finset.sum_comm]
    _ = _ := by
      rw [Finset.mul_sum]
      exact Finset.sum_congr rfl (fun a _ => energy_perm f (anchorSwap a))

/-- The exact graph label-transposition generator is controlled by twice the
source's actual switch proposal Laplacian. -/
theorem labelSwitch_comparison (f : GraphState n d → ℝ) :
    (∑ G, f G * labelLaplacian f G) ≤ 2*(∑ G, f G * switchLaplacian n d f G) := by
  let F : StateSpace n d := WithLp.toLp 2 f
  have hs : SharpSwitch.SliceVariance := by
    intro α _ _ q _ g
    exact SliceGap.variance_le_quarter_swap_squared_differences g
  have h1 : (∑ a ∈ pairs n, ∑ G, (f G - f (anchorSwap a G))^2) ≤
      4 * ⟪F,generator n d F⟫ := by
    rw [generator_apply, inner_sum,Finset.mul_sum]
    exact Finset.sum_le_sum fun a _ => fiber_perm_energy a (anchorSwap a) (sameFiber_anchor a) F
  have h2 := SharpSwitch.generator_comparison hs F
  change ⟪F,generator n d F⟫ ≤ ∑ G, f G * switchLaplacian n d f G at h2
  rw [← labelLaplacian_energy] at h1
  linarith

#print axioms sameFiber_swap
#print axioms fiber_perm_energy
#print axioms anchorSwap_apply
#print axioms labelSwitch_comparison
end OAI.Problem315.UnigraphUpper
