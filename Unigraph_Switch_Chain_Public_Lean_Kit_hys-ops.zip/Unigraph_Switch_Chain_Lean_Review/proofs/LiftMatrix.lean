import SpectralTrace
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphTrace
variable {X A F : Type*} [Fintype X] [DecidableEq X] [Fintype A]
variable [NormedAddCommGroup F] [InnerProductSpace ℝ F]

theorem trace_pow_spectrum {P : Matrix X X ℝ} (hP : P.IsHermitian) (k : ℕ) :
    (P^k).trace=∑ i,(hP.eigenvalues i)^k := by
  have h := congrArg (fun M : Matrix X X ℝ => (M^k).trace) hP.spectral_theorem
  rw [← map_pow, Unitary.conjStarAlgAut_apply, Matrix.trace_mul_cycle,
    Unitary.coe_star_mul_self,one_mul,Matrix.diagonal_pow,Matrix.trace_diagonal] at h
  simpa using h

theorem matrix_lifted_trace {P : Matrix X X ℝ} (hP : P.PosSemidef)
    (T : EuclideanSpace ℝ X →ₗᵢ[ℝ] F) (J : F →ₗ[ℝ] F) (b : OrthonormalBasis A ℝ F)
    (ξ : A → ℝ) (hb : ∀ a,J (b a)=ξ a • b a) {Q : ℝ} (hQ : 0<Q)
    (hform : ∀ x,⟪T x,J (T x)⟫ ≤ 2*Q*(‖x‖^2 - ⟪x,P.toEuclideanLin x⟫)) (t : ℕ) :
    (P^(2*t)).trace ≤ ∑ a, Real.exp (-(t:ℝ)/Q*ξ a) := by
  rw [trace_pow_spectrum hP.1]
  let e := hP.1.eigenvectorBasis
  apply lifted_trace (fun i => T (e i)) (e.orthonormal.comp_linearIsometry T) b J ξ hb _
    hP.eigenvalues_nonneg hQ _ t
  intro i
  have he : P.toEuclideanLin (e i) = (hP.1.eigenvalues i) • e i := by
    apply PiLp.ext; intro j
    exact congrFun (hP.1.mulVec_eigenvectorBasis i) j
  simpa [he,real_inner_smul_right,real_inner_self_eq_norm_sq,e.orthonormal.1 i] using hform (e i)

/-- Count the group-coordinate spectral factor bounds rather than the total number of graph states. -/
theorem product_row_bound {P : Matrix X X ℝ} (hP : P.PosSemidef) (hr : ∀ x,∑ y,P x y=1)
    (transitive : ∀ x y,∃ e : Equiv.Perm X,e x=y ∧ ∀ a b,P (e a) (e b)=P a b)
    {C : Type*} [Fintype C] [DecidableEq C] {B : C → Type*} [∀ c,Fintype (B c)]
    (T : EuclideanSpace ℝ X →ₗᵢ[ℝ] F) (J : F →ₗ[ℝ] F)
    (b : OrthonormalBasis (∀ c,B c) ℝ F) (ξ : ∀ c,B c→ℝ)
    (hb : ∀ a,J (b a)=(∑ c,ξ c (a c)) • b a) {Q : ℝ} (hQ : 0<Q)
    (hform : ∀ x, ⟪T x,J (T x)⟫ ≤ 2*Q*(‖x‖^2-⟪x,P.toEuclideanLin x⟫))
    (a₀ : ∀ c,B c) (m : C → ℝ) (hz : ∀ c, ξ c (a₀ c)=0)
    (hg : ∀ c a,a ≠ a₀ c → m c≤ξ c a) (t : ℕ) (x : X) :
    4*(rowTV P t x)^2 ≤
      (∏ c,(1+((Fintype.card (B c):ℝ)-1)*Real.exp (-(t:ℝ)/Q*m c)))-1 := by
  apply (rowTV_trace P (Matrix.isHermitian_iff_isSymm.mp hP.1) hr transitive t x).trans
  apply sub_le_sub_right
  have h := matrix_lifted_trace hP T J b _ hb hQ hform t
  have hneg : (-(t:ℝ))/Q = -((t:ℝ)/Q) := by ring
  simp only [hneg] at h ⊢
  rw [product_heat ξ ((t:ℝ)/Q)] at h
  apply h.trans
  exact Finset.prod_le_prod₀ (fun i _ => Finset.sum_nonneg fun j _ => Real.exp_nonneg _)
    (fun i _ => one_factor (ξ i) (a₀ i) (m i) ((t:ℝ)/Q) (by positivity) (hz i) (hg i))

#print axioms matrix_lifted_trace
#print axioms product_row_bound
end UnigraphTrace
