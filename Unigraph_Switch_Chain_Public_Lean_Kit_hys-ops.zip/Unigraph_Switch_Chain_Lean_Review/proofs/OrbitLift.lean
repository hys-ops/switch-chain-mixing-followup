import DegreeAction
import GraphTrace

open scoped BigOperators RealInnerProductSpace Matrix
noncomputable section
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
open PairResampling
variable {n : ℕ} {d : Fin n → ℕ}

def scale (base : GraphState n d) : ℝ := (Real.sqrt (fiberSize base base : ℝ))⁻¹

theorem scale_normalized (base : GraphState n d) :
    (scale base)^2 * (fiberSize base base : ℝ) = 1 := by
  have hp : 0 < (fiberSize base base : ℝ) := by exact_mod_cast fiberSize_pos base
  rw [scale,inv_pow,Real.sq_sqrt hp.le,inv_mul_cancel₀ hp.ne']

/-- Isometric lifting from one graph orbit to its whole finite relabeling group. -/
def orbitLift (hu : IsUnigraphic d) (base : GraphState n d) :
    StateSpace n d →ₗᵢ[ℝ] InvolutionGap.E (Γ d) where
  toFun x := WithLp.toLp 2 (fun g => scale base * x (orbit base g))
  map_add' x y := by
    ext g
    change scale base*(x (orbit base g)+y (orbit base g)) =
      scale base*x (orbit base g)+scale base*y (orbit base g)
    ring
  map_smul' a x := by
    ext g
    change scale base*(a*x (orbit base g)) = a*(scale base*x (orbit base g))
    ring
  norm_map' x := by
    apply sq_eq_sq₀ (norm_nonneg _) (norm_nonneg _) |>.mp
    rw [InvolutionGap.norm_sq_as_sum,InvolutionGap.norm_sq_as_sum]
    change (∑ g, (scale base * x (orbit base g))^2) = _
    simp_rw [mul_pow]
    rw [← Finset.mul_sum,sum_orbit hu base (fun H => (x H)^2),← mul_assoc,scale_normalized,one_mul]

theorem regLap_lift (hu : IsUnigraphic d) (base : GraphState n d) (x : StateSpace n d)
    (g : Γ d) :
    InvolutionGap.lap regMove (orbitLift hu base x) g =
      scale base * labelLaplacian (fun H => x H) (orbit base g) := by
  rw [InvolutionGap.lap_apply,labelLaplacian,Finset.mul_sum]
  change (∑ a : ↥(pairs n), (scale base*x (orbit base g) -
      scale base*x (orbit base (g*groupAnchor d a.1)))) = _
  rw [← Finset.sum_coe_sort (pairs n) (fun a => scale base *
    (x (orbit base g) - x (anchorSwap a (orbit base g))))]
  apply Finset.sum_congr rfl
  intro a _
  change _-scale base*x (action (groupAnchor d a.1) (orbit base g)) = _
  rw [action_anchor]
  ring

theorem lift_energy (hu : IsUnigraphic d) (base : GraphState n d) (x : StateSpace n d) :
    ⟪orbitLift hu base x, InvolutionGap.lap regMove (orbitLift hu base x)⟫ =
      ∑ G, x G * labelLaplacian (fun H => x H) G := by
  rw [InvolutionGap.inner_as_sum]
  simp_rw [regLap_lift]
  change (∑ g, (scale base*x (orbit base g))*(scale base*labelLaplacian _ (orbit base g))) = _
  simp_rw [show ∀ a b : ℝ,(scale base*a)*(scale base*b)=(scale base)^2*(a*b) by intro a b;ring]
  rw [← Finset.mul_sum,sum_orbit hu base (fun H => x H * labelLaplacian _ H),← mul_assoc,
    scale_normalized,one_mul]

theorem lifted_graphP_energy (hn : 4 ≤ n) (hu : IsUnigraphic d) (base : GraphState n d)
    (x : StateSpace n d) :
    ⟪orbitLift hu base x,InvolutionGap.lap regMove (orbitLift hu base x)⟫ ≤
      2*(12*(n.choose 4 : ℝ))*(‖x‖^2 - ⟪x,(graphP d).toEuclideanLin x⟫) := by
  rw [lift_energy]
  exact graphP_energy hn x

#print axioms orbitLift
#print axioms lift_energy
#print axioms lifted_graphP_energy
end OAI.Problem315.UnigraphUpper
