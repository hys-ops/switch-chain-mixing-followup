import Mathlib.Analysis.Matrix.PosDef
import Mathlib.Analysis.Convex.SpecificFunctions.Basic
import Mathlib.Algebra.Order.Chebyshev
import Mathlib.Tactic
open scoped BigOperators Matrix
noncomputable section

namespace UnigraphTrace
variable {X : Type*} [Fintype X] [DecidableEq X]
/-- Single-start total variation at step t, relative to uniform measure. -/
def rowTV (P : Matrix X X ℝ) (t : ℕ) (x : X) : ℝ :=
  (∑ y, |(P ^ t) x y - 1/(Fintype.card X : ℝ)|)/2

theorem pow_rows (P : Matrix X X ℝ) (hr : ∀ x, ∑ y, P x y = 1) (t : ℕ) :
    ∀ x, ∑ y, (P^t) x y = 1 := by
  induction t with
  | zero => simp [Matrix.one_apply]
  | succ t ih =>
    intro x
    simp only [pow_succ, Matrix.mul_apply]
    rw [Finset.sum_comm]
    simp_rw [← Finset.mul_sum,hr,mul_one]
    exact ih x

theorem pow_relabel (P : Matrix X X ℝ) (e : Equiv.Perm X)
    (he : ∀ x y, P (e x) (e y)=P x y) (t : ℕ) :
    ∀ x y, (P^t) (e x) (e y)=(P^t) x y := by
  induction t with
  | zero => simp [Matrix.one_apply]
  | succ t ih =>
    intro x y
    simp only [pow_succ, Matrix.mul_apply]
    calc
      _ = ∑ z, (P^t) (e x) (e z) * P (e z) (e y) :=
          (Equiv.sum_comp e (fun z => (P^t) (e x) z * P z (e y))).symm
      _ = _ := by simp_rw [ih,he]

theorem rowTV_trace (P : Matrix X X ℝ) (hs : P.IsSymm)
    (hr : ∀ x, ∑ y, P x y=1)
    (htrans : ∀ x y, ∃ e : Equiv.Perm X, e x=y ∧ ∀ a b, P (e a) (e b)=P a b)
    (t : ℕ) (x : X) : 4*(rowTV P t x)^2 ≤ (P^(2*t)).trace-1 := by
  classical
  let N : ℝ := Fintype.card X
  have : Nonempty X := ⟨x⟩
  have hn : N ≠ 0 := by dsimp [N]; exact_mod_cast (Fintype.card_ne_zero (α := X))
  have hdiag (y : X) : (P^(2*t)) y y = (P^(2*t)) x x := by
    obtain ⟨e, ex, he⟩ := htrans x y
    simpa [ex] using pow_relabel P e he (2*t) x x
  have htrace : (P^(2*t)).trace = N * (P^(2*t)) x x := by
    simp only [Matrix.trace, Matrix.diag_apply,hdiag,Finset.sum_const,Finset.card_univ,
      nsmul_eq_mul,N]
  have hdiag_sq : (P^(2*t)) x x = ∑ y, ((P^t) x y)^2 := by
    rw [two_mul,pow_add,Matrix.mul_apply]
    exact Finset.sum_congr rfl (fun y _ => by rw [(hs.pow t).apply y x]; ring)
  have hsums : (∑ y, ((P^t) x y - 1/N)^2) =
        (∑ y, ((P^t) x y)^2) - 1/N := by
    simp only [sub_sq,Finset.sum_add_distrib,Finset.sum_sub_distrib,← Finset.sum_mul,
      ← Finset.mul_sum,pow_rows P hr,Finset.sum_const,Finset.card_univ,nsmul_eq_mul]
    change _ - 2*1*(1/N)+N*(1/N)^2 = _
    field_simp
    ring
  have hb := sq_sum_le_card_mul_sum_sq (s:=Finset.univ)
    (f:=fun y => |(P^t) x y-1/N|)
  simp only [sq_abs,Finset.card_univ] at hb
  change _ ≤ N * _ at hb
  rw [hsums] at hb
  rw [htrace,hdiag_sq]
  change 4 * ((∑ y, |(P^t) x y-1/N|)/2)^2 ≤ _
  have hinv : N*(1/N)=1 := by field_simp
  nlinarith

/-- Project a factored symmetric heat matrix along any quotient. Equal diagonal
and the positive-semidefinite factorization imply domination by the regular trace. -/
theorem quotient_heat_trace {G : Type*} [Fintype G] [DecidableEq G]
    (π : G → X) (hπ : Function.Surjective π) (B C : Matrix G G ℝ) (H : Matrix X X ℝ)
    (hfac : B=C*C.transpose) (hd : ∀ g h, B g g=B h h)
    (hpush : ∀ g y, H (π g) y = ∑ h, if π h=y then B g h else 0) :
    H.trace ≤ B.trace := by
  classical
  have hmax (g h : G) : B g h ≤ B h h := by
    have hn : 0 ≤ ∑ k, (C g k - C h k)^2 := Finset.sum_nonneg fun k _ => sq_nonneg _
    have ident : (∑ k, (C g k-C h k)^2) = B g g+B h h-2*B g h := by
      rw [hfac]; simp only [Matrix.mul_apply,Matrix.transpose_apply]
      rw [← Finset.sum_add_distrib,Finset.mul_sum,← Finset.sum_sub_distrib]
      exact Finset.sum_congr rfl fun k _ => by ring
    rw [ident, hd g h] at hn
    linarith
  calc
    H.trace = ∑ y, H y y := rfl
    _ ≤ ∑ y, ∑ h, if π h=y then B h h else 0 := by
      apply Finset.sum_le_sum
      intro y _
      obtain ⟨g,hg⟩ := hπ y
      rw [←hg,hpush]
      apply Finset.sum_le_sum
      intro h _
      split_ifs
      · exact hmax g h
      · exact le_rfl
    _ = B.trace := by rw [Finset.sum_comm]; simp [Matrix.trace]

#print axioms rowTV_trace
#print axioms quotient_heat_trace
end UnigraphTrace
