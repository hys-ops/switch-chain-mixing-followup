import PaddedLower
import UnigraphUpper

namespace LayeredLower.Padding
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable

/-- All labeled realizations on n vertices with floor(n/4) complete blocks. -/
abbrev familyState (n : ℕ) : Bits (n/4) ≃ GraphState n (family n) :=
  cube (show 4*(n/4)≤n by omega)

/-- The exact diagonal in the original discrete graph kernel. -/
theorem family_hold {n : ℕ} (hn : 4≤n) (x : Bits (n/4)) :
    switchKernel n (family n) (familyState n x) (familyState n x)
      = 1-((n/4 : ℕ):ℝ)/(12*(n.choose 4 : ℝ)) := by
  let e := familyState n
  have hf (i : Fin (n/4)) : e (CubeLower.flip i x) ≠ e x :=
    e.injective.ne (flip_ne x i)
  have hop := operator_equiv (show 4*(n/4)≤n by omega) hn
    (fun G => if G=e x then (1:ℝ) else 0) x
  change (∑ H, switchKernel n (family n) (e x) H * (if H=e x then (1:ℝ) else 0))
    = (1-((n/4 : ℕ):ℝ)/clock n)*(if e x=e x then 1 else 0)
      + (∑ i, if e (CubeLower.flip i x)=e x then 1 else 0) / clock n at hop
  change switchKernel n (family n) (e x) (e x) = 1-((n/4 : ℕ):ℝ)/clock n
  simp [mul_ite,hf] at hop
  exact hop

/-- The exact off-diagonal kernel: a particular coordinate flip has probability
1/Q(n); every other distinct realization has probability zero. -/
theorem family_off_diagonal {n : ℕ} (x y : Bits (n/4)) (hxy : x ≠ y) :
    switchKernel n (family n) (familyState n x) (familyState n y)
      = if ∃ i, y=CubeLower.flip i x then 1/(12*(n.choose 4 : ℝ)) else 0 := by
  rw [switchKernel_of_ne ((familyState n).injective.ne hxy),step_iff_flip]
  by_cases hh : ∃ i, y=CubeLower.flip i x <;> simp [hh]

theorem family_flip {n : ℕ} (x : Bits (n/4)) (i : Fin (n/4)) :
    switchKernel n (family n) (familyState n x) (familyState n (CubeLower.flip i x))
      = 1/(12*(n.choose 4 : ℝ)) := by
  rw [family_off_diagonal x _ (flip_ne x i).symm]
  exact ite_eq_left ⟨i,rfl⟩

/-- The finite-n lower signal in original quarter-TV mixing time for every
n≥4. It is nonpositive when floor(n/4)≤16. -/
theorem finite_mixingTime_lower {n : ℕ} (hn : 4≤n) (h : ∃ t, MixedAt n (family n) t) :
    (12*(n.choose 4 : ℝ))/8 * Real.log (((n/4:ℕ):ℝ)/16) <
      (mixingTime n (family n) h : ℝ) := by
  have hd : 4*(n/4)≤n := by omega
  have hb := clock_bounds hn hd
  have hs := CubeLower.Upstream.mixingTime_bound (familyState n)
    (operator_equiv hd hn) (show 0 < n/4 by omega) hb.1 hb.2 h
  change clock n / 8 * _ < _
  linarith

/-- The same finite-n lower bound has an actual finite mixing time, obtained
here using the unigraph clock proved independently of the cube lower bound. -/
theorem finite_mixingTime_bounds {n : ℕ} (hn : 4≤n) :
    ∃ h : ∃ t, MixedAt n (family n) t,
      (12*(n.choose 4 : ℝ))/8 * Real.log (((n/4:ℕ):ℝ)/16) <
        (mixingTime n (family n) h : ℝ) ∧
      mixingTime n (family n) h ≤ ⌈(12*(n.choose 4 : ℝ))*Real.log (3*(n:ℝ))⌉₊ := by
  obtain ⟨h,hu⟩ := UnigraphUpper.unigraph_mixing_upper hn (family_unigraphic n)
  exact ⟨h,finite_mixingTime_lower hn h,hu⟩

#print axioms family_hold
#print axioms family_off_diagonal
#print axioms family_flip
#print axioms finite_mixingTime_lower
#print axioms finite_mixingTime_bounds
end
end LayeredLower.Padding
