import PaddedMove
import AllClock
import CubeUnigraphPadding
import CubeUpstream
import OAI.Probability.SwitchChain.SwitchLaplacian

namespace LayeredLower.Padding
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k n : ℕ}

abbrev clock (n : ℕ) : ℝ := 12*(n.choose 4 : ℝ)

theorem operator_equiv (h : 4*k ≤ n) (hn : 4 ≤ n)
    (f : GraphState n (extendDegrees (deg k)) → ℝ) (x : Bits k) :
    (∑ H, switchKernel n (extendDegrees (deg k)) (cube h x) H * f H)
      = CubeLower.step (clock n) (fun z => f (cube h z)) x := by
  let e := cube h
  have lap : switchLaplacian n (extendDegrees (deg k)) f (e x)
      = ∑ i, (f (e x) - f (e (CubeLower.flip i x))) := by
    change (∑ H, if SwitchStep n _ (e x) H then f (e x) - f H else 0) = _
    rw [←e.sum_comp (fun H => if SwitchStep n _ (e x) H then f (e x) - f H else 0)]
    change (∑ y, if SwitchStep n _ (cube h x) (cube h y) then f (e x) - f (e y) else 0) = _
    simp_rw [step_iff_flip]
    rw [←Finset.sum_filter]
    have hs : univ.filter (fun y : Bits k => ∃ i, y=CubeLower.flip i x) = univ.image (fun i=> CubeLower.flip i x) := by
      ext y
      simp [eq_comm]
    rw [hs, Finset.sum_image (fun i _ j _ hh => flip_inj x hh)]
  have hop := sub_markovApply_eq_switchLaplacian (switchKernel_row_sum hn) f (e x)
  rw [lap,Finset.sum_sub_distrib] at hop
  simp only [Finset.sum_const,Finset.card_univ,Fintype.card_fin,nsmul_eq_mul] at hop
  calc
    _ = markovApply n (extendDegrees (deg k)) f (e x) := rfl
    _ = f (e x) - ((k:ℝ)*f (e x)-(∑ i, f (e (CubeLower.flip i x)))) / clock n := by
      change f (e x) - _ = _ / clock n at hop
      linarith
    _ = _ := by unfold CubeLower.step; change _ = (1-(k:ℝ)/clock n)*f (e x) + _; ring

theorem clock_bounds (hn : 4 ≤ n) (hk : 4*k ≤ n) :
    4 ≤ clock n ∧ (k:ℝ) ≤ clock n := by
  have hh := choose_four (n-4)
  rw [show n-4+4=n by omega] at hh
  have h1 : (1:ℝ) ≤ (n.choose 4 : ℝ) := by exact_mod_cast (show 1 ≤ n.choose 4 by omega)
  have h2 : (k : ℝ) ≤ (n.choose 4 : ℝ) := by exact_mod_cast (show k ≤ n.choose 4 by omega)
  unfold clock; constructor <;> linarith

abbrev family (n : ℕ) : Fin n → ℕ := extendDegrees (deg (n/4))

theorem family_graphical (n : ℕ) : Graphical n (family n) :=
  ⟨cube (show 4*(n/4) ≤ n by omega) (CubeLower.origin _)⟩

theorem family_unigraphic (n : ℕ) : UnigraphUpper.IsUnigraphic (family n) :=
  isUnigraphic_layered_extend (show 4*(n/4) ≤ n by omega)

/-- No mixed time at TV 1/4 can precede this all-n clock for the stated
actual graphical, unigraphic sequence. -/
theorem all_n_mixed_requires {n t : ℕ} (hn : 65536 ≤ n) (ht : MixedAt n (family n) t) :
    (n:ℝ)^4 * Real.log n / 512 < t := by
  have h : 4*(n/4) ≤ n := by omega
  have bn := clock_bounds (by omega : 4 ≤ n) h
  have hmix := CubeLower.Upstream.mixedAt_bound (cube h) (operator_equiv h (by omega))
    (show 0 < n/4 by omega) bn.1 bn.2 t ht
  exact (AllClock.lower_clock hn).trans_lt hmix

theorem all_n_mixingTime {n : ℕ} (hn : 65536 ≤ n) (hex : ∃ t, MixedAt n (family n) t) :
    (n:ℝ)^4 * Real.log n / 512 < (mixingTime n (family n) hex : ℝ) :=
  all_n_mixed_requires hn (Nat.find_spec hex)

#print axioms operator_equiv
#print axioms family_unigraphic
#print axioms all_n_mixingTime
end
end LayeredLower.Padding
