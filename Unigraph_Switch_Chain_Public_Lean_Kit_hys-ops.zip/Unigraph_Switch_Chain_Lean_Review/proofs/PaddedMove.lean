import Padding

namespace LayeredLower.Padding
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k n : ℕ}

abbrev cube (h : 4*k ≤ n) := (LayeredLower.stateEquiv k).trans (stateEquiv h (deg k))
abbrev gr (h : 4*k ≤ n) (x : Bits k) := (graph x).map (emb h)

lemma support_block (h : 4*k ≤ n) {x y : Bits k} {p : SwitchProposal n}
    (hv : validSwitch (gr h x) p) (hr : proposalResult (gr h x) p = gr h y)
    (i : Fin k) (hi : x i ≠ y i) : p.1.val=(block i).map (emb h) := by
  apply Eq.symm; apply eq_of_subset_of_card_le _ (by rw [p.1.property,card_map,block_card])
  intro w hw
  obtain ⟨u,hu,rfl⟩ := mem_map.mp hw
  obtain ⟨j,s,b,rfl⟩ := vertex_cases u
  have hji := (mem_block i j s b).mp hu; subst j
  apply ((p.2.val.1.property).mem_iff_exists_adj _).mpr
  refine ⟨emb h (mate x (pt i s b)),(removedMatching_adj_iff hv _ _).mpr ⟨SimpleGraph.map_adj_apply.mpr (Or.inr rfl),?_⟩⟩
  rw [hr,SimpleGraph.map_adj_apply]; exact old_edge_changes x y _ hi s b

lemma only_flip (h : 4*k ≤ n) {x y : Bits k} {p : SwitchProposal n}
    (hv : validSwitch (gr h x) p) (hr : proposalResult (gr h x) p = gr h y)
    (i : Fin k) (hi : x i ≠ y i) : y=CubeLower.flip i x := by
  have hs := support_block h hv hr i hi
  funext j
  by_cases he : j=i
  · subst j; simp only [CubeLower.flip]; cases h : x i <;> cases h' : y i <;> simp_all
  · simp only [CubeLower.flip,ite_eq_right he]; by_contra hne
    have hs' := support_block h hv hr j (Ne.symm hne)
    have hm : emb h (pt j false false) ∈ (block i).map (emb h) := by
      rw [←hs,hs']; simp [mem_block]
    exact he ((mem_block i j false false).mp (by simpa only [Finset.mem_map'] using hm))

theorem flip_step (h : 4*k ≤ n) (x : Bits k) (i : Fin k) :
    SwitchStep n (extendDegrees (deg k)) (cube h x) (cube h (CubeLower.flip i x)) := by
  let a := emb h (pt i true false)
  let b := emb h (pt i false (x i))
  let c := emb h (pt i false (!(x i)))
  let d := emb h (pt i true true)
  have distinct : FourDistinct a b c d := by
    simpa only [FourDistinct,a,b,c,d,(emb h).injective.ne_iff] using four_in_block x i
  let p := fourVertexProposal a b c d distinct
  have hab : (gr h x).Adj a b := SimpleGraph.map_adj_apply.mpr ((cross_adj _ _ _ _).2 (by simp))
  have hcd : (gr h x).Adj c d := SimpleGraph.map_adj_apply.mpr (((cross_adj _ _ _ _).2 (by simp)).symm)
  have hac : ¬(gr h x).Adj a c := by
    change ¬(gr h x).Adj (emb h (pt i true false)) (emb h (pt i false (!(x i))))
    rw [SimpleGraph.map_adj_apply,cross_adj]; cases x i <;> decide
  have hbd : ¬(gr h x).Adj b d := by
    change ¬(gr h x).Adj (emb h (pt i false (x i))) (emb h (pt i true true))
    rw [SimpleGraph.map_adj_apply,(graph x).adj_comm,cross_adj]; cases x i <;> decide
  have hv : validSwitch (gr h x) p := (validSwitch_fourVertexProposal_iff _ _ _ _ _ _).2 ⟨hab,hcd,hac,hbd⟩
  let z := proposalState (cube h x) p
  let y := (cube h).symm z
  have hr : proposalResult (gr h x) p = gr h y := congrArg Subtype.val ((cube h).apply_symm_apply z).symm
  have hrm : (removedMatching p).Adj a b := (removedMatching_fourVertexProposal _ _ _ _ _ _ _).mpr (Or.inl ⟨rfl,rfl⟩)
  have hn := ((removedMatching_adj_iff hv a b).mp hrm).2
  rw [hr] at hn
  have hc : x i ≠ y i := by
    intro he
    exact hn (SimpleGraph.map_adj_apply.mpr ((cross_adj y i false (x i)).2 (by simp [he])))
  have hy := only_flip h hv hr i hc
  exact ⟨p,hv,hr.trans (congrArg (gr h) hy)⟩

theorem step_iff_flip (h : 4*k ≤ n) (x y : Bits k) :
    SwitchStep n (extendDegrees (deg k)) (cube h x) (cube h y) ↔ ∃ i,y=CubeLower.flip i x := by
  constructor
  · rintro ⟨p,hv,hr⟩
    have hne : x≠y := by intro he; subst y; exact (proposalResult_ne_of_validSwitch hv) hr
    obtain ⟨i,hi⟩ := Function.ne_iff.mp hne
    exact ⟨i,only_flip h hv hr i hi⟩
  · rintro ⟨i,rfl⟩
    exact flip_step h x i

#print axioms step_iff_flip
end
end LayeredLower.Padding
