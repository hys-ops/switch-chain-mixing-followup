import Conjugacy
import Mathlib.GroupTheory.Perm.ViaEmbedding

namespace LayeredLower.Padding
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {m n : ℕ}

abbrev emb (h : m ≤ n) := Fin.castLEEmb h

def extendDegrees (d : Fin m → ℕ) (v : Fin n) : ℕ :=
  if a : v.val < m then d ⟨v.val,a⟩ else 0

@[simp] lemma extend_apply (h : m ≤ n) (d : Fin m → ℕ) (u : Fin m) :
    extendDegrees d (emb h u) = d u := by simp [extendDegrees,emb,Fin.castLEEmb,u.isLt]

lemma degree_eq (G : SimpleGraph (Fin n)) (v : Fin n) : graphDegree G v = G.degree v := by
  rw [← G.card_neighborFinset_eq_degree,SimpleGraph.neighborFinset_eq_filter]; rfl

def pad (h : m ≤ n) {d : Fin m → ℕ} (g : GraphState m d) :
    GraphState n (extendDegrees d) := by
  refine ⟨g.val.map (emb h), fun v => ?_⟩
  by_cases hv : v.val < m
  · let u : Fin m := ⟨v.val,hv⟩
    change graphDegree (g.val.map (emb h)) (emb h u) = extendDegrees d (emb h u)
    rw [extend_apply,degree_eq,SimpleGraph.degree_map_apply,←degree_eq,g.property]
  · rw [extendDegrees,dite_eq_right hv,degree_eq,SimpleGraph.degree_eq_zero]
    intro w hadj
    obtain ⟨u,z,_,hu,_⟩ := (SimpleGraph.map_adj ..).mp hadj
    exact hv ((congrArg Fin.val hu) ▸ u.isLt)

lemma adj_active {d : Fin m → ℕ} (G : GraphState n (extendDegrees d)) {u v : Fin n}
    (huv : G.val.Adj u v) : u.val < m := by
  by_contra h
  have hp := (G.val.degree_pos_iff_exists_adj u).mpr ⟨v,huv⟩
  rw [←degree_eq,G.property,extendDegrees,dite_eq_right h] at hp
  exact (Nat.lt_irrefl _ hp)

lemma recovered (h : m ≤ n) {d : Fin m → ℕ} (G : GraphState n (extendDegrees d)) :
    (G.val.comap (emb h)).map (emb h) = G.val := by
  ext u v
  constructor
  · intro ha
    rw [SimpleGraph.map_adj] at ha
    obtain ⟨u',v',huv,rfl,rfl⟩ := ha
    exact huv
  · intro ha
    exact (SimpleGraph.map_adj ..).mpr ⟨⟨u.val,adj_active G ha⟩,⟨v.val,adj_active G ha.symm⟩,ha,rfl,rfl⟩

def trim (h : m ≤ n) {d : Fin m → ℕ} (G : GraphState n (extendDegrees d)) : GraphState m d := by
  refine ⟨G.val.comap (emb h),fun u => ?_⟩
  have hdeg (K : SimpleGraph (Fin m)) : graphDegree (K.map (emb h)) (emb h u) = graphDegree K u := by
    rw [degree_eq,degree_eq,SimpleGraph.degree_map_apply]
  rw [←hdeg,recovered,G.property,extend_apply]

def stateEquiv (h : m ≤ n) (d : Fin m → ℕ) : GraphState m d ≃ GraphState n (extendDegrees d) where
  toFun := pad h
  invFun := trim h
  left_inv g := Subtype.ext (SimpleGraph.comap_map_eq (emb h) g.val)
  right_inv g := Subtype.ext (recovered h g)

def padded_iso (h : m ≤ n) {G H : SimpleGraph (Fin m)} (e : G ≃g H) :
    G.map (emb h) ≃g H.map (emb h) := by
  let d := Equiv.Perm.viaEmbedding e.toEquiv (emb h)
  have image (i : Fin m) : d (emb h i) = emb h (e i) := Equiv.Perm.viaEmbedding_apply e.toEquiv (emb h) i
  refine ⟨d, ?_⟩
  intro x y
  constructor
  · intro ha
    obtain ⟨i,j,ha,hi,hj⟩ := (SimpleGraph.map_adj ..).mp ha
    let u := e.symm i
    let v := e.symm j
    have hu : emb h u = x := d.injective (by rw [image,show e u = i from e.apply_symm_apply i]; exact hi)
    have hv : emb h v = y := d.injective (by rw [image,show e v = j from e.apply_symm_apply j]; exact hj)
    exact (SimpleGraph.map_adj ..).mpr ⟨u,v,e.symm.map_rel_iff.mpr ha,hu,hv⟩
  · intro ha
    obtain ⟨i,j,ha,rfl,rfl⟩ := (SimpleGraph.map_adj ..).mp ha
    rw [image,image,SimpleGraph.map_adj_apply]
    exact e.map_rel_iff.mpr (SimpleGraph.map_adj_apply.mp ha)

#print axioms stateEquiv
#print axioms padded_iso
end
end LayeredLower.Padding
