import DegreeProduct

noncomputable section
open scoped BigOperators
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
open PairResampling
variable {n : ℕ} {d : Fin n → ℕ}

theorem sum_blocks (d : Fin n → ℕ) (f : Fin n → ℝ) :
    (∑ v, f v) = ∑ k : Colors d, ∑ u : Block d k, f u.1 := by
  rw [← Equiv.sum_comp (sigmaVertices d) f, Fintype.sum_sigma]
  rfl

theorem sum_pairs_blocks (F : Finset (Fin n) → ℝ)
    (hdiag : ∀ i, F {i,i} = 0) (hcross : ∀ i j, d i ≠ d j → F {i,j}=0) :
    2 * (∑ a ∈ pairs n, F a) =
      ∑ k : Colors d, ∑ u : Block d k, ∑ v : Block d k, F {u.1,v.1} := by
  classical
  have hoff : (∑ p ∈ (Finset.univ : Finset (Fin n)).offDiag, F {p.1,p.2}) =
      ∑ p : Fin n × Fin n, F {p.1,p.2} := by
    apply Finset.sum_subset (Finset.subset_univ _)
    rintro ⟨i,j⟩ _ hn
    have he : i=j := by simpa using hn
    subst j
    exact hdiag i
  calc
    _ = ∑ p ∈ (Finset.univ : Finset (Fin n)).offDiag, F {p.1,p.2} :=
      (UnorderedPairSums.sum_offDiag_eq_two_mul _ _).symm
    _ = ∑ i : Fin n, ∑ j : Fin n, F {i,j} := by rw [hoff,Fintype.sum_prod_type]
    _ = _ := by
      rw [sum_blocks d (fun i => ∑ j, F {i,j})]
      apply Finset.sum_congr rfl
      intro k _
      apply Finset.sum_congr rfl
      intro u _
      rw [sum_blocks d (fun j => F {u.1,j})]
      apply Finset.sum_eq_single k
      · intro l _ hl
        exact Finset.sum_eq_zero fun v _ => hcross _ _ (fun h => hl (Subtype.ext
          (v.2.symm.trans (h.symm.trans u.2))))
      · simp

private theorem eligible_pair {i j : Fin n} {p : Fin n × Fin n}
    (h : Eligible (d:=d) {i,j} p) : i≠j ∧ d i = d j := by
  have hp : ({i,j}: Set (Fin n)) = {p.1,p.2} := by
    simpa using congrArg (fun (s : Finset (Fin n)) => (s : Set (Fin n))) h.2.1
  rcases Set.pair_eq_pair_iff.mp hp with he | he
  · rw [he.1,he.2]; exact ⟨h.1,h.2.2⟩
  · rw [he.1,he.2]; exact ⟨h.1.symm,h.2.2.symm⟩

theorem anchor_inactive {i j : Fin n} (h : ¬ (i≠j ∧ d i=d j)) :
    anchorSwap (d:=d) {i,j} = 1 := by
  unfold anchorSwap
  apply dite_eq_right
  rintro ⟨p,hp⟩
  exact h (eligible_pair hp)

theorem action_block_eq_anchor (k : Colors d) (u v : Block d k) (G : GraphState n d) :
    action (blockAnchor k u v) G = anchorSwap {u.1,v.1} G := by
  by_cases h : u.1 = v.1
  · have h' : u=v := Subtype.ext h
    subst v
    rw [anchor_inactive (by simp)]
    apply Subtype.ext
    ext i j
    change G.1.Adj (Equiv.swap u.1 u.1 i) (Equiv.swap u.1 u.1 j) ↔ G.1.Adj i j
    simp
  · exact (anchorSwap_apply _ _ h (u.2.trans v.2.symm) G).symm

/-- Two orientations of an unordered admissible label pair give the two
ordered terms of its class's transposition generator. -/
theorem labelLaplacian_blocks (f : GraphState n d → ℝ) (G : GraphState n d) :
    2*labelLaplacian f G =
      ∑ k : Colors d, ∑ u : Block d k, ∑ v : Block d k,
        (f G - f (action (blockAnchor k u v) G)) := by
  let F (a : Finset (Fin n)) := f G - f (anchorSwap a G)
  have hz (i j : Fin n) (h : ¬(i≠j ∧ d i=d j)) : F {i,j}=0 := by
    simp [F,anchor_inactive h]
  have h := sum_pairs_blocks F (fun i => hz i i (by simp))
    (fun i j he => hz i j (fun p => he p.2))
  simpa only [F,labelLaplacian,action_block_eq_anchor] using h

#print axioms sum_pairs_blocks
#print axioms labelLaplacian_blocks
end OAI.Problem315.UnigraphUpper
