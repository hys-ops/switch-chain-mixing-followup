import PermutationModes
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphModes
variable {A : Type*} [Fintype A] [DecidableEq A]

/-- Exact action on the observation of the label at one fixed position. -/
theorem coordinate_action (h : A → ℝ) (a : A) (x : Equiv.Perm A) :
    (regularLap A *ᵥ (fun y : Equiv.Perm A => h (y a))) x =
      (Fintype.card A : ℝ)*h (x a) - ∑ c,h c := by
  classical
  have each (i j : A) : h (x a) - h ((x * Equiv.swap i j) a) =
      (if i=a then h (x a) - h (x j) else 0) +
      (if j=a then h (x a) - h (x i) else 0) := by
    change h (x a) - h (x ((Equiv.swap i j) a)) = _
    by_cases hi : i=a
    · subst i
      by_cases hj : j=a
      · subst j; simp
      · simp [hj]
    · by_cases hj : j=a
      · subst j; simp [hi]
      · simp [hi,hj,Equiv.swap_apply_of_ne_of_ne (Ne.symm hi) (Ne.symm hj)]
  rw [regularLap_apply]
  simp only [each, Finset.sum_add_distrib, ← Finset.ite_sum_zero, Finset.sum_ite_eq',
    Finset.mem_univ,ite_true, Finset.sum_sub_distrib, Finset.sum_const, Finset.card_univ, nsmul_eq_mul]
  rw [Equiv.sum_comp x h]
  ring

/-- Witness of equality in the m-gap lower bound for every label set of size at least two. -/
theorem regular_gap_attained (hA : 2 ≤ Fintype.card A) :
    ∃ f : Equiv.Perm A → ℝ, f≠0 ∧ (regularLap A *ᵥ f)=(Fintype.card A : ℝ) • f := by
  classical
  obtain ⟨a,b,hab⟩ := Fintype.one_lt_card_iff.mp hA
  let h : A → ℝ := fun i => (if i=a then 1 else 0) - (if i=b then 1 else 0)
  have hzero : (∑ i,h i)=0 := by simp [h,Finset.sum_sub_distrib]
  refine ⟨fun x => h (x a),?_,?_⟩
  · intro H
    have hh := congrFun H (1:Equiv.Perm A)
    simp [h,hab] at hh
  · funext x
    rw [coordinate_action,hzero,sub_zero]
    rfl

#print axioms coordinate_action
#print axioms regular_gap_attained
end UnigraphModes
