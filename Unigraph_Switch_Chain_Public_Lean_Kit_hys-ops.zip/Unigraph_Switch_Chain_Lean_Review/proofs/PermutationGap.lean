import Mathlib.GroupTheory.Perm.Sign
import Mathlib.Tactic
open scoped BigOperators
noncomputable section
namespace UnigraphPermutation
variable {A : Type*} [Fintype A] [DecidableEq A]
abbrev Perm (A : Type*) := Equiv.Perm A
def mass (f : Perm A → ℝ) := ∑ x, f x ^ 2
def corr (f : Perm A → ℝ) (s : Perm A) := ∑ x, f x * f (x*s)
def edge (f : Perm A → ℝ) (i j : A) := mass f - corr f (Equiv.swap i j)
def lap (f : Perm A → ℝ) (x : Perm A) :=
  (∑ i : A, ∑ j : A, (f x - f (x*Equiv.swap i j)))/2

theorem reindex (s : Perm A) (h : Perm A → ℝ) : (∑ x, h (x*s)) = ∑ x, h x :=
  Equiv.sum_comp (Equiv.mulRight s) h

theorem edge_nonnegative (f : Perm A → ℝ) (i j : A) : 0 ≤ edge f i j := by
  let s := Equiv.swap i j
  have h := reindex s (fun x => f x ^ 2)
  have hp : 0 ≤ ∑ x, (f x - f (x*s))^2 := Finset.sum_nonneg fun _ _ => sq_nonneg _
  simp only [sub_sq, Finset.sum_add_distrib, Finset.sum_sub_distrib, mul_assoc,
    ← Finset.mul_sum] at hp
  change (∑ x, f (x*s)^2) = _ at h
  change 0 ≤ (∑ x, f x^2) - ∑ x, f x * f (x*s)
  linarith

/-- The local three-cycle inequality, before choosing the transpositions. -/
theorem order_three (f : Perm A → ℝ) (r : Perm A) (hr : r*r*r=1) :
    -mass f ≤ 2*corr f r := by
  let B (x : Perm A) := f (x*r)
  let C (x : Perm A) := f (x*r*r)
  have h1 : (∑ x, B x ^ 2) = mass f := reindex r (fun x => f x ^ 2)
  have h2 : (∑ x, C x ^ 2) = mass f := (reindex r (fun x => B x ^2)).trans h1
  have h3 : (∑ x, B x * C x) = corr f r := reindex r (fun x => f x * B x)
  have hh (x : Perm A) : x*r*r*r = x := by rw [mul_assoc x r r, mul_assoc x (r*r) r, hr, mul_one]
  have h4 : (∑ x, C x * f x) = corr f r := by
    calc
      _ = ∑ x, (B (x*r) * C (x*r)) := by simp [B,C,hh]
      _ = _ := (reindex r (fun x => B x*C x)).trans h3
  have hp : 0 ≤ ∑ x, (f x + B x + C x)^2 := Finset.sum_nonneg fun _ _ => sq_nonneg _
  have hx (x : Perm A) : (f x+B x+C x)^2 =
      f x^2+B x^2+C x^2+2*(f x*B x)+2*(B x*C x)+2*(C x*f x) := by ring
  simp only [hx,Finset.sum_add_distrib,← Finset.mul_sum] at hp
  have h5 : (∑ x, f x*B x) = corr f r := rfl
  have h6 : (∑ x, f x^2) = mass f := rfl
  linarith

theorem touching_edge (f : Perm A → ℝ) (a b c : A) (hab : a ≠ b) (hac : a ≠ c)
    (hbc : b ≠ c) (hf : ∀ x, f (x*Equiv.swap a b) = -f x) :
    mass f / 2 ≤ edge f a c := by
  let s := Equiv.swap a c
  let w := Equiv.swap a b
  have hr : (s*w)*(s*w)*(s*w) = 1 := by
    ext x
    by_cases hxa : x=a
    · subst x; simp [s,w,Equiv.Perm.mul_apply,Equiv.swap_apply_def, hbc, hab.symm, hac.symm, hbc.symm]
    by_cases hxb : x=b
    · subst x; simp [s,w,Equiv.Perm.mul_apply,Equiv.swap_apply_def, hbc, hab.symm, hac.symm, hbc.symm]
    by_cases hxc : x=c
    · subst x; simp [s,w,Equiv.Perm.mul_apply,Equiv.swap_apply_def, hbc, hab.symm, hac.symm, hbc.symm]
    simp [s,w,Equiv.Perm.mul_apply,Equiv.swap_apply_def, hxa, hxb, hxc]
  have h := order_three f _ hr
  have ht : corr f (s*w) = -corr f s := by
    unfold corr
    simp only [← mul_assoc, w, hf, mul_neg, Finset.sum_neg_distrib]
  change mass f/2 ≤ mass f - corr f s
  linarith

theorem edge_symm (f : Perm A → ℝ) (i j : A) : edge f i j = edge f j i := by
  unfold edge
  rw [Equiv.swap_comm i j]

theorem lap_comm (f : Perm A → ℝ) (s x : Perm A) :
    lap (fun y => f (y*s)) x = lap f (x*s) := by
  unfold lap
  congr 1
  let e := s⁻¹
  have he (i j : A) : x*Equiv.swap i j*s = (x*s)*Equiv.swap (e i) (e j) := by
    rw [mul_assoc, Equiv.swap_mul_eq_mul_swap, ← mul_assoc]
  simp only [he]
  calc
    _ = ∑ i : A, ∑ j : A, (f (x*s) - f (x*s*Equiv.swap (e i) j)) := by
      apply Finset.sum_congr rfl
      intro i _
      exact Equiv.sum_comp e (fun j : A => f (x*s) - f (x*s*Equiv.swap (e i) j))
    _ = _ := Equiv.sum_comp e (fun i : A => ∑ j : A, (f (x*s) - f (x*s*Equiv.swap i j)))

theorem lap_sub (f g : Perm A → ℝ) (x : Perm A) :
    lap (fun y => f y-g y) x = lap f x-lap g x := by
  have h (s : Perm A) : f x-g x-(f (x*s)-g (x*s)) = (f x-f (x*s))-(g x-g (x*s)) := by ring
  simp only [lap,h,Finset.sum_sub_distrib]
  ring

theorem edge_sum (f : Perm A → ℝ) :
    (∑ i, ∑ j, edge f i j) = 2*∑ x, f x*lap f x := by
  have h (i j : A) : edge f i j = ∑ x, f x*(f x - f (x*Equiv.swap i j)) := by
    simp [edge,mass,corr,mul_sub,Finset.sum_sub_distrib,pow_two]
  simp only [h,lap,mul_div_assoc',← Finset.sum_div]
  rw [Finset.sum_comm]
  simp_rw [Finset.sum_comm (s := Finset.univ) (t := (Finset.univ : Finset (Perm A)))]
  simp only [← Finset.mul_sum]
  ring_nf
  apply Finset.sum_congr rfl
  intro x _
  congr 1
  exact Finset.sum_comm

private def slot (M : ℝ) (z i j : A) : ℝ :=
  if i=z then (if j=z then 0 else M/2) else 0
private def bonus (M : ℝ) (a b i j : A) : ℝ :=
  if i=a then (if j=b then M else 0) else 0

private theorem slot_total (M : ℝ) (z : A) :
    (∑ i : A, ∑ j : A, slot M z i j) = (Fintype.card A-1 : ℝ)*M/2 := by
  let K := M/2
  have h (i j : A) : slot M z i j = if i=z then (K - (if j=z then K else 0)) else 0 := by
    simp [slot,K]; split_ifs <;> simp_all
  simp only [h, ← Finset.ite_sum_zero, Finset.sum_sub_distrib, Finset.sum_ite_eq',
    Finset.mem_univ, ite_true,Finset.sum_const,Finset.card_univ,nsmul_eq_mul,K]
  ring

private theorem bonus_total (M : ℝ) (a b : A) : (∑ i : A, ∑ j : A, bonus M a b i j)=M := by
  simp [bonus]

set_option maxHeartbeats 1200000 in
theorem antisymmetric_energy (f : Perm A → ℝ) (a b : A) (hab : a ≠ b)
    (hf : ∀ x, f (x*Equiv.swap a b) = -f x) :
    2*(Fintype.card A : ℝ)*mass f ≤ ∑ i, ∑ j, edge f i j := by
  let M := mass f
  have habE : edge f a b = 2*M := by
    simp [edge,corr,hf,mul_neg,Finset.sum_neg_distrib,M,mass,pow_two]; ring
  have H (i j : A) :
      slot M a i j + slot M b i j + slot M a j i + slot M b j i +
      bonus M a b i j + bonus M b a i j ≤ edge f i j := by
    have hf' (x : Perm A) : f (x*Equiv.swap b a) = -f x := by rw [Equiv.swap_comm b a,hf]
    have aa (z : A) (hz : z≠a) (hz' : z≠b) : M/2 ≤ edge f a z :=
      touching_edge f a b z hab hz.symm hz'.symm hf
    have bb (z : A) (hz : z≠a) (hz' : z≠b) : M/2 ≤ edge f b z :=
      touching_edge f b a z hab.symm hz'.symm hz.symm hf'
    by_cases hi : i=a
    · subst i
      by_cases hj : j=a
      · subst j; simpa [slot,bonus,hab] using edge_nonnegative f a a
      by_cases hj' : j=b
      · subst j; simp [slot,bonus,hab,hab.symm,habE]; linarith
      · simpa [slot,bonus,hab,hj,hj'] using aa j hj hj'
    by_cases hi' : i=b
    · subst i
      by_cases hj : j=a
      · subst j; simp [slot,bonus,hi,hab,edge_symm f b a,habE]; linarith
      by_cases hj' : j=b
      · subst j; simpa [slot,bonus,hi] using edge_nonnegative f b b
      · simpa [slot,bonus,hi,hj,hj'] using bb j hj hj'
    by_cases hj : j=a
    · subst j; simpa [slot,bonus,hi,hi',hab,edge_symm f i a] using aa i hi hi'
    by_cases hj' : j=b
    · subst j; simpa [slot,bonus,hi,hi',hj,edge_symm f i b] using bb i hi hi'
    · simpa [slot,bonus,hi,hi',hj,hj'] using edge_nonnegative f i j
  have hh := Finset.sum_le_sum (s := (Finset.univ : Finset A)) (fun i _ =>
    Finset.sum_le_sum (s := (Finset.univ : Finset A)) (fun j _ => H i j))
  have swapSum (z : A) : (∑ i : A, ∑ j : A, slot M z j i) = (Fintype.card A-1 : ℝ)*M/2 :=
    Finset.sum_comm.trans (slot_total M z)
  simp only [Finset.sum_add_distrib,slot_total,swapSum,bonus_total] at hh
  change 2*(Fintype.card A : ℝ)*M ≤ _
  linarith

private theorem gap_of_change (f : Perm A → ℝ) (v : ℝ)
    (he : ∀ x, lap f x = v*f x) (a b : A) (x : Perm A) (hx : f x ≠ f (x*Equiv.swap a b)) :
    (Fintype.card A : ℝ) ≤ v := by
  have hab : a ≠ b := by
    rintro rfl
    apply hx
    rw [show Equiv.swap a a = (1 : Perm A) by exact Equiv.swap_eq_one_iff.mpr rfl, mul_one]
  let g (y : Perm A) := f y - f (y*Equiv.swap a b)
  have hg (y : Perm A) : lap g y = v*g y := by
    change lap (fun z => f z - f (z*Equiv.swap a b)) y = _
    rw [lap_sub,lap_comm,he,he]
    dsimp [g]; ring
  have ha (y : Perm A) : g (y*Equiv.swap a b) = -g y := by simp [g]
  have M : 0 < mass g := by
    exact Finset.sum_pos' (fun _ _ => sq_nonneg _) ⟨x,Finset.mem_univ _,sq_pos_of_ne_zero (sub_ne_zero.mpr hx)⟩
  have hh := antisymmetric_energy g a b hab ha
  rw [edge_sum] at hh
  simp_rw [hg,show ∀ a : ℝ, a*(v*a) = v*a^2 by intro;ring,← Finset.mul_sum] at hh
  change 2*↑(Fintype.card A)*mass g ≤ 2*(v*mass g) at hh
  by_contra! hn
  nlinarith only [hh,mul_lt_mul_of_pos_right hn M]

/-- Nonzero eigenvalues of the unordered transposition sum in the regular
permutation representation are at least the number of labels. -/
theorem eigen_gap (f : Perm A → ℝ) (v : ℝ) (hv : v≠0)
    (hn : ∃ x, f x≠0) (he : ∀ x, lap f x = v*f x) :
    (Fintype.card A : ℝ) ≤ v := by
  classical
  obtain ⟨a,b,x,hx⟩ : ∃ a b x, f x ≠ f (x*Equiv.swap a b) := by
    by_contra! hh
    obtain ⟨x,hx⟩ := hn
    have hzero : lap f x = 0 := by
      unfold lap
      simp [fun i j => sub_eq_zero.mpr (hh i j x)]
    exact (mul_ne_zero hv hx) ((he x).symm.trans hzero)
  exact gap_of_change f v he a b x hx

theorem zero_iff_constant (f : Perm A → ℝ) :
    (∀ x, lap f x=0) ↔ ∀ x, f x = f 1 := by
  constructor
  · intro he x
    have hi (a b : A) (y : Perm A) : f (y*Equiv.swap a b) = f y := by
      by_contra h
      let _ : Nonempty A := ⟨a⟩
      have hc : (0:ℝ) < Fintype.card A := by exact_mod_cast Fintype.card_pos
      have hle := gap_of_change f 0 (by simpa using he) a b y (Ne.symm h)
      linarith
    induction x using Equiv.Perm.swap_induction_on' with
    | one => rfl
    | mul_swap x a b hab ih => exact (hi a b x).trans ih
  · intro h x
    unfold lap
    have ha (i j : A) : f x - f (x*Equiv.swap i j) = 0 := sub_eq_zero.mpr ((h x).trans (h _).symm)
    simp [ha]

#print axioms eigen_gap
#print axioms zero_iff_constant
end UnigraphPermutation
