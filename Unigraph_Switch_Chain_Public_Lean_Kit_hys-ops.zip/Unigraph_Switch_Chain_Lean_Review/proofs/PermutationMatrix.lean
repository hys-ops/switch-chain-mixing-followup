import GapModes
import Mathlib.GroupTheory.Perm.Sign
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphModes
variable {A : Type*} [Fintype A] [DecidableEq A]

/-- The permutation matrix for right multiplication by the label transposition (i,j). -/
def rightSwap (i j : A) : Matrix (Equiv.Perm A) (Equiv.Perm A) ℝ :=
  Matrix.of fun x y => if x * Equiv.swap i j = y then 1 else 0

theorem rightSwap_apply (i j : A) (f : Equiv.Perm A → ℝ) (x : Equiv.Perm A) :
    ((rightSwap i j) *ᵥ f) x = f (x*Equiv.swap i j) := by
  classical
  simp [Matrix.mulVec,dotProduct,rightSwap,ite_mul]

omit [Fintype A] in
private theorem swap_cond (x y : Equiv.Perm A) (i j : A) :
    x*Equiv.swap i j=y ↔ y*Equiv.swap i j=x := by
  constructor <;> rintro rfl <;> simp [mul_assoc]

theorem rightSwap_hermitian (i j : A) : (rightSwap i j).IsHermitian := by
  apply Matrix.isHermitian_iff_isSymm.mpr
  ext x y
  change (if y * Equiv.swap i j = x then (1:ℝ) else 0) =
    (if x * Equiv.swap i j = y then 1 else 0)
  by_cases h : y * Equiv.swap i j = x
  · simp [h,(swap_cond y x i j).mp h]
  · have hh : ¬x*Equiv.swap i j = y := fun hx => h ((swap_cond x y i j).mp hx)
    simp [h,hh]

/-- Distinct unordered label transpositions once, equivalently half the ordered double sum. -/
def regularLap (A : Type*) [Fintype A] [DecidableEq A] : Matrix (Equiv.Perm A) (Equiv.Perm A) ℝ :=
  (1/2:ℝ) • ∑ i : A, ∑ j : A, (1 - rightSwap i j)

theorem regularLap_apply (f : Equiv.Perm A → ℝ) (x : Equiv.Perm A) :
    (regularLap A *ᵥ f) x = (∑ i : A, ∑ j : A, (f x-f (x*Equiv.swap i j)))/2 := by
  classical
  simp only [regularLap, Matrix.smul_mulVec, Matrix.sum_mulVec, Matrix.sub_mulVec,
    Matrix.one_mulVec, Pi.smul_apply,Finset.sum_apply,Pi.sub_apply,rightSwap_apply,smul_eq_mul]
  ring

theorem regularLap_hermitian : (regularLap A).IsHermitian := by
  classical
  unfold regularLap
  apply Matrix.IsHermitian.smul _ (by simp)
  change (∑ i : A, ∑ j : A, (1 - rightSwap i j))ᴴ = _
  simp only [Matrix.conjTranspose_sum,Matrix.conjTranspose_sub,Matrix.conjTranspose_one,
    fun i j : A => (rightSwap_hermitian i j).eq]

#print axioms regularLap_apply
#print axioms regularLap_hermitian
end UnigraphModes
