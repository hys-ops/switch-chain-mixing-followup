import PermutationMatrix
import PermutationGap
import Mathlib.GroupTheory.Perm.Finite
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphModes
variable {A : Type*} [Fintype A] [DecidableEq A]

/-- The regular-representation matrix is precisely the sum of unordered
transposition differences in the certified gap argument. -/
theorem regularLap_eq_lap (f : Equiv.Perm A → ℝ) (x : Equiv.Perm A) :
  (regularLap A *ᵥ f) x = UnigraphPermutation.lap f x := regularLap_apply f x

/-- The complete transposition Cayley graph on permutations has a single
constant mode, and all other eigenvalues are at least the label count. -/
theorem regular_gap_modes (A : Type*) [Fintype A] [DecidableEq A] :
    ∃ (b : OrthonormalBasis (Equiv.Perm A) ℝ (EuclideanSpace ℝ (Equiv.Perm A)))
      (ξ : Equiv.Perm A → ℝ) (a₀ : Equiv.Perm A),
      ξ a₀=0 ∧ (∀ a, a≠a₀ → (Fintype.card A : ℝ)≤ξ a) ∧
      (∀ i, regularLap A *ᵥ (b i : Equiv.Perm A→ℝ)=ξ i • (b i : Equiv.Perm A→ℝ)) := by
  classical
  apply gap_modes (regularLap A) regularLap_hermitian
  · funext x
    rw [regularLap_eq_lap]
    simp [UnigraphPermutation.lap]
  · intro f h
    refine ⟨f 1,(UnigraphPermutation.zero_iff_constant f).mp ?_⟩
    intro x
    simpa only [regularLap_eq_lap,Pi.zero_apply] using congrFun h x
  · intro f v hv hf he
    apply UnigraphPermutation.eigen_gap f v hv
    · contrapose! hf
      funext x
      exact hf x
    · intro x
      simpa only [regularLap_eq_lap,Pi.smul_apply,smul_eq_mul] using congrFun he x

#print axioms regular_gap_modes
end UnigraphModes
