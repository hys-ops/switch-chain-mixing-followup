import PermutationModes
import TensorBound
open scoped BigOperators Matrix RealInnerProductSpace
open UnigraphTrace
noncomputable section
namespace UnigraphModes
variable {X C : Type*} [Fintype X] [DecidableEq X] [Fintype C] [DecidableEq C]

/-- A transitive positive Markov matrix with energy dominating the pulled-back
actual block-permutation generator has the factorial heat bound. No eigenvalue,
basis, or individual zero-mode data are assumptions in this statement. -/
theorem permutation_row_bound (A : C → Type*) [∀ c, Fintype (A c)] [∀ c, DecidableEq (A c)]
    {P : Matrix X X ℝ} (hP : P.PosSemidef) (hr : ∀ x, ∑ y,P x y=1)
    (transitive : ∀ x y,∃ e : Equiv.Perm X, e x=y ∧ ∀ a b,P (e a) (e b)=P a b)
    (T : EuclideanSpace ℝ X →ₗᵢ[ℝ] ProductL2 (fun c => Equiv.Perm (A c)))
    {Q : ℝ} (hQ : 0<Q)
    (hform : ∀ x, ⟪T x, tensorLap (fun c => regularLap (A c)) (T x)⟫ ≤
      2*Q*(‖x‖^2-⟪x,P.toEuclideanLin x⟫)) (t : ℕ) (x : X) :
    4*(rowTV P t x)^2 ≤
      (∏ c, (1+(((Fintype.card (A c)).factorial : ℝ)-1)*
        Real.exp (-(t:ℝ)/Q*(Fintype.card (A c):ℝ))))-1 := by
  simpa only [Fintype.card_perm] using tensor_row_bound hP hr transitive
    (fun c => regularLap (A c)) (fun c => (Fintype.card (A c):ℝ))
    (fun c => regular_gap_modes (A c)) T hQ hform t x

#print axioms permutation_row_bound
end UnigraphModes
