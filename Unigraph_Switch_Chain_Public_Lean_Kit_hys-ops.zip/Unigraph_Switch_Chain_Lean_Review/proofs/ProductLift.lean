import PairPartition
import OrbitLift
import RegularProduct

noncomputable section
open scoped BigOperators Matrix RealInnerProductSpace
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
open PairResampling
variable {n : ℕ} {d : Fin n → ℕ}

def productLift (hu : IsUnigraphic d) (base : GraphState n d) :
    StateSpace n d →ₗᵢ[ℝ] EuclideanSpace ℝ (Blocks d) :=
  (LinearIsometryEquiv.piLpCongrLeft 2 ℝ ℝ (blockEquiv d).toEquiv).toLinearIsometry.comp
    (orbitLift hu base)

theorem productLift_apply (hu : IsUnigraphic d) (base : GraphState n d) (x : StateSpace n d)
    (g : Γ d) : productLift hu base x (blockEquiv d g) = scale base * x (orbit base g) := by
  change scale base * x (orbit base ((blockEquiv d).symm (blockEquiv d g))) = _
  rw [MulEquiv.symm_apply_apply]

abbrev tensorD (d : Fin n → ℕ) := UnigraphTrace.tensorLap (fun c => UnigraphModes.regularLap (Block d c))

theorem tensor_lift_eq (hu : IsUnigraphic d) (base : GraphState n d) (x : StateSpace n d)
    (g : Γ d) : tensorD d (productLift hu base x) (blockEquiv d g) =
      scale base * labelLaplacian (fun H => x H) (orbit base g) := by
  unfold tensorD
  rw [UnigraphTrace.tensor_regular_apply]
  have hs (k : Colors d) (u v : Block d k) :
      (productLift hu base x) (Function.update (blockEquiv d g) k
        (blockEquiv d g k * Equiv.swap u v)) =
        scale base * x (action (blockAnchor k u v) (orbit base g)) := by
    rw [← updated_group, productLift_apply]
    rfl
  simp_rw [productLift_apply, hs, ← mul_sub, ← Finset.mul_sum, mul_div_assoc]
  rw [← Finset.mul_sum, ← Finset.sum_div, ← labelLaplacian_blocks]
  ring

theorem product_energy_eq (hu : IsUnigraphic d) (base : GraphState n d) (x : StateSpace n d) :
    ⟪productLift hu base x,tensorD d (productLift hu base x)⟫ =
      ⟪orbitLift hu base x,InvolutionGap.lap regMove (orbitLift hu base x)⟫ := by
  rw [InvolutionGap.inner_as_sum,InvolutionGap.inner_as_sum]
  rw [← Equiv.sum_comp (blockEquiv d).toEquiv
    (fun y => (productLift hu base x) y * tensorD d (productLift hu base x) y)]
  apply Finset.sum_congr rfl
  intro g _
  change (productLift hu base x) (blockEquiv d g) * tensorD d (productLift hu base x) (blockEquiv d g) = _
  rw [productLift_apply,tensor_lift_eq,regLap_lift]
  rfl

theorem product_graphP_energy (hn : 4 ≤ n) (hu : IsUnigraphic d) (base : GraphState n d)
    (x : StateSpace n d) :
    ⟪productLift hu base x,tensorD d (productLift hu base x)⟫ ≤
      2*(12*(n.choose 4 : ℝ))*(‖x‖^2 - ⟪x,(graphP d).toEuclideanLin x⟫) := by
  rw [product_energy_eq]
  exact lifted_graphP_energy hn hu base x

#print axioms tensor_lift_eq
#print axioms product_graphP_energy
end OAI.Problem315.UnigraphUpper
