import TensorBasis
import PermutationMatrix
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphTrace
variable {C : Type*} [Fintype C] [DecidableEq C]
variable (A : C → Type*) [∀ c,Fintype (A c)] [∀ c,DecidableEq (A c)]
/-- Evaluate the tensor sum of the concrete transposition generators:
only one permutation coordinate changes in each summand. -/
theorem tensor_regular_apply (f : ProductL2 (fun c => Equiv.Perm (A c)))
    (x : ∀ c,Equiv.Perm (A c)) :
    tensorLap (fun c => UnigraphModes.regularLap (A c)) f x =
    ∑ c, (∑ i : A c,∑ j : A c,
      (f x - f (Function.update x c (x c * Equiv.swap i j))))/2 := by
  change (∑ c,∑ y, UnigraphModes.regularLap (A c) (x c) y * f (Function.update x c y))=_
  apply Finset.sum_congr rfl
  intro c _
  have h := UnigraphModes.regularLap_apply (fun y => f (Function.update x c y)) (x c)
  simpa only [Function.update_eq_self, Matrix.mulVec, dotProduct] using h
#print axioms tensor_regular_apply
end UnigraphTrace
