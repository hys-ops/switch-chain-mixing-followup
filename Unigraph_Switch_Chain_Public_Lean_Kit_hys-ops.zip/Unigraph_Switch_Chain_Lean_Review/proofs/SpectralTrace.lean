import OrbitTrace
import Mathlib.Analysis.Convex.Jensen
import Mathlib.Analysis.InnerProductSpace.Trace
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphTrace
variable {I A : Type*} [Fintype I] [Fintype A]

/-- Jensen's trace comparison with sub-bistochastic overlap weights. -/
theorem weighted_trace (w : I → A → ℝ) (eigP : I → ℝ) (ξ : A → ℝ)
    (Q : ℝ) (hQ : 0<Q) (hw : ∀ i a,0≤w i a)
    (hrow : ∀ i, ∑ a,w i a=1) (hcol : ∀ a,∑ i,w i a≤1)
    (hpos : ∀ i,0≤eigP i) (hform : ∀ i, ∑ a,w i a*ξ a ≤ 2*Q*(1-eigP i))
    (t : ℕ) :
    (∑ i, (eigP i)^(2*t)) ≤ ∑ a, Real.exp (-(t:ℝ)/Q*ξ a) := by
  have hu : 0 ≤ (t:ℝ)/Q := by positivity
  have hterm (i : I) : (eigP i)^(2*t) ≤ ∑ a,w i a*Real.exp (-(t:ℝ)/Q*ξ a) := by
    have h0 : eigP i ≤ Real.exp (eigP i-1) := by linarith [Real.add_one_le_exp (eigP i-1)]
    have hle := mul_le_mul_of_nonneg_right (hform i) hu
    have hstep : (2*(t:ℝ))*(eigP i-1) ≤ (-(t:ℝ)/Q)*(∑ a,w i a*ξ a) := by
      field_simp at hle ⊢
      nlinarith
    calc
      _ ≤ (Real.exp (eigP i-1))^(2*t) := pow_le_pow_left₀ (hpos i) h0 _
      _ = Real.exp ((2*(t:ℝ))*(eigP i-1)) := by rw [←Real.exp_nat_mul];norm_num
      _ ≤ _ := Real.exp_le_exp.mpr hstep
      _ = Real.exp (∑ a,w i a*((-(t:ℝ)/Q)*ξ a)) := by rw [Finset.mul_sum];congr 1;apply Finset.sum_congr rfl;intros;ring
      _ ≤ _ := by
        simpa only [smul_eq_mul] using
          convexOn_exp.map_sum_le (fun a _ => hw i a) (hrow i)
            (fun a _ => Set.mem_univ ((-(t:ℝ)/Q)*ξ a))
  calc
    _ ≤ ∑ i, ∑ a, w i a*Real.exp (-(t:ℝ)/Q*ξ a) := Finset.sum_le_sum fun i _ => hterm i
    _ = ∑ a, (∑ i,w i a)*Real.exp (-(t:ℝ)/Q*ξ a) := by rw [Finset.sum_comm];simp_rw [Finset.sum_mul]
    _ ≤ _ := Finset.sum_le_sum fun a _ => by simpa using mul_le_mul_of_nonneg_right (hcol a) (Real.exp_nonneg _)

variable {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F]
/-- Dirichlet energy in an orthonormal eigenbasis, including a lift from a quotient. -/
theorem basis_energy (b : OrthonormalBasis A ℝ F) (J : F →ₗ[ℝ] F)
    (ξ : A → ℝ) (hb : ∀ a, J (b a)=ξ a • b a) (x : F) :
    (∑ a, ⟪x,b a⟫^2*ξ a)=⟪x,J x⟫ := by
  conv_rhs => rhs; rw [← b.sum_repr' x]
  simp only [map_sum,map_smul,hb,inner_sum,real_inner_smul_right]
  apply Finset.sum_congr rfl
  intro a _
  rw [real_inner_comm (b a) x]
  ring

theorem lifted_trace (v : I → F) (hv : Orthonormal ℝ v) (b : OrthonormalBasis A ℝ F)
    (J : F →ₗ[ℝ] F) (ξ : A → ℝ) (hb : ∀ a,J (b a)=ξ a • b a)
    (eigP : I → ℝ) (hpos : ∀ i,0≤eigP i) {Q : ℝ} (hQ : 0<Q)
    (hform : ∀ i,⟪v i,J (v i)⟫ ≤ 2*Q*(1-eigP i)) (t : ℕ) :
    (∑ i,(eigP i)^(2*t)) ≤ ∑ a, Real.exp (-(t:ℝ)/Q*ξ a) := by
  apply weighted_trace (fun i a => ⟪v i,b a⟫^2) eigP ξ Q hQ (fun _ _ => sq_nonneg _) _ _ hpos _ t
  · intro i; simpa [hv.1 i] using b.sum_sq_inner_left (v i)
  · intro a
    simpa [Real.norm_eq_abs, b.orthonormal.1 a] using
      (hv.sum_inner_products_le (s:=Finset.univ) (b a))
  · intro i; rw [basis_energy b J ξ hb];exact hform i

/-- Exact spectral factorization for a tensor sum, with dependent factor dimensions. -/
theorem product_heat {C : Type*} [Fintype C] [DecidableEq C]
    {B : C → Type*} [∀ c,Fintype (B c)] (ξ : ∀ c,B c→ℝ) (u : ℝ) :
    (∑ a : ∀ c,B c, Real.exp (-u*(∑ c,ξ c (a c)))) =
      ∏ c,∑ i, Real.exp (-u*ξ c i) := by
  rw [Fintype.prod_sum]
  congr 1
  funext a
  rw [Finset.mul_sum,Real.exp_sum]

/-- The zero mode and the gap give the single-factor heat bound. -/
theorem one_factor (ξ : A → ℝ) (a₀ : A) (m u : ℝ) (hu : 0≤u)
    (hz : ξ a₀=0) (hg : ∀ a,a ≠ a₀ → m≤ξ a) :
    (∑ a,Real.exp (-u*ξ a)) ≤ 1+((Fintype.card A:ℝ)-1)*Real.exp (-u*m) := by
  classical
  rw [← Finset.add_sum_erase Finset.univ _ (Finset.mem_univ a₀),hz,mul_zero,Real.exp_zero]
  apply add_le_add_right
  calc
    _ ≤ ∑ _a ∈ Finset.univ.erase a₀,Real.exp (-u*m) := by
      apply Finset.sum_le_sum
      intro a ha
      apply Real.exp_le_exp.mpr
      exact mul_le_mul_of_nonpos_left (hg a (Finset.mem_erase.mp ha).1) (by linarith)
    _ = _ := by
      have : Nonempty A := ⟨a₀⟩
      simp only [Finset.sum_const,nsmul_eq_mul,Finset.card_erase_of_mem (Finset.mem_univ a₀),Finset.card_univ]
      rw [Nat.cast_sub (Fintype.card_pos (α:=A))]
      norm_num

#print axioms lifted_trace
#print axioms product_heat
#print axioms one_factor
end UnigraphTrace
