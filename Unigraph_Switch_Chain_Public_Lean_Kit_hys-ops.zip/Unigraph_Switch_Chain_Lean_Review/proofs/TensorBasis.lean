import OrbitTrace
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
open scoped BigOperators Matrix RealInnerProductSpace
open WithLp
noncomputable section
namespace UnigraphTrace
variable {C : Type*} [Fintype C] [DecidableEq C]
variable {B : C → Type*} [∀ c,Fintype (B c)] [∀ c,DecidableEq (B c)]
abbrev ProductL2 (B : C → Type*) := EuclideanSpace ℝ (∀ c,B c)

def prodVec (v : ∀ c,OrthonormalBasis (B c) ℝ (EuclideanSpace ℝ (B c))) (a : ∀ c,B c) :
    ProductL2 B := toLp 2 fun x => ∏ c,v c (a c) (x c)

theorem prodVec_orthonormal (v : ∀ c,OrthonormalBasis (B c) ℝ (EuclideanSpace ℝ (B c))) :
    Orthonormal ℝ (prodVec v) := by
  classical
  rw [orthonormal_iff_ite]
  intro a b
  change (∑ x : ∀ c,B c, (∏ c, v c (b c) (x c)) * ∏ c, v c (a c) (x c)) = _
  simp_rw [←Finset.prod_mul_distrib]
  rw [← Fintype.prod_sum (fun (c : C) (y : B c) => v c (b c) y * v c (a c) y)]
  have h (c : C) : (∑ x, v c (b c) x * v c (a c) x) = (if a c=b c then 1 else 0) := by
    exact (orthonormal_iff_ite.mp (v c).orthonormal) (a c) (b c)
  simp_rw [h]
  by_cases hab : a=b
  · simp [hab]
  · obtain ⟨c,hc⟩ := Function.ne_iff.mp hab
    simp only [if_neg hab]
    apply Finset.prod_eq_zero (Finset.mem_univ c)
    simp [hc]

def prodBasis (v : ∀ c,OrthonormalBasis (B c) ℝ (EuclideanSpace ℝ (B c))) :
    OrthonormalBasis (∀ c,B c) ℝ (ProductL2 B) :=
  OrthonormalBasis.mk (prodVec_orthonormal v)
    ((prodVec_orthonormal v).linearIndependent.span_eq_top_of_card_eq_finrank' (by
      rw [finrank_euclideanSpace])).ge

/-- The operator replaces one coordinate at a time using the matrix indexed by that factor. -/
def tensorLap (D : ∀ c,Matrix (B c) (B c) ℝ) :
    ProductL2 B →ₗ[ℝ] ProductL2 B where
  toFun f := toLp 2 fun x => ∑ c,∑ y,D c (x c) y * f (Function.update x c y)
  map_add' f g := by
    apply PiLp.ext
    intro x
    simp [Finset.sum_add_distrib,mul_add]
  map_smul' z f := by
    apply PiLp.ext
    intro x
    simp [Finset.mul_sum,mul_left_comm]

theorem tensorLap_eigen (D : ∀ c,Matrix (B c) (B c) ℝ)
    (v : ∀ c,OrthonormalBasis (B c) ℝ (EuclideanSpace ℝ (B c))) (ξ : ∀ c,B c→ℝ)
    (heig : ∀ c i,D c *ᵥ (v c i : B c→ℝ) = ξ c i • (v c i : B c→ℝ))
    (a : ∀ c,B c) :
    tensorLap D (prodBasis v a)=(∑ c,ξ c (a c)) • prodBasis v a := by
  classical
  simp only [prodBasis, OrthonormalBasis.coe_mk]
  ext x
  change (∑ c,∑ y,D c (x c) y * ∏ j, v j (a j) (Function.update x c y j)) =
    (∑ c,ξ c (a c)) * ∏ j,v j (a j) (x j)
  rw [Finset.sum_mul]
  apply Finset.sum_congr rfl
  intro c _
  let rest := ∏ j ∈ Finset.univ.erase c, v j (a j) (x j)
  have cut (y : B c) : (∏ j,v j (a j) (Function.update x c y j)) =
        v c (a c) y * rest := by
    rw [←Finset.mul_prod_erase _ _ (Finset.mem_univ c),Function.update_self]
    congr 1
    exact Finset.prod_congr rfl fun j hj => by rw [Function.update_of_ne (Finset.mem_erase.mp hj).1]
  have full : (∏ j,v j (a j) (x j)) = v c (a c) (x c) * rest :=
    (Finset.mul_prod_erase _ _ (Finset.mem_univ c)).symm
  simp_rw [cut,← mul_assoc]
  rw [← Finset.sum_mul, full, ← mul_assoc]
  exact congrArg (fun u : ℝ => u*rest) (congrFun (heig c (a c)) (x c))

#print axioms prodBasis
#print axioms tensorLap_eigen
end UnigraphTrace
