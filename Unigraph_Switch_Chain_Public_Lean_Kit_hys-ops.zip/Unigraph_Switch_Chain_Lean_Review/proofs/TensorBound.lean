import TensorBasis
import LiftMatrix
open scoped BigOperators Matrix RealInnerProductSpace
noncomputable section
namespace UnigraphTrace
variable {X C : Type*} [Fintype X] [DecidableEq X] [Fintype C] [DecidableEq C]
variable {B : C → Type*} [∀ c,Fintype (B c)] [∀ c,DecidableEq (B c)]

/-- Ready-to-use input: a scaled orbit lift, each actual factor matrix, and
zero/gap/eigenvector data per factor. The product eigenbasis is constructed here. -/
theorem tensor_row_bound {P : Matrix X X ℝ} (hP : P.PosSemidef) (hr : ∀ x,∑ y,P x y=1)
    (transitive : ∀ x y,∃ e : Equiv.Perm X,e x=y ∧ ∀ a b,P (e a) (e b)=P a b)
    (D : ∀ c,Matrix (B c) (B c) ℝ) (m : C → ℝ)
    (modes : ∀ c, ∃ (b : OrthonormalBasis (B c) ℝ (EuclideanSpace ℝ (B c)))
      (ξ : B c → ℝ) (zero : B c), ξ zero=0 ∧
        (∀ a,a ≠ zero → m c ≤ ξ a) ∧ (∀ i,D c *ᵥ (b i : B c→ℝ)=ξ i • (b i : B c→ℝ)))
    (T : EuclideanSpace ℝ X →ₗᵢ[ℝ] ProductL2 B) {Q : ℝ} (hQ : 0<Q)
    (hform : ∀ x, ⟪T x,tensorLap D (T x)⟫ ≤ 2*Q*(‖x‖^2-⟪x,P.toEuclideanLin x⟫))
    (t : ℕ) (x : X) :
    4*(rowTV P t x)^2 ≤
      (∏ c,(1+((Fintype.card (B c):ℝ)-1)*Real.exp (-(t:ℝ)/Q*m c)))-1 := by
  choose b ξ zero hzero hgap heig using modes
  exact product_row_bound hP hr transitive T (tensorLap D) (prodBasis b) ξ
    (tensorLap_eigen D b ξ heig) hQ hform zero m hzero hgap t x

#print axioms tensor_row_bound
end UnigraphTrace
