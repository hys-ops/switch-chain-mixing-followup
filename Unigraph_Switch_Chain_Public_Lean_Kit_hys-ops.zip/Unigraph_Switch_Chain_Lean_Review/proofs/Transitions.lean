import Identify
import CubeWalk
import OAI.Probability.SwitchChain.KernelNormalization

namespace LayeredLower
open OAI.Problem315 Finset
noncomputable section
attribute [local instance] Classical.propDecidable
variable {k : ℕ}

def block (i : Fin k) : Finset (V k) := {pt i false false,pt i false true,pt i true false,pt i true true}
lemma mem_block (i j : Fin k) (s b : Bool) : pt j s b ∈ block i ↔ j=i := by
  cases s <;> cases b <;> simp [block]
lemma block_card (i : Fin k) : (block i).card=4 := by simp [block]

lemma old_edge_changes (x y : Bits k) (i : Fin k) (h : x i ≠ y i) (s b : Bool) :
    ¬ (graph y).Adj (pt i s b) (mate x (pt i s b)) := by
  rw [graph_adj]
  rintro (ha|hb)
  · have hz := mate_weights x (pt i s b); exact (ne_of_gt ha.2) hz
  · simp only [mate_pt,pt_eq] at hb
    exact h (by simpa using hb.2.2)

lemma support_eq_block {x y : Bits k} {p : SwitchProposal (4*k)}
    (hv : validSwitch (graph x) p) (hr : proposalResult (graph x) p = graph y)
    (i : Fin k) (hi : x i ≠ y i) : p.1.val=block i := by
  apply Eq.symm; apply eq_of_subset_of_card_le _ (by rw [p.1.property,block_card])
  intro v hvb
  obtain ⟨j,s,b,rfl⟩ := vertex_cases v
  have hji := (mem_block i j s b).mp hvb; subst j
  apply ((p.2.val.1.property).mem_iff_exists_adj _).mpr
  refine ⟨mate x (pt i s b),(removedMatching_adj_iff hv _ _).mpr ⟨Or.inr rfl,?_⟩⟩
  rw [hr]; exact old_edge_changes x y _ hi s b

lemma flip_of_change {x y : Bits k} {p : SwitchProposal (4*k)}
    (hv : validSwitch (graph x) p) (hr : proposalResult (graph x) p = graph y)
    (i : Fin k) (hi : x i≠y i) : y=CubeLower.flip i x := by
  have hs := support_eq_block hv hr i hi
  funext j; by_cases he : j=i
  · subst j; simp only [CubeLower.flip]
    cases h : x i <;> cases h' : y i <;> simp_all
  · simp only [CubeLower.flip,ite_eq_right he]; by_contra h
    have hs' := support_eq_block hv hr j (Ne.symm h)
    have hm : pt j false false ∈ block i := by rw [← hs,hs']; simp [mem_block]
    exact he ((mem_block _ _ _ _).mp hm)

lemma cross_adj (x : Bits k) (i : Fin k) (b c : Bool) :
    (graph x).Adj (pt i true b) (pt i false c) ↔ c=(b ^^ x i) := by
  rw [graph_adj,mate_pt,pt_eq]; simp [Back]

lemma four_in_block (x : Bits k) (i : Fin k) :
    FourDistinct (pt i true false) (pt i false (x i)) (pt i false (!(x i))) (pt i true true) := by
  cases h : x i <;> simp [FourDistinct]

/-- The published four-vertex proposal switches exactly the requested matching. -/
theorem step_flip (x : Bits k) (i : Fin k) :
    SwitchStep (4*k) (deg k) (state x) (state (CubeLower.flip i x)) := by
  let a:=pt i true false; let b:=pt i false (x i)
  let c:=pt i false (!(x i));let d:=pt i true true
  have h : FourDistinct a b c d := four_in_block x i
  let p := fourVertexProposal a b c d h
  have h₁ : (graph x).Adj a b := (cross_adj _ _ _ _).2 (by simp)
  have h₂ : (graph x).Adj c d := (graph x).symm.symm _ _ ((cross_adj _ _ _ _).2 (by simp))
  have h₃ : ¬(graph x).Adj a c := by
    change ¬ (graph x).Adj (pt i true false) (pt i false (!(x i))); rw [cross_adj]; cases x i <;> decide
  have h₄ : ¬(graph x).Adj b d := by
    rw [(graph x).adj_comm]; change ¬(graph x).Adj (pt i true true) (pt i false (x i))
    rw [cross_adj]; cases x i <;> decide
  have hv : validSwitch (graph x) p := (validSwitch_fourVertexProposal_iff _ _ _ _ _ _).2 ⟨h₁,h₂,h₃,h₄⟩
  let y := decode (proposalState (state x) p)
  have hr : proposalResult (graph x) p = graph y := congrArg Subtype.val (state_decode (proposalState (state x) p)).symm
  have hrm : (removedMatching p).Adj a b := (removedMatching_fourVertexProposal _ _ _ _ _ _ _).mpr (Or.inl ⟨rfl,rfl⟩)
  have hn := ((removedMatching_adj_iff hv a b).mp hrm).2
  rw [hr] at hn
  have hc : x i≠y i := by intro hh; exact hn ((cross_adj _ _ _ _).2 (by simpa [b] using hh))
  have hy:=flip_of_change hv hr i hc
  exact ⟨p,hv,hr.trans (congrArg graph hy)⟩

theorem step_iff (x y : Bits k) :
    SwitchStep (4*k) (deg k) (state x) (state y) ↔ ∃ i,y=CubeLower.flip i x := by
  constructor
  · rintro ⟨p,hv,hr⟩
    have hne : x≠y := by
      intro he; subst y; exact (proposalResult_ne_of_validSwitch hv) hr
    obtain ⟨i,hi⟩ := Function.ne_iff.mp hne
    exact ⟨i,flip_of_change hv hr i hi⟩
  · rintro ⟨i,rfl⟩; exact step_flip _ _

noncomputable def Q (k : ℕ) : ℝ := 12*(Nat.choose (4*k) 4 : ℝ)

/-- The exact published transition probability for every pair of distinct graph states. -/
theorem off_diagonal (x y : Bits k) (h : x≠y) :
   switchKernel (4*k) (deg k) (state x) (state y) = if (∃ i, y=CubeLower.flip i x) then 1/Q k else 0 := by
  have hxy : state x≠state y := fun he => h ((stateEquiv k).injective he)
  rw [switchKernel_of_ne hxy,step_iff]; by_cases hh : ∃ i, y=CubeLower.flip i x <;> simp [hh,Q]

#print axioms off_diagonal
end
end LayeredLower
