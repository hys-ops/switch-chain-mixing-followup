import UnigraphWorst
import PaddedExact
import ClosedLower
import ActualLower
import Degrees
import PermutationAttainment
import Lean.Util.FoldConsts
open Lean

namespace UnigraphReviewAudit

/-- Only project modules may refer to the audited declarations. Imported
third-party packages are earlier in Lean's immutable module order. -/
private def project (env : Environment) (n : Name) : Bool := Id.run do
  let some index := env.getModuleIdxFor? n | return false
  let m := env.allImportedModuleNames[index.toNat]!
  let root := (m.toString.splitOn ".").head!
  return !(["Init","Lean","Mathlib","Std","Aesop","Batteries","Qq","Plausible",
    "ProofWidgets","LeanSearchClient","ImportGraph","Lake","Cli"].contains root)

private partial def closure (env : Environment) (pending : List Name) (seen : NameSet) : NameSet :=
  match pending with
  | [] => seen
  | n :: rest =>
    if seen.contains n || !project env n then closure env rest seen
    else
      let more := (env.find? n).map (fun d => d.getUsedConstantsAsSet.toList) |>.getD []
      closure env (more ++ rest) (seen.insert n)

run_cmd
  let env ← getEnv
  let old := [`OAI.Problem315.switch_chain_main,`OAI.Problem315.switch_chain_tv_bound,
    `OAI.Problem315.VerifiedSwitch.switch_mixing, `OAI.Problem315.VerifiedSwitch.switch_tv]
  let upper := [`OAI.Problem315.UnigraphUpper.labelSwitch_comparison,
    `OAI.Problem315.UnigraphUpper.switchKernel_labelEquiv,
    `OAI.Problem315.UnigraphUpper.product_graphP_energy, `UnigraphPermutation.eigen_gap,
    `UnigraphPermutation.zero_iff_constant,`UnigraphModes.permutation_row_bound,
    `UnigraphTrace.rowTV_trace,`UnigraphTrace.weighted_trace]
  let lower := [`LayeredLower.forced_adjacency, `LayeredLower.stateEquiv,
    `LayeredLower.Padding.step_iff_flip, `LayeredLower.Padding.operator_equiv,
    `CubeLower.Upstream.mixedAt_bound, `LayeredLower.AllClock.lower_clock]
  for (target,includeSet,excludeSet) in [
    (`OAI.Problem315.UnigraphUpper.unigraph_product_bound,upper,old),
    (`OAI.Problem315.UnigraphUpper.unigraph_mixing_upper,upper,old),
    (`LayeredLower.Padding.all_n_mixingTime,lower,old),
    (`LayeredLower.Padding.finite_mixingTime_bounds,upper++[
      `LayeredLower.Padding.operator_equiv,`CubeLower.Upstream.mixedAt_bound],old),
    (`UnigraphWorst.worst_theta,upper++lower++[`LayeredLower.Padding.family_unigraphic,
      `UnigraphWorst.worst,`OAI.Problem315.UnigraphUpper.unigraph_mixing_upper],old)] do
    let used := closure env [target] {}
    logInfo m!"audited {target}; project declarations {used.toList.length}"
    for n in includeSet do
      unless used.contains n do throwError "required dependency missing {n}"
      logInfo m!"uses {n}"
    for n in excludeSet do
      unless (env.find? n).isSome do throwError "audit target is unknown {n}"
      if used.contains n then throwError "unexpected dependency {n}"
      logInfo m!"bypasses {n}"

#check @OAI.Problem315.UnigraphUpper.unigraph_product_bound
#check @OAI.Problem315.UnigraphUpper.unigraph_mixing_upper
#check @LayeredLower.Padding.family_hold
#check @LayeredLower.Padding.family_flip
#check @LayeredLower.Padding.family_off_diagonal
#check @LayeredLower.Padding.finite_mixingTime_bounds
#check @LayeredLower.Padding.all_n_mixingTime
#check @UnigraphWorst.worst_bounds
#check @UnigraphWorst.worst_attained
#check @UnigraphWorst.worst_theta
#print axioms UnigraphWorst.worst_theta
end UnigraphReviewAudit
