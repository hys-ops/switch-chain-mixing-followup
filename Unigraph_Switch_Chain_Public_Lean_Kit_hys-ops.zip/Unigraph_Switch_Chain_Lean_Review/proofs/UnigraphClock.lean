import Mathlib.Analysis.SpecialFunctions.Log.Basic
import Mathlib.Data.Nat.Factorial.Basic
import Mathlib.Data.Nat.Choose.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Positivity
import Mathlib.Tactic.Ring

namespace UnigraphClock

/-- A single permutation-class heat trace at the proposed clock. -/
private theorem factor_le {n m : ℕ} {u : ℝ} (hn : 0 < n) (hm : 2 ≤ m)
    (hmn : m ≤ n) (hu : Real.log (3 * (n : ℝ)) ≤ u) :
    1 + ((m.factorial : ℝ) - 1) * Real.exp (-(m : ℝ) * u) ≤
      Real.exp ((m : ℝ) / (9 * n)) := by
  have hn' : 0 < (n : ℝ) := by exact_mod_cast hn
  have hm' : (m : ℝ) ≤ n := by exact_mod_cast hmn
  have h3 : 0 < 3 * (n : ℝ) := by positivity
  have h9 : 0 < 9 * (n : ℝ) := by positivity
  have hf : (m.factorial : ℝ) ≤ (m : ℝ)^m := by exact_mod_cast Nat.factorial_le_pow m
  have hfac : (m.factorial : ℝ) - 1 ≤ (m : ℝ)^m := by linarith
  have hclock : Real.exp (-(m : ℝ) * u) ≤ ((3 * (n : ℝ))⁻¹)^m := by
    calc
      _ ≤ Real.exp ((m : ℝ) * -Real.log (3 * (n : ℝ))) := by
        apply Real.exp_le_exp.mpr
        nlinarith [mul_nonneg (show 0 ≤ (m : ℝ) by positivity) (sub_nonneg.mpr hu)]
      _ = _ := by rw [Real.exp_nat_mul, Real.exp_neg, Real.exp_log h3]
  have hr0 : 0 ≤ (m : ℝ) / (3 * n) := by positivity
  have hr1 : (m : ℝ) / (3 * n) ≤ 1 := (div_le_one h3).mpr (by linarith)
  have hsquare : ((m : ℝ)/(3*n))^2 ≤ (m : ℝ)/(9*n) := by
    field_simp [ne_of_gt hn']
    nlinarith [mul_nonneg (show 0 ≤ (m : ℝ) by positivity) (sub_nonneg.mpr hm')]
  have hterm : ((m.factorial : ℝ) - 1) * Real.exp (-(m : ℝ) * u) ≤ (m : ℝ)/(9*n) := by
    calc
      _ ≤ (m : ℝ)^m * (((3 * (n : ℝ))⁻¹)^m) :=
        mul_le_mul hfac hclock (Real.exp_pos _).le (by positivity)
      _ = ((m : ℝ)/(3*n))^m := by rw [← mul_pow, div_eq_mul_inv]
      _ ≤ ((m : ℝ)/(3*n))^2 := pow_le_pow_of_le_one hr0 hr1 hm
      _ ≤ _ := hsquare
  linarith [Real.add_one_le_exp ((m : ℝ)/(9*n))]

private theorem product_le {n : ℕ} {u : ℝ} (hn : 0 < n)
    (hu : Real.log (3 * (n : ℝ)) ≤ u) (sizes : List ℕ)
    (hm : ∀ m ∈ sizes, 2 ≤ m) (hs : sizes.sum ≤ n) :
    (sizes.map (fun (m : ℕ) => 1 + ((m.factorial : ℝ)-1) * Real.exp (-(m : ℝ)*u))).prod ≤
      Real.exp ((sizes.sum : ℝ)/(9*n)) := by
  induction sizes with
  | nil => simp
  | cons m ms ih =>
    simp only [List.sum_cons] at hs
    have hms : ms.sum ≤ n := by omega
    have hm_le : m ≤ n := by omega
    have hm2 := hm m (by simp)
    have htail := ih (fun a ha => hm a (by simp [ha])) hms
    have hhead := factor_le hn hm2 hm_le hu
    have hhead_pos : 0 ≤ 1 + ((m.factorial : ℝ)-1) * Real.exp (-(m : ℝ)*u) := by
      have hf : (1 : ℝ) ≤ m.factorial := by exact_mod_cast Nat.factorial_pos m
      nlinarith [mul_nonneg (sub_nonneg.mpr hf) (Real.exp_pos (-(m : ℝ)*u)).le]
    simp only [List.map_cons, List.prod_cons, List.sum_cons, Nat.cast_add]
    calc
      _ ≤ (1 + ((m.factorial : ℝ)-1) * Real.exp (-(m : ℝ)*u)) * Real.exp ((ms.sum : ℝ)/(9*n)) :=
        mul_le_mul_of_nonneg_left htail hhead_pos
      _ ≤ Real.exp ((m : ℝ)/(9*n)) * Real.exp ((ms.sum : ℝ)/(9*n)) :=
        mul_le_mul_of_nonneg_right hhead (Real.exp_pos _).le
      _ = _ := by rw [← Real.exp_add, add_div]

/-- For the list of nontrivial equal-degree class sizes, the RHS in (U1) is
strictly below 1/4 at every `t/Q ≥ log(3n)`. The statement is algebraic and
does not assume a graph, or that a separate heat-trace comparison holds. -/
theorem quarter_clock {n : ℕ} (hn : 0 < n) (sizes : List ℕ)
    (hm : ∀ m ∈ sizes, 2 ≤ m) (hs : sizes.sum ≤ n)
    (t Q : ℝ) (hu : Real.log (3 * (n : ℝ)) ≤ t / Q) :
    (sizes.map (fun (m : ℕ) => 1 + ((m.factorial : ℝ)-1) * Real.exp (-(m : ℝ)*(t/Q)))).prod - 1 < 1/4 := by
  have hn' : 0 < (n : ℝ) := by exact_mod_cast hn
  have hs' : (sizes.sum : ℝ) ≤ n := by exact_mod_cast hs
  have hx : (sizes.sum : ℝ)/(9*n) ≤ 1/9 := (div_le_iff₀ (by positivity)).mpr (by linarith)
  have hp := (product_le hn hu sizes hm hs).trans (Real.exp_le_exp.mpr hx)
  have hneg := Real.add_one_le_exp (-(1/9 : ℝ))
  rw [Real.exp_neg] at hneg
  have hnum := (le_div_iff₀ (Real.exp_pos (1/9))).mp (by simpa only [one_div] using hneg : -(1/9 : ℝ) + 1 ≤ 1/Real.exp (1/9))
  linarith

/-- The natural-time endpoint for Q = 12 * n.choose 4. The argument named
`hU1` is the exact remaining mathematical input: a bound by the heat product.
In particular this theorem does not assert `hU1` for the graph walk. -/
theorem quarter_tv_of_U1 {n : ℕ} (hn : 4 ≤ n) (sizes : List ℕ)
    (hm : ∀ m ∈ sizes, 2 ≤ m) (hs : sizes.sum ≤ n) (t : ℕ)
    (ht : ⌈(12 * (n.choose 4 : ℝ)) * Real.log (3 * (n : ℝ))⌉₊ ≤ t)
    (distance : ℝ)
    (hU1 : 4 * distance^2 ≤ (sizes.map (fun (m : ℕ) =>
      1 + ((m.factorial : ℝ)-1) * Real.exp (-(m : ℝ)*((t : ℝ)/(12*(n.choose 4 : ℝ)))))).prod - 1) :
    distance < 1/4 := by
  have hchoose : 0 < (n.choose 4 : ℝ) := by exact_mod_cast Nat.choose_pos hn
  have hQ : (0 : ℝ) < 12*(n.choose 4 : ℝ) := by positivity
  have hr : (12*(n.choose 4 : ℝ))*Real.log (3*(n : ℝ)) ≤ (t : ℝ) :=
    (Nat.le_ceil _).trans (by exact_mod_cast ht)
  have hclock : Real.log (3*(n : ℝ)) ≤ (t : ℝ)/(12*(n.choose 4 : ℝ)) :=
    (le_div_iff₀ hQ).mpr (by simpa only [mul_comm] using hr)
  have hd := hU1.trans_lt (quarter_clock (by omega : 0 < n) sizes hm hs t (12*(n.choose 4 : ℝ)) hclock)
  by_contra! h
  nlinarith [mul_nonneg (sub_nonneg.mpr h) (show 0 ≤ distance+(1/4 : ℝ) by linarith)]

#print axioms quarter_clock
#print axioms quarter_tv_of_U1
end UnigraphClock
