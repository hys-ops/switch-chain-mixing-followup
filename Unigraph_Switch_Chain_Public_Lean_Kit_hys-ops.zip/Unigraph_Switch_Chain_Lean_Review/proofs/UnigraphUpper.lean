import ProductLift
import PermutationProduct
import Clock

noncomputable section
open scoped BigOperators Matrix RealInnerProductSpace
namespace OAI.Problem315.UnigraphUpper
attribute [local instance] Classical.propDecidable
variable {n : ℕ} {d : Fin n → ℕ}

private theorem clock_pos (hn : 4 ≤ n) : 0 < 12*(n.choose 4 : ℝ) := by
  have hc : (0:ℝ) < n.choose 4 := by exact_mod_cast Nat.choose_pos hn
  positivity

/-- All-time bound for each starting labeled graph of a unigraphic degree sequence.
Singleton degree classes contribute a factor of one. -/
theorem unigraph_product_bound (hn : 4 ≤ n) (hu : IsUnigraphic d)
    (t : ℕ) (G : GraphState n d) :
    4*(tvDistanceFrom n d t G)^2 ≤
      (∏ k : Colors d, (1+(((Fintype.card (Block d k)).factorial : ℝ)-1)*
        Real.exp (-(t:ℝ)/(12*(n.choose 4 : ℝ))*(Fintype.card (Block d k):ℝ))))-1 := by
  rw [← rowTV_eq]
  exact UnigraphModes.permutation_row_bound (Block d) (graphP_psd hn) (switchKernel_row_sum hn)
    (unigraph_kernel_transitive hu) (productLift hu G) (clock_pos hn)
    (product_graphP_energy hn hu G) t G

theorem unigraph_mixed_clock (hn : 4 ≤ n) (hu : IsUnigraphic d) :
    MixedAt n d ⌈(12*(n.choose 4 : ℝ))*Real.log (3*(n:ℝ))⌉₊ := by
  intro G
  apply UnigraphTrace.quarter_of_product (fun k : Colors d => Fintype.card (Block d k))
    n (by omega) (block_card_sum d).le _ (clock_pos hn) _ (Nat.le_ceil _) _
  exact unigraph_product_bound hn hu _ G

/-- Worst-start TV mixing on OpenAI's original discrete-time label-preserving
simple undirected graph chain at its original threshold 1/4. -/
theorem unigraph_mixing_upper (hn : 4 ≤ n) (hu : IsUnigraphic d) :
    ∃ h : (∃ t : ℕ, MixedAt n d t),
      mixingTime n d h ≤ ⌈(12*(n.choose 4 : ℝ))*Real.log (3*(n:ℝ))⌉₊ :=
  exists_mixingTime_le_of_mixedAt n d _ (unigraph_mixed_clock hn hu)

#print axioms unigraph_product_bound
#print axioms unigraph_mixed_clock
#print axioms unigraph_mixing_upper
end OAI.Problem315.UnigraphUpper
