import WorstAssembly
import UnigraphUpper

namespace UnigraphWorst
open OAI.Problem315 OAI.Problem315.UnigraphUpper Filter Asymptotics

/-- Explicit two-sided scale on the single well-defined worst-case mixing-time function. -/
theorem worst_bounds {n : ℕ} (hn : 65536 ≤ n) :
    (n:ℝ)^4*Real.log n/512 < (worst n:ℝ) ∧
    (worst n:ℝ) ≤ 2*(n:ℝ)^4*Real.log n :=
  assemble_bounds (fun hn hu => unigraph_mixing_upper hn hu) hn

/-- Worst-case quarter-TV mixing among graphical unigraphs is Θ(n⁴ log n). -/
theorem worst_theta :
    (fun n : ℕ => (worst n:ℝ)) =Θ[atTop] (fun n : ℕ => (n:ℝ)^4*Real.log n) :=
  assemble_theta (fun hn hu => unigraph_mixing_upper hn hu)

/-- At every size in the explicit range the maximum belongs to an actual unigraphic degree vector. -/
theorem worst_attained {n : ℕ} (hn : 65536 ≤ n) : ∃ d : Fin n → ℕ,
    Graphical n d ∧ IsUnigraphic d ∧ ∃ h : ∃ t, MixedAt n d t, mixingTime n d h=worst n := by
  have hlog : 0≤Real.log (n:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤n by omega))
  have hscale : 0≤(n:ℝ)^4*Real.log n/512 := by positivity
  exact attained (by exact_mod_cast hscale.trans_lt (worst_bounds hn).1)

#print axioms worst_bounds
#print axioms worst_theta
#print axioms worst_attained
end UnigraphWorst
