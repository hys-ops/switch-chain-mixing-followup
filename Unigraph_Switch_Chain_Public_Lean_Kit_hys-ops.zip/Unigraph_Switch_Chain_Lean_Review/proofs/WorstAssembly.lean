import WorstSetup
namespace UnigraphWorst
open OAI.Problem315 OAI.Problem315.UnigraphUpper Finset Filter Asymptotics
noncomputable section
attribute [local instance] Classical.propDecidable

/-- The only theorem supplied to the assembly is the uniform quarter-TV clock on
unigraphs. The explicit lower family uses the clock merely as its existence witness. -/
def UpperClock : Prop := ∀ {n : ℕ} {d : Fin n → ℕ}, 4≤n → IsUnigraphic d →
    ∃ h : (∃ t,MixedAt n d t), mixingTime n d h ≤ ⌈(12*(n.choose 4 : ℝ))*Real.log (3*(n:ℝ))⌉₊

theorem assemble_bounds (hupper : UpperClock) {n : ℕ} (hn : 65536≤n) :
    (n:ℝ)^4*Real.log n/512 < (worst n:ℝ) ∧ (worst n:ℝ) ≤ 2*(n:ℝ)^4*Real.log n := by
  have hn4 : 4≤n := by omega
  constructor
  · obtain ⟨hw,_⟩ := hupper hn4 (LayeredLower.Padding.family_unigraphic n)
    have hslow := LayeredLower.Padding.all_n_mixingTime hn hw
    exact hslow.trans_le (by exact_mod_cast le_worst (LayeredLower.Padding.family_graphical n) (LayeredLower.Padding.family_unigraphic n) hw)
  · apply le_trans _ (upper_clock hn4)
    apply Nat.cast_le.mpr
    apply worst_le_of_forall
    intro d _ hu hm
    obtain ⟨_,h⟩ := hupper hn4 hu
    exact h

theorem assemble_theta (hupper : UpperClock) :
    (fun n : ℕ => (worst n:ℝ)) =Θ[atTop] (fun n : ℕ => (n:ℝ)^4*Real.log n) := by
  constructor
  · apply isBigO_iff.mpr; refine ⟨2,?_⟩
    filter_upwards [eventually_ge_atTop 65536] with n hn
    have hpos : 0≤Real.log (n:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤n by omega))
    have hw : (0:ℝ)≤worst n := Nat.cast_nonneg _
    have hb : 0≤(n:ℝ)^4*Real.log n := by positivity
    change ‖(worst n:ℝ)‖ ≤ 2*‖(n:ℝ)^4*Real.log n‖
    simpa only [Real.norm_eq_abs,abs_of_nonneg hw,abs_of_nonneg hb,mul_assoc] using ((assemble_bounds hupper hn).2)
  · apply isBigO_iff.mpr; refine ⟨512,?_⟩
    filter_upwards [eventually_ge_atTop 65536] with n hn
    have hpos : 0≤Real.log (n:ℝ) := Real.log_nonneg (by exact_mod_cast (show 1≤n by omega))
    have hw : (0:ℝ)≤worst n := Nat.cast_nonneg _
    have hb : 0≤(n:ℝ)^4*Real.log n := by positivity
    change ‖(n:ℝ)^4*Real.log n‖ ≤ 512*‖(worst n:ℝ)‖
    simp only [Real.norm_eq_abs,abs_of_nonneg hw,abs_of_nonneg hb]
    linarith [(assemble_bounds hupper hn).1]

/-- Once the maximum is positive, an actual graphical unigraph attaining it exists. -/
theorem attained {n : ℕ} (hn : 0<worst n) : ∃ d : Fin n → ℕ,
  Graphical n d ∧ IsUnigraphic d ∧ ∃ h : ∃ t,MixedAt n d t, mixingTime n d h = worst n := by
  have hm := Finset.sup_mem_of_nonempty (f:=score (n:=n)) (s:=univ) univ_nonempty
  obtain ⟨c,_,he⟩ := hm
  by_cases hc : Graphical n (degrees c) ∧ IsUnigraphic (degrees c) ∧ ∃ t,MixedAt n (degrees c) t
  · refine ⟨degrees c,hc.1,hc.2.1,hc.2.2,?_⟩
    simpa [score,hc,worst] using he
  · have : worst n=0 := by simpa [score,hc,worst] using he.symm
    omega

#print axioms assemble_bounds
#print axioms assemble_theta
end
end UnigraphWorst
