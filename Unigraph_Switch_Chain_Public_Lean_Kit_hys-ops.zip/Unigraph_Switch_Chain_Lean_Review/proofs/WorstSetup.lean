import PaddedLower
import Mathlib.Analysis.Asymptotics.Theta
import Mathlib.Analysis.Complex.ExponentialBounds

namespace UnigraphWorst
open OAI.Problem315 OAI.Problem315.UnigraphUpper Finset
noncomputable section
attribute [local instance] Classical.propDecidable

/-- All labeled degree vectors with entries at most n. The endpoint n safely
includes all possible degrees even at size zero. Nongraphical codes contribute zero. -/
abbrev Code (n : ℕ) := Fin n → Fin (n+1)

def degrees {n : ℕ} (c : Code n) : Fin n → ℕ := fun v => c v

def score {n : ℕ} (c : Code n) : ℕ :=
  if h : Graphical n (degrees c) ∧ IsUnigraphic (degrees c) ∧ ∃ t, MixedAt n (degrees c) t
  then mixingTime n (degrees c) h.2.2 else 0

/-- The maximum quarter-TV mixing time over graphical unigraphic degree vectors.
The value is zero if there is no such vector with finite mixing time. -/
def worst (n : ℕ) : ℕ := (univ : Finset (Code n)).sup score

lemma encode {n : ℕ} {d : Fin n → ℕ} (hg : Graphical n d) : ∃ c : Code n, degrees c=d := by
  obtain ⟨G⟩ := hg
  have hv (v : Fin n) : d v<n+1 := by
    rw [←G.2 v]; unfold graphDegree
    have h := Finset.card_le_card (filter_subset (G.val.Adj v) univ)
    simpa using Nat.lt_succ_of_le h
  exact ⟨fun v => ⟨d v,hv v⟩,rfl⟩

lemma le_worst {n : ℕ} {d : Fin n → ℕ} (hg : Graphical n d) (hu : IsUnigraphic d)
    (hm : ∃ t,MixedAt n d t) : mixingTime n d hm ≤ worst n := by
  obtain ⟨c,rfl⟩ := encode hg
  have h : Graphical n (degrees c) ∧ IsUnigraphic (degrees c) ∧ ∃ t,MixedAt n (degrees c) t := ⟨hg,hu,hm⟩
  simpa [score,h,worst] using (le_sup (f:=score) (mem_univ c))

lemma worst_le_of_forall {n B : ℕ}
    (h : ∀ d : Fin n → ℕ, Graphical n d → IsUnigraphic d →
         ∀ hm : (∃ t,MixedAt n d t), mixingTime n d hm ≤ B) : worst n ≤ B := by
  apply Finset.sup_le; intro c _; unfold score
  split_ifs with hh
  · exact h (degrees c) hh.1 hh.2.1 hh.2.2
  · omega

lemma upper_clock {n : ℕ} (hn : 4≤n) :
    (⌈(12*(n.choose 4:ℝ))*Real.log (3*(n:ℝ))⌉₊ : ℝ) ≤ 2*(n:ℝ)^4*Real.log n := by
  have hn' : (4:ℝ)≤n := by exact_mod_cast hn
  have hlog : 1 ≤ Real.log (n:ℝ) := (Real.le_log_iff_exp_le (by linarith)).2
    (Real.exp_one_lt_three.le.trans (by linarith))
  have h3 : Real.log 3 ≤ Real.log (n:ℝ) := Real.log_le_log (by norm_num) (by linarith)
  have hl : Real.log (3*(n:ℝ)) ≤ 2*Real.log n := by
    rw [Real.log_mul (by norm_num) (by positivity : (n:ℝ)≠0)]; linarith
  have hc := Nat.choose_le_pow_div (α:=ℝ) 4 n
  norm_num [Nat.factorial] at hc
  have hQ : 12*(n.choose 4:ℝ) ≤ (n:ℝ)^4/2 := by linarith
  have hpos : 0≤Real.log (3*(n:ℝ)) := Real.log_nonneg (by linarith)
  have hprod := mul_le_mul hQ hl hpos (by positivity)
  have hn4 : (1:ℝ) ≤ (n:ℝ)^4 := one_le_pow₀ (by linarith)
  have hbig : (1:ℝ) ≤ (n:ℝ)^4*Real.log n := one_le_mul_of_one_le_of_one_le hn4 hlog
  have hceil := Nat.ceil_lt_add_one (show 0≤12*(n.choose 4:ℝ)*Real.log (3*(n:ℝ)) by positivity)
  nlinarith

private lemma lower_witness {n : ℕ} (hn : 65536 ≤ n) : ∃ t,MixedAt n (LayeredLower.Padding.family n) t := by
  have hg := LayeredLower.Padding.family_graphical n
  obtain ⟨G⟩ := hg
  have hv (v : Fin n) : LayeredLower.Padding.family n v ≤ n-1 := by
    rw [←G.2 v]; unfold graphDegree
    have hs : univ.filter (G.val.Adj v) ⊆ univ.erase v := by
      intro j hj; refine mem_erase.mpr ⟨?_,mem_univ _⟩
      intro hh; subst j; exact G.val.loopless.irrefl v (mem_filter.mp hj).2
    simpa using card_le_card hs
  exact ((switch_chain_main n _ (by omega) hv ⟨G⟩).1).choose

/-- A concrete unigraph at every sufficiently large n attains the lower scale. -/
theorem lower {n : ℕ} (hn : 65536≤n) : (n:ℝ)^4*Real.log n/512 < (worst n:ℝ) := by
  let h := lower_witness hn
  have hlo := LayeredLower.Padding.all_n_mixingTime hn h
  exact hlo.trans_le (by exact_mod_cast le_worst (LayeredLower.Padding.family_graphical n) (LayeredLower.Padding.family_unigraphic n) h)

#print axioms lower
end
end UnigraphWorst
