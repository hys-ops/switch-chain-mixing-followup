#!/usr/bin/env python3
"""Rebuild the checked theorem closure in an isolated directory; only pinned external libraries are used."""
import argparse
from concurrent.futures import FIRST_COMPLETED, ThreadPoolExecutor, wait
from hashlib import sha1, sha256
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
DEPS = ROOT / "dependencies"
CONFIG = DEPS / "config"
IMPORT = re.compile(r"^import\s+([\w.]+)\s*$", re.M)
AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
PRINTED = re.compile(r"'([^']+)' depends on axioms: \[([^\]]*)\]")
def digest(data):
    return sha256(data).hexdigest()
def check(ok, message):
    if not ok:
        raise RuntimeError(str(message))
def paths(module):
    return Path(*module.split(".")).with_suffix(".lean")
def record(path, obj):
    path.write_text(json.dumps(obj,indent=2,sort_keys=True)+"\n")

def sources(native):
    locked=json.loads((CONFIG/"source-lock.json").read_text())
    check(len(locked)==165, "incorrect upstream lock")
    modules={}
    header="".join("import "+name+"\n" for name in (CONFIG/"focused-imports.txt").read_text().splitlines())
    if not native:
        modules["GraphMathlibImports"]=header
    for name, hashes in locked.items():
        data=(DEPS/"upstream"/name).read_bytes()
        check(digest(data)==hashes["sha256"] and sha1(b"blob %d\0"%len(data)+data).hexdigest()==hashes["git_blob"], name)
        txt=data.decode()
        modules[name[:-5].replace("/",".")]=txt if native else txt.replace("import Mathlib\n","import GraphMathlibImports\n")
    for directory in [DEPS/"row-fiber",ROOT/"proofs"]:
        for path in sorted(directory.glob("*.lean")):
            check(path.stem not in modules, path)
            modules[path.stem]=path.read_text()
    for name,txt in modules.items():
        check(not re.search(r"\b(?:sorry|admit|sorryAx|axiom)\b",txt),name+" placeholder/axiom token")
        for dep in IMPORT.findall(txt):
            check(dep in modules or dep.startswith(("Mathlib","Lean","Std","Init")),name+" missing "+dep)
    return modules

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean",required=True,type=Path)
    parser.add_argument("--packages",required=True,type=Path)
    parser.add_argument("--build",required=True,type=Path)
    parser.add_argument("--jobs",type=int,default=2)
    parser.add_argument("--native",action="store_true",help="retain the broad upstream Mathlib import")
    parser.add_argument("--resume",action="store_true",help="reuse only previous objects whose source, log, bytes and recursive dependencies still match")
    args=parser.parse_args()
    modules=sources(args.native)
    work=args.build.resolve()
    if not args.resume: check(not work.exists() or not any(work.iterdir()),"choose a fresh directory or --resume")
    src,out,logs=[work/d for d in ("src","out","logs")]
    for path in (src,out,logs): path.mkdir(parents=True,exist_ok=True)
    ext=[]
    manifest=json.loads((CONFIG/"lake-manifest.json").read_text())
    for spec in manifest["packages"]:
        repo=args.packages.resolve()/spec["name"]
        rev=subprocess.check_output(["git","-C",str(repo),"rev-parse","HEAD"],text=True).strip()
        check(rev==spec["rev"],str(repo)+" revision")
        lib=repo/".lake/build/lib/lean"
        if lib.is_dir():
            check(all(not (lib/paths(m).with_suffix(".olean")).exists() for m in modules),str(lib)+" shadows project")
            ext.append(lib)
    lean=args.lean.resolve()
    env=dict(os.environ,LEAN_PATH=os.pathsep.join(map(str,[out,*ext])),LEAN_NUM_THREADS="1")
    version=subprocess.check_output([str(lean),"--version"],env=env,text=True).strip()
    check("version 4.34.1," in version and "5045d0056413266e57c625dcd7c365b10e377c52" in version,version)
    prior=work/"progress.json"
    old=json.loads(prior.read_text()).get("modules",{}) if args.resume and prior.exists() else {}
    options=["-j1","-DElab.async=false","-DautoImplicit=false"]
    receipt={"lean":version,"upstream":"4eaee87548250b2682affda7d05d947c05554bae","mode":"native" if args.native else "named","options":options,"modules":{}}
    rows=receipt["modules"]
    dep={m:sorted(set(IMPORT.findall(txt)) & modules.keys()) for m,txt in modules.items()}
    def build(m):
        data=modules[m].encode()
        p=paths(m)
        obj=(out/p).with_suffix(".olean")
        log=logs/(m+".log")
        key=digest(json.dumps([version,options,digest(data),[(d,rows[d]["key"],rows[d]["object"]) for d in dep[m]]],sort_keys=True).encode())
        prev=old.get(m,{})
        if key==prev.get("key") and obj.exists() and log.exists() and digest(obj.read_bytes())==prev["object"] and digest(log.read_bytes())==prev["log"]:
            return prev
        begin=time.monotonic()
        (src/p).parent.mkdir(parents=True,exist_ok=True)
        (src/p).write_bytes(data)
        obj.parent.mkdir(parents=True,exist_ok=True)
        run=subprocess.run([str(lean),*options,"-o",str(obj),str(p)],cwd=src,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        log.write_bytes(run.stdout)
        check(run.returncode==0 and obj.exists() and b"sorryAx" not in run.stdout and b"uses 'sorry'" not in run.stdout,m+" failed:\n"+run.stdout.decode()[-2200:])
        reports=dict(PRINTED.findall(run.stdout.decode()))
        for target,values in reports.items():
            check({v.strip() for v in values.split(",")}<=AXIOMS,target+" unexpected axiom "+values)
        return {"exit":run.returncode,"source":digest(data),"object":digest(obj.read_bytes()),"log":digest(run.stdout),"seconds":round(time.monotonic()-begin,3),"imports":dep[m],"key":key,"printed_axioms":reports}
    pending=set(modules)
    live={}
    check(args.jobs>0,"--jobs must be positive")
    with ThreadPoolExecutor(args.jobs) as pool:
        while pending or live:
            ready=sorted(m for m in pending if set(dep[m])<=rows.keys())
            for m in ready[:args.jobs-len(live)]:
                pending.remove(m)
                live[pool.submit(build,m)]=m
            check(live,"import cycle")
            done,_=wait(live,return_when=FIRST_COMPLETED)
            for fut in done:
                m=live.pop(fut)
                rows[m]=fut.result()
                print(f"{len(rows)}/{len(modules)} {m}",flush=True)
                record(prior,receipt)
    check(len(rows)==len(modules),"incomplete")
    record(work/"receipt.json",receipt)
if __name__=="__main__":
    main()
