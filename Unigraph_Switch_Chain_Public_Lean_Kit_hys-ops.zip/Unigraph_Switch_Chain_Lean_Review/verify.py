#!/usr/bin/env python3
"""Check retained source and log hashes, axiom reports and required dependency receipts."""
from pathlib import Path
import hashlib
import json
import sys
sys.dont_write_bytecode = True
from replay import ROOT, AXIOMS, PRINTED, check, digest, sources
def main():
    manifest=(ROOT/"SHA256SUMS").read_text().splitlines()
    for line in manifest:
        sha,rel=line.split("  ",1)
        check(digest((ROOT/rel).read_bytes())==sha,rel)
    result=json.loads((ROOT/"checks/receipt.json").read_text())
    modules=sources(False)
    check(set(modules)==set(result["modules"]),"module inventory mismatch")
    ax={}
    for key,mod in result["modules"].items():
        check(mod["exit"]==0 and digest(modules[key].encode())==mod["source"],key)
        data=(ROOT/"checks/logs"/(key+".log")).read_bytes()
        check(digest(data)==mod["log"],key+" log digest")
        check(b"sorryAx" not in data and b"error:" not in data,key)
        printed=dict(PRINTED.findall(data.decode()))
        check(printed==mod["printed_axioms"],key+" axiom receipt")
        for name,values in printed.items():
            check({v.strip() for v in values.split(",")}<=AXIOMS,name)
        ax.update(printed)
    for target in ["OAI.Problem315.UnigraphUpper.unigraph_product_bound","OAI.Problem315.UnigraphUpper.unigraph_mixing_upper","LayeredLower.Padding.finite_mixingTime_bounds","UnigraphWorst.worst_bounds","UnigraphWorst.worst_theta","UnigraphWorst.worst_attained"]:
        check({v.strip() for v in ax[target].split(",")}==AXIOMS,target)
    log=(ROOT/"checks/logs/UnigraphAudit.log").read_text()
    for target in ["OAI.Problem315.UnigraphUpper.unigraph_product_bound","UnigraphWorst.worst_theta","LayeredLower.Padding.finite_mixingTime_bounds"]:
        check("audited "+target+";" in log,target+" dependency receipt")
    cases=json.loads((ROOT/"checks/checks.json").read_text())
    check((cases["total_states"],cases["total_ordered_proposals"])==(72,364704),"enumeration counts")
    print(f"PASS: {len(modules)} source and compiler logs, {len(ax)} unique printed axiom reports, validated original source lock and audited endpoint dependency receipts")
if __name__=="__main__":
    main()
